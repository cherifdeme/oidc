# Application blanche - Back For Front Spring Boot

Ce projet contient les sources Back For Front Spring Boot de l'application blanche de la filière IHM Light

## Wiki
Un wiki d'explication de la filière est présent à cette endroit: [Wiki IHM Light](https://ttp10-pord.ca-technologies.fr/xwiki/bin/view/Filieres%20de%20developpement/Frontend/IHM%20Light/)

## Releases
### 3.1.12
* Montée version Feign
* Suppression utilisation des headers  CATS
* Ajout clé publique AUC9

### 3.1.11
* Montée de version Spring Boot 2.7.2

### 3.1.10
* Ajout des probes (healthcheck, liveness, readiness) avec Spring Actuactor
* Suppression du Redis Cluster Node
* Modification des url d'appel d'API en "catech.group.gca"
* Mise à jour de l'image alpine3-aojdk11

### 3.1.9
* Ajout de l'accès au dossier nexus
* Activation du CsrfFilter pour les logs
* Montée de version Spring Boot 2.7.0, et des dépendances
* Suppression Autowired
* Ajout d'interfaces

### 3.1.8

* Montée de version Spring Boot 2.6.6
* Montée de version image alpine3-aojdk11
* allow origine : fix prise en compte liste
* pom : ménage
* test : fix test sur log

### 3.1.7

* Montée de version Spring Boot 2.6.4
* Desactivation CSRF de Spring Security et ajout d'un CsrfFilter (nécessaire si IHM Light intégrée dans le PUC ou NPC)

### 3.1.6

* Montée de version Spring Boot 2.6.3
* Utilisation logback comme logger
* Feign Retry
* Spring session : suppression utilisation Mode PUB/SUB
* Utilisation de Redis Sentinel

### 3.1.5

* Montée de version Spring Boot 2.5.7
* Mise en place Spring security
	* Sécurisation des accès aux API
	* Injection Csrf
	* Gestion CORS
* Gestion globale des erreurs

### 3.1.4

* Montée de version Spring Boot 2.5.6
* Utilisation paramètre "domaine pattern" pour spécification du domaine du cookie SESSION_ID
* Gestion du canal INTER / INTRA
* Gestion d'appel BDD
	* DAO MyBatis
	* Spring data JPA
* Correction de violation sonar
* Correction de violation X Ray

### 3.1.1

* Montée de version Spring Boot 2.5.5
* Ajout du pattern CircuitBreaker avec Reslience4J
* Ajout de la cinématique Back Channel Logout


### 3.1.0

* Ajout de la validation de l'ID Token avec la clé publique
* Amélioration de la vérification CSRF lors du login
* Utilisation Feign pour les appels aux API
* Ajout de la validation des champs en entrée des requêtes (spring validator)
* Montée de version Spring Boot 2.5.1
* Mise à jour de certaines librairies


### 3.0.6

* Ajout filtre CsrfFilter pour la protection contre les attaques Csrf
* Ajout Swagger

### 3.0.5

* Initialisation du read me du projet
* Contient la démonstration des patterns
    * Connexion à une application
    * Déconnexion d'une application
    * Persistance de session
    * Appel d'API
    * Transfert de contexte
    * Traçabilité et log
	* Metriques
* Tests
	* Unitaires
	* Intégration
* Règles Sonar
