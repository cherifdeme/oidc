package fr.ca.cat.ihml.oidc.bff;

import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.services.logs.ApplicationLogger;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.ImportAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationFailedEvent;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.cloud.openfeign.FeignAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.EnableScheduling;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;

/**
 * Classe principale de configuration de l'application
 *
 */
@SpringBootApplication
@EnableScheduling
@EnableFeignClients
@ImportAutoConfiguration({FeignAutoConfiguration.class})
public class Application {	
    
    /**
     * Déclaration du logger de la classe
     */
    private static ApplicationLogger appLogger = ApplicationLogger.getLogger(Application.class);

    public static void main(String[] args) {
        SpringApplication.run(Application.class);
    }
	
    @EventListener(ApplicationReadyEvent.class)
    public void handleApplicationReadyEvent() {
    	appLogger.initLog()
    	.level(LogLevel.INFO)
    	.message("Application démarrée")
    	.eventTyp(Constants.LOGS_EVT_TYPE_APP_LIFECYCLE)
    	.eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTED)
    	.log();
    }
    
    @EventListener(ApplicationFailedEvent.class)
    public void handleApplicationFailedEvent() {
    	appLogger.initLog()
    	.level(LogLevel.INFO)
    	.message("Démmarage de l'application en erreur")
    	.eventTyp(Constants.LOGS_EVT_TYPE_APP_LIFECYCLE)
    	.eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
    	.log();
    }
    
    @Bean
    public OpenAPI customOpenAPI(@Value("${app.framework}") String appDesciption, @Value("${app.version}") String appVersion) {
     return new OpenAPI()
          .info(new Info()
          .title("Application blanche IHM Light - Spring Boot")
          .version(appVersion)
          .description(appDesciption)
          .termsOfService("http://swagger.io/terms/")
          .license(new License().name("Apache 2.0").url("http://springdoc.org")));
    }

}