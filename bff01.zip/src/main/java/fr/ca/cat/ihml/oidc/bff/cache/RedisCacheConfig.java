package fr.ca.cat.ihml.oidc.bff.cache;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;

import fr.ca.cat.ihml.oidc.bff.models.logs.LogClientConfiguration;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.models.security.tokens.RefreshToken;
import fr.ca.cat.ihml.oidc.bff.services.logs.ApplicationLogger;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;
import org.springframework.session.web.context.AbstractHttpSessionApplicationInitializer;

/**
 * Classe pour configurer l'utilisation de spring session avec REDIS. Elle
 * déclare aussi le cache REDIS pour le stockage des refresh token
 * 
 * @author ET02720
 *
 */
@Configuration
@EnableCaching
public class RedisCacheConfig extends AbstractHttpSessionApplicationInitializer {
	
    /**
     * Déclaration du logger de la classe
     */
    private static ApplicationLogger appLogger = ApplicationLogger.getLogger(RedisCacheConfig.class);

    /**
     * Injection de TTL pour la cache des refresh token
     * Default Value Lax
     */
    @Value("${redis.cache.prefix}")
    private String redisCachePrefix;    
    
    /**
     * Injection de TTL pour la cache des refresh token
     * Default Value Lax
     */
    @Value("${redis.cache.refresh.token.ttl}")
    private Duration refreshTokenCacheTtl;
    
    /**
     * Injection du SameSite du cookie
     * Default Value Lax
     */
    @Value("${redis.cache.logs.configuration.ttl}")
    private Duration logsConfigurationCacheTtl;

    /**
     * Création du bean permettant la création du cache manager Redis
     * 
     * @param redisConnectionFactory
     * Une factory de connexion au REDIS
     * @return Un cache manager
     * @see {@link CacheManager}
     */
    @Bean
    public CacheManager cacheManager(RedisConnectionFactory redisConnectionFactory) {
        // Creation liste des caches
        Map<String, RedisCacheConfiguration> cacheConfigurations = new HashMap<>();

        // Création configuration par défaut des caches
        var refrehsTokenCacheConfiguration = RedisCacheConfiguration.defaultCacheConfig()
        		.entryTtl(refreshTokenCacheTtl)
        		.prefixCacheNameWith(redisCachePrefix)
        		.serializeValuesWith(RedisSerializationContext.SerializationPair.fromSerializer(new Jackson2JsonRedisSerializer<>(RefreshToken.class)));

        // Ajout du cache pour la gestion des Refresh Token
        cacheConfigurations.put(Constants.REFRESH_TOKEN_CACHE, refrehsTokenCacheConfiguration);
        appLogger.initLog().level(LogLevel.INFO)
        .message("Configuration du cache REDIS pour les refresh Token")
        .eventTyp(Constants.LOGS_EVT_TYPE_CONFIGURATION)
        .eventCod(Constants.LOGS_EVT_CODE_CONFIGURING_REDIS_TOKEN_CACHE)
        .log();
        
        // Ajout du cache pour la gestion de la configuration de log
        var logsConfigurationCacheConfiguration = RedisCacheConfiguration.defaultCacheConfig()
        		.entryTtl(refreshTokenCacheTtl)
        		.prefixCacheNameWith(redisCachePrefix)
        		.serializeValuesWith(RedisSerializationContext.SerializationPair.fromSerializer(new Jackson2JsonRedisSerializer<>(LogClientConfiguration.class)));
        cacheConfigurations.put(Constants.LOGS_CONFIGURATION_CACHE, logsConfigurationCacheConfiguration.entryTtl(logsConfigurationCacheTtl).prefixCacheNameWith(redisCachePrefix));
        
        appLogger.initLog().level(LogLevel.INFO)
        .message("Configuration du cache REDIS pour les configurations des logs clients")
        .eventTyp(Constants.LOGS_EVT_TYPE_CONFIGURATION)
        .eventCod(Constants.LOGS_EVT_CODE_CONFIGURING_REDIS_LOGS_CACHE)
        .log();
        return RedisCacheManager.builder(redisConnectionFactory).cacheDefaults(RedisCacheConfiguration.defaultCacheConfig()).withInitialCacheConfigurations(cacheConfigurations).build();
    }

}
