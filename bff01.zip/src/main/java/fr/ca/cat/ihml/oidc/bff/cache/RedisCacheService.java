package fr.ca.cat.ihml.oidc.bff.cache;

import java.util.Objects;

import fr.ca.cat.ihml.oidc.bff.models.entities.UserInfosEntity;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogClientConfiguration;
import fr.ca.cat.ihml.oidc.bff.models.security.tokens.RefreshToken;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Service;

/**
 * Service pour l'utilisation du cache REDIS
 * 
 * @author ET02720
 *
 */
@Service
@SuppressWarnings("java:S2259")
public class RedisCacheService {

    /**
     * Injection de l'objet CacheManager pour gérer l'accès au caches Redis
     */
    protected CacheManager cacheManager;

    @Autowired
    public RedisCacheService(CacheManager cacheManager) {
    	this.cacheManager = cacheManager;
    }

    /**
     * Sauvegarde d'un refresh token dans le cache TOKEN REDIS
     * 
     * @param key La clé de sauvegarde
     * @param refreshToken Le refresh token à sauvegarder
     */
    public void storeRefreshToken(String key, RefreshToken refreshToken) {
    	if (Objects.nonNull(this.cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE))) {
    		this.cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE).put(key, refreshToken);
    	} else {
    		throw new IllegalArgumentException(Constants.CACHE_REFRESH_TOKEN_NULL);
    	}
    }

    /**
     * Indique si la clé du refresh token existe
     * 
     * @param key La clé à rechercher
     * @return
     * <ul>
     * <li>True si la clé existe</li>
     * <li>False si la clé n'existe pas où a expirée.
     * </li>
     */
    public boolean isRefreshTokenKeyExist(String key) {
    	if (Objects.nonNull(this.cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE))) {
    		return !Objects.isNull(this.cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE).get(key));
    	} else {
    		throw new IllegalArgumentException(Constants.CACHE_REFRESH_TOKEN_NULL);
    	}
    }

    /**
     * Retourne la valeur du refresh token
     * 
     * @param key La clé souhaitée
     * @return La valeur dans le cache REDIS
     */
    public RefreshToken getRefreshToken(String key) {
    	if (Objects.nonNull(this.cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE))) {
    		return this.cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE).get(key, RefreshToken.class);
    	} else {
    		throw new IllegalArgumentException(Constants.CACHE_REFRESH_TOKEN_NULL);
    	}        
    }

    /**
     * Suppression de la clé dans le cache refresk token
     * 
     * @param key La clé à supprimer
     */
    public void deleteRefreshToken(String key) {
    	if (Objects.nonNull(this.cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE))) {
            this.cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE).evict(key);
    	} else {
    		throw new IllegalArgumentException(Constants.CACHE_REFRESH_TOKEN_NULL);
    	}    
    }

    /**
     * Sauvegarde de la configuration de log du client front end
     * 
     * @param clientLogConfiguration {@link LogClientConfiguration}
     */
    public void storeClientLogConfiguration(LogClientConfiguration clientLogConfiguration) {
    	if (Objects.nonNull(this.cacheManager.getCache(Constants.LOGS_CONFIGURATION_CACHE))) {
        	this.cacheManager.getCache(Constants.LOGS_CONFIGURATION_CACHE).put(Constants.LOGS_DEFAULT_CONF_CLIENT_KEY, clientLogConfiguration);
    	} else {
    		throw new IllegalArgumentException(Constants.CACHE_LOGS_NULL);
    	} 
    }

    /**
     * Indique si la configuration de la log client existe
     * 
     * @return
     * <ul>
     * <li>True si la clé existe</li>
     * <li>False si la clé n'existe pas où a expirée.
     * </li>
     */
    public boolean isClientLogConfigurationExist() {
    	if (Objects.nonNull(this.cacheManager.getCache(Constants.LOGS_CONFIGURATION_CACHE))) {
    		return !Objects.isNull(this.cacheManager.getCache(Constants.LOGS_CONFIGURATION_CACHE).get(Constants.LOGS_DEFAULT_CONF_CLIENT_KEY));
    	} else {
    		throw new IllegalArgumentException(Constants.CACHE_LOGS_NULL);
    	} 
    }

    /**
     * Récupération de la configuration de la log du client front end
     * 
     * @return la configuration de la log du client
     * @see {@link LogClientConfiguration}
     */
    public LogClientConfiguration getClientLogConfiguration() {
    	if (Objects.nonNull(this.cacheManager.getCache(Constants.LOGS_CONFIGURATION_CACHE))) {
            return this.cacheManager.getCache(Constants.LOGS_CONFIGURATION_CACHE).get(Constants.LOGS_DEFAULT_CONF_CLIENT_KEY, LogClientConfiguration.class);
    	} else {
    		throw new IllegalArgumentException(Constants.CACHE_LOGS_NULL);
    	} 
    }

	public void storeUserInfos(UserInfosEntity userInfos) {

		this.getCache(Constants.TOKEN_JWT_CACHE, Constants.CACHE_USERINFOS_JWT_NULL).put(Constants.USER_ENTITLEMENTS,
				userInfos);
	}

	public UserInfosEntity getUserInfos() {
		return this.getCache(Constants.TOKEN_JWT_CACHE, Constants.CACHE_USERINFOS_JWT_NULL)
				.get(Constants.USER_ENTITLEMENTS, UserInfosEntity.class);
	}

	public void storeJwt(String jwt) {
		this.getCache(Constants.TOKEN_JWT_CACHE, Constants.CACHE_TOKEN_JWT_NULL).put(Constants.TOKEN_JWT, jwt);
	}

	public String getJwt() {
		return this.getCache(Constants.TOKEN_JWT_CACHE, Constants.CACHE_TOKEN_JWT_NULL).get(Constants.TOKEN_JWT,
				String.class);

	}

	public void storeSub(String sub) {
		this.getCache(Constants.TOKEN_JWT_CACHE, Constants.CACHE_JWT_SUB_NULL).put(Constants.ID_TOKEN_SUB, sub);
	}

	public String getSub() {
		return this.getCache(Constants.TOKEN_JWT_CACHE, Constants.CACHE_JWT_SUB_NULL).get(Constants.ID_TOKEN_SUB,
				String.class);
	}

	public Cache getCache(String key, String errorMessage) {
		var cache = this.cacheManager.getCache(key);
		if (Objects.nonNull(cache)) {
			return cache;
		}
		throw new IllegalArgumentException(errorMessage);
	}
}
