package fr.ca.cat.ihml.oidc.bff.controllers;

import java.io.IOException;
import java.util.UUID;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.models.context.Ctx9WriteContext;
import fr.ca.cat.ihml.oidc.bff.services.api.IContextService;
import jakarta.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fr.ca.cat.ihml.oidc.bff.models.context.ApplicationContext;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

/**
 * Controller pour la ressource gérant les appels à l'API CTX9
 * 
 * @author ET02720
 *
 */
@RestController
@RequestMapping("/context")
public class ContextController {

	/**
	 * Injection du service gérant le Contexte
	 */
	private IContextService contextService;
	
	/**
	 * Constructor
	 * @param contextService {@link IContextService}
	 */
	public ContextController (IContextService contextService) {
		this.contextService = contextService;
	}

	/**
	 * Ressource pour récupérer le contexte de l'application
	 * 
	 * @param ctxId id du contexte à récupérer
	 * 
	 * @return {@link ApplicationContext}
	 * @throws IOException Erreur IO
	 * @throws ApiException Erreur lors de l'appel HTTP
	 */
	@GetMapping("/{ctxId}")
	@Operation(summary = "Récupération d'un contexte applicatif")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Récupération contexte application OK", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = ApplicationContext.class)) }),
			@ApiResponse(responseCode = "500", description = "Erreur serveur interne", content = @Content),
			@ApiResponse(responseCode = "404", description = "Contexte inconnu", content = @Content),
			@ApiResponse(responseCode = "401", description = "Identifiants de connexion invalides", content = @Content) })
	public ResponseEntity<ApplicationContext> getContext(@PathVariable("ctxId") UUID ctxId)	throws IOException, ApiException {
		var applicationContext = this.contextService.getContext(ctxId);
		return ResponseEntity.ok().body(applicationContext);
	}

	/**
	 * Ressource pour sauvegarder le contexte de l'application
	 * 
	 * @param applicationContext Contexte à sauvegarder
	 * 
	 * @return {@link ApplicationContext}
	 * @throws IOException Erreur IO
	 * @throws ApiException Erreur lors de l'appel HTTP
	 */
	@PostMapping()
	@Operation(summary = "Sauvegarde d'un contexte applicatif")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Sauvegarde du contexte application OK", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = Ctx9WriteContext.class)) }),
			@ApiResponse(responseCode = "500", description = "Erreur serveur interne", content = @Content),
			@ApiResponse(responseCode = "401", description = "Identifiants de connexion invalides", content = @Content) })
	public ResponseEntity<Ctx9WriteContext> setContext(@RequestBody @Valid ApplicationContext applicationContext) throws IOException, ApiException {
		var ctx9WriteContext = this.contextService.setContext(applicationContext);
		return ResponseEntity.ok().body(ctx9WriteContext);
	}
}
