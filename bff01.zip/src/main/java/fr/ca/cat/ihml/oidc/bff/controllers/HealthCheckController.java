package fr.ca.cat.ihml.oidc.bff.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fr.ca.cat.ihml.oidc.bff.services.health.HealthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

/**
 * Controller pour test de bonne santé de l'application
 * 
 * @author ET02720
 * 
 */
@RestController
@RequestMapping("/healthcheck")
public class HealthCheckController {

	/**
	 * Injection de la factory redis
	 */
	@Autowired
	private HealthService healthService;

	/**
	 * Ressource pour test de bonne santé
	 */
	@GetMapping()
	@Operation(summary = "Test de vie de bonne santé")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Test de vie OK", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = String.class)) }),
			@ApiResponse(responseCode = "500", description = "Erreur serveur interne", content = @Content) })
	public ResponseEntity<String> alive() {
		// Test de vie redis
		boolean healthOk = healthService.isRedisOk();
		
		if (healthOk) {
			return ResponseEntity.ok().body("Healthy");			
		} else {
			return ResponseEntity.internalServerError().body("Dead");
		}
	}
}
