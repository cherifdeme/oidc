package fr.ca.cat.ihml.oidc.bff.controllers;

import fr.ca.cat.ihml.oidc.bff.models.logs.LogClientConfiguration;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogMessage;
import fr.ca.cat.ihml.oidc.bff.services.logs.ILogsService;
import jakarta.validation.Valid;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fr.ca.cat.ihml.oidc.bff.models.context.ApplicationContext;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

/**
 * Controller pour la ressource gérant les logs
 * 
 * @author ET02720
 *
 */
@RestController
@RequestMapping("/logs")
public class LogsController {

	/**
	 * Injection du service de gestion des logs
	 */
	private ILogsService logsService;
	
	/**
	 * Constructor
	 * @param logsService {@link ILogsService}
	 */
	public LogsController(ILogsService logsService) {
		this.logsService = logsService;
	}

	/**
	 * Permet la réception d'une log provenant du client front end
	 * 
	 * @param logMessage
	 * @see {@link LogMessage}
	 */
	@PostMapping("/send")
	@Operation(summary = "Réception de log depuis une application front end")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Réception de log OK", content = { @Content }),
			@ApiResponse(responseCode = "500", description = "Erreur serveur interne", content = @Content) })
	public ResponseEntity<Void> postLogs(@RequestBody @Valid LogMessage logMessage) {
		this.logsService.treatmentClientLog(logMessage);
		return ResponseEntity.ok().build();
	}

	/**
	 * Permet de récupérer la configuration de log pour le client front end
	 * 
	 * @return @see {@link LogClientConfiguration}
	 */
	@GetMapping("/configuration")
	@Operation(summary = "Réception de la configuration de log de l'application")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Réception de la configuration de log OK", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = ApplicationContext.class)) }),
			@ApiResponse(responseCode = "404", description = "Configuration de log inconnue", content = @Content),
			@ApiResponse(responseCode = "500", description = "Erreur serveur interne", content = @Content) })
	public ResponseEntity<LogClientConfiguration> getClientLogConfiguration() {
		return ResponseEntity.ok().body(this.logsService.getClientLogConfiguration());
	}

	/**
	 * Permet de spécifier la configuration de log pour le client front end
	 * 
	 * @param clientLogConfiguration
	 * @see {@link LogClientConfiguration}
	 */
	@PostMapping("/configuration")
	@Operation(summary = "Spécification de la configuration de log de l'application")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Spécification de la configuration de log OK", content = {@Content }),
			@ApiResponse(responseCode = "500", description = "Erreur serveur interne", content = @Content) })
	public ResponseEntity<Void> setClientLogConfiguration(@RequestBody @Valid LogClientConfiguration clientLogConfiguration) {
		this.logsService.storeClientLogConfiguration(clientLogConfiguration);
		return ResponseEntity.ok().build();
	}
}
