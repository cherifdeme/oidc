package fr.ca.cat.ihml.oidc.bff.controllers;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fr.ca.cat.ihml.oidc.bff.models.manifest.ApplicationManifest;
import fr.ca.cat.ihml.oidc.bff.services.manifest.IManifestService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

/**
 * Controller pour la ressource gérant le manifest de l'application
 * 
 * @author ET02720
 *
 */
@RestController
@RequestMapping("/manifest")
public class ManifestController {

	/**
	 * Injection du service de gestion du manifest
	 */
	private IManifestService manifestService;
	
	/**
	 * Constructor
	 * @param manifestService {@link IManifestService}
	 */
	public ManifestController (IManifestService manifestService) {
		this.manifestService = manifestService;
	}

	/**
	 * Récupérer le manifest de l'application
	 * 
	 * @return Le manifest de l'application
	 * @see {@link ApplicationManifest}
	 */
	@GetMapping()
	@Operation(summary = "Récupération de détail sur la version et le type du serveur")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Version et type de serveur", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = ApplicationManifest.class)) }),
			@ApiResponse(responseCode = "500", description = "Erreur serveur interne", content = @Content) })
	public ResponseEntity<ApplicationManifest> getManifest() {
		return ResponseEntity.ok().body(manifestService.getManifest());
	}

}
