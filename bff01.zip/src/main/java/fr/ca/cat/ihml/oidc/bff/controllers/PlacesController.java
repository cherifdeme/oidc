package fr.ca.cat.ihml.oidc.bff.controllers;

import jakarta.validation.constraints.Digits;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.models.places.CR;
import fr.ca.cat.ihml.oidc.bff.models.places.DistributionEntity;
import fr.ca.cat.ihml.oidc.bff.models.places.Entity;
import fr.ca.cat.ihml.oidc.bff.services.api.IPlacesService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

/**
 * Controller pour la ressource gérant les appels à l'API Places
 * 
 * @author ET02720
 *
 */
@RestController
@RequestMapping("/places")
@Validated
public class PlacesController {

    private IPlacesService placesService;
    
    /**
     * Constructor
	 * @param placesService {@link IPlacesService}
     */
    public PlacesController(IPlacesService placesService) {
    	this.placesService = placesService;
    }
    
    /**
     * Ressource pour récupérer la liste des CR
     * 
     * @return Liste de {@link CR}
     * @throws ApiException Erreur lors de l'appel HTTP
     */
    @GetMapping("/regional_banks")
	@Operation(summary = "Réception de la liste des CR")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Réception de la liste des CR OK", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = CR[].class)) }),
			@ApiResponse(responseCode = "401", description = "Identifiants invalides", content = @Content),
			@ApiResponse(responseCode = "500", description = "Erreur serveur interne", content = @Content) })
    public ResponseEntity<CR[]> getCRList() throws ApiException {
        CR[] crs = this.placesService.getCRList();
        return ResponseEntity.ok().body(crs);
    }

    /**
     * Ressource pour récupérer la liste des villes d'une CR
     * 
     * @param crId Id de la CR
     * @return Liste d' {@link Entity}
     * @throws ApiException Erreur lors de l'appel HTTP
     */
    @GetMapping("/regional_banks/{crId}/cities_with_distribution_entities")
	@Operation(summary = "Réception de la liste des villes d'une CR")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Réception de la liste des villes d'une CR OK", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = Entity[].class)) }),
			@ApiResponse(responseCode = "401", description = "Identifiants invalides", content = @Content),
			@ApiResponse(responseCode = "500", description = "Erreur serveur interne", content = @Content) })
    public ResponseEntity<Entity[]> getCREntities(@PathVariable("crId") @Digits(integer= 3, fraction= 0)int crId) throws ApiException {
        Entity[] entities = this.placesService.getCREntities(crId);
        return ResponseEntity.ok().body(entities);
    }

    /**
     * Ressource pour récupérer les agences d'une ville d'une CR
     * 
     * @param crId Id de la CR
     * @param zipCode Zipcode de l'Entity (ville)
     * @return Liste d' {@link DistributionEntity}
     * @throws ApiException Erreur lors de l'appel HTTP
     */
    @GetMapping("/distribution_entities/search_by_city/{crId}/{zipCode}")
	@Operation(summary = "Réception des agences d'une villes d'une CR")
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "Réception des agences d'une villes d'une CR OK", content = {
					@Content(mediaType = "application/json", schema = @Schema(implementation = DistributionEntity[].class)) }),
			@ApiResponse(responseCode = "401", description = "Identifiants invalides", content = @Content),
			@ApiResponse(responseCode = "500", description = "Erreur serveur interne", content = @Content) })
    public ResponseEntity<DistributionEntity[]> getCRAgencesList(@PathVariable("crId") @Digits(integer= 3, fraction= 0)int crId, @PathVariable("zipCode") @Digits(integer= 5, fraction= 0)int zipCode) throws ApiException {
        DistributionEntity[] distributionEntities = this.placesService.getCRAgencesList(crId, zipCode);
        return ResponseEntity.ok().body(distributionEntities);
    }
}
