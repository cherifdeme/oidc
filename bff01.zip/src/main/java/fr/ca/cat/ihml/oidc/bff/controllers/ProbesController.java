package fr.ca.cat.ihml.oidc.bff.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fr.ca.cat.ihml.oidc.bff.services.health.HealthService;

/**
 * Controller pour les sondes de vie Kubernetes
 * 
 * @author ET02720
 *
 */
@RestController
@RequestMapping("/probes")
public class ProbesController {

	/**
	 * Injection de la factory redis
	 */
	@Autowired
	private HealthService healthService;

	/**
	 * Ressource pour la sonde de readyness
	 * 
	 */
	@GetMapping("/ready")
	public ResponseEntity<String> ready() {
		var redisOk = healthService.isRedisOk();
		
		if (redisOk) {
			return ResponseEntity.ok().body("Ready");			
		} else {
			return ResponseEntity.internalServerError().body("Not Ready");
		}
	}

	/**
	 * Ressource pour la sonde de liveness
	 */
	@GetMapping("/alive")
	public ResponseEntity<String> alive() {
		return ResponseEntity.ok().body("Alive");
	}
}
