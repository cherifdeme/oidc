package fr.ca.cat.ihml.oidc.bff.controllers;

import java.util.Objects;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.models.security.user.UserDetails;
import fr.ca.cat.ihml.oidc.bff.services.security.ISecurityService;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.util.MultiValueMap;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import fr.ca.cat.ihml.oidc.bff.utils.AppUtils;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

/**
 * Controller pour la ressource gérant la sécurité de l'application
 * 
 * @author ET02720
 *
 */
@RestController
@RequestMapping("/security")
@Validated
public class SecurityController {

    /**
     * Injection de la variable pour le chemin des cookies
     */
    @Value("${security.session.cookie.path}")
    private String path;

    /**
     * Injection de la variable pour la propriété SameSite des cookies
     */
    @Value("${security.session.cookie.samesite}")
    private String sameSite;
    
    /**
     * Injection de la variable pour la propriété du nom du cookie secret (SSO application mobile)
     */
    @Value("${secret.cookie}")
    private String secretCookie;
    
    /**
     * Injection du SecurityService
     */
    private ISecurityService securityService;
    
    /**
     * Injection de la requête
     */
     private HttpServletRequest request;
     
     /**
      * Constructor
      * @param securityService {@link ISecurityService}
      * @param request {@link HttpServletRequest}
      */
     public SecurityController(ISecurityService securityService, HttpServletRequest request) {
    	 this.securityService = securityService;
    	 this.request = request;
     }

    /**
     * Ressource d'identification à l'application
     * 
     * @param code Authorization code fourni par la mire X Connect
     * @param redirectUri Url de redirection de l'application founie à X Connect
     * @param state Token pour la gestion CSRF
     * @param secretCookieValue cookie pour la connexion via NMB
     * @throws ApiException Erreur lors de l'appel HTTP
     */
    @GetMapping("/login")
    @Operation(summary = "Connexion d'un utilisateur")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Connexion d'un utilisateur OK", content = { @Content }), 
            @ApiResponse(responseCode = "500", description = "Erreur serveur interne", content = @Content), 
            @ApiResponse(responseCode = "400", description = "Erreur authentification", content = @Content), 
            @ApiResponse(responseCode = "401", description = "Identifiants de connexion invalides", content = @Content) })
    public ResponseEntity<Void> login(@RequestParam(value = Constants.CODE_PARAM) @NotBlank String code,
            @RequestParam(value = Constants.REDIRECT_URI_PARAM) @NotBlank @Pattern(regexp = "^(http|https)://.+")String redirectUri, 
            @RequestParam(value = Constants.STATE) @NotBlank String state,
            @CookieValue(value = "${secret.cookie}", required= false) String secretCookieValue) throws ApiException {
        var refreshTokenKey = this.securityService.login(code, redirectUri, state, secretCookieValue);

        // Création du cookie SESSION_REFRESH permettant de récupérer le refresh token dans le cache REDIS
        var responseHeaders = new HttpHeaders();
        responseHeaders.add(HttpHeaders.SET_COOKIE, AppUtils.buildCookie(Constants.SESSION_REFRESH_COOKIE, refreshTokenKey, request.getServerName(), path, true, sameSite, false));
        
        // Si cookie secret présent on le supprime
        if (Objects.nonNull(secretCookieValue)){
            var secretCookieDelete = AppUtils.buildCookie(secretCookie, Constants.DELETED_VALUE, request.getServerName(), path, true, sameSite, true);
            responseHeaders.add(HttpHeaders.SET_COOKIE, secretCookieDelete);
        }

        return ResponseEntity.ok().headers(responseHeaders).build();
    }
    
    /**
     * Ressource de déconnexion en mode standalone
     * 
     * @param refreshCookieValue ID de "refresh session" fourni lors de la connexion
     * @throws ApiException Erreur lors de l'appel HTTP
     */
    @PostMapping("/standalonelogout")
    @Operation(summary = "Déconnexion d'un utilisateur")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Déconnexion d'un utilisateur OK", content = { @Content }), 
            @ApiResponse(responseCode = "500", description = "Erreur serveur interne", content = @Content), 
            @ApiResponse(responseCode = "400", description = "Erreur authentification", content = @Content),
            @ApiResponse(responseCode = "401", description = "Identifiants de connexion invalides", content = @Content) })
    public ResponseEntity<Void> standAloneLogout(@CookieValue(Constants.SESSION_REFRESH_COOKIE) String refreshCookieValue) throws ApiException {
        this.securityService.standAloneLogout(refreshCookieValue);

        // Révocation du cookie SESSION_REFRESH
        var responseHeaders = new HttpHeaders();
        var cookieString = AppUtils.buildCookie(Constants.SESSION_REFRESH_COOKIE, Constants.DELETED_VALUE, request.getServerName(), path, true, sameSite, true);
        responseHeaders.set(HttpHeaders.SET_COOKIE, cookieString);

        return ResponseEntity.ok().headers(responseHeaders).build();
    }

    /**
     * Ressource de déconnexion back channel appelée par les mires X Connect
     * 
     * @param body Contient le logout token envoyé par  X connect
     * @throws ApiException Erreur lors de l'appel HTTP
     */
    @PostMapping(path = "/backloggedout", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    @Operation(summary = "Déconnexion d'un utilisateur")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Déconnexion d'un utilisateur OK", content = { @Content }), 
            @ApiResponse(responseCode = "500", description = "Erreur serveur interne", content = @Content), 
            @ApiResponse(responseCode = "400", description = "Erreur authentification", content = @Content),
            @ApiResponse(responseCode = "401", description = "Identifiants de connexion invalides", content = @Content) })
    public ResponseEntity<Void> backChannelLogout(@RequestParam MultiValueMap<String, String> body) throws ApiException {
        var found = this.securityService.backChannelLogout(body);
        
        return found ? ResponseEntity.ok().build() : ResponseEntity.notFound().build();
    }

    /**
     * Ressource pour récupérer les informations sur le user de la session
     * 
     * @param refreshCookieValue ID de "refresh token" fourni lors de la connexion
     * @return {@link UserDetails}
     */
    @GetMapping("/user")
    @Operation(summary = "Récupération information utilisateur connecté")
    @ApiResponses(value = { @ApiResponse(responseCode = "200", description = "Récupération information utilisateur connecté OK", 
    content = { @Content(mediaType = "application/json", schema = @Schema(implementation = UserDetails.class)) }), 
            @ApiResponse(responseCode = "500", description = "Erreur serveur interne", content = @Content), 
            @ApiResponse(responseCode = "404", description = "Utilisateur inconnu", content = @Content) })
    public ResponseEntity<UserDetails> getUserDetails(Authentication auth, @CookieValue(value = Constants.SESSION_REFRESH_COOKIE, required = false) String refreshCookieValue) {
        var responseHeaders = new HttpHeaders();
        
        // Récupération de l'utilisateur
        var user = this.securityService.getUserDetails(auth, refreshCookieValue);
        
        // Si l'utilisateur n'existe pas et que le cookie refresh existe on le revoke
        if (Objects.nonNull(refreshCookieValue) && Objects.isNull(user.getId())) {
            var cookieString = AppUtils.buildCookie(Constants.SESSION_REFRESH_COOKIE, Constants.DELETED_VALUE, request.getServerName(), path, true, sameSite, true);
            responseHeaders.set("Set-Cookie", cookieString);
        }
        
        return ResponseEntity.ok().headers(responseHeaders).body(user);
    }
}
