package fr.ca.cat.ihml.oidc.bff.exceptions;

/**
 * Exception pour les erreurs de types API
 * 
 * @author ET02720
 *
 */
public class ApiException extends Exception {

    private static final long serialVersionUID = 7813475184600026302L;
    private final int statusCode;

    /**
     * Récupération du code HTTP de l'erreur
     * 
     * @return Code HTTP
     */
    public int getStatusCode() {
        return statusCode;
    }

    /**
     * Déclaration d'une ApiException
     * 
     * @param code Code HTTP de l'erreur
     * @param message Message de l'exception
     */
    public ApiException(int code, String message) {
        super(message);
        this.statusCode = code;
    }

}
