package fr.ca.cat.ihml.oidc.bff.exceptions;

import fr.ca.cat.ihml.oidc.bff.services.logs.ApplicationLogger;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;

import fr.ca.cat.ihml.oidc.bff.models.http.ErrorResponse;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.models.validator.ValidationErrorResponse;
import fr.ca.cat.ihml.oidc.bff.models.validator.Violation;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;

/**
 * Classe en charge de la gestion globale des erreurs
 * @author ET02720
 *
 */
@ControllerAdvice
public class RestResponseEntityExceptionHandler {
	
    /**
     * Déclaration du logger de la classe;
     */
    private static ApplicationLogger appLogger = ApplicationLogger.getLogger(RestResponseEntityExceptionHandler.class);
    
    /**
     * Gestion des ConstraintViolationException
     * @param e ConstraintViolationException
     * @return {@link ValidationErrorResponse} 
     */
    @ExceptionHandler(ConstraintViolationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    ValidationErrorResponse onConstraintValidationException(ConstraintViolationException e) {
        var error = new ValidationErrorResponse();
        for (ConstraintViolation<?> violation : e.getConstraintViolations()) {
            error.getViolations().add(new Violation(violation.getPropertyPath().toString(), violation.getMessage()));
        }
        return error;
    }

    /**
     * Gestion des MethodArgumentNotValidException
     * @param e MethodArgumentNotValidException
     * @return {@link ValidationErrorResponse} 
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    ValidationErrorResponse onMethodArgumentNotValidException(MethodArgumentNotValidException e) {
        var error = new ValidationErrorResponse();
        for (FieldError fieldError : e.getBindingResult().getFieldErrors()) {
            error.getViolations().add(new Violation(fieldError.getField(), fieldError.getDefaultMessage()));
        }
        return error;
    }
    
    
	/**
	 * Gestion des ApiException
	 * @param e ApiException
	 * @param request Requête HTTP
	 * @return {@link ErrorResponse}
	 */
	@ExceptionHandler(ApiException.class)
	protected ResponseEntity<ErrorResponse> onApiException(ApiException e, WebRequest request) {
		var req = (ServletWebRequest) request;
		
        // S'il y a une erreur lors de l'appel de la requête on intercepte l'erreur pour la caster dans une reponse standard
        var errorResponse = new ErrorResponse();

        // Par défaut on met un code erreur 500
        errorResponse.setStatus(e.getStatusCode());
        errorResponse.setMessage(e.getMessage());
        
        // Log de l'erreur
        appLogger.initLog().level(LogLevel.ERROR)
        .message(String.format("HTTP %d - %s", errorResponse.getStatus(), e.getMessage()))
        .eventTyp(Constants.LOGS_EVT_TYPE_API)
        .eventCod(Constants.LOGS_EVT_CODE_API_ERROR)
        .uri(req.getRequest().getRequestURI())
        .log();
        
		return new ResponseEntity<>(errorResponse, HttpStatus.valueOf(errorResponse.getStatus()));
	}
	
	/**
	 * Gestion des RuntimeExpception
	 * @param e RuntimeExpception
	 * @param request Requête HTTP
	 * @return {@link ErrorResponse}
	 */
	@ExceptionHandler(RuntimeException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ResponseBody
	protected ErrorResponse onRuntimeException(RuntimeException e, WebRequest request) {
		var req = (ServletWebRequest) request;
		
        // S'il y a une erreur lors de l'appel de la requête on intercepte l'erreur pour la caster dans une reponse standard
        var errorResponse = new ErrorResponse();

        // Par défaut on met un code erreur 500
        errorResponse.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
        errorResponse.setMessage(e.getMessage());
        
        // Log de l'erreur
        appLogger.initLog().level(LogLevel.ERROR)
        .message(String.format("HTTP %d - %s", errorResponse.getStatus(), e.getMessage()))
        .eventTyp(Constants.LOGS_EVT_TYPE_API)
        .eventCod(Constants.LOGS_EVT_CODE_API_ERROR)
        .uri(req.getRequest().getRequestURI())
        .log();
        
		return errorResponse;
	}
}
