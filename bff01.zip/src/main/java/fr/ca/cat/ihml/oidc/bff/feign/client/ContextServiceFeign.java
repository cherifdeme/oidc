package fr.ca.cat.ihml.oidc.bff.feign.client;

import java.util.Map;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.models.context.Ctx9WriteContext;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.util.MultiValueMap;

import feign.Headers;
import feign.QueryMap;
import feign.RequestLine;
import fr.ca.cat.ihml.oidc.bff.feign.config.BearerClientFeignConfig;
import fr.ca.cat.ihml.oidc.bff.models.context.Ctx9ReadContext;


/**
 * Service Feign Client pour appeler les ressources de l'API CTX9
 * 
 * @author ET02720
 * 
 */
@FeignClient(value ="context",url="${service.ctx9}", configuration=BearerClientFeignConfig.class)
public interface ContextServiceFeign {
	
	/**
	 * Ressource pour la recupération d'un contexte
	 * 
	 * @param queryMap Paramètres de la requête
	 * @return  {@link Ctx9ReadContext}
	 */
 	@RequestLine("GET /contexts")
	Ctx9ReadContext getContextRequest(@QueryMap Map<String, Object> queryMap) throws ApiException;
	
 	/**
 	 * Ressource pour la sauvegarde d'un contexte
 	 * 
 	 * @param param Parametres du body
 	 * @return
 	 */
    @RequestLine("POST /contexts")
    @Headers("Content-Type: application/x-www-form-urlencoded;charset=UTF-8")
    Ctx9WriteContext setContext(MultiValueMap<String, Object> param) throws ApiException;
}
