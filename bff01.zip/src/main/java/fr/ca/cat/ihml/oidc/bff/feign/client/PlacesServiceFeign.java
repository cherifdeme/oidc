package fr.ca.cat.ihml.oidc.bff.feign.client;

import java.util.Map;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.models.places.CR;
import fr.ca.cat.ihml.oidc.bff.models.places.DistributionEntity;
import fr.ca.cat.ihml.oidc.bff.models.places.Entity;
import fr.ca.cat.ihml.oidc.bff.services.logs.ApplicationLogger;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import org.springframework.cloud.openfeign.FeignClient;

import feign.Param;
import feign.QueryMap;
import feign.RequestLine;
import fr.ca.cat.ihml.oidc.bff.feign.config.BearerClientFeignConfig;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

/**
 * Service Feign Client pour appeler les ressources de l'API Places
 * 
 * @author ET02720
 *
 */
@FeignClient(value = "places", url = "${service.places}", configuration = BearerClientFeignConfig.class)
@SuppressWarnings("squid:S1214")
public interface PlacesServiceFeign {
    
    /**
     * Déclaration du logger de la classe
     */
    public static ApplicationLogger appLogger = ApplicationLogger.getLogger(PlacesServiceFeign.class);

    /**
     * Ressource pour la récupération de la liste des CR
     * 
     * @return {@link CR}
     */
    @RequestLine("GET /regional_banks")
    @CircuitBreaker(name = "placesGetCRList", fallbackMethod = "getCRListRequestFallback")
    CR[] getCRListRequest() throws ApiException;

    /**
     * Ressource pour la récupération de la liste des villes d'une CR
     * 
     * @param crId Id de la CR
     * @return {@link Entity}
     */
    @RequestLine("GET /regional_banks/{crId}/cities_with_distribution_entities?type=1")
    @CircuitBreaker(name = "placesGetCREntities", fallbackMethod = "getCREntitiesRequestFallback")
    Entity[] getCREntitiesRequest(@Param("crId") int crId) throws ApiException;

    /**
     * Ressource pour la récupération des agences d'une ville d'une CR
     * 
     * @param queryMap Paramètres de la requête
     * @return {@link DistributionEntity}
     */
    @RequestLine("GET /distribution_entities/search_by_city")
    @CircuitBreaker(name = "placesGetDistributionEntities", fallbackMethod = "getDistributionEntitiesRequestFallback")
    DistributionEntity[] getDistributionEntitiesRequest(@QueryMap Map<String, Object> queryMap) throws ApiException;

    /**
     * CallBack pour la gestion du CircuitBreaker placesGetCRList
     * @param e Exception levée par l'API
     * @return Liste de CR par défaut
     */
    default CR[] getCRListRequestFallback(Exception e) {
        
        if (e instanceof ApiException) {
            appLogger.initLog().level(LogLevel.INFO)
            .message("Fallback method: Erreur lors de l'appel à l'api Places: getCRListRequest")
            .eventTyp(Constants.LOGS_EVT_TYPE_API)
            .eventCod(Constants.LOGS_EVT_CODE_PLACES_GET_CR_FALLBACK)
            .log();            
        } else if (e instanceof CallNotPermittedException) {
            appLogger.initLog().level(LogLevel.INFO)
            .message("Fallback method: Erreur lors de l'appel à l'api Places: getCRListRequest - Circuitbreaker OUVERT")
            .eventTyp(Constants.LOGS_EVT_TYPE_API)
            .eventCod(Constants.LOGS_EVT_CODE_PLACES_GET_CR_FALLBACK_CB_OPEN)
            .log();            
        }

        return new CR[] {};
    }
    
    /**
     * CallBack pour la gestion du CircuitBreaker placesGetCREntities
     * @param e Exception levée par l'API
     * @return Liste de Entity par défaut
     */
    default Entity[] getCREntitiesRequestFallback(Exception e) {
        
        if (e instanceof ApiException) {
            appLogger.initLog().level(LogLevel.INFO)
            .message("Fallback method: Erreur lors de l'appel à l'api Places: getCREntities")
            .eventTyp(Constants.LOGS_EVT_TYPE_API)
            .eventCod(Constants.LOGS_EVT_CODE_PLACES_GET_ENTITIES_FALLBACK)
            .log();            
        } else if (e instanceof CallNotPermittedException) {
            appLogger.initLog().level(LogLevel.INFO)
            .message("Fallback method: Erreur lors de l'appel à l'api Places: getCREntities - Circuitbreaker OUVERT")
            .eventTyp(Constants.LOGS_EVT_TYPE_API)
            .eventCod(Constants.LOGS_EVT_CODE_PLACES_GET_ENTITIES_FALLBACK_CB_OPEN)
            .log();            
        }

        return new Entity[] {};
    }
    
    /**
     * CallBack pour la gestion du CircuitBreaker placesGetDistributionEntities
     * @param e Exception levée par l'API
     * @return Liste de DistributionEntity par défaut
     */
    default DistributionEntity[] getDistributionEntitiesRequestFallback(Exception e) {
        
        if (e instanceof ApiException) {
            appLogger.initLog().level(LogLevel.INFO)
            .message("Fallback method: Erreur lors de l'appel à l'api Places: getDistributionEntities")
            .eventTyp(Constants.LOGS_EVT_TYPE_API)
            .eventCod(Constants.LOGS_EVT_CODE_PLACES_GET_DISTRIBUTION_ENTITIES_FALLBACK)
            .log();            
        } else if (e instanceof CallNotPermittedException) {
            appLogger.initLog().level(LogLevel.INFO)
            .message("Fallback method: Erreur lors de l'appel à l'api Places: getDistributionEntities - Circuitbreaker OUVERT")
            .eventTyp(Constants.LOGS_EVT_TYPE_API)
            .eventCod(Constants.LOGS_EVT_CODE_PLACES_GET_DISTRIBUTION_ENTITIES_FALLBACK_CB_OPEN)
            .log();            
        }

        return new DistributionEntity[] {};
    }
    
}
