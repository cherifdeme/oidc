package fr.ca.cat.ihml.oidc.bff.feign.client;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.models.security.tokens.OAuthToken;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.util.MultiValueMap;

import feign.Headers;
import feign.RequestLine;
import fr.ca.cat.ihml.oidc.bff.feign.config.BasicClientFeignConfig;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;


/**
 * Service Feign Client pour appeler les ressources de l'API AUC9
 * 
 * @author ET02720
 *
 */
@FeignClient(value ="security",url="${service.auc9}", configuration=BasicClientFeignConfig.class)
public interface SecurityServiceFeign {
	
	/**
	 * Ressource pour la récupération d'un Token à partir d'un az code
	 * @param param Paramètre du body de la requête
	 * @return {@link OAuthToken}
	 */
    @RequestLine("POST /openid/token")
    @Headers("Content-Type: application/x-www-form-urlencoded;charset=UTF-8")
    @CircuitBreaker(name = "security")
    OAuthToken getOpenIdTokenRequest(MultiValueMap<String, Object> param) throws ApiException;
    
    /**
     * Ressource pour la revocation d'un refresh token
     * 
     * @param param Paramètre du body de la requête
     */
    @RequestLine("POST /openid/revoke")
    @Headers("Content-Type: application/x-www-form-urlencoded;charset=UTF-8")
    @CircuitBreaker(name = "security")
    void getOpenIdRevokeTokenRequest(MultiValueMap<String, Object> param) throws ApiException;

    /**
     * Ressource pour la récupération de la clé publique
     * 
     * @return La clé publique
     */
    @RequestLine("GET /certs")
    @CircuitBreaker(name = "security")
    String getPublicKey() throws ApiException;
}
