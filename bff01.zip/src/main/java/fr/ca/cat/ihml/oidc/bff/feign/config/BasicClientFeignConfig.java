package fr.ca.cat.ihml.oidc.bff.feign.config;

import java.util.Base64;

import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpHeaders;

import feign.RequestInterceptor;
import fr.ca.cat.ihml.oidc.bff.utils.AppUtils;

/**
 * Feign configuration pour les ressource de securisation en mode Basic
 * 
 * @author ET02720
 *
 */
public class BasicClientFeignConfig {
    
    /**
     * Injection de la propriété clientId de l'application
     */
    @Value("${security.clientID}")
    protected String clientId;

    /**
     * Injection de la propriété secretId de l'application
     */
    @Value("${security.secretID}")
    protected String secretId;
	
	
	/**
	 * Declaration du Request Interceptor pour la sécurité
	 * 
	 * @return
	 */
    @Bean
    public RequestInterceptor securityRequestInterceptor() {
        return requestTemplate -> {
            requestTemplate.header(HttpHeaders.AUTHORIZATION, String.format(Constants.BASIC_HEADER_VALUE, this.getAuthorizationToken()));
            requestTemplate.header(Constants.CORRELATION_ID_HEADER, AppUtils.getCorrelationId());
        };
    }
    
    private String getAuthorizationToken() {
        return Base64.getEncoder().encodeToString((String.format("%s:%s", clientId, secretId).getBytes()));
    }

}
