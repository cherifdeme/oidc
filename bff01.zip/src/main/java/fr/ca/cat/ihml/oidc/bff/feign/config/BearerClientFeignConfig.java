package fr.ca.cat.ihml.oidc.bff.feign.config;

import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpHeaders;
import org.springframework.security.core.context.SecurityContextHolder;

import feign.RequestInterceptor;
import fr.ca.cat.ihml.oidc.bff.utils.AppUtils;

/**
 * Feign configuration pour les ressource authentifie en mode Bearer
 * 
 * @author ET02720
 *
 */
public class BearerClientFeignConfig {

	/**
	 * Déclaration du Request Interceptor
	 *
	 */
	@Bean
	public RequestInterceptor basicRequestInterceptor() {
	    return requestTemplate -> {
	        var userAuthentication = SecurityContextHolder.getContext().getAuthentication();
	        
	        requestTemplate.header(HttpHeaders.AUTHORIZATION,String.format("Bearer %s", userAuthentication.getCredentials()));
	        requestTemplate.header(Constants.CORRELATION_ID_HEADER, AppUtils.getCorrelationId());
        };
	}

}
