package fr.ca.cat.ihml.oidc.bff.feign.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import feign.Contract;
import fr.ca.cat.ihml.oidc.bff.feign.error.ClientFeignErrorDecoder;

/**
 * Configuration générale des clients Feign
 * 
 * @author ET02720
 *
 */
@Configuration
public class GenericClientFeignConfig {
	
	/**
	 * Déclation de la gestion des erreurs
	 * 
	 * @return {@link ClientFeignErrorDecoder}
	 */
	@Bean
	public ClientFeignErrorDecoder clientFeignErrorDecoder() {
		return new ClientFeignErrorDecoder();
	}

	/**
	 * Declaration du contrat d'interface utilisé par Feign
	 * 
	 * @return {@link Contract}
	 */
	@Bean
	public Contract feignContract() {
		return new Contract.Default();
	}
}
