package fr.ca.cat.ihml.oidc.bff.feign.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import feign.Logger;

/**
 * Configuration de la log des clients Feign
 * 
 * @author ET02720
 *
 */
@Configuration
public class LogFeignClientConfiguration {
    
	/**
	 * Variable du niveau de log Feign
	 */
	@Value("${service.feign.log}")
    protected Logger.Level level;
	
	/**
	 * Déclaration du niveau de log Feign
	 * @return {@link Logger.Level}
	 */
    @Bean
    Logger.Level feignLoggerLevel() {
    	return level;
    }
}