package fr.ca.cat.ihml.oidc.bff.feign.error;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.services.logs.ApplicationLogger;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import org.apache.commons.io.IOUtils;
import org.springframework.http.HttpStatus;

import feign.Response;
import feign.RetryableException;
import feign.codec.ErrorDecoder;

/**
 * Classe pour la gestion globale des erreurs des clients Feign
 * 
 * @author ET02720
 *
 */
public class ClientFeignErrorDecoder implements ErrorDecoder {

	private static ApplicationLogger appLogger = ApplicationLogger.getLogger(ClientFeignErrorDecoder.class);

	/**
     * Gestion des erreurs pour les client Feign
     */
    @Override
    public Exception decode(String invoqueur, Response response) {
        // Lecture du message d'erreur du body de la réponse
    	String errorMessage = getResponseErrorMessage(response);    	

        if (HttpStatus.valueOf(response.status()).value() == 429) {
            // Si erreur 429 on envoit un retry erreur pour réessai de la requête
            return new RetryableException(response.status(), response.reason(), response.request().httpMethod(), 10L, response.request());
        } else {
        	return new ApiException(response.status(), errorMessage);
        }
    }
    
    /**
     * Lecture du body de la reponse
     * @param response La réponse à lire
     * @return le contenu du body de la réponse
     */
    private String getResponseErrorMessage(Response response) {
        String erroMessage = null;
        Reader reader = null;
        try {
            reader = response.body().asReader(StandardCharsets.UTF_8);
            erroMessage = IOUtils.toString(reader);
        } catch (IOException e) {
            appLogger.initLog().level(LogLevel.ERROR)
            .message("Erreur lors de lecture du body de la réponse")
            .eventTyp(Constants.LOGS_EVT_TYPE_API)
            .eventCod(Constants.LOGS_EVT_CODE_API_ERROR)
            .uri(response.request().url())
            .log();
            erroMessage = "Server error";

        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
                appLogger.initLog().level(LogLevel.ERROR)
                .message("Erreur lors de lecture du body de la réponse")
                .eventTyp(Constants.LOGS_EVT_TYPE_API)
                .eventCod(Constants.LOGS_EVT_CODE_API_ERROR)
                .uri(response.request().url())
                .log(); 
                erroMessage = "Server error";
            }
        }
        
        return erroMessage;
    }
}
