package fr.ca.cat.ihml.oidc.bff.feign.retry;

import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.services.logs.ApplicationLogger;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import feign.RetryableException;
import feign.Retryer;

/**
 * Classe pour gérer le retry des requêtesen erreur par Feign
 * @author ET02720
 *
 */
@Configuration
public class FeignRetryer implements Retryer {

	/**
	 * Déclaration du logger de la classe
	 */
	private static ApplicationLogger appLogger = ApplicationLogger.getLogger(FeignRetryer.class);

	/**
	 * Nombre de ressaie maxmimum
	 * @see FeignRetryer#getRetryMaxAttempts()
	 * @see FeignRetryer#setRetryMaxAttempts(int)
	 */
	@Value("${feign.retry.max.attempts}")
	private int retryMaxAttempts;

	/**
	 * Durée d'attente entre de essais (en ms)
	 * @see FeignRetryer#getRetryInterval()
	 * @see FeignRetryer#setRetryInterval(Long)
	 */
	@Value("${feign.retry.interval}")
	private Long retryInterval;
	
	/**
	 * Compteur d'essais
	 */
	private int attempt;
	
	// Default constructor
	public FeignRetryer() {
		this.attempt = 0;
        this.retryMaxAttempts = 1;
        this.retryInterval = 1000L;
	}
	
	// Constructeur pour le clone
    public FeignRetryer(int retryMaxAttempts, Long retryInterval) {
        this.retryMaxAttempts = retryMaxAttempts;
        this.retryInterval = retryInterval;
        this.attempt = 0;
    }

	@Override
	public void continueOrPropagate(RetryableException e) {
		// Log du nombre d'essai
    	appLogger.initLog().level(LogLevel.DEBUG)
        .message(String.format("Error calling api --> %s. %d - %s. Retry Attempt %d", e.request().url(), e.status(), e.getMessage(), attempt))
        .eventTyp(Constants.LOGS_EVT_TYPE_API)
        .eventCod(Constants.LOGS_EVT_CODE_API_RETRY)
        .log(); 

    	// Si le nombre d'essai maximum est atteint on renvoit l'exception
		if (attempt++ == retryMaxAttempts) {
			throw e;
		}
		
		// Attente avant un ressais
		try {
			Thread.sleep(retryInterval);
		} catch (InterruptedException ignored) {
			Thread.currentThread().interrupt();
		}

	}

	@Override
	@SuppressWarnings("java:S2975")
	public Retryer clone() {
		return new FeignRetryer(this.retryMaxAttempts, this.retryInterval);
	}

}
