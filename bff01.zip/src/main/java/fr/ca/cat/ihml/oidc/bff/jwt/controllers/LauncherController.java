package fr.ca.cat.ihml.oidc.bff.jwt.controllers;

import java.io.IOException;
import java.net.URISyntaxException;
import java.security.cert.CertPathValidatorException;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.jose4j.jwt.MalformedClaimException;
import org.jose4j.jwt.consumer.InvalidJwtException;
import org.jose4j.lang.JoseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import fr.ca.cat.ihml.oidc.bff.cache.RedisCacheService;
import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.services.logs.ApplicationLogger;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;

/**
 * Controller du point d'entrée, reçoit le formulaire de lancement et appelle le
 * service de verification du jeton jwt
 *
 * @author ETPD355
 */

@Controller
@RequestMapping("/launcher")
public class LauncherController {
    private static ApplicationLogger appLogger = ApplicationLogger.getLogger(LauncherController.class);

    // doit etre 'https://localhost:4200/home' en local
    @Value("${remote.server.url}")
    private String feUrl;

    protected RedisCacheService redisCacheService;

    @Autowired
    public LauncherController(RedisCacheService redisCacheService) {
        super();
        this.redisCacheService = redisCacheService;
    }

    public LauncherController() {

    }

    /**
     * point d'entré de l'application
     *
     * @param correlationId
     * @param requestVersion
     * @param ihmLaunchParams
     * @param userIdpHint
     * @param contextInitial
     * @param response
     * @throws ApiException
     * @throws MalformedClaimException
     * @throws JoseException
     * @throws InvalidJwtException
     * @throws IOException
     * @throws CertPathValidatorException
     * @throws URISyntaxException
     */
    @PostMapping(value = "/entrypoint", consumes = {MediaType.APPLICATION_FORM_URLENCODED_VALUE})
    public void entryPoint(@RequestParam(Constants.CORRELATION_ID) String correlationId,
                           @RequestParam(Constants.REQUEST_VERSION) String requestVersion,
                           @RequestParam(Constants.IHM_LAUNCH_PARAMS) String ihmLaunchParams,
                           @RequestParam(Constants.USER_IDP_HINT) String userIdpHint,
                           @RequestParam(Constants.CONTEXT_INITIAL) String contextInitial,
                           HttpServletResponse response) throws ApiException {

        //on verifie la version, si elle est differente de 3 on leve une exception
        if (!"3".equals(requestVersion) || requestVersion.isBlank()) {

            appLogger.initLog().level(LogLevel.ERROR).message(Constants.BAD_REQUEST_RESPONSES)
                    .eventTyp(Constants.LOGS_EVT_TYPE_AUTH).eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
                    .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();
            throw new ApiException(HttpStatus.UNAUTHORIZED.value(), Constants.VERSION_ERROR);
        }
        try {
            redisCacheService.storeJwt(ihmLaunchParams);
            response.setStatus(302);
            response.sendRedirect(feUrl);
        } catch (IOException | IllegalStateException e) {
            throw new ApiException(HttpStatus.UNAUTHORIZED.value(), Constants.REDIRECTION_ERROR);
        }
    }

    /**
     * methode qui intercepte toutes exceptions soulevées lors de la verification du
     * jeton
     *
     * @param ex
     * @param request
     * @param response
     * @param model
     * @return
     */
    @ExceptionHandler
    public String handle(ApiException ex, HttpServletRequest request, HttpServletResponse response, Model model) {
        final var requestStatus = ex.getStatusCode();
        final var requestUrl = request.getRequestURL().toString();
        model.addAttribute(Constants.STATUS, requestStatus);
        model.addAttribute(Constants.REQUESTEXCEPTIONTYPE, "");
        model.addAttribute(Constants.REQUESTURI, requestUrl);
        model.addAttribute(Constants.REQUESTEXCEPTION, ex);
        model.addAttribute(Constants.REQUESTMESSAGE, ex.getMessage());
        response.setStatus(requestStatus);
        return Constants.ERROR_TEMPLATE;
    }
}
