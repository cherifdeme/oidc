package fr.ca.cat.ihml.oidc.bff.jwt.controllers;

import fr.ca.cat.ihml.oidc.bff.cache.RedisCacheService;
import fr.ca.cat.ihml.oidc.bff.models.http.Message;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.jwt.services.messages.EncryptionMessageService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * Controleur qui appelle le service de chiffrage du message
 *
 * @author ETPD355
 */

@RestController
@RequestMapping("/encrypt")
public class MessageEncryptionController {
    private EncryptionMessageService encryptionMessageService;

    @Autowired
    public MessageEncryptionController(final EncryptionMessageService encryptionMessageService, RedisCacheService redisCacheService) {
        this.encryptionMessageService = encryptionMessageService;
        encryptionMessageService.setRedis(redisCacheService);
    }

    @PostMapping("/message")
    @ResponseBody
    public ResponseEntity<Message> encrypt(@RequestBody Message message, HttpServletRequest request) throws ApiException {
        final var result = new Message();
        result.setMessage(encryptionMessageService.cipher(message.getMessage(), request));
        return ResponseEntity.ok(result);
    }
}