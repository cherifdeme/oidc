package fr.ca.cat.ihml.oidc.bff.jwt.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.models.entities.ErrorResponse;
import fr.ca.cat.ihml.oidc.bff.models.entities.UserInfosEntity;
import fr.ca.cat.ihml.oidc.bff.jwt.services.security.OIDCControlService;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.services.logs.ApplicationLogger;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;

@Controller
@RequestMapping("/control")
public class OIDCController {

    private OIDCControlService controlService;

    private static ApplicationLogger appLogger = ApplicationLogger.getLogger(OIDCController.class);

    @Autowired
    public OIDCController(OIDCControlService controlService) {
        super();
        this.controlService = controlService;
    }

    @GetMapping("/token")
    public ResponseEntity<?> controlAllToken() {

        appLogger.initLog().level(LogLevel.INFO).message(Constants.BEGIN_JWT_CONTROL)
                .eventTyp(Constants.LOGS_EVT_TYPE_AUTH).eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTED)
                .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();
        try {
            // on appelle la fonction de verification du token
            controlService.checkToken();
        } catch (ApiException e) {
            return ResponseEntity.ok().body(new ErrorResponse(HttpStatus.FORBIDDEN.value(), e.getMessage()));
        }
        return ResponseEntity.ok().body(new UserInfosEntity());
    }
}
