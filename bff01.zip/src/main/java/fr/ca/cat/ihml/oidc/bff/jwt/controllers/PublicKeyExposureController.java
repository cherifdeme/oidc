package fr.ca.cat.ihml.oidc.bff.jwt.controllers;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.services.logs.ApplicationLogger;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;

/**
 * Controller pour l'exposition de la clé publique
 * 
 * @author ETPD355
 *
 */

@RestController
@RequestMapping("/public")
public class PublicKeyExposureController {

    @Value("${public.key.path}")
    private String publicKeyPath;
    private static ApplicationLogger appLogger = ApplicationLogger.getLogger(PublicKeyExposureController.class);

    @GetMapping("/cert")
    public ResponseEntity<ByteArrayResource> download() throws ApiException {
	try {
	    final var inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(publicKeyPath);
	    final var data = inputStream.readAllBytes();
	    final var resource = new ByteArrayResource(data);
	    appLogger.initLog().level(LogLevel.INFO).message(Constants.BEGIN_DOWNLOAD_PUBLIC_KEY).log();
	    return ResponseEntity.ok()
		    // Content-Disposition
		    .header(HttpHeaders.CONTENT_DISPOSITION, "Attachment;filename=" + publicKeyPath)
		    // Content-Type
		    .contentType(MediaType.APPLICATION_OCTET_STREAM)
		    // Contet-Length
		    .contentLength(resource.contentLength()) //
		    .body(resource);
	} catch (IOException e) {
	    appLogger.initLog().level(LogLevel.ERROR).message(Constants.LOADING_ERROR).log();
	    throw new ApiException(HttpStatus.UNAUTHORIZED.value(), Constants.LOADING_ERROR);
	}
    }
}
