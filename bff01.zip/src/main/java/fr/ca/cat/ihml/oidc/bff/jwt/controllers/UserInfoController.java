package fr.ca.cat.ihml.oidc.bff.jwt.controllers;

import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fr.ca.cat.ihml.oidc.bff.cache.RedisCacheService;
import fr.ca.cat.ihml.oidc.bff.models.entities.UserInfosEntity;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.services.logs.ApplicationLogger;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;

/**
 * Controller qui renvoie les infos du user
 * 
 * @author ETPD355
 *
 */

@RestController
@RequestMapping("/infos")
public class UserInfoController {
    private RedisCacheService redisCacheService;

    @Autowired
    public UserInfoController(RedisCacheService redisCacheService) {
	super();
	this.redisCacheService = redisCacheService;
    }

    private static ApplicationLogger appLogger = ApplicationLogger.getLogger(UserInfoController.class);

    @GetMapping("/users")
    public ResponseEntity<UserInfosEntity> getUserInfos(HttpSession session) {

	appLogger.initLog().level(LogLevel.INFO).message(Constants.GET_USER_DATA).eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
		.eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTED).secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
		.log();
	final var entity = this.redisCacheService.getUserInfos();

	return ResponseEntity.ok().body(entity);
    }
}
