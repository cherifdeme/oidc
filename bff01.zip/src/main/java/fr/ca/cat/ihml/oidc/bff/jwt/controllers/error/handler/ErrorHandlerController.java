package fr.ca.cat.ihml.oidc.bff.jwt.controllers.error.handler;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import fr.ca.cat.ihml.oidc.bff.utils.Constants;

/**
 * Controller qui intercepte les erreurs http et affiche une page d'erreur
 * custom intercepte les erreurs quand un service rest n'est pas disponible
 *
 * @author ETPD355
 */

@Controller
@RequestMapping("/")
public class ErrorHandlerController implements ErrorController {

    @GetMapping(value = "/error")
    public String handleError(HttpServletRequest request, Model model) {

        final var requestStatus = this.getAttribute(request, RequestDispatcher.ERROR_STATUS_CODE);
        final var requestExceptionType = this.getAttribute(request, RequestDispatcher.ERROR_EXCEPTION_TYPE);
        final var requestUri = this.getAttribute(request, RequestDispatcher.ERROR_REQUEST_URI);
        final var requestException = this.getAttribute(request, RequestDispatcher.ERROR_EXCEPTION);
        final var requestMessage = this.getAttribute(request, RequestDispatcher.ERROR_MESSAGE);

        if (!requestStatus.isBlank()) {

            model.addAttribute(Constants.STATUS, requestStatus);
            model.addAttribute(Constants.REQUESTEXCEPTIONTYPE, requestExceptionType);
            model.addAttribute(Constants.REQUESTURI, requestUri);
            model.addAttribute(Constants.REQUESTEXCEPTION, requestException);
            model.addAttribute(Constants.REQUESTMESSAGE, requestMessage);
            return Constants.ERROR_TEMPLATE;
        }
        return Constants.DEFAULT_ERROR_TEMPLATE;
    }

    private String getAttribute(HttpServletRequest request, String id) {
        return request.getAttribute(id) == null ? " " : request.getAttribute(id).toString();
    }
}
