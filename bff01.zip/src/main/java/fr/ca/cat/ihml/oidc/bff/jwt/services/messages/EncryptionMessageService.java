package fr.ca.cat.ihml.oidc.bff.jwt.services.messages;

import java.io.*;
import java.net.URISyntaxException;
import java.net.http.HttpResponse;
import java.security.*;
import java.security.cert.*;
import java.security.cert.Certificate;
import java.security.interfaces.RSAPublicKey;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.KeyGenerator;

import com.nimbusds.jose.*;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.jwk.RSAKey;
import fr.ca.cat.ihml.oidc.bff.cache.RedisCacheService;

import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.ClassicHttpResponse;
import org.apache.hc.core5.http.HttpException;
import org.apache.hc.core5.http.io.HttpClientResponseHandler;
import org.apache.hc.core5.http.io.entity.EntityUtils;
import org.apache.hc.core5.net.URIBuilder;
import org.jose4j.jwt.JwtClaims;
import org.jose4j.lang.JoseException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.nimbusds.jose.crypto.RSAEncrypter;
import com.nimbusds.jose.util.Base64;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.services.logs.ApplicationLogger;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;

/**
 * Service qui chiffre les données sensibles d'un post message
 *
 * @author ETPD355
 */

@Service
public class EncryptionMessageService {
    @Value("${private.key.path}")
    private String privateKeyFile;
    @Value("${private.key.keystore.alias}")
    private String alias;
    @Value("${private.key.keystore.pwd}")
    private String pwd;
    private KeyStore ks;
    @Value("${cert.url}")
    private String publicKeyUrl;
    private Certificate certificate;

    private static ApplicationLogger appLogger = ApplicationLogger.getLogger(EncryptionMessageService.class);

    private RedisCacheService redisCacheService;
    private HttpServletRequest request;

    public void setRedis(RedisCacheService redisCacheService) {
        this.redisCacheService = redisCacheService;
    }

    /**
     * point d'entrée
     *
     * @param message
     * @return jwe
     * @throws ApiException
     */
    public String cipher(final Object message, final HttpServletRequest request) throws ApiException {
        this.request = request;
        return cipher(message, (RSAPublicKey) certificate.getPublicKey());
    }

    /**
     * generation du certificat à partir de la clé publique
     *
     * @param certificateAsString
     * @return certificate
     */
    private static final Certificate generateCert(final String certificateAsString) {
        appLogger.initLog().level(LogLevel.INFO).message(Constants.LOAD_CERT)
                .eventTyp(Constants.LOGS_EVT_CODE_SECURED_DATA_ENCRYPTION)
                .eventCod(Constants.LOGS_EVT_TYPE_SECURED_DATA_ENCRYPTION)
                .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_ENCRYPTION).log();
        CertificateFactory certFactory;
        try {
            certFactory = CertificateFactory.getInstance(Constants.CERTIFICATE_INSTANCE);
            return certFactory.generateCertificate(new ByteArrayInputStream(certificateAsString.getBytes()));
        } catch (CertificateException e) {
            appLogger.initLog().level(LogLevel.ERROR).message(Constants.GET_CERT_ERROR)
                    .eventTyp(Constants.LOGS_EVT_CODE_SECURED_DATA_ENCRYPTION)
                    .eventCod(Constants.LOGS_EVT_TYPE_SECURED_DATA_ENCRYPTION)
                    .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_ENCRYPTION).log();
        }
        return null;
    }

    /**
     * methode qui chiffre la donnée sensible inclut dans un post message renvoie un
     * jeton jwe
     *
     * @return jwe
     * @throws ApiException
     */
    private String cipher(final Object message, RSAPublicKey publicKey) throws ApiException {

        appLogger.initLog().level(LogLevel.INFO).message(Constants.ENCRYPTION_PRECESSING)
                .eventTyp(Constants.LOGS_EVT_CODE_SECURED_DATA_ENCRYPTION)
                .eventCod(Constants.LOGS_EVT_TYPE_SECURED_DATA_ENCRYPTION)
                .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_ENCRYPTION).log();
        try {
            var enc = EncryptionMethod.A256GCM;
            if (javax.crypto.Cipher.getMaxAllowedKeyLength(Constants.AES) == 128) {
                enc = EncryptionMethod.A128GCM;
            }

            //Renvoie un objet KeyGenerator qui génère des clés secrètes pour l'algorithme spécifié.
            final var keyGen = KeyGenerator.getInstance(Constants.AES);
            keyGen.init(enc.cekBitLength());

            //Génère une clé secrète. Retour: la nouvelle clé
            final var cek = keyGen.generateKey();

            final List<Base64> x5c = new ArrayList<>();
            x5c.add(Base64.encode(publicKey.getEncoded()));

            //generation du header jwe
            final var header = new JWEHeader.Builder(JWEAlgorithm.RSA_OAEP_256, enc)
                    .compressionAlgorithm(CompressionAlgorithm.DEF).x509CertChain(x5c).build();

            final var claims = new JwtClaims();
            claims.setSubject(redisCacheService.getSub());
            claims.setAudience("fanfoue", "k8s", "cherif");
            claims.setExpirationTimeMinutesInTheFuture(60);
            claims.setIssuedAtToNow();
            claims.setIssuer(request.getRequestURL().toString());
            claims.setClaim("parametres", message);

            //generation du jeton jwe dont le payload est le message reçu
            final var jwe = new JWEObject(header, new Payload(generateJwt(claims.toJson())));

            //chiffage et retour du jeton
            final var encrypter = new RSAEncrypter(publicKey, cek);
            jwe.encrypt(encrypter);
            return jwe.serialize();

        } catch (JOSEException | NoSuchAlgorithmException e) {
            appLogger.initLog().level(LogLevel.ERROR).message(Constants.ENCRYPTION_ERROR)
                    .eventTyp(Constants.LOGS_EVT_CODE_SECURED_DATA_ENCRYPTION)
                    .eventCod(Constants.LOGS_EVT_TYPE_SECURED_DATA_ENCRYPTION)
                    .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_ENCRYPTION).log();
            throw new ApiException(HttpStatus.SERVICE_UNAVAILABLE.value(),
                    Constants.IMPOSSIBLE_DE_CHIFFRER_LE_POST_MESSAGE);
        }
    }

    /**
     * generation du jwt
     *
     * @param message
     * @return jwt
     * @throws JoseException
     * @throws CertificateException
     * @throws KeyStoreException
     * @throws JOSEException
     */
    private String generateJwt(final String message) throws ApiException {
        try {
            final var key4sign = RSAKey.load(ks, alias, pwd.toCharArray());
            final var signer = new RSASSASigner(key4sign);
            List<Base64> x5c = new ArrayList<>();
            x5c.add(Base64.encode(ks.getCertificate(alias).getEncoded()));

            // Prepare JWS object with simple string as payload
            final var jwsObject = new JWSObject(
                    new JWSHeader.Builder(JWSAlgorithm.RS256).type(JOSEObjectType.JWT).x509CertChain(x5c).build(),
                    new Payload(message));

            jwsObject.sign(signer);

            return jwsObject.serialize();

        } catch (JOSEException | KeyStoreException | CertificateEncodingException e) {
            appLogger.initLog().level(LogLevel.ERROR).message(Constants.IMPOSSIBLE_DE_GÉNÉRER_LE_JWT)
                    .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
                    .eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
                    .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();
            throw new ApiException(HttpStatus.FORBIDDEN.value(), Constants.IMPOSSIBLE_DE_GÉNÉRER_LE_JWT);
        }
    }

    /**
     * recuperation de la clé publique
     *
     * @throws ApiException
     * @throws URISyntaxException
     */
    @PostConstruct
    public void getPublicKey() throws ApiException, URISyntaxException {

        try (final CloseableHttpClient httpclient = HttpClients.createDefault()) {
            //creation de luri à partir de l'url de la clé publique
            final var uriBuilder = new URIBuilder(this.getPublicKeyUrl());
            final var httpget = new HttpGet(uriBuilder.build().toString());
            final var httpClientResponseHandler = new HttpClientResponseHandler<Certificate>() {
                //recuperation de la clé publique puis on génére le certificat
                @Override
                public Certificate handleResponse(ClassicHttpResponse response) throws HttpException, IOException {
                    final var status = response.getCode();
                    if (status >= 200 && status < 300) {
                        final var entity = response.getEntity();
                        if (entity == null) {
                            return null;
                        }
                        return generateCert(EntityUtils.toString(entity));
                    }
                    return null;
                }
            };
            //on recupere le certificat qui contient la clé publique
            certificate = httpclient.execute(httpget, httpClientResponseHandler);
            appLogger.initLog().level(LogLevel.INFO).message(Constants.CERT_LOADED)
                    .eventTyp(Constants.LOGS_EVT_CODE_SECURED_DATA_ENCRYPTION)
                    .eventCod(Constants.LOGS_EVT_TYPE_SECURED_DATA_ENCRYPTION)
                    .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_ENCRYPTION).log();
            if (certificate == null) {
                throw new ApiException(HttpStatus.SERVICE_UNAVAILABLE.value(),
                        Constants.IMPOSSIBLE_DE_RECUPERER_LE_CERTIFICAT);
            }
        } catch (IOException e) {
            appLogger.initLog().level(LogLevel.ERROR).message(Constants.GET_CERT_ERROR)
                    .eventTyp(Constants.LOGS_EVT_CODE_SECURED_DATA_ENCRYPTION)
                    .eventCod(Constants.LOGS_EVT_TYPE_SECURED_DATA_ENCRYPTION)
                    .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_ENCRYPTION).log();
        }
    }

    /**
     * on charge le keyStore
     */
    @PostConstruct
    public void laodPrivateKey() throws ApiException {

        if (null == privateKeyFile || privateKeyFile.isEmpty())
            return;

        InputStream is = null;
        try {
            //Retourne un flux d'entrée pour lire la ressource spécifiée.
            is = Thread.currentThread().getContextClassLoader().getResourceAsStream(privateKeyFile);
            if (null == is) {
                appLogger.initLog().level(LogLevel.ERROR).message(Constants.KEY_STORE_INTROUVABLE)
                        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
                        .eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
                        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();
                throw new ApiException(HttpStatus.FORBIDDEN.value(), Constants.KEY_STORE_INTROUVABLE);
            }

            ks = KeyStore.getInstance("PKCS12");
            ks.load(is, pwd.toCharArray());

        } catch (KeyStoreException | RuntimeException | CertificateException | NoSuchAlgorithmException
                 | IOException e) {
            appLogger.initLog().level(LogLevel.ERROR).message(Constants.KEY_STORE_INTROUVABLE)
                    .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
                    .eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
                    .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();
            throw new ApiException(HttpStatus.FORBIDDEN.value(), Constants.KEY_STORE_INTROUVABLE);
        }
    }

    public String getPublicKeyUrl() {
        return publicKeyUrl;
    }

    public void setPublicKeyUrl(final String publicKeyUrl) {
        this.publicKeyUrl = publicKeyUrl;
    }

    public String getPrivateKeyFile() {
        return privateKeyFile;
    }

    public void setPrivateKeyFile(String privateKeyFile) {
        this.privateKeyFile = privateKeyFile;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public void setCertificate(Certificate certificate) {
        this.certificate = certificate;
    }
}