package fr.ca.cat.ihml.oidc.bff.jwt.services.security;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.services.logs.ApplicationLogger;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.io.*;
import java.nio.file.Paths;
import java.security.*;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Service qui lit le fichier truststore à l'init et verifie si le AC autorise
 * le certificat contenu dans le jeton
 *
 * @author ETPD355
 */

@Service
public class CAControlService {
    private X509Certificate issuerCert;
    private X509Certificate root;
    @Value("${truststore.ac.store}")
    private String fileName;
    @Value("${truststore.pwd}")
    private String pwd;
    @Value("${truststore.ac.alias}")
    private String alias;
    @Value("${truststore.ac.root.alias}")
    private String rootAlias;

    private static ApplicationLogger appLogger = ApplicationLogger.getLogger(CAControlService.class);

    /**
     * recuperation fichier truststore et chargement du certificat
     *
     * @throws KeyStoreException
     * @throws NoSuchAlgorithmException
     * @throws CertificateException
     * @throws ApiException
     */
    @PostConstruct
    public void initAC() throws ApiException {

        final var currentRelativePath = Paths.get("");
        final var baseDirectory = currentRelativePath.toAbsolutePath().toString();

        final var file = new File(baseDirectory + fileName);

        if (null == fileName || fileName.isEmpty())
            return;
        //Retourne un flux d'entrée pour lire la ressource spécifiée.
        InputStream is = null;
        try {
            is = new FileInputStream(file);
            // obtention du mot de passe de l'utilisateur et le flux d'entrée du fichier
            var password = pwd.toCharArray();

            //Renvoie un objet keystore du type spécifié.
            final var ks = KeyStore.getInstance(Constants.KEY_STORE_INSTANCE);

            //Charge ce KeyStore à partir du flux d'entrée donné.
            ks.load(is, password);
            appLogger.initLog().level(LogLevel.INFO).message(Constants.TRUSTSTORE_CHARGED)
                    .eventTyp(Constants.LOGS_EVT_TYPE_AUTH).eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTED)
                    .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();
            if (ks.isCertificateEntry(alias)) {
                var certificate = ks.getCertificate(alias);
                var cf = CertificateFactory.getInstance(Constants.CERTIFICATE_INSTANCE);
                var byteArray = new ByteArrayInputStream(certificate.getEncoded());
                var x509Certificate = (X509Certificate) cf.generateCertificate(byteArray);
                this.setIssuerCert(x509Certificate);
            } else {
                appLogger.initLog().level(LogLevel.ERROR).message(Constants.ALIAS_TRUSTSTORE_NOT_FOUND)
                        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
                        .eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
                        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();
                throw new ApiException(HttpStatus.FORBIDDEN.value(), Constants.ALIAS_TRUSTSTORE_NOT_FOUND);
            }
            if (ks.isCertificateEntry(rootAlias)) {
                var certificate = ks.getCertificate(rootAlias);
                var cf = CertificateFactory.getInstance(Constants.CERTIFICATE_INSTANCE);
                var byteArray = new ByteArrayInputStream(certificate.getEncoded());
                var rootCA = (X509Certificate) cf.generateCertificate(byteArray);
                this.setRoot(rootCA);
            } else {
                appLogger.initLog().level(LogLevel.ERROR).message(Constants.ALIAS_TRUSTSTORE_ROOT_NOT_FOUND)
                        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
                        .eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
                        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();
                throw new ApiException(HttpStatus.FORBIDDEN.value(), Constants.ALIAS_TRUSTSTORE_NOT_FOUND);
            }
        } catch (KeyStoreException | NoSuchAlgorithmException | CertificateException | FileNotFoundException e) {
            appLogger.initLog().level(LogLevel.ERROR).message(Constants.TRUSTSTORE_NOT_FOUND)
                    .eventTyp(Constants.LOGS_EVT_TYPE_AUTH).eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
                    .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();
            appLogger.initLog().level(LogLevel.ERROR).message(e.getMessage())
                    .eventTyp(Constants.LOGS_EVT_TYPE_AUTH).eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
                    .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();
            throw new ApiException(HttpStatus.FORBIDDEN.value(), Constants.TRUSTSTORE_NOT_FOUND);

        } catch (IOException e) {
            appLogger.initLog().level(LogLevel.ERROR).message(Constants.ALIAS_TRUSTSTORE_NOT_FOUND)
                    .eventTyp(Constants.LOGS_EVT_TYPE_AUTH).eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
                    .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();
            throw new ApiException(HttpStatus.FORBIDDEN.value(), Constants.ALIAS_TRUSTSTORE_NOT_FOUND);
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    appLogger.initLog().level(LogLevel.ERROR).message(Constants.TRUSTSTORE_CLOSING_ERROR)
                            .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
                            .eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
                            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();
                }
            }
        }
    }

    /**
     * validation du certificat issu du jeton et verification par le AC
     *
     * @param certificate
     * @return
     * @throws GeneralSecurityException
     */
    public boolean validate(final X509Certificate certificate) {
        try {
            // Vérifier que la chaîne d’Autorité de Certification (AC) émettrice du
            // certificat n’est pas expirée.
            issuerCert.checkValidity();
            isSignerAuthorized(certificate);
            appLogger.initLog().level(LogLevel.INFO).message(Constants.VALIDATED_WITH_AC)
                    .eventTyp(Constants.LOGS_EVT_TYPE_AUTH).eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTED)
                    .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();
            return true;

        } catch (InvalidKeyException | CertificateException | NoSuchAlgorithmException | NoSuchProviderException
                 | SignatureException e) {
            appLogger.initLog().level(LogLevel.ERROR).message(Constants.CERTIFICAT_NOT_VALIDATED_WITH_AC)
                    .eventTyp(Constants.LOGS_EVT_TYPE_AUTH).eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
                    .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();
            return false;
        }
    }

    /**
     * Vérification de la validité de la signature de la clé publique transmise dans
     * le certificat par la clé publique de l'AC émettrice.
     *
     * @param sigCert
     * @throws InvalidKeyException
     * @throws CertificateException
     * @throws NoSuchAlgorithmException
     * @throws NoSuchProviderException
     * @throws SignatureException
     */
    private void isSignerAuthorized(final X509Certificate sigCert) throws InvalidKeyException, CertificateException,
            NoSuchAlgorithmException, NoSuchProviderException, SignatureException {

        //Vérifie que ce certificat a été signé à l'aide de la clé privée qui correspond à la clé publique spécifiée.
        sigCert.verify(this.getIssuerCert().getPublicKey());
    }

    public X509Certificate getIssuerCert() {
        return issuerCert;
    }

    private void setIssuerCert(X509Certificate issuerCert) {
        this.issuerCert = issuerCert;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getAlias() {
        return alias;
    }

    public void setAlias(String alias) {
        this.alias = alias;
    }

    public X509Certificate getRoot() {
        return root;
    }

    public void setRoot(X509Certificate root) {
        this.root = root;
    }
}
