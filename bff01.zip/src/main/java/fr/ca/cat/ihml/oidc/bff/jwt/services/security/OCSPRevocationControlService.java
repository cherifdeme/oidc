package fr.ca.cat.ihml.oidc.bff.jwt.services.security;

import java.io.BufferedOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Authenticator;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.PasswordAuthentication;
import java.net.Proxy;
import java.net.URL;
import java.security.cert.CertificateEncodingException;
import java.security.cert.X509Certificate;

import jakarta.annotation.PostConstruct;
import org.bouncycastle.asn1.oiw.OIWObjectIdentifiers;
import org.bouncycastle.asn1.x509.AlgorithmIdentifier;
import org.bouncycastle.cert.X509CertificateHolder;
import org.bouncycastle.cert.ocsp.BasicOCSPResp;
import org.bouncycastle.cert.ocsp.CertificateID;
import org.bouncycastle.cert.ocsp.OCSPException;
import org.bouncycastle.cert.ocsp.OCSPReq;
import org.bouncycastle.cert.ocsp.OCSPReqBuilder;
import org.bouncycastle.cert.ocsp.OCSPResp;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.jcajce.JcaDigestCalculatorProviderBuilder;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.services.logs.ApplicationLogger;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;

/**
 * Service qui controle la non revocation du certificat issu du token
 *
 * @author ETPD355
 */

@Service
public class OCSPRevocationControlService {
    public static final int OCSP_CONNECT_TIMEOUT = 10000; // 10 sec
    private static ApplicationLogger appLogger = ApplicationLogger.getLogger(OCSPRevocationControlService.class);

    @Value("${ocsp.url}")
    private String ocspUrl;

    @Value("${proxy.adress}")
    private String proxyAdress;

    @Value("${proxy.port}")
    private int proxyPort;

    @Value("${proxy.username}")
    private String proxyUsername;

    @Value("${proxy.secret}")
    private String proxyPassword;


    /**
     * Fonction qui fait appelle au serveur OCSP pour le controle de la non revocation
     * @param cert
     * @param issuerCertificate
     * @return
     * @throws ApiException
     * @throws IOException
     */
    public boolean check(final X509Certificate cert, final X509Certificate issuerCertificate)
            throws ApiException, IOException {

        try {
            //recuperation de l'identifiant de l'algo
            var id = new AlgorithmIdentifier(OIWObjectIdentifiers.idSHA1);

            //créer à partir d'un certificat émetteur et du numéro de série du certificat qu'il a signé.
            var certificateId = new CertificateID(new JcaDigestCalculatorProviderBuilder().build().get(id),
                    new X509CertificateHolder(issuerCertificate.getEncoded()), cert.getSerialNumber());

            //Générer une requête OCSP non signée
            final var ocspReq = new OCSPReqBuilder().addRequest(certificateId).build();

            //recuperation de la reponse et traitement de celle ci
            final var resp = getResponse(ocspReq);

            //Récupère le contenu de la connexion URL.

            return responseProcessing(resp);

        } catch (OperatorCreationException | OCSPException | CertificateEncodingException | ApiException e) {
            throw new ApiException(HttpStatus.FORBIDDEN.value(), Constants.OCSP_VERIFICATION_PROBLEM);
        }
    }

    /**
     * traitement de la reponse du serveur OCSP
     * retourne "true" si la reponse du serveur OCSP est 0 et "false" dans les autres cas
     * @param con
     * @return
     * @throws ApiException
     * @throws OCSPException
     */
    private boolean responseProcessing(final HttpURLConnection con) throws ApiException, OCSPException, IOException {
        final var in = (InputStream) con.getContent();
        final var ocspResp = new OCSPResp(in);
        if (ocspResp.getStatus() == OCSPResp.SUCCESSFUL) {
                if (ocspResp.getResponseObject() instanceof BasicOCSPResp) {
                    appLogger.initLog().level(LogLevel.INFO).message(Constants.OCSP_CERTIFICATE_NOT_REVOKED)
                            .eventTyp(Constants.LOGS_EVT_TYPE_AUTH).eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTED)
                            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();
                    return true;
                } else {
                    throw new ApiException(HttpStatus.FORBIDDEN.value(), Constants.OCSP_VERIFICATION_PROBLEM);
                }
        }
        con.disconnect();
        return false;
    }

    /**
     * Fonction qui appelle le serveur OCSP et traitement de la reponse
     *
     * @param ocspReq
     * @return
     * @throws ApiException
     */
    private HttpURLConnection getResponse(final OCSPReq ocspReq) throws ApiException {
        try {

            appLogger.initLog().level(LogLevel.INFO).message("debut du controle de la non revocation")
                    .eventTyp(Constants.LOGS_EVT_TYPE_AUTH).eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTED)
                    .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();

            appLogger.initLog().level(LogLevel.INFO)
                    .message("serveur OCSP: " + ocspUrl + " " + proxyAdress + " " + proxyPort + " " + proxyUsername + " " + proxyPassword)
                    .eventTyp(Constants.LOGS_EVT_TYPE_AUTH).eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTED)
                    .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();

            var array = ocspReq.getEncoded();

            var url = new URL(ocspUrl);
            var webProxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(this.proxyAdress, this.proxyPort));

            //ouverture de connection vers le serveur ocsp à travers le proxy
            var con = (HttpURLConnection) url.openConnection();
            con.setConnectTimeout(OCSP_CONNECT_TIMEOUT);
            con.setReadTimeout(OCSP_CONNECT_TIMEOUT);
            con.setRequestProperty("Content-Type", "application/ocsp-request");
            con.setRequestProperty("Accept", "application/ocsp-response");
            con.setRequestProperty("Content-length", String.valueOf(array.length));
            con.setDoOutput(true);
            //ec
            var out = con.getOutputStream();
            var dataOut = new DataOutputStream(new BufferedOutputStream(out));
            dataOut.write(array);
            dataOut.flush();
            dataOut.close();

            //verification de la reponse
            if (con.getResponseCode() / 100 != 2) {
                appLogger.initLog().level(LogLevel.ERROR).message(Constants.ERREUR_LORS_DU_CONTROLE_OCSP + con.getResponseCode())
                        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
                        .eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
                        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();

                throw new ApiException(HttpStatus.FORBIDDEN.value(), Constants.OCSP_REVOCATION_STATE_ERROR);
            }

            return con;

        } catch (IOException | ApiException e) {
            appLogger.initLog().level(LogLevel.ERROR).message(Constants.ERREUR_LORS_DU_CONTROLE_OCSP + e.getMessage())
                    .eventTyp(Constants.LOGS_EVT_TYPE_AUTH).eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
                    .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();

            throw new ApiException(HttpStatus.FORBIDDEN.value(), Constants.OCSP_REVOCATION_STATE_ERROR);
        }
    }

    /**
     * configuration du proxy
     */
    @PostConstruct
    public void setProxy() {
        Authenticator authenticator = new Authenticator() {
            @Override
            public PasswordAuthentication getPasswordAuthentication() {
                return (new PasswordAuthentication(proxyUsername, proxyPassword.toCharArray()));
            }
        };
        Authenticator.setDefault(authenticator);
    }
}
