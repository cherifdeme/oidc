package fr.ca.cat.ihml.oidc.bff.jwt.services.security;

import java.io.IOException;
import java.net.URISyntaxException;
import java.security.cert.CertPathValidatorException;
import java.util.LinkedHashMap;
import java.util.List;

import fr.ca.cat.ihml.oidc.bff.utils.AppUtils;
import org.jose4j.jwa.AlgorithmConstraints;
import org.jose4j.jwa.AlgorithmConstraints.ConstraintType;
import org.jose4j.jwe.JsonWebEncryption;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.jwt.MalformedClaimException;
import org.jose4j.jwt.consumer.ErrorCodes;
import org.jose4j.jwt.consumer.InvalidJwtException;
import org.jose4j.jwt.consumer.JwtConsumerBuilder;
import org.jose4j.keys.resolvers.X509VerificationKeyResolver;
import org.jose4j.lang.JoseException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import fr.ca.cat.ihml.oidc.bff.cache.RedisCacheService;
import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.models.entities.UserInfosEntity;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.services.api.ApiService;
import fr.ca.cat.ihml.oidc.bff.services.logs.ApplicationLogger;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;

/**
 * service qui se charge de controller la validité de la signature, le controle
 * par le CA et de controler la revoction soit par le serveur OCSP soit par java
 * à travers un traitement avec le fichier CRL
 *
 * @author ETPD355
 */

@Service
public class OIDCControlService extends ApiService {

    private static ApplicationLogger appLogger = ApplicationLogger.getLogger(OIDCControlService.class);

    private CAControlService authorityChecker;

    private RedisCacheService redisCacheService;

    private OCSPRevocationControlService revoctionController;
    @Value("${private.key.path}")
    private String privateKey;

    @Value("${private.key.keystore.pwd}")
    private String pwd;

    @Value("${private.key.keystore.alias}")
    private String alias;

    @Autowired
    public OIDCControlService(CAControlService authorityChecker, OCSPRevocationControlService revoctionController,
                              RedisCacheService redisCacheService) {
        super();
        this.authorityChecker = authorityChecker;
        this.revoctionController = revoctionController;
        this.redisCacheService = redisCacheService;
    }

    /**
     * Cette methode fait la verification du jeton jwt
     *
     * @throws MalformedClaimException
     * @throws JoseException
     * @throws InvalidJwtException
     * @throws URISyntaxException
     * @throws CertPathValidatorException
     * @throws ApiException
     * @throws IOException
     */
    public void checkToken() throws ApiException {
        try {
            //recuperation du jeton jwt à partir du cache Redis
            var jwt = this.redisCacheService.getJwt();

            //si le jeton jwt est nul ou vide, on leve une exception
            if (jwt.isBlank()) {
                appLogger.initLog().level(LogLevel.ERROR).message(Constants.TOKEN_NULL)
                        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
                        .eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
                        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();

                throw new ApiException(HttpStatus.FORBIDDEN.value(), Constants.TOKEN_NULL);
            }

            //on dechiffre le jeton si c'est un jwe ou renvoie le jeton jwt
            final var token = decryptAndGetJwt(jwt);

            final var firstPassJwtConsumer = new JwtConsumerBuilder().setSkipAllValidators()
                    .setDisableRequireSignature().setSkipSignatureVerification().build();

            //la librairie JOSE parse le jeton
            final var jwtContext = firstPassJwtConsumer.process(token);

            //recuperation des parties du jeton
            final var joseObjects = jwtContext.getJoseObjects();
            final var rawJson = (LinkedHashMap<?, ?>) jwtContext.getJwtClaims()
                    .getClaimValue(Constants.JWT_LAUNCH_CONTEXT);
            final var jwtSub = (String) jwtContext.getJwtClaims().getClaimValue(Constants.SUB);

            //le resulat du parsing est vide, ce n'est pas normal, on leve une exception
            if (joseObjects.isEmpty()) {
                appLogger.initLog().level(LogLevel.ERROR).message(Constants.ERROR_JETON_JWT)
                        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
                        .eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
                        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();

                throw new ApiException(HttpStatus.FORBIDDEN.value(), Constants.ERROR_JETON_JWT);
            }

            final var joseObject = joseObjects.get(0);

            //Recuperation de l'algo utilisé pour le hashage
            final var algo = joseObject.getAlgorithm().getAlgorithmIdentifier();

            //recuperation des certificats inclus dans le jeton jwt
            final var certificates = joseObject.getCertificateChainHeaderValue();

            //si la signature est vide on arrete la verification
            if (certificates.isEmpty()) {
                appLogger.initLog().level(LogLevel.ERROR).message(Constants.CERTIFICAT_VIDE)
                        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
                        .eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
                        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();

                throw new ApiException(HttpStatus.FORBIDDEN.value(), Constants.CERTIFICAT_VIDE);
            }

            //recuperation du certificat dans la liste
            final var certificate = certificates.get(0);

            final var x509VerificationKeyResolver = new X509VerificationKeyResolver(certificate);
            x509VerificationKeyResolver.setTryAllOnNoThumbHeader(true);

            final var signature = new JsonWebSignature();

            //Définir les contraintes de l'algorithme en fonction de ce qui est convenu ou
            //attendu de l'expéditeur
            signature.setAlgorithmConstraints(new AlgorithmConstraints(ConstraintType.PERMIT, algo));

            //Définir la sérialisation compacte sur le JWS
            signature.setCompactSerialization(token);
            signature.setKey(certificate.getPublicKey());
            signature.setPayload(jwtContext.getJwtClaims().getRawJson());

            //Verification de la signature
            signatureVerification(signature);

            //recuperation de la validité du certificat par l'autorité de certification et check de la non revocation du certificat par OCSP
            final var issuerCert = authorityChecker.getIssuerCert();

            final var result = authorityChecker.validate(certificate)
                    && revoctionController.check(certificate, issuerCert);
           // && revoctionController.check(issuerCert, authorityChecker.getRoot());

            //Si on arrive à ce stage la signature est OK
            final var jwtConsumer = new JwtConsumerBuilder().setRequireSubject()
                    .setVerificationKeyResolver(x509VerificationKeyResolver).setSkipDefaultAudienceValidation()
                    .setJwsAlgorithmConstraints(ConstraintType.PERMIT, algo) // which is only RS256 here
                    .build();

            //validation du jeton jwt
            jwtConsumer.processToClaims(token);
            appLogger.initLog().level(LogLevel.INFO).message(Constants.JWT_TOKEN_VALID)
                    .eventTyp(Constants.LOGS_EVT_TYPE_AUTH).eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTED)
                    .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();

            //le certificat est validé par le CA et non revoqué
            if (result) {
                appLogger.initLog().level(LogLevel.INFO).message(Constants.JWT_TOKEN_VALID_NO_REVOKED)
                        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH).eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTED)
                        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();
            } else {
                throw new ApiException(HttpStatus.FORBIDDEN.value(), Constants.JWT_TOKEN_INVALID);
            }

            //extracton des données du user
            final var userDatabase = (List<?>) rawJson.get(Constants.USER_ENTITLEMENTS);
            final var userInfo = (LinkedHashMap<?, ?>) userDatabase.get(0);
            final var userInfosEntity = new UserInfosEntity((String) userInfo.get(Constants.UOM_CODE),
                    (String) userInfo.get(Constants.USER_PROFILE), (List<?>) userInfo.get(Constants.ADDITIONAL_ELEMENT),
                    jwtSub);

            //sauvegarde des données du user connecté
            redisCacheService.storeUserInfos(userInfosEntity);
            appLogger.initLog().level(LogLevel.INFO).message(Constants.USER_DATA_SAVED)
                    .eventTyp(Constants.LOGS_EVT_TYPE_AUTH).eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTED)
                    .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();

            //le jeton jwt est invalide
        } catch (InvalidJwtException e) {
            appLogger.initLog().level(LogLevel.ERROR).message(Constants.JWT_TOKEN_INVALID)
                    .eventTyp(Constants.LOGS_EVT_TYPE_AUTH).eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
                    .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();

            //le jeton jwt est expiré
            if (e.hasExpired()) {
                appLogger.initLog().level(LogLevel.ERROR).message(Constants.JWT_TOKEN_EXPIRED)
                        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
                        .eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
                        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();
            }

            //peut-être que l'audience n'était pas valide
            if (e.hasErrorCode(ErrorCodes.AUDIENCE_INVALID)) {
                appLogger.initLog().level(LogLevel.ERROR).message(Constants.JWT_AUDIENCE_INCORRECT)
                        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
                        .eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
                        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();
            }
            throw new ApiException(HttpStatus.FORBIDDEN.value(), Constants.JWT_TOKEN_INVALID);

        } catch (JoseException e) {
            appLogger.initLog().level(LogLevel.ERROR).message(Constants.JWT_TOKEN_INVALID)
                    .eventTyp(Constants.LOGS_EVT_TYPE_AUTH).eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
                    .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();

            throw new ApiException(HttpStatus.FORBIDDEN.value(), Constants.JWT_TOKEN_INVALID);
        } catch (ApiException e) {
            appLogger.initLog().level(LogLevel.ERROR).message(e.getMessage()).eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
                    .eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
                    .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();

            throw e;
        } catch (IOException e) {
            throw new ApiException(HttpStatus.FORBIDDEN.value(), Constants.JWT_TOKEN_INVALID);
        }
    }

    /**
     * dechiffrement du jeton jwe, ce type de jeton possede 5 parties encodées, separées par des points
     *
     * @param token
     * @return token
     * @throws ApiException
     * @throws JoseException
     */
    private String decryptAndGetJwt(String token) throws ApiException, JoseException {

        //on verifie si c'est un jeton jwe puis on le dechiffre
        if (token.split("\\.").length == 5) {
            appLogger.initLog().level(LogLevel.INFO).message("Debut de verification et decryptage du jwe")
                    .eventTyp(Constants.LOGS_EVT_TYPE_AUTH).eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTED)
                    .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();
            var jwe = new JsonWebEncryption();

            //on renseigne la clé privée dans le but de dechiffrer le jeton
            jwe.setKey(AppUtils.loadKeyStore(privateKey, pwd, alias));
            jwe.setCompactSerialization(token);
            return jwe.getPayload();
        }
        return token;
    }

    /**
     * Cette methode fait la verication de la signature du jeton jwt
     *
     * @param jws
     * @throws JoseException
     * @throws ApiException
     */
    private void signatureVerification(final JsonWebSignature jws) throws ApiException {
        try {
            jws.verifySignature();
        } catch (JoseException e) {
            appLogger.initLog().level(LogLevel.ERROR).message(Constants.SIGN_INVALID)
                    .eventTyp(Constants.LOGS_EVT_TYPE_AUTH).eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
                    .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();
            throw new ApiException(HttpStatus.FORBIDDEN.value(), Constants.SIGN_INVALID);
        }

        appLogger.initLog().level(LogLevel.INFO).message(Constants.SIGN_VALID).eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
                .eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTED).secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
                .log();
    }
}
