package fr.ca.cat.ihml.oidc.bff.metrics;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.autoconfigure.metrics.MeterRegistryCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.micrometer.core.aop.TimedAspect;
import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Tags;
import io.micrometer.core.instrument.config.MeterFilter;

@Configuration
public class MetricsConfiguration {

	@Bean
	public MeterRegistryCustomizer<MeterRegistry> metricsCommonTags() {
		return registry -> registry.config().meterFilter(new MeterFilter() {
			@Override
			public Meter.Id map(Meter.Id id) {
				String description = id.getDescription();
				if (Objects.nonNull(description) && description.contains("\"")) {
					description = description.replace("\"", "");
				}

				return new Meter.Id(id.getName(), Tags.of(id.getTags()), id.getBaseUnit(), description, id.getType());
			}
		});
	}

	@Bean
	@Autowired
	public TimedAspect timedAspect(MeterRegistry meterRegistry) {
		return new TimedAspect(meterRegistry);
	}
}
