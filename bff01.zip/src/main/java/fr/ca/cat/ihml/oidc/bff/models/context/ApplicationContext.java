package fr.ca.cat.ihml.oidc.bff.models.context;

import jakarta.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;

import fr.ca.cat.ihml.oidc.bff.utils.AppUtils;

/**
 * Classe décrivant le contexte de l'application
 * 
 * @author ET02720
 *
 */
public class ApplicationContext {

    /**
     * le client Id de l'application ciblée
     * 
     * @see ApplicationContext#getClientId()
     * @see ApplicationContext#setClientId(string)
     */
    @NotBlank
    private String clientId;

    /**
     * Id de la CR
     * 
     * @see ApplicationContext#getRegionalBankId()
     * @see ApplicationContext#setRegionalBankId(String)
     */
    @NotBlank
    private String regionalBankId;

    /**
     * Code postal de la ville
     * 
     * @see ApplicationContext#getZipCode()
     * @see ApplicationContext#setZipCode(String)
     */
    @NotBlank
    private String zipCode;

    /**
     * Retourne le client Id de l'application ciblée
     * 
     * @return L'idClient de l'application ciblée
     */
    @JsonProperty(value = "client_id", required = false)
    public String getClientId() {
        return clientId;
    }

    /**
     * Met à jour le client Id de l'application ciblée
     * 
     * @param clientId Le nouvel client Id de l'application ciblée
     */
    @JsonProperty(value = "client_id", required = false)
    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    /**
     * Retourne l'Id de la CR
     * 
     * @return L'Id de la CR
     */
    @JsonProperty(value = "regional_bank_id", required = false)
    public String getRegionalBankId() {
        return regionalBankId;
    }

    /**
     * Met à jour l'Id de la CR
     * 
     * @param regionalBankId Le nouvel Id de la CR
     */
    @JsonProperty(value = "regional_bank_id", required = false)
    public void setRegionalBankId(String regionalBankId) {
        this.regionalBankId = regionalBankId;
    }

    /**
     * Retourne le code postal de la ville
     * 
     * @return Le code postal de la ville
     */
    @JsonProperty(value = "zip_code", required = false)
    public String getZipCode() {
        return zipCode;
    }

    /**
     * Met à jour le code postal de la ville
     * 
     * @param zipCode Le nouveau code postal de la ville
     */
    @JsonProperty(value = "zip_code", required = false)
    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    /**
     * Convertir un {@link ApplicationContext} en chaine JSON
     * 
     * @return une chaine JSON
     * @throws JsonProcessingException
     */
    public String toJsonString() throws JsonProcessingException {
        return AppUtils.convertObjectToJsonString(this);
    }
}
