package fr.ca.cat.ihml.oidc.bff.models.context;

import java.io.IOException;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.type.TypeReference;

import fr.ca.cat.ihml.oidc.bff.utils.AppUtils;

/**
 * Classe pour définir le contexte renvoyé par l'API CTX9
 * 
 * @author ET02720
 *
 */
public class Ctx9ReadContext {

    /**
     * Contexte renvoyé par l'API CTX9
     * 
     * @see {@link Ctx9ReadContext#getContext()}
     * @see {@link Ctx9ReadContext#setContext()}
     */
    private String context;

    /**
     * Retourne le contexte CTX9
     * 
     * @return Un contexte au format string
     */
    @JsonProperty(value = "context")
    public String getContext() {
        return context;
    }

    /**
     * Spécifie le contexte CTX9
     * 
     * @param context Un contexte au format string
     */
    @JsonProperty(value = "context")
    public void setContext(String context) {
        this.context = context;
    }

    /**
     * Convertir {@link Ctx9ReadContext} en {@link ApplicationContext}
     * 
     * @return {@link ApplicationContext}
     * @throws IOException
     */
    public ApplicationContext toApplicationContext() throws IOException {
        return AppUtils.jsonStringToObject(this.context, new TypeReference<ApplicationContext>() {
        });
    }

}
