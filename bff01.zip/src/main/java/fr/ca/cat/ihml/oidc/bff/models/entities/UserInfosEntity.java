package fr.ca.cat.ihml.oidc.bff.models.entities;

import java.io.Serializable;
import java.util.List;

/**
 * DTO pour les infos de l'utilisateur inclus dans le token
 *
 * @author ETPD355
 */

public class UserInfosEntity implements Serializable {
    private String uomCode;
    private String userProfile;
    private List<?> additionalElement;
    private String sub;

    private static final long serialVersionUID = 3033154127634134191L;

    public UserInfosEntity(String uomCode, String userProfile, List<?> list, String sub) {
        super();
        this.uomCode = uomCode;
        this.userProfile = userProfile;
        this.additionalElement = list;
        this.sub = sub;
    }

    public UserInfosEntity() {
        super();
    }

    public String getUomCode() {
        return uomCode;
    }

    public void setUomCode(String uomCode) {
        this.uomCode = uomCode;
    }

    public String getUserProfile() {
        return userProfile;
    }

    public void setUserProfile(String userProfile) {
        this.userProfile = userProfile;
    }

    public List<?> getAdditionalElement() {
        return additionalElement;
    }

    public void setAdditionalElement(List<?> additionalElement) {
        this.additionalElement = additionalElement;
    }

    public String getSub() {
        return sub;
    }

    public void setSub(String sub) {
        this.sub = sub;
    }
}
