package fr.ca.cat.ihml.oidc.bff.models.http;

/**
 * Objet définissant une réponse suite à une erreur
 * 
 * @author ET02720
 *
 */
public class ErrorResponse {

    /**
     * Message de la réponse
     * 
     * @see ErrorResponse#getMessage()
     * @see ErrorResponse#setMessage(String)
     */
    private String message;

    /**
     * Code HTTP de la réponse
     * 
     * @see ErrorResponse#getStatus()
     * @see ErrorResponse#setStatus(int)
     */
    private int status;

    /**
     * Retourne le message de l'erreur
     * 
     * @return Le message de l'erreur
     */
    public String getMessage() {
        return message;
    }

    /**
     * Met à jour le message de l'erreur
     * 
     * @param message Le nouveau message de l'erreur
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * Retourne le code HTTP de l'erreur
     * 
     * @return Le code HTTP de l'erreur
     */
    public int getStatus() {
        return status;
    }

    /**
     * Met à jour le code HTTP de l'erreur
     * 
     * @param status Le nouveau code HTTP de l'erreur
     */
    public void setStatus(int status) {
        this.status = status;
    }

}
