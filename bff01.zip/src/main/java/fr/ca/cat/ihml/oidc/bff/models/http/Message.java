package fr.ca.cat.ihml.oidc.bff.models.http;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class Message implements Serializable {
    private static final long serialVersionUID = -4733386772230040013L;
    @JsonProperty("message")
    private Object msg;

    public Message() {
    }

    public Object getMessage() {
        return msg;
    }

    public void setMessage(Object message) {
        this.msg = message;
    }

    public Message(Object message) {
        this.msg = message;
    }
}
