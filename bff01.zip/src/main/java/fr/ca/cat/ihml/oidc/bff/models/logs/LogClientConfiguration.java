package fr.ca.cat.ihml.oidc.bff.models.logs;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Décrit la configuration de log du client front end
 * 
 * @author ET02720
 *
 */
public class LogClientConfiguration {

    /**
     * Spécifie le niveau de log géré par le client front end
     * 
     * @see {@linkplain LogClientConfiguration#getClientLoglevel()}
     * @see {@linkplain LogClientConfiguration#setClientLoglevel()}
     */
    @Min(0)
    @Max(7)
    @NotNull
    private int clientLoglevel;

    /**
     * Spécifie le niveau de log à envoyer au serveur par le client front end
     * 
     * @see {@linkplain LogClientConfiguration#getServerLogLovel()}
     * @see {@linkplain LogClientConfiguration#setServerLogLovel()}
     */
    @Min(0)
    @Max(7)
    @NotNull
    private int serverLogLovel;

    /**
     * Spécifie si le console log est désactivé dans le front end
     * 
     * @see {@linkplain LogClientConfiguration#isDisableConsoleLog()}
     * @see {@linkplain LogClientConfiguration#setDisableConsoleLog(boolean)}
     */
    private boolean disableConsoleLog;

    /**
     * Récupération du niveau de log du client front end
     * 
     * @return le niveau de log du client front end
     */
    @JsonProperty(value = "clientLogLevel")
    public int getClientLoglevel() {
        return clientLoglevel;
    }

    /**
     * Spécifie le niveau de log du client front end
     * 
     * @param clientLoglevel le nouveau niveau du log du client front end
     */
    @JsonProperty(value = "clientLogLevel")
    public void setClientLoglevel(int clientLoglevel) {
        this.clientLoglevel = clientLoglevel;
    }

    /**
     * Récupération du niveau de log du serveur
     * 
     * @return le niveau de log du serveur
     */
    @JsonProperty(value = "serverLogLevel")
    public int getServerLogLovel() {
        return serverLogLovel;
    }

    /**
     * Spécifie le niveau de log du serveur
     * 
     * @param serverLogLovel le nouveau niveau de log du serveur
     */
    @JsonProperty(value = "serverLogLevel")
    public void setServerLogLovel(int serverLogLovel) {
        this.serverLogLovel = serverLogLovel;
    }

    /**
     * Savoir si la console doit être désactivé dans le front end
     * 
     * @return
     * <ul>
     * <li>True si la console doit être désactivée</li>
     * <li>False si la console doit être activée.
     * </li>
     */
    @JsonProperty(value = "disableConsoleLog")
    public boolean isDisableConsoleLog() {
        return disableConsoleLog;
    }

    /**
     * Spécifie si la console doit être activée ou non dans le front end
     * 
     * @param disableConsoleLog la nouvelle valeur d'activation de la console log
     */
    @JsonProperty(value = "disableConsoleLog")
    public void setDisableConsoleLog(boolean disableConsoleLog) {
        this.disableConsoleLog = disableConsoleLog;
    }

}
