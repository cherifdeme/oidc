package fr.ca.cat.ihml.oidc.bff.models.logs;

import com.fasterxml.jackson.annotation.JsonProperty;

import fr.ca.cat.ihml.oidc.bff.utils.AppUtils;

/**
 * Permet de définit le context d'une trace de log
 * 
 * @author ET02720
 *
 */
public class LogContext {

    /**
     * L'event code de la log
     * 
     * @see {@link LogContext#getEventCode()}
     * @see {@link LogContext#setEventCode()}
     */
    private String eventCode;

    /**
     * L'event type de la log
     * 
     * @see {@link LogContext#getEventType()}
     * @see {@link LogContext#setEventType()}
     */
    private String eventType;

    /**
     * L'event de sécurité de la log
     * 
     * @see {@link LogContext#getSecurityEventType()}
     * @see {@link LogContext#setSecurityEventType()}
     */
    private String securityEventType;

    /**
     * Le user Id de la log
     * 
     * @see {@link LogContext#getUserId()}
     * @see {@link LogContext#setUserId()}
     */
    private String userId;

    /**
     * Le code de l'identité
     * 
     * @see {@link LogContext#getUomCode()}
     * @see {@link LogContext#setUom_Code()}
     */
    private String uomCode;

    /**
     * L'id de l'application
     * 
     * @see {@link LogContext#getApplicationId()}
     * @see {@link LogContext#setApplicationId()}
     */
    private String applicationId;

    /**
     * L'id du component
     * 
     * @see {@link LogContext#getComponentId()}
     * @see {@link LogContext#setComponentId()}
     */
    private String componentId;

    /**
     * Le correlation Id de la log
     * 
     * @see {@link LogContext#getCorrelationId()}
     * @see {@link LogContext#setCorrelationId()}
     */
    private String correlationId;

    /**
     * L'id de la session
     * 
     * @see {@link LogContext#getSessionId()}
     * @see {@link LogContext#setSessionId()}
     */
    private String sessionId;

    /**
     * Le client id de source de la log
     * 
     * @see {@link LogContext#getSourceClientId()}
     * @see {@link LogContext#setSourceClientId()}
     */
    private String sourceClientId;

    /**
     * Le profil de l'utilisateur de la log
     * 
     * @see {@link LogContext#getProfil()}
     * @see {@link LogContext#setProfil()}
     */
    private String profil;

    /**
     * Le nom de l'instance de la log
     * 
     * @see {@link LogContext#getInstanceName()}
     * @see {@link LogContext#setInstanceName()}
     */
    private String instanceName;

    /**
     * L'uri de la log
     * 
     * @see {@link LogContext#getUri()}
     * @see {@link LogContext#setUri()}
     */
    private String uri;

    /**
     * Le type de component de la log
     * 
     * @see {@link LogContext#getComponentType()}
     * @see {@link LogContext#getComponentType()}
     */
    private String componentType;

    /**
     * Le terminal de la log
     * 
     * @see {@link LogContext#getTerminal()}
     * @see {@link LogContext#setTerminal()}
     */
    private String terminal;

    /**
     * L'eds de la log
     * 
     * @see {@link LogContext#getEds()}
     * @see {@link LogContext#setEds()}
     */
    private String eds;

    /**
     * Le poste opérationnel de la log
     * 
     * @see {@link LogContext#getOperationalPostId()}
     * @see {@link LogContext#setOperationalPostId()}
     */
    private String operationalPostId;

    /**
     * La source de la log
     * 
     * @see {@link LogContext#getSource()}
     * @see {@link LogContext#setSource()}
     */
    private String source;

    /**
     * La stack trace de la log
     * 
     * @see {@link LogContext#getStackTrace()}
     * @see {@link LogContext#setStackTrace()}
     */
    private String stackTrace;

    /**
     * Le client source de la log
     * 
     * @see {@link LogContext#getSourceClient()}
     * @see {@link LogContext#setSourceClient()}
     */
    private String sourceClient;

    /**
     * Récupération du code event de la log
     * 
     * @return le code event de la log
     */
    @JsonProperty(value = "event_cod")
    public String getEventCode() {
        return eventCode;
    }

    /**
     * Spécifie le code event de la log
     * 
     * @param eventCode le nouveau code event de la log
     */
    @JsonProperty(value = "event_cod")
    public void setEventCode(String eventCode) {
        this.eventCode = eventCode;
    }

    /**
     * Récupération de event type de la log
     * 
     * @return l'event type de la log
     */
    @JsonProperty(value = "event_typ")
    public String getEventType() {
        return eventType;
    }

    /**
     * Spécifie l'event type de la log
     * 
     * @param eventType le nouvel event type de la log
     */
    @JsonProperty(value = "event_typ")
    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    /**
     * Récupération de l'event type de sécurité de la log
     * 
     * @return l'event type de sécurité de la log
     */
    @JsonProperty(value = "sec_event_typ")
    public String getSecurityEventType() {
        return securityEventType;
    }

    /**
     * Spécifie l'event type de sécurité de la log
     * 
     * @param securityEventType le nouvel event type de sécurité de la log
     */
    @JsonProperty(value = "sec_event_typ")
    public void setSecurityEventType(String securityEventType) {
        this.securityEventType = securityEventType;
    }

    /**
     * Récupération du user id de la log
     * 
     * @return le user id de la log
     */
    @JsonProperty(value = "usr_id")
    public String getUserId() {
        return userId;
    }

    /**
     * Spécifie le user id de la log
     * 
     * @param userId le nouvel user id de la log
     */
    @JsonProperty(value = "usr_id")
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * Récupération de code uom de la log
     * 
     * @return le code uom de la log
     */
    @JsonProperty(value = "uom_cod")
    public String getUomCode() {
        return uomCode;
    }

    /**
     * Spécifie le code uom de la log
     * 
     * @param uomCode le nouvel code uom de la log
     */
    @JsonProperty(value = "uom_cod")
    public void setUomCode(String uomCode) {
        this.uomCode = uomCode;
    }

    /**
     * Récupération du code application de la log
     * 
     * @return le code application de la log
     */
    @JsonProperty(value = "app_id")
    public String getApplicationId() {
        return applicationId;
    }

    /**
     * Spécifie le code application de la log
     * 
     * @param applicationId le nouveau code application de la log
     */
    @JsonProperty(value = "app_id")
    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    /**
     * Récupération du component id de la log
     * 
     * @return le component id de la log
     */
    @JsonProperty(value = "component_id")
    public String getComponentId() {
        return componentId;
    }

    /**
     * Spécifie le component id de la log
     * 
     * @param componentId le nouveau component id de la log
     */
    @JsonProperty(value = "component_id")
    public void setComponentId(String componentId) {
        this.componentId = componentId;
    }

    /**
     * Récupération du correlation id de la log
     * 
     * @return le correlation id de la log
     */
    @JsonProperty(value = "corr_id")
    public String getCorrelationId() {
        return correlationId;
    }

    /**
     * Spécifie le correlation id de la log
     * 
     * @param correlationId le nouveau correlation id de la log
     */
    @JsonProperty(value = "corr_id")
    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    /**
     * Récupération du session id de la log
     * 
     * @return le session id de la log
     */
    @JsonProperty(value = "sess_id")
    public String getSessionId() {
        return sessionId;
    }

    /**
     * Spécifie le session id de la log
     * 
     * @param sessionId le nouveau session id de la log
     */
    @JsonProperty(value = "sess_id")
    public void setSessionId(String sessionId) {
        // Offuscation de la sessionId
        this.sessionId = AppUtils.obfuscateUUIDString(sessionId);
    }

    /**
     * Récupération du client source id de la log
     * 
     * @return le client source id de la log
     */
    @JsonProperty(value = "src_client_id")
    public String getSourceClientId() {
        return sourceClientId;
    }

    /**
     * Spécifie le client source id de la log
     * 
     * @param sourceClientId le nouveau client source id de la log
     */
    @JsonProperty(value = "src_client_id")
    public void setSourceClientId(String sourceClientId) {
        this.sourceClientId = sourceClientId;
    }

    /**
     * Récupération du profil de la log
     * 
     * @return le profil de la log
     */
    @JsonProperty(value = "profil")
    public String getProfil() {
        return profil;
    }

    /**
     * Spécifie le profil de la log
     * 
     * @param profil le nouveau profil de la log
     */
    @JsonProperty(value = "profil")
    public void setProfil(String profil) {
        this.profil = profil;
    }

    /**
     * Récupération de l'instance name de la log
     * 
     * @return l'instance name de la log
     */
    @JsonProperty(value = "instance_name")
    public String getInstanceName() {
        return instanceName;
    }

    /**
     * Spécifie l'instance name de la log
     * 
     * @param instanceName le nouveau instance name de la log
     */
    @JsonProperty(value = "instance_name")
    public void setInstanceName(String instanceName) {
        this.instanceName = instanceName;
    }

    /**
     * Récupération de l'uri de la log
     * 
     * @return l'uri de la log
     */
    @JsonProperty(value = "uri")
    public String getUri() {
        return uri;
    }

    /**
     * Spécifie l'uri de la log
     * 
     * @param uri la nouveal uri de la log
     */
    @JsonProperty(value = "uri")
    public void setUri(String uri) {
        this.uri = uri;
    }

    /**
     * Récupération du component type de la log
     * 
     * @return le component type de la log
     */
    @JsonProperty(value = "component_type")
    public String getComponentType() {
        return componentType;
    }

    /**
     * Spécifie le component type de la log
     * 
     * @param componentType le nouveau component type de la log
     */
    @JsonProperty(value = "component_type")
    public void setComponentType(String componentType) {
        this.componentType = componentType;
    }

    /**
     * Récupération du terminal de la log
     * 
     * @return le terminal de la log
     */
    @JsonProperty(value = "terminal")
    public String getTerminal() {
        return terminal;
    }

    /**
     * Spécifie le terminal de la log
     * 
     * @param terminal le nouveau terminal de la log
     */
    @JsonProperty(value = "terminal")
    public void setTerminal(String terminal) {
        this.terminal = terminal;
    }

    /**
     * Récupération de l'eds de la log
     * 
     * @return l'eds de la log
     */
    @JsonProperty(value = "eds")
    public String getEds() {
        return eds;
    }

    /**
     * Spécifie l'eds de la log
     * 
     * @param eds le nouvel eds de la log
     */
    @JsonProperty(value = "eds")
    public void setEds(String eds) {
        this.eds = eds;
    }

    /**
     * Récupération de poste opérationnel de la log
     * 
     * @return le poste opérationnel de la log
     */
    @JsonProperty(value = "operational_post_id")
    public String getOperationalPostId() {
        return operationalPostId;
    }

    /**
     * Spécifie le poste opérationnel de la log
     * 
     * @param operationalPostId le nouveau poste opérationnel de la log
     */
    @JsonProperty(value = "operational_post_id")
    public void setOperationalPostId(String operationalPostId) {
        this.operationalPostId = operationalPostId;
    }

    /**
     * Récupération de la source de la log
     * 
     * @return la source de la log
     */
    @JsonProperty(value = "source")
    public String getSource() {
        return source;
    }

    /**
     * Spécifie la source de la log
     * 
     * @param source la nouvelle source de la log
     */
    @JsonProperty(value = "source")
    public void setSource(String source) {
        this.source = source;
    }

    /**
     * Récupération de la stack trace de la log
     * 
     * @return la stack trace de la log
     */
    @JsonProperty(value = "stack_trace")
    public String getStackTrace() {
        return stackTrace;
    }

    /**
     * Spécifie la stack trace de la log
     * 
     * @param stackTrace la nouvelle stack trace de la log
     */
    @JsonProperty(value = "stack_trace")
    public void setStackTrace(String stackTrace) {
        this.stackTrace = stackTrace;
    }

    /**
     * Récupération de la source client de la log
     * 
     * @return la source client de la log
     */
    @JsonProperty(value = "src_client")
    public String getSourceClient() {
        return sourceClient;
    }

    /**
     * Spécifie la source client de la log
     * 
     * @param sourceClient la nouvelle source client de la log
     */
    @JsonProperty(value = "src_client")
    public void setSourceClient(String sourceClient) {
        this.sourceClient = sourceClient;
    }
}
