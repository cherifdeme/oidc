package fr.ca.cat.ihml.oidc.bff.models.logs;

import java.util.HashMap;
import java.util.Map;

/**
 * Enumération pour décrire le niveau de log de l'application
 * 
 * @author ET02720
 *
 */
public enum LogLevel {
    TRACE(0), DEBUG(1), INFO(2), LOG(3), WARN(4), ERROR(5), FATAL(6), OFF(7);

    private int level;
    private static Map<Integer, LogLevel> map = new HashMap<>();

    static {
        for (LogLevel logLevel : LogLevel.values()) {
            map.put(logLevel.level, logLevel);
        }
    }

    /**
     * Constructeur de l'énumération
     * 
     * @param level
     */
    private LogLevel(int level) {
        this.level = level;
    }

    /**
     * Récupération du niveau de log de l'application
     * 
     * @return Le niveau de log
     */
    public int getLevel() {
        return this.level;
    }

    /**
     * Conversion du niveau de log en chaine de caractère
     * 
     * @param level le niveau de log Integer
     * @return La valeur de l'énumération associée
     */
    public static LogLevel valueOf(int level) {
        return map.get(level);
    }

}
