package fr.ca.cat.ihml.oidc.bff.models.logs;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.type.TypeReference;

import fr.ca.cat.ihml.oidc.bff.utils.AppUtils;

/**
 * Classe décrivant un message de log provenant du front end
 * 
 * @author ET02720
 *
 */
public class LogMessage {

    /**
     * Le niveau de la log
     * 
     * @see {@link LogMessage#getLevel()}
     * @see {@link LogMessage#setLevel()}
     */
    @Min(0)
    @Max(7)
    @NotNull
    private int level;

    /**
     * L'horodatade de la log
     * 
     * @see {@link LogMessage#getTimeStamp()}
     * @see {@link LogMessage#setTimeStamp()}
     */
    private String timeStamp;

    /**
     * La nom du fichier émetteur de la log
     * 
     * @see {@link LogMessage#getFileName()}
     * @see {@link LogMessage#setFileName()}
     */
    private String fileName;

    /**
     * La ligne du fichier émétteur de la log
     * 
     * @see {@link LogMessage#getLineNumber()}
     * @see {@link LogMessage#setLineNumber()}
     */
    private String lineNumber;

    /**
     * Le message d'erreur de la log
     * 
     * @see {@link LogMessage#getMessage()
     * @see {@link LogMessage#setMessage()}
     */
    @NotBlank
    private String message;

    /**
     * Le contenu additionel de la log
     * 
     * @see {@link LogMessage#getAdditional()}
     * @see {@link LogMessage#setAdditional()}
     */
    private List<String> additional;

    /**
     * Constructeur initial
     */
    public LogMessage() {
        this.level = 0;
        this.additional = new ArrayList<>();
    }

    /**
     * Récupération du niveau de la log
     * 
     * @return le niveau de log
     */
    @JsonProperty(value = "level")
    public int getLevel() {
        return level;
    }

    /**
     * Spécifie le niveau de log
     * 
     * @param level le nouveau niveau de log
     */
    @JsonProperty(value = "level")
    public void setLevel(int level) {
        this.level = level;
    }

    /**
     * Récupération du niveau de log au format LogLevel
     * 
     * @return Le niveau de log au format LogLevel
     * @see {@link LogLevel}
     */
    public LogLevel getLogLevel() {
        return LogLevel.valueOf(level);
    }

    /**
     * Récupération de l'horodatage de la log
     * 
     * @return L'horodatage de la log
     */
    @JsonProperty(value = "timestamp")
    public String getTimeStamp() {
        return timeStamp;
    }

    /**
     * Spécifie l'horodatage de la log
     * 
     * @param timeStamp le nouvel horodatage de la log
     */
    @JsonProperty(value = "timestamp")
    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    /**
     * Récupération du nom du fichier émétteur de la log
     * 
     * @return Le nom du fichier émétteur de la log
     */
    @JsonProperty(value = "fileName")
    public String getFileName() {
        return fileName;
    }

    /**
     * Spécifie le nom du fichier émétteur de la log
     * 
     * @param fileName Le nouveau nom du fichier émétteur de la log
     */
    @JsonProperty(value = "fileName")
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * Récupération du numéro de la ligne éméttrice de la log
     * 
     * @return Le numéro de ligne
     */
    @JsonProperty(value = "lineNumber")
    public String getLineNumber() {
        return lineNumber;
    }

    /**
     * Spécifie la ligne éméttrice de la log
     * 
     * @param lineNumber La nouvel ligne de log
     */
    @JsonProperty(value = "lineNumber")
    public void setLineNumber(String lineNumber) {
        this.lineNumber = lineNumber;
    }

    /**
     * Récupération du message de la log
     * 
     * @return Le message de la log
     */
    @JsonProperty(value = "message")
    public String getMessage() {
        return message;
    }

    /**
     * Spécifie le message de la log
     * 
     * @param message Le nouveau message de la log
     */
    @JsonProperty(value = "message")
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * Récupération des paramètres additionels de la log
     * 
     * @return Les paramètres additonels de la log
     */
    @JsonProperty(value = "additional")
    public List<String> getAdditional() {
        return additional;
    }

    /**
     * Spécifie les paramètres additionels de la log
     * 
     * @param additional Les nouveaux paramètres additionels de la log
     */
    @JsonProperty(value = "additional")
    public void setAdditional(List<String> additional) {
        this.additional = additional;
    }

    /**
     * Convertie la chaine des paramètres additionels au format JSON
     * 
     * @return Une map des paramètres additionels
     * @throws IOException
     */
    public LogContext getLogContext() {

        if (this.additional.isEmpty()) {
            return new LogContext();
        } else {
            try {
                return AppUtils.jsonStringToObject(this.additional.get(0), new TypeReference<LogContext>() {
                });
            } catch (IOException e) {
                return new LogContext();
            }
        }
    }
}
