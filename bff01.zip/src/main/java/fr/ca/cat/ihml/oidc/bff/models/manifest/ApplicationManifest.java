package fr.ca.cat.ihml.oidc.bff.models.manifest;

/**
 * Classe pour définir le manifest de l'application
 * 
 * @author ET02720
 *
 */
public class ApplicationManifest {

    /**
     * La version de l'application
     * 
     * @see ApplicationManifest#getVersion()
     * @see ApplicationManifest#setVersion(String)
     */
    private String version;

    /**
     * Le type de framework de l'application
     * 
     * @see ApplicationManifest#getFramework()
     * @see ApplicationManifest#setFramework(String)
     */
    private String framework;

    /**
     * Récupération de la version
     * 
     * @return La version de l'application
     */
    public String getVersion() {
        return version;
    }

    /**
     * Spécifier la version de l'application
     * 
     * @param version
     */
    public void setVersion(String version) {
        this.version = version;
    }

    /**
     * Récupérer le framework de l'application
     * 
     * @return Le framework de l'application
     */
    public String getFramework() {
        return framework;
    }

    /**
     * Spécifier le framework de l'application
     * 
     * @param framework le nouveau framework de l'application
     */
    public void setFramework(String framework) {
        this.framework = framework;
    }

}
