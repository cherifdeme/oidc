package fr.ca.cat.ihml.oidc.bff.models.places;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Objet définissant une adresse d'une agence
 * @author ET02720
 *
 */
public class Address extends Entity {

	/**
	 * Adresse de l'agence
	 * @see Address#getAddress()
	 * @see Address#setAddress(String)
	 */
	@SuppressWarnings("squid:S1700")
	private String address;	

	
	/**
	 * Code postal profressionel de l'agence
	 * @see Address#getBusinessZipCode()
	 * @see Address#setBusinessZipCode(String)
	 */
	private String businessZipCode;
	
	 /**
     * District de l'agence
     * @see Address#getDistrict()
     * @see Address#setDistrict(String)
     */
	private String district;
	
	/**
	 * Retourne l'adresse
	 * @return Une adresse
	 */
	@JsonProperty(value = "address")
	public String getAddress() {
		return address;
	}
	
	/**
	 * Met à jour l'adress
	 * @param address Nouvelle adresse
	 */
	@JsonProperty(value = "address")
	public void setAddress(String address) {
		this.address = address;
	}
	
	/**
	 * Retourne le code postal professionel
	 * @return Le code postal professionel
	 */
	@JsonProperty(value = "business_zip_code")
	public String getBusinessZipCode() {
		return businessZipCode;
	}
	
	/**
	 * Met à jour le code postal professionnel
	 * @param businessZipCode Le nouveau code postal profressionnel
	 */
	@JsonProperty(value = "business_zip_code")
	public void setBusinessZipCode(String businessZipCode) {
		this.businessZipCode = businessZipCode;
	}	
	
	 /**
     * Retourne le district
     * @return Le district
     */
    @JsonProperty(value = "district")
    public String getDistrict() {
        return this.district;
    }
    
    /**
     * Met à jour le district
     * @param district Le nouveau district
     */
    @JsonProperty(value = "district")
    public void setDistrict(String district) {
        this.district = district;
    }
}
