package fr.ca.cat.ihml.oidc.bff.models.places;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Object définissant une CR
 * @author ET02720
 *
 */
public class CR {
	
	/**
	 * Id de la CR
	 * @see CR#getRegionalBankId()
	 * @see CR#setRegionalBankId(String)
	 */
	private String regionalBankId;
	
	/**
	 * Nom de la CR
	 * @see CR#getRegionalBankName()
	 * @see CR#setRegionalBankName(String)
	 */
	private String regionalBankName;
	
	/**
	 * Retourne l'Id de la CR
	 * @return L'Id de la CR
	 */
	@JsonProperty(value = "regional_bank_id")
	public String getRegionalBankId() {
		return regionalBankId;
	}
	
	/**
	 * Met à jour l'Id de la CR
	 * @param regionalBankId Le nouvel Id de la CR
	 */
	@JsonProperty(value = "regional_bank_id")
	public void setRegionalBankId(String regionalBankId) {
		this.regionalBankId = regionalBankId;
	}
	
	/**
	 * Retourne la nom de la CR
	 * @return Le nom de la CR
	 */
	@JsonProperty(value = "regional_bank_name")
	public String getRegionalBankName() {
		return regionalBankName;
	}
	
	/**
	 * Met à jour le nom de la CR
	 * @param regionalBankName Le nouveau nom de la CR
	 */
	@JsonProperty(value = "regional_bank_name")
	public void setRegionalBankName(String regionalBankName) {
		this.regionalBankName = regionalBankName;
	}
	
	
}
