package fr.ca.cat.ihml.oidc.bff.models.places;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Object définissant des coordonées
 * @author ET02720
 *
 */
public class Coordinates {

	/**
	 * Latitude
	 * @see Coordinates#getLatitude()
	 * @see Coordinates#setLatitude(String)
	 */
	private String latitude;
	
	/**
	 * Longitude
	 * @see Coordinates#getLongitude()
	 * @see Coordinates#setLongitude(String)
	 */
	private String longitude;
	
	
	/**
	 * Retourne la latitude de la coordonée
	 * @return La latitude
	 */
	@JsonProperty(value = "latitude")
	public String getLatitude() {
		return latitude;
	}
	
	/**
	 * Met à jour la latitude de la coordonée
	 * @param latitude La nouvelle latitude
	 */
	@JsonProperty(value = "latitude")
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	
	/**
	 * Retourne la longitude de la coordonée
	 * @return La longitude
	 */
	@JsonProperty(value = "longitude")
	public String getLongitude() {
		return longitude;
	}
	
	/**
	 * Met à jour la longitude de la coordonée
	 * @param longitude La nouvelle longitude
	 */
	@JsonProperty(value = "longitude")
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
}
