package fr.ca.cat.ihml.oidc.bff.models.places;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Objet définissant une agence d'un CR
 * @author ET02720
 *
 */
public class DistributionEntity {
	
	/**
	 * Id de l'agence
	 * @see DistributionEntity#getId()
	 * @see DistributionEntity#setId(String)
	 */
	private String id;
	
	/**
	 * Nom de l'agence
	 * @see DistributionEntity#getName()
	 * @see DistributionEntity#setName(String)
	 */
	private String name;
	
	/**
	 * Id de la CR de l'agence
	 * @see DistributionEntity#getRegionalBankId()
	 * @see DistributionEntity#setRegionalBankId(String)
	 */
	private String regionalBankId;
	
	/**
	 * Type de l'agence
	 * @see DistributionEntity#getType()
	 * @see DistributionEntity#setType(int)
	 */
	private int type;
	
	/**
	 * {@link Services} proposés par l'agenc 
	 * @see DistributionEntity#getServices()
	 * @see DistributionEntity#setServices(Services)
	 */
	private Services services;
	
	/**
	 * {@link Address} de l'agence
	 * @see DistributionEntity#getAddress()
	 * @see DistributionEntity#setAddress(Address)
	 */
	private Address address;
	
	/**
	 * Planning d'ouverture de l'agence
	 * @see {@link WeekSchedule}
	 * @see DistributionEntity#getWeekSchedule()
	 * @see DistributionEntity#setWeekSchedule(WeekSchedule[])
	 */
	private WeekSchedule[] weekSchedule;
	
	/**
	 * Coordonées de l'agence
	 * @see {@link Coordinates}
	 * @see DistributionEntity#getCoordinates()
	 * @see DistributionEntity#setCoordinates(Coordinates)
	 */
	private Coordinates coordinates;
	
	/**
	 * Type de marché de l'agence
	 * @see {@link Market}
	 * @see DistributionEntity#getMarket()
	 * @see DistributionEntity#setMarket(Market)
	 */
	private Market market;
	
	/**
	 * Information de contact de l'agence
	 * @see {@link Contact}
	 * @see DistributionEntity#getContact()
	 * @see DistributionEntity#setContact(Contact)
	 */
	private Contact contact;
	
	/**
	 * ID de l'EDS de l'agence
	 * @see DistributionEntity#getIdEdsBanalise()
	 * @see DistributionEntity#setIdEdsBanalise(String)
	 */
	private String idEdsBanalise;
	
	/**
     * Zone exterieure de l'agence
     * @see DistributionEntity#isOutsideRegionalBankArea()
     * @see DistributionEntity#setOutsideRegionalBankArea(boolean)
     */
    private boolean outsideRegionalBankArea;
    
    /**
     * Fermeture exceptionnelle
     * @see DistributionEntity#isExceptionalClosure()
     * @see DistributionEntity#setExceptionalClosure(boolean)
     */
    private boolean exceptionalClosure;
    
    /**
     * Structure active
     * @see DistributionEntity#isActiveStructure()
     * @see DistributionEntity#setActiveStructure(String)
     */
    private boolean activeStructure;
    
    /**
     * Information agence
     * @see DistributionEntity#getAgencyInformation()
     * @see DistributionEntity#setAgencyInformation(String)
     */
    private String agencyInformation;

	/**
	 * Retourne l'Id de l'agence
	 * @return L'Id de l'agence
	 */
	@JsonProperty(value = "id")
	public String getId() {
		return id;
	}
	
	/**
	 * Met à jour l'Id de l'agence
	 * @param id Le nouvel Id
	 */
	@JsonProperty(value = "id")
	public void setId(String id) {
		this.id = id;
	}
	
	/**
	 * Retourne le nom de l'agence
	 * @return Le nom de l'agence
	 */
	@JsonProperty(value = "name")
	public String getName() {
		return name;
	}
	
	/**
	 * Met à jour le nom de l'agence
	 * @param name Le nouveau nom de l'agence
	 */
	@JsonProperty(value = "name")
	public void setName(String name) {
		this.name = name;
	}
	
	/**
	 * Retourne l'Id de la CR de l'agence
	 * @return L'Id de la CR de l'agence
	 */
	@JsonProperty(value = "regional_bank_id")
	public String getRegionalBankId() {
		return regionalBankId;
	}
	
	/**
	 * Met à jour l'Id de la CR de l'agence
	 * @param regionalBankId Le nouvel Id
	 */
	@JsonProperty(value = "regional_bank_id")
	public void setRegionalBankId(String regionalBankId) {
		this.regionalBankId = regionalBankId;
	}
	
	/**
	 * Retourne le type de l'agence
	 * @return Le type de l'agence au format Integer
	 */
	@JsonProperty(value = "type")
	public int getType() {
		return type;
	}
	
	/**
	 * Met à jour le type de l'agence
	 * @param type Le nouveau type de l'agence au format Integer
	 */
	@JsonProperty(value = "type")
	public void setType(int type) {
		this.type = type;
	}
	
	/**
	 * Retourne les services proposés par l'agence
	 * @return Les services proposés par l'agence
	 * @see {@link Services}
	 */
	@JsonProperty(value = "services")
	public Services getServices() {
		return services;
	}
	
	/**
	 * Met à jour les service proposés par l'agence
	 * @param services Les nouveaux services proposés par l'agence
	 * @see {@link ApiService}
	 */
	@JsonProperty(value = "services")
	public void setServices(Services services) {
		this.services = services;
	}
	
	/**
	 * Retourne l'adresse de l'agence
	 * @return L'adresse de l'agence
	 * @see {@link Address}
	 */
	@JsonProperty(value = "address")
	public Address getAddress() {
		return address;
	}
	
	/**
	 * Met à jour l'adresse de l'agence
	 * @param address La nouvelle adresse de l'agence
	 * @see {@link Address}
	 */
	@JsonProperty(value = "address")
	public void setAddress(Address address) {
		this.address = address;
	}
	
	/**
	 * Retourne le planning d'ouverture de l'agence
	 * @return Le planning d'ouverture de l'agence
	 * @see {@linkplain WeekSchedule}
	 */
	@JsonProperty(value = "week_schedule")
	public WeekSchedule[] getWeekSchedule() {
		return weekSchedule;
	}
	
	/**
	 * Met à jour le planning d'ouverture de l'agence
	 * @param weekSchedule Le nouveau planning d'ouverture de l'agence
	 * @see {@linkplain WeekSchedule}
	 */
	@JsonProperty(value = "week_schedule")
	public void setWeekSchedule(WeekSchedule[] weekSchedule) {
		this.weekSchedule = weekSchedule;
	}
	
	/**
	 * Retourne les coordonées GPS de l'agence
	 * @return Les coordonnées GPS de l'agence
	 * @see {@linkplain Coordinates}
	 */
	@JsonProperty(value = "coordinates")
	public Coordinates getCoordinates() {
		return coordinates;
	}
	
	/**
	 * Met à jour les coordonées GPS de l'agence
	 * @param coordinates Les nouvelles coordonées GPS de l'agence
	 * @see {@linkplain Coordinates}
	 */
	@JsonProperty(value = "coordinates")
	public void setCoordinates(Coordinates coordinates) {
		this.coordinates = coordinates;
	}
	
	/**
	 * Retourne de le type de marché de l'agence
	 * @return Le type de marché de l'agence
	 * @see {@link Market}
	 */
	@JsonProperty(value = "market")
	public Market getMarket() {
		return market;
	}
	
	/**
	 * Met à jour le type de marché de l'agence
	 * @param market Le nouveau type de marché de l'agence
	 * @see {@link Market}
	 */
	@JsonProperty(value = "market")
	public void setMarket(Market market) {
		this.market = market;
	}
	
	/**
	 * Retourne les informations de contact de l'agence
	 * @return Les informations de contact de l'agence
	 * @see {@link Contact}
	 */
	@JsonProperty(value = "contact")
	public Contact getContact() {
		return contact;
	}
	
	/**
	 * Met à jour les informations de contact de l'agence
	 * @param contact Les nouvelles informations de contact de l'agence
	 * @see {@link Contact}
	 */
	@JsonProperty(value = "contact")
	public void setContact(Contact contact) {
		this.contact = contact;
	}
	
	/**
	 * Retourne l'Id de l'EDS de l'agence
	 * @return L'Id de l'EDS de l'agence
	 */
	@JsonProperty(value = "id_eds_banalise")
	public String getIdEdsBanalise() {
		return idEdsBanalise;
	}
	
	/**
	 * Met à jour l'Id de l'EDS de l'agence
	 * @param idEdsBanalise Le nouvel Id de l'EDS de l'agence
	 */
	@JsonProperty(value = "id_eds_banalise")
	public void setIdEdsBanalise(String idEdsBanalise) {
		this.idEdsBanalise = idEdsBanalise;
	}

    
    /**
     * Retroune la zone exterieure
     * @return si l'agence fait partie d'une zone externe
     */
	@JsonProperty(value = "outside_regional_bank_area")
    public boolean isOutsideRegionalBankArea() {
        return outsideRegionalBankArea;
    }

    
    /**
     * Met à jour la zone exterieure
     * @param outsideRegionalBankArea la nouvelle zone exterieure
     */
	@JsonProperty(value = "outside_regional_bank_area")
    public void setOutsideRegionalBankArea(boolean outsideRegionalBankArea) {
        this.outsideRegionalBankArea = outsideRegionalBankArea;
    }

    
    /**
     * Retourne la fermeture exceptionnelle
     * @return si l'agence est en fermeture exceptionnelle
     */
	@JsonProperty(value = "exceptional_closure")
    public boolean isExceptionalClosure() {
        return exceptionalClosure;
    }

    
    /**
     * Met à jour la fermeture exceptionnelle
     * @param exceptionalClosure la nouvelle fermeture exceptionnelle
     */
	@JsonProperty(value = "exceptional_closure")
    public void setExceptionalClosure(boolean exceptionalClosure) {
        this.exceptionalClosure = exceptionalClosure;
    }

    
    /**
     * Retourne la structure active
     * @return la structure active
     */
	@JsonProperty(value = "active_structure")
    public boolean isActiveStructure() {
        return activeStructure;
    }

    
    /**
     * Met à jour la structure active
     * @param activeStructure la nouvelle structure active
     */
	@JsonProperty(value = "active_structure")
    public void setActiveStructure(boolean activeStructure) {
        this.activeStructure = activeStructure;
    }
    
    /**
     * Retourne les informations de l'agence
     * @return les information de l'agence
     */
	@JsonProperty(value = "agency_information")
    public String getAgencyInformation() {
        return agencyInformation;
    }

    
    /**
     * Met à jour les infomration sur l'agence
     * @param agencyInformation les nouvelles informations sur l'agence
     */
	@JsonProperty(value = "agency_information")
    public void setAgencyInformation(String agencyInformation) {
        this.agencyInformation = agencyInformation;
    }
	
}
