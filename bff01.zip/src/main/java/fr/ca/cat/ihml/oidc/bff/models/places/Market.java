package fr.ca.cat.ihml.oidc.bff.models.places;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Object définissant le type de marché d'une agence
 * @author ET02720
 *
 */
public class Market {
	
	/**
	 * Type de marché général public
	 * @see Market#isGeneralPublic()
	 * @see Market#setGeneralPublic(boolean)
	 */
	private boolean generalPublic;
	
	/**
	 * Type de marché banque privée
	 * @see Market#isPrivateBanking()
	 * @see Market#setPrivateBanking(boolean)
	 */
	private boolean privateBanking;
	
	/**
	 * Type de marché pro
	 * @see Market#isPro()
	 * @see Market#setPro(boolean)
	 */
	private boolean pro;
	
	/**
	 * Type de marché agriculteur
	 * @see Market#isFarmer()
	 * @see Market#setFarmer(boolean)
	 */
	private boolean farmer;
	
	/**
	 * Type de marché association
	 * @see Market#isAssociation()
	 * @see Market#setAssociation(boolean)
	 */
	private boolean association;
	
	/**
	 * Type de marché entreprise
	 * @see Market#isEnterprise()
	 * @see Market#setEnterprise(boolean)
	 */
	private boolean enterprise;
	
	/**
	 * Type de marché collectivité publique
	 * @see Market#isPublicCollectivity()
	 * @see Market#setPublicCollectivity(boolean)
	 */
	private boolean publicCollectivity;
	
	/**
	 * Indique si l'agence gère les clients publiques
	 * @return True si l'agence gère les clients publiques
	 */
	@JsonProperty(value = "general_public")
	public boolean isGeneralPublic() {
		return generalPublic;
	}
	
	/**
	 * Spécifie si l'agence gère les clients publiques
	 * @param generalPublic True si l'agence gère les clients publiques
	 */
	@JsonProperty(value = "general_public")
	public void setGeneralPublic(boolean generalPublic) {
		this.generalPublic = generalPublic;
	}
	
	/**
	 * Indique si l'agence est une banque privée
	 * @return True si l'agence est une banque privée
	 */
	@JsonProperty(value = "private_banking")
	public boolean isPrivateBanking() {
		return privateBanking;
	}
	
	/**
	 * Spécifie si l'agence est une banque privée
	 * @param generalPublic True si l'agence est une banque privée
	 */
	@JsonProperty(value = "private_banking")
	public void setPrivateBanking(boolean privateBanking) {
		this.privateBanking = privateBanking;
	}
	
	/**
	 * Indique si l'agence gère les pros
	 * @return True si l'agence gère les pros
	 */
	@JsonProperty(value = "pro")
	public boolean isPro() {
		return pro;
	}
	
	/**
	 * Spécifie si l'agence gère les pros
	 * @param generalPublic True si l'agence gère les pros
	 */
	@JsonProperty(value = "pro")
	public void setPro(boolean pro) {
		this.pro = pro;
	}
	
	/**
	 * Indique si l'agence gère les agriculteurs
	 * @return True si l'agence gère les agriculteurs
	 */
	@JsonProperty(value = "farmer")
	public boolean isFarmer() {
		return farmer;
	}
	
	/**
	 * Spécifie si l'agence gère les agriculteurs
	 * @param generalPublic True si l'agence gère les agriculteurs
	 */
	@JsonProperty(value = "farmer")
	public void setFarmer(boolean farmer) {
		this.farmer = farmer;
	}
	
	/**
	 * Indique si l'agence gère les associations
	 * @return True si l'agence gère les associations
	 */
	@JsonProperty(value = "association")
	public boolean isAssociation() {
		return association;
	}
	
	/**
	 * Spécifie si l'agence gère les associations
	 * @param generalPublic True si l'agence gère les associations
	 */
	@JsonProperty(value = "association")
	public void setAssociation(boolean association) {
		this.association = association;
	}
	
	/**
	 * Indique si l'agence gère les entreprises
	 * @return True si l'agence gère les entreprises
	 */
	@JsonProperty(value = "enterprise")
	public boolean isEnterprise() {
		return enterprise;
	}
	
	/**
	 * Spécifie si l'agence gère les entreprises
	 * @param generalPublic True si l'agence gère les entreprises
	 */
	@JsonProperty(value = "enterprise")
	public void setEnterprise(boolean enterprise) {
		this.enterprise = enterprise;
	}
	
	/**
	 * Indique si l'agence gère les collectivités publiques
	 * @return True si l'agence gère les collectivités publiques
	 */
	@JsonProperty(value = "public_collectivity")
	public boolean isPublicCollectivity() {
		return publicCollectivity;
	}
	
	/**
	 * Spécifie si l'agence gère les collectivités publiques
	 * @param generalPublic True si l'agence gère les collectivités publiques
	 */
	@JsonProperty(value = "public_collectivity")
	public void setPublicCollectivity(boolean publicCollectivity) {
		this.publicCollectivity = publicCollectivity;
	}
}
