package fr.ca.cat.ihml.oidc.bff.models.places;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Objet définissant les heures d'ouvertures de l'agence
 * @author ET02720
 *
 */
public class OpeningHours {

	/**
	 * Heure d'ouverture de l'agence
	 * @see OpeningHours#getOpening()
	 * @see OpeningHours#setOpening(String)
	 */
	private String opening;
	
	/**
	 * Heure de fermeture de l'agence
	 * @see OpeningHours#getClosing()
	 * @see OpeningHours#setClosing(String)
	 */
	private String closing;
	
	/**
     * Type de l'heure
     * @see OpeningHours#getHou()
     * @see OpeningHours#setClosing(String)
     */
    private String hoursType;
	
	/**
	 * Retourne une heure d'ouverture de l'agence
	 * @return Une heure d'ouverture de l'agence
	 */
	@JsonProperty(value = "opening")
	public String getOpening() {
		return opening;
	}
	
	/**
	 * Met à jour une heure d'ouvertude de l'agence
	 * @param opening La nouvelle heure d'ouverture de l'agence
	 */
	@JsonProperty(value = "opening")
	public void setOpening(String opening) {
		this.opening = opening;
	}
	
	/**
	 * Retourne une heure de fermeture de l'agence
	 * @return Une heure de fermeture de l'agence
	 */
	@JsonProperty(value = "closing")
	public String getClosing() {
		return closing;
	}
	
	/**
	 * Met à jour une heure de fermeture de l'agence
	 * @param closing Une nouvelle heure de fermeture de l'agence
	 */
	@JsonProperty(value = "closing")
	public void setClosing(String closing) {
		this.closing = closing;
	}
	
	 /**
     * Retourne le type de l'heure
     * @return Type de l'heure
     */
    @JsonProperty(value = "hoursType")
    public String getHoursType() {
        return hoursType;
    }
    
    /**
     * Met à jour le type de l'heure
     * @param hoursType Un nouveau type de l'heure
     */
    @JsonProperty(value = "hoursType")
    public void setHoursType(String hoursType) {
        this.hoursType = hoursType;
    }
}
