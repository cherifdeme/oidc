package fr.ca.cat.ihml.oidc.bff.models.places;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Objet définissant les services proposés par une agence
 * @author ET02720
 *
 */
public class Services {

	/**
	 * Possède un guichet automatioque bancaire
	 * @see Services#isAtm()
	 * @see Services#setAtm(boolean)
	 */
	private boolean atm;
	
	/**
	 * Possède un distributeur automatique de billets
	 * @see Services#isAutomaticCashMachine()
	 * @see Services#setAutomaticCashMachine(boolean)
	 */
	private boolean automaticCashMachine;
	
	/**
	 * Possède une rampe d'accès pour les personnes handicapés
	 * @see Services#isWheelChairAccess()
	 * @see Services#setWheelChairAccess(boolean)
	 */
	private boolean wheelChairAccess;
	
	/**
	 * Possède un parking
	 * @see Services#isCarPark()
	 * @see Services#setCarPark(boolean)
	 */
	private boolean carPark;
	
	/**
	 * Possède un service de conversion de monnaie
	 * @see Services#isExchangeCurrency()
	 * @see Services#setExchangeCurrency(boolean)
	 */
	private boolean exchangeCurrency;
	
	/**
	 * Possède un service supplémentaire
	 * @see Services#getExtraService1()
	 * @see Services#setExtraService1(String)
	 */
	private String extraService1;
	
	/**
	 * Possède un second service supplémentaire
	 * @see Services#getExtraService2()
	 * @see Services#setExtraService2(String)
	 */
	private String extraService2;
	
	/**
	 * Possède une troisième service supplémentaire
	 * @see Services#getExtraService3()
	 * @see Services#setExtraService3(String)
	 */
	private String extraService3;
	
	/**
	 * Indique si l'agence possède un guichet automatioque bancaire
	 * @return True si l'agence possède un guichet automatioque bancaire
	 */
	@JsonProperty(value = "atm")
	public boolean isAtm() {
		return atm;
	}
	
	/**
	 * Spécifie si l'agence possède un guichet automatioque bancaire
	 * @param atm True si l'agence possède un guichet automatioque bancaire
	 */
	@JsonProperty(value = "atm")
	public void setAtm(boolean atm) {
		this.atm = atm;
	}
	
	/**
	 * Indique si l'agence possède un distributeur de billets automatique
	 * @return True si l'agence possède un distributeur de billets automatique
	 */
	@JsonProperty(value = "automatic_cash_machine")
	public boolean isAutomaticCashMachine() {
		return automaticCashMachine;
	}
	
	/**
	 * Spécifie si l'agence possède un distributeur de billets automatique
	 * @param atm True si l'agence possède un distributeur de billets automatique
	 */
	@JsonProperty(value = "automatic_cash_machine")
	public void setAutomaticCashMachine(boolean automaticCashMachine) {
		this.automaticCashMachine = automaticCashMachine;
	}
	
	/**
	 * Indique si l'agence possède une rampe d'accès pour les personnes handicapés
	 * @return True si l'agence possède une rampe d'accès pour les personnes handicapés
	 */
	@JsonProperty(value = "wheel_chair_access")
	public boolean isWheelChairAccess() {
		return wheelChairAccess;
	}
	
	/**
	 * Spécifie si l'agence possède une rampe d'accès pour les personnes handicapés
	 * @param atm True si l'agence possède une rampe d'accès pour les personnes handicapés
	 */
	@JsonProperty(value = "wheel_chair_access")
	public void setWheelChairAccess(boolean wheelChairAccess) {
		this.wheelChairAccess = wheelChairAccess;
	}
	
	/**
	 * Indique si l'agence possède un parking
	 * @return True si l'agence possède un parking
	 */
	@JsonProperty(value = "car_park")
	public boolean isCarPark() {
		return carPark;
	}
	
	/**
	 * Spécifie si l'agence possède un parking
	 * @param atm True si l'agence possède un parking
	 */
	@JsonProperty(value = "car_park")
	public void setCarPark(boolean carPark) {
		this.carPark = carPark;
	}
	
	/**
	 * Indique si l'agence possède un service de conversion de monnaie
	 * @return True si l'agence possède un service de conversion de monnaie
	 */
	@JsonProperty(value = "exchange_currency")
	public boolean isExchangeCurrency() {
		return exchangeCurrency;
	}
	
	/**
	 * Spécifie si l'agence possède un service de conversion de monnaie
	 * @param atm True si l'agence possède un service de conversion de monnaie
	 */
	@JsonProperty(value = "exchange_currency")
	public void setExchangeCurrency(boolean exchangeCurrency) {
		this.exchangeCurrency = exchangeCurrency;
	}
	
	
	/**
	 * Retourne un service supplémentaire de l'agence
	 * @return Un service supplémentaire de l'agence
	 */
	@JsonProperty(value = "extra_service_1")
	public String getExtraService1() {
		return extraService1;
	}
	
	/**
	 * Met à jour un service supplémentaire de l'agence
	 * @param extraService1 Le nouveau service supplémentaire de l'agence
	 */
	@JsonProperty(value = "extra_service_1")
	public void setExtraService1(String extraService1) {
		this.extraService1 = extraService1;
	}
	
	/**
	 * Retourne un second service supplémentaire de l'agence
	 * @return Un second service supplémentaire de l'agence
	 */
	@JsonProperty(value = "extra_service_2")
	public String getExtraService2() {
		return extraService2;
	}
	
	/**
	 * Met à jour un second service supplémentaire de l'agence
	 * @param extraService2 Le nouveau second service supplémentaire de l'agence
	 */
	@JsonProperty(value = "extra_service_2")
	public void setExtraService2(String extraService2) {
		this.extraService2 = extraService2;
	}
	
	/**
	 * Retourne un troisième service supplémentaire de l'agence
	 * @return Un troisième service supplémentaire de l'agence
	 */
	@JsonProperty(value = "extra_service_3")
	public String getExtraService3() {
		return extraService3;
	}
	
	/**
	 * Met à jour un troisième service supplémentaire de l'agence
	 * @param extraService3 Le nouveau troisième service supplémentaire de l'agence
	 */
	@JsonProperty(value = "extra_service_3")
	public void setExtraService3(String extraService3) {
		this.extraService3 = extraService3;
	}
	
}
