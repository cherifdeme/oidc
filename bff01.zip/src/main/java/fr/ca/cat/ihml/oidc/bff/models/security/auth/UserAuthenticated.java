package fr.ca.cat.ihml.oidc.bff.models.security.auth;

import java.util.Collection;

import fr.ca.cat.ihml.oidc.bff.models.security.user.UserDetails;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;

/**
 * Class représentant un utilisateur de connexion
 * @author ET02720
 *
 */
public class UserAuthenticated implements Authentication {

	private static final long serialVersionUID = 1L;
	
	/**
	 * Access token pour l'accès au API
	 */
	private String accessToken;
	
	/**
	 * Information sur l'utilisateur connecté
	 */
	private UserDetails user;
	
	/**
	 * Boolean pour savoir si l'utilisateur est connecté
	 */
	private boolean authenticated;

	/**
	 * Constructeur
	 * @param user Details sur l'utilisateur connecté
	 * @param accessToken Access token d'accès aux API
	 */
	public UserAuthenticated(UserDetails user, String accessToken) {
		this.accessToken = accessToken;
		this.user = user;
	}

	@Override
	public String getName() {
		return this.user.getId();
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return this.user.getRoles();
	}

	@Override
	public String getCredentials() {
		return this.accessToken;
	}

	@Override
	public String getDetails() {
		return this.user.getFpLabel();
	}

	@Override
	public UserDetails getPrincipal() {
		return this.user;
	}

	@Override
	public boolean isAuthenticated() {
		return authenticated;
	}

	@Override
	public void setAuthenticated(boolean isAuthenticated) {
		this.authenticated = isAuthenticated;
	}

}
