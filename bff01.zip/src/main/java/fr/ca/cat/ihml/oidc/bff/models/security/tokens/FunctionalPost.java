package fr.ca.cat.ihml.oidc.bff.models.security.tokens;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Classe représentant un poste fonctionnel
 * 
 * @author ET02720
 *
 */
public class FunctionalPost {
    
	/**
	 * Id du poste fonctionnel
	 * @see FunctionalPost#getId()
	 * @see FunctionalPost#setId(String) 
	 */
    private String id;
    
    /**
     * Label du poste fonctionnel
     * @see FunctionalPost#getLabel()
     * @see FunctionalPost#setLabel(String)
     */
    private String label;
    
    /**
     * Id de l'element de structure
     * @see FunctionalPost#getStructureElementId()
     * @see FunctionalPost#setStructureElementId(String)
     */
    private String structureElementId;
    
    /**
     * Récupération de l'id du poste fonctionnel
     * @return L'id du poste fonctionnel
     */
    @JsonProperty(value = "id")
    public String getId() {
        return id;
    }

    /**
     * Spécifie l'id du poste fonctionnel
     * @param id Le nouvel id du poste fonctionnel
     */
    @JsonProperty(value = "id")
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Récupération du label du poste fonctionnel
     * @return Le label du poste fonctionnel
     */
    @JsonProperty(value = "label")
    public String getLabel() {
        return label;
    }

    /**
     * Spécifie le label du poste fonctionnel
     * @param label Le nouveau label du poste fonctionnel
     */
    @JsonProperty(value = "label")
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * Récuparation de l'id d'element de structure du poste fonctionnel
     * @return L'id d'element de structure du poste fonctionnel
     */
    @JsonProperty(value = "structure_element_id")
    public String getStructureElementId() {
        return structureElementId;
    }

    /**
     * Spécifie l'id d'element de structure du poste fonctionnel
     * @param structureElementId Le nouvel id d'element de structure du poste fonctionnel
     */
    @JsonProperty(value = "structure_element_id")
    public void setStructureElementId(String structureElementId) {
        this.structureElementId = structureElementId;
    }
    
}
