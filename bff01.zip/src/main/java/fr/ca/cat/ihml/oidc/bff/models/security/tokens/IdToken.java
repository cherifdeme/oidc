package fr.ca.cat.ihml.oidc.bff.models.security.tokens;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Classe  representant les informations essentielles d'un IdToken
 * 
 * @author ET02720
 *
 */
public class IdToken {

	/**
	 * Identifiant de l'utilisateur
	 * @see IdToken#getSub()
	 * @see IdToken#setSub(String)
	 */
    private String sub;
    
    /**
     * Liste despostes fonctionnels de l'utilisateur
     * @see IdToken#getFunctionalPosts()
     * @see IdToken#setFunctionalPosts(List)
     */
    private List<FunctionalPost> functionalPosts;
    
    /**
     * Poste fonctionnel actuel de l'utilisateur
     * @see IdToken#getFunctionalPost()
     * @see IdToken#setFunctionalPosts(List)
     */
    private FunctionalPost functionalPost;
    
    /**
     * Id de session X Connect
     * @see IdToken#getSid()
     * @see IdToken#setSid(String)
     */
    private String sid;
    
    /**
     * Jti
     * @see IdToken#getJti()
     * @see IdToken#setJti(String)
     */
    private String jti;

    /**
     * Récupération de l'id de l'utilisateur
     * @return L'id de l"utilisateur
     */
    @JsonProperty(value = "sub")
    public String getSub() {
        return sub;
    }

    /**
     * Spécifie l'Id de l'utilisateur
     * @param sub Le nouvel Id de l'utilisateur
     */
    @JsonProperty(value = "sub")
    public void setSub(String sub) {
        this.sub = sub;
    }

    /**
     * Récupération de la liste des postes fonctionnels de l'utilisateur
     * @return La liste des postes fonctionnels de l'utilisateur
     */
    @JsonProperty(value = "functional_posts")
    public List<FunctionalPost> getFunctionalPosts() {
        return functionalPosts;
    }

    /**
     * Spécifie la liste des postes fonctionnels de l'utilisateur
     * @param functionalPosts Les nouveaux postes fonctionnels de l'utilisateur
     */
    @JsonProperty(value = "functional_posts")
    public void setFunctionalPosts(List<FunctionalPost> functionalPosts) {
        this.functionalPosts = functionalPosts;
    }

    /**
     * Récupération du poste fonctionnel actuel de l'utilisateur
     * @return Le poste fonctionnel actuel de l'utilisateur
     */
    @JsonProperty(value = "functional_post")
    public FunctionalPost getFunctionalPost() {
        return functionalPost;
    }

    /**
     * Spécifie le poste fonctionnel actuel de l'utilisateur
     * @param functionalPost Le nouveau poste fonctionel de l'utilisateur
     */
    @JsonProperty(value = "functional_post")
    public void setFunctionalPost(FunctionalPost functionalPost) {
        this.functionalPost = functionalPost;
    }

    /**
     * Récupération de l'id de session X connect
     * @return L'id de session X Connect
     */
    @JsonProperty(value = "sid")
    public String getSid() {
        return sid;
    }

    /**
     * Spécifie l'id de session X Connect
     * @param sid Le nouvel id de session  X Connect
     */
    @JsonProperty(value = "sid")
    public void setSid(String sid) {
        this.sid = sid;
    }

    /**
     * Récupération du jti
     * @return le Jti
     */
    @JsonProperty(value = "jti")
    public String getJti() {
        return jti;
    }

    /**
     * Spécifie le Jti
     * @param jti Le nouvel JTI
     */
    @JsonProperty(value = "jti")
    public void setJti(String jti) {
        this.jti = jti;
    }
}
