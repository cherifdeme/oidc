package fr.ca.cat.ihml.oidc.bff.models.security.tokens;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * Classe représentant un Logout Token X connect
 * @author ET02720
 *
 */
public class LogoutToken {

	/**
	 * L'issuer
	 * @see LogoutToken#getIss()
	 * @see LogoutToken#setIss(String)
	 */
    private String iss;
    
    /**
     * Les events
     * @see LogoutToken#getEvents()
     * @see LogoutToken#setEvents(Map)
     */
    private Map<String,Object> events;
    
    /**
     * L'id de session X Connect
     * @see LogoutToken#getSid()
     * @see LogoutToken#setSid(String)
     */
    private String sid;

    /**
     * Récupération de l'issueur
     * @return L'isseur
     */
    @JsonProperty(value = "iss")
    public String getIss() {
        return iss;
    }

    /**
     * Spécifie l'issueur
     * @param iss Le nouvel issueur
     */
    @JsonProperty(value = "iss")
    public void setIss(String iss) {
        this.iss = iss;
    }

    /**
     * Récupération des events
     * @return Les events
     */
    @JsonProperty(value = "events")
    public Map<String, Object> getEvents() {
        return events;
    }

    /**
     * Spécifie les events
     * @param events Les nouveaux events
     */
    @JsonProperty(value = "events")
    public void setEvents(Map<String, Object> events) {
        this.events = events;
    }

    /**
     * Récupération de l'id de session X Connect
     * @return L'id de session X Connect
     */
    @JsonProperty(value = "sid")
    public String getSid() {
        return sid;
    }

    /**
     * Spécifie l'id de session X Connect
     * @param sid Le nouveal Id de session X Connect
     */
    @JsonProperty(value = "sid")
    public void setSid(String sid) {
        this.sid = sid;
    }    
}
