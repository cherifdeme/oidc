package fr.ca.cat.ihml.oidc.bff.models.security.tokens;

/**
 * Classe  décrivant l'objet de stockage du RefreshToken dans le cache Redis
 *
 * @author ET02720
 *
 */
public class RefreshToken {

	/**
	 * Le refresh token
	 */
	private String token;

	/**
	 * La session liée au refresh token
	 */
	private String sessionId;
	
	/**
	 * Default constructor
	 */
	public RefreshToken() {}

	/**
	 * Constructeur d'un RefreshToken
	 * 
	 * @param token le refresh token
	 * @param sessionId l'id de la session liée au refresh token
	 */
	public RefreshToken(String token, String sessionId) {
		super();
		this.token = token;
		this.sessionId = sessionId;
	}

	/***
	 * Retourne le refresh token
	 * 
	 * @return le refresh token
	 */
	public String getToken() {
		return token;
	}

	/**
	 * Met à jour le refresh token
	 * 
	 * @param token Le nouveau refresh token
	 */
	public void setToken(String token) {
		this.token = token;
	}

	/**
	 * Retourne l'id de la session liée au refresh token
	 * 
	 * @return L'id de la session liée au refresh token
	 */
	public String getSessionId() {
		return sessionId;
	}

	/**
	 * Met à jour l'id de la session liée au refresh token
	 * 
	 * @param sessionId  L'id de la nouvelle session liée au refresh token
	 */
	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

}
