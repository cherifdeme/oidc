package fr.ca.cat.ihml.oidc.bff.models.security.user;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import org.springframework.security.core.GrantedAuthority;

/**
 * Objet définissant un utilisateur
 * 
 * @author ET02720
 *
 */
public class UserDetails implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	/**
	 * Id de l'utilisateur
	 * 
	 * @see UserDetails#getId()
	 * @see UserDetails#setId(String)
	 */
	private String id;

	/**
	 * label du poste fonctionnel
	 * 
	 * @see UserDetails#getFpLabel()
	 * @see UserDetails#setFpLabel(String)
	 */
	private String fpLabel;
	
	/**
	 * State pour la protection csrf
	 * @see UserDetails#getState()
	 * @see UserDetails#setState(String)
	 */
	private String state;
	
	/**
	 * Liste des roles de l'utilisateur
	 * @see UserDetails#getRoles()
	 * @see UserDetails#setRoles(Set)
	 */
	private Set<GrantedAuthority> roles;
	
	
	/**
	 * Constructeur privé
	 */
	public UserDetails() {
		this.roles = new HashSet<>();
	}
	
	/**
	 * Retourne l'Id de l'utilisateur
	 * 
	 * @return L'Id de l'utilisateur
	 */
	public String getId() {
		return id;
	}

	/**
	 * Spécifie l'Id de l'utilisateur
	 * 
	 * @param id Le nouveal Id de l'utilisateur
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * Récupération du poste fonctionnel de l'utilisateur
	 * @return Le poste fonctionnel de l'utilisateur
	 */
	public String getFpLabel() {
		return fpLabel;
	}

	/**
	 * Spécifie le poste fonctionnel de l'utilisateur
	 * @param fpLabel Le nouveau poste fonctionnel de l'utilisateur
	 */
	public void setFpLabel(String fpLabel) {
		this.fpLabel = fpLabel;
	}

	/**
	 * Récupération du state de la session utilisateur
	 * @return Le state de la session utilisateur
	 */
	public String getState() {
		return state;
	}

	/**
	 * Spécifie le state de la session utilisateur
	 * @param state Le nouveau state de la session utilisateur
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * Récupération de la liste des roles de l'utilisateurs
	 * @return La liste des roles de l'utilisateur
	 */
	public Set<GrantedAuthority> getRoles() {
		return roles;
	}

	/**
	 * Méthode non autorisée
	 * @param authorities
	 */
	public void setRoles(Set<GrantedAuthority> roles) {
		this.roles = roles;
	}

}
