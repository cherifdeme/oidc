package fr.ca.cat.ihml.oidc.bff.models.validator;

import java.util.ArrayList;
import java.util.List;

/**
 * Class représentant une reponse contenant les erreurs de validation
 * 
 * @author ET02720
 *
 */
public class ValidationErrorResponse {

    /**
     * Liste des violations
     * 
     * @see ValidationErrorResponse#getViolations()
     * @see ValidationErrorResponse#setViolations(List)
     */
    private List<Violation> violations = new ArrayList<>();

    public ValidationErrorResponse() {
        super();
    }

    public ValidationErrorResponse(List<Violation> violations) {
        super();
        this.violations = violations;
    }

    /**
     * Retourne la liste des violations
     * 
     * @return La liste de violation
     */
    public List<Violation> getViolations() {
        return violations;
    }

    /**
     * Spécifie la liste des violations
     * 
     * @param violations la liste des violations
     */
    public void setViolations(List<Violation> violations) {
        this.violations = violations;
    }

}
