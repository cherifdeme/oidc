package fr.ca.cat.ihml.oidc.bff.models.validator;

/**
 * Class representant une erreur de validation
 * 
 * @author ET02720
 *
 */
public class Violation {

    /**
     * le champ en erreur
     * 
     * @see Violation#getFieldName()
     * @see Violation#setFieldName(String)
     */
    private String fieldName;

    /**
     * Le message de la violation
     * 
     * @see Violation#getMessage()
     * @see Violation#setMessage(String)
     */
    private String message;

    public Violation() {
        super();
    }

    public Violation(String fieldName, String message) {
        super();
        this.fieldName = fieldName;
        this.message = message;
    }

    /**
     * Retourne le champ en erreur
     * 
     * @return Le champ en erreur
     */
    public String getFieldName() {
        return fieldName;
    }

    /**
     * Spécifie le champ en erreur
     * 
     * @param fieldName Le champ en erreur
     */
    public void setFieldName(String fieldName) {
        this.fieldName = fieldName;
    }

    /**
     * Retourne le message de violation
     * 
     * @return le message de violation
     */
    public String getMessage() {
        return message;
    }

    /**
     * Spécifie le message de violation
     * 
     * @param message Le message de violation
     */
    public void setMessage(String message) {
        this.message = message;
    }

}
