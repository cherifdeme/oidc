package fr.ca.cat.ihml.oidc.bff.security;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.services.logs.ApplicationLogger;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.access.AccessDeniedHandlerImpl;
import org.springframework.security.web.server.csrf.CsrfException;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.web.filter.OncePerRequestFilter;

import fr.ca.cat.ihml.oidc.bff.utils.AppUtils;

/**
 * Filtre en charge de la protection CSRF.
 * Implémentation du pattern Double submit cookie
 * @author ET02720
 *
 */
public class CsrfFilter extends OncePerRequestFilter {
    /**
     * Déclaration du logger de la classe
     */
    private static ApplicationLogger appLogger = ApplicationLogger.getLogger(CsrfFilter.class);
    
    /**
     * Injection de la variable pour le chemin des cookies
     */
    private String csrfCookiePath;
    
    /**
     * Injection de la variable pour la propriété SameSite des cookies
     */
    private String csrfCookieSameSite;
    
    /**
     * Handler spring pour gérer l'erreur 403 CSRF
     */    
    private AccessDeniedHandler accessDeniedHandler = new AccessDeniedHandlerImpl();
    
    /**
     * Liste des URL Matcher à exclure de la vérification CSRF
     */
    private List<AntPathRequestMatcher> antPathMatchers = new ArrayList<>(); 
    
    /**
     * Constructeur
     * @param excludeUrls AntPathPAttern des url a exclure du filtre
     */
	public CsrfFilter(String cookiePath, String cookieSameSite, String... excludeUrls) {
		super();
		this.csrfCookiePath = cookiePath;
		this.csrfCookieSameSite = cookieSameSite;
		
		// Construction ant path request matcher des url à exclure du filtre
		for (String excludeUrl: excludeUrls) {
			antPathMatchers.add(new AntPathRequestMatcher(excludeUrl));
		}
	}

    @Override
    @SuppressWarnings("findsecbugs:HTTP_RESPONSE_SPLITTING")
    public void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException  {
    	
    	List<String> secureMethods = Arrays.asList("POST", "DELETE", "PUT", "PATCH");
    	
	
    	if (isUrlCsrfRequired(request) && secureMethods.contains(request.getMethod())) {
            appLogger.initLog().level(LogLevel.DEBUG)
            .message("Vérification CSRF nécessaire")
            .eventTyp(Constants.LOGS_EVT_TYPE_CSRF)
            .eventCod(Constants.LOGS_EVT_CODE_CSRF_VERIFICATION)
            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_CSRF)
            .log(); 

    		// Récupération header csrf
        	String csrfRequestHeaderValue = request.getHeader(Constants.X_XSRF_TOKEN_HEADER);
        	
        	// Récupération cookie csrf
        	Cookie[] cookiesRequest = request.getCookies();
        	Optional<Cookie> csrfCookieValue = Objects.nonNull(cookiesRequest) ? Arrays.asList(cookiesRequest).stream().filter(c-> c.getName().equals(Constants.XSRF_TOKEN_COOKIE)).findFirst() : Optional.empty();
                	
        	if (StringUtils.isBlank(csrfRequestHeaderValue) ||
        	        !csrfCookieValue.isPresent() || 
        	        StringUtils.isBlank(csrfCookieValue.get().getValue()) ||
        	        !csrfRequestHeaderValue.equals(csrfCookieValue.get().getValue())) {
                // Si header CSRF Absent
        		// ou Cookie CSRF Absent
        		// ou value header et cookie différents --> Erreur CSRF
        	    // ou un des deux valeurs est vide
        		appLogger.initLog().level(LogLevel.ERROR)
                .message("Error CSRF detecté")
                .eventTyp(Constants.LOGS_EVT_TYPE_CSRF)
                .eventCod(Constants.LOGS_EVT_CODE_CSRF_ERROR)
                .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_CSRF)
                .log();    		
        		
        		this.accessDeniedHandler.handle(request, response, new CsrfException("Error CSRF detectée"));
        		return;
        	}
    	}
    	
    	// Ajout d'un nouveau cookie CSRF à chaque réponse
    	var cookieString = AppUtils.buildCookie(Constants.XSRF_TOKEN_COOKIE, generateCsrfToken(), request.getServerName(), csrfCookiePath, false, csrfCookieSameSite, false);
    	response.setHeader("Set-Cookie", cookieString);    		
    	
		chain.doFilter(request, response);

	}
    

    
    /**
     * Generate a crsf token for the use session
     * @return
     */
	private String generateCsrfToken() {
		return UUID.randomUUID().toString();
	}
	
    /**
     * Test si l'url de la requête doit etre vérifié par le filtre
     * 
     * @param request La reqûete entrante
     * @return True si le path de la requête match @see {@link AbstractSecurityFilter#getFilterUrls()}
     */
    protected boolean isUrlCsrfRequired(HttpServletRequest request) {
        return antPathMatchers.stream().filter(matcher -> matcher.matches(request)).count() == 0;
    }


}

