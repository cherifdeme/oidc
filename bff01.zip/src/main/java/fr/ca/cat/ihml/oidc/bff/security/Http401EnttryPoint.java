package fr.ca.cat.ihml.oidc.bff.security;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;

import fr.ca.cat.ihml.oidc.bff.models.http.ErrorResponse;
import fr.ca.cat.ihml.oidc.bff.utils.AppUtils;

/**
 * Classe pour définir le format de retour d'une reponse HTTP 401
 * @author ET02720
 *
 */
public class Http401EnttryPoint implements AuthenticationEntryPoint {

	@Override
	@SuppressWarnings("findsecbugs:XSS_SERVLET")
	public void commence(HttpServletRequest request, HttpServletResponse response, AuthenticationException authException) throws IOException, ServletException {
		var errorResponse = new ErrorResponse();
		errorResponse.setStatus(HttpStatus.UNAUTHORIZED.value());
		errorResponse.setMessage("Identifiants invalides");
		
        // Ecriture de la réponse
        response.setStatus(errorResponse.getStatus());
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.getWriter().write(AppUtils.convertObjectToJsonString(errorResponse));
	}

}
