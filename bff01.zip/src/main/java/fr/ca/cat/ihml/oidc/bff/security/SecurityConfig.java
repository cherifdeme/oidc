package fr.ca.cat.ihml.oidc.bff.security;

import fr.ca.cat.ihml.oidc.bff.services.security.SecurityServiceImpl;
import jakarta.annotation.Nullable;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AnonymousAuthenticationFilter;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.util.List;

/**
 * Class de configuration de la sécurité via spring security
 *
 * @author ET02720
 */
@Configuration
@EnableWebSecurity
public class SecurityConfig {

    /**
     * Injection de la variable allow origin
     */
    @Value("${cors.allow.origin}")
    private List<String> allowOrigin;

    /**
     * Injection de la variable allow headers
     */
    @Value("${cors.allow.headers}")
    private List<String> allowHeaders;

    /**
     * Injection de la variable allow methods
     */
    @Value("${cors.allow.methods}")
    private List<String> allowMethods;

    /**
     * Injection de la variable allow credentials
     */
    @Value("${cors.allow.credentials}")
    private boolean allowCredentials;

    /**
     * Injection de la propriété pour spécifier le path pour le cookie de
     * session Spring
     */
    @Value("${security.session.cookie.path}")
    private String path;

    /**
     * Injection de la propriété pour spécifier le samesite pour le cookie de
     * session Spring
     */
    @Value("${security.session.cookie.samesite}")
    private String sameSite;

    /**
     * Injection du seuil de durée de l'access token
     */
    @Value("${security.access.token.threshold:30}")
    private int accessTokenThreshold;

    private final ApplicationContext context;

    public SecurityConfig(ApplicationContext context) {
        this.context = context;
    }

    /**
     * Spécification de la configuration CORS
     *
     * @return {@link WebMvcConfigurer}
     */
    @Bean
    public WebMvcConfigurer corsConfigurer() {
        return new WebMvcConfigurer() {
            @Override
            public void addCorsMappings(@Nullable CorsRegistry registry) {
                registry.addMapping("/**")
                        .allowedOrigins(allowOrigin.toArray(String[]::new))
                        .allowedHeaders(allowHeaders.toArray(String[]::new))
                        .allowedMethods(allowMethods.toArray(String[]::new))
                        .maxAge(2147483647)
                        .allowCredentials(allowCredentials);
            }
        };
    }

    /**
     * Déclaration du filtre pour la gestion des CSRF
     *
     * @return {@link CsrfFilter}
     */
    public CsrfFilter csrfFilter() {
        return new CsrfFilter(path, sameSite, "/security/**", "/logs/send");
    }

    /**
     * Déclaration du filtre pour l'authentification d'une session
     *
     * @return {@link SessionAuthenticationFilter}
     */
    public SessionAuthenticationFilter sessionAuthenticationFilter() {
        return new SessionAuthenticationFilter(context.getBean(SecurityServiceImpl.class), accessTokenThreshold);
    }

    /**
     * Configuration de la sécurité Http
     */
    @Bean
    @SuppressWarnings("findsecbugs:SPRING_CSRF_PROTECTION_DISABLED")
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .securityContext(securityContext -> securityContext
                        .requireExplicitSave(false))

                // Gestion CORS
                .cors(cors -> cors.configure(http))

                // Spécifie 401 sur erreur authentification
                .exceptionHandling(exceptionHandling -> exceptionHandling.authenticationEntryPoint(new Http401EnttryPoint()))

                // Gestion de l'accès au API
                .csrf(csrf -> csrf.disable())
                .addFilterBefore(sessionAuthenticationFilter(), AnonymousAuthenticationFilter.class)
                .addFilterBefore(csrfFilter(), AnonymousAuthenticationFilter.class)
                .authorizeHttpRequests((requests) -> requests.requestMatchers("/places/**", "/context/**").authenticated()
                        .anyRequest().permitAll())

                // Désactivation authentification par défaut spring security
                .httpBasic(httpBasic -> httpBasic.disable())
                .formLogin(formLogin -> formLogin.disable())
                .logout(logout -> logout.disable());
        return http.build();
    }


    /**
     * Spécification de la sécurité Web
     */
    @Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        // Desactivation de la sécurité pour ces points d'accès
        return web -> web.ignoring().requestMatchers("/probes/**", "/openapi/**", "/swagger-ui/**", "/metrics", "/health", "/healthcheck", "/launcher/**", "/public/**", "/encrypt/**");
    }
}
