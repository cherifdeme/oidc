package fr.ca.cat.ihml.oidc.bff.security;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.services.logs.ApplicationLogger;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import org.jose4j.base64url.Base64;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import fr.ca.cat.ihml.oidc.bff.services.security.SecurityServiceImpl;
import fr.ca.cat.ihml.oidc.bff.utils.AppUtils;

/**
 * Filtre pour la gestion de la sécurité des ressources de l'application
 * 
 * @author ET02720
 *
 */
public class SessionAuthenticationFilter extends OncePerRequestFilter {

	/**
	 * Injection SecurityService
	 */
    private SecurityServiceImpl securityService;
    
    /**
     * Injection du seuil de durée de l'access token
     * 
     */
    private int accessTokenThreshold;
    

    /**
     * Déclaration du logger de la classe
     */
    private static ApplicationLogger appLogger = ApplicationLogger.getLogger(SessionAuthenticationFilter.class);
    
    public SessionAuthenticationFilter(SecurityServiceImpl securityService, int accessTokenThreshold) {
    	this.securityService = securityService;
    	this.accessTokenThreshold = accessTokenThreshold;
    }
    
    @Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws ServletException, IOException {

    	appLogger.initLog().level(LogLevel.DEBUG)
        .message("Extraction des données de session de la requête")
        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
        .eventCod(Constants.LOGS_EVT_CODE_FILTER_START)
        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
        .log(); 
    	
    	// Récupération de la session
		var session = request.getSession();
        	
        // Récupération des cookies
    	Cookie[] cookies = request.getCookies();
    	Map<String, Cookie> cookiesRequest = Objects.nonNull(cookies) ? Arrays.asList(cookies).stream().collect(Collectors.toMap(Cookie::getName, cookie -> cookie)) : new HashMap<>();
    	
    	var sessionIdCookie = cookiesRequest.get(Constants.SESSION_ID_COOKIE);
    	var sessionIdCookieValue = Objects.nonNull(sessionIdCookie) ? sessionIdCookie.getValue() : null;
    	
    	var refreshCookie = cookiesRequest.get(Constants.SESSION_REFRESH_COOKIE);
    	var refreshTokenKey = Objects.nonNull(refreshCookie) ? refreshCookie.getValue() : null;
    	
		// Test pour savoir si on doit rafraichir le token
		boolean sessionExpired = isSessionExpired(session);
    	
		// La session a expirée. On essaye de la renouveller
		if (sessionExpired && Objects.nonNull(refreshTokenKey) && Objects.nonNull(sessionIdCookieValue)) {
            try {
                // Demande de refresh token
                this.securityService.refreshToken(refreshTokenKey, new String(Base64.decode(sessionIdCookieValue)));
            } catch (ApiException | IllegalArgumentException e) {
            	
                // Une erreur est intervenue dans la demande du refresh_token. On refuse l'authentication
                appLogger.initLog().level(LogLevel.ERROR)
                .message(e.getMessage())
                .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
                .eventCod(Constants.LOGS_EVT_CODE_REFRESH_TOKEN_KO)
                .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_SESSION)
                .log();	 
                
                SecurityContextHolder.getContext().setAuthentication(null);
            }
		} else if (Objects.isNull(refreshTokenKey) || Objects.isNull(sessionIdCookieValue) ) {
			SecurityContextHolder.getContext().setAuthentication(null);
		}
		
		if (Objects.isNull(SecurityContextHolder.getContext().getAuthentication())) {            
            appLogger.initLog().level(LogLevel.DEBUG)
            .message("Aucun utilisateur authentifié pour cette session.")
            .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
            .eventCod(Constants.LOGS_EVT_CODE_NO_USER_FOR_SESSION)
            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_SESSION)
            .log();            
		} else {			
        	appLogger.initLog().level(LogLevel.DEBUG)
            .message("Utilisateur authentifié")
            .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
            .eventCod(Constants.LOGS_EVT_CODE_SESSION_OK)
            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
            .log();        	
		}
		
		// On passe au filtre suivant
		chain.doFilter(request, response);
    }  
    
    /**
     * Méthode pour savoir si la session a expirée
     * @param HttpSession session en cours
     * @return True ou false
     */
    private boolean isSessionExpired(HttpSession session) {
    	var sessionExpired = false;
    	
    	 // Récupération de la clé d'expiration du token depuis la session
        var expiresKey = session.getAttribute(Constants.EXPIRES_AT_KEY);
        var sessionExpirationDateInMilli = Objects.nonNull(expiresKey) ? (long) expiresKey : 0;

        if (sessionExpirationDateInMilli > 0) {
            // Clé valide. On calcul la date d'expiration
            var sessionExpirationDate = AppUtils.dateFromMilliseconds(sessionExpirationDateInMilli);

            // on se laisse de la marge pour que l' access token ne
            // devienne pas invalide au milieu d'une séquence d'appels
            var threshold = LocalDateTime.now().plusSeconds(this.accessTokenThreshold);

            if (threshold.isAfter(sessionExpirationDate)) {
                // Si la session va expiré dans 30 seconds on demande le
                // refresh du token
            	sessionExpired = true;
                appLogger.initLog().level(LogLevel.DEBUG)
                .message(String.format("L'access token de la session va expirée dans %d secondes. On demande le refresh du token", this.accessTokenThreshold))
                .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
                .eventCod(Constants.LOGS_EVT_CODE_REFRESH_TOKEN_NEEDED_ACCESS_TOKEN_EXPIRED)
                .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_SESSION)
                .log();
            }
            
            appLogger.initLog().level(LogLevel.DEBUG)
            .message("L'access token de la session est valide pour accéder à la ressource")
            .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
            .eventCod(Constants.LOGS_EVT_CODE_SESSION_OK)
            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_SESSION)
            .log();
            
        } else {
        	// La session spring a expiré. 
        	// Demande d'access token via le RT pour la nouvelle session spring
            appLogger.initLog().level(LogLevel.DEBUG)
            .message("La session spring a expirée.")
            .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
            .eventCod(Constants.LOGS_EVT_CODE_SESSION_EXPIRED)
            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_SESSION)
            .log();
            
        	sessionExpired = true;
        }    
        
        return sessionExpired;
    }

}
