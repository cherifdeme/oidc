package fr.ca.cat.ihml.oidc.bff.services.api;

import jakarta.servlet.http.HttpSession;

/**
 * Classe parente pour déclarer les Services nécessitant l'accès aux API
 * 
 * @author ET02720
 *
 */
public class ApiService {

    /**
     * Inject de la session HTTP
     */
    protected HttpSession springSession;
	
}
