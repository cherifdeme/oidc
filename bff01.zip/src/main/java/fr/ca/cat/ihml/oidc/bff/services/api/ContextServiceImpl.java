package fr.ca.cat.ihml.oidc.bff.services.api;

import java.io.IOException;
import java.util.Collections;
import java.util.UUID;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.services.logs.ApplicationLogger;
import jakarta.servlet.http.HttpSession;

import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import fr.ca.cat.ihml.oidc.bff.feign.client.ContextServiceFeign;
import fr.ca.cat.ihml.oidc.bff.models.context.ApplicationContext;
import fr.ca.cat.ihml.oidc.bff.models.context.Ctx9WriteContext;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;

/**
 * Service pour appeler les ressources de l'API CTX9
 * 
 * @author ET02720
 *
 */
@Service
public class ContextServiceImpl extends ApiService implements IContextService {

    /**
     * Déclaration du logger de la classe
     */
    private static ApplicationLogger appLogger = ApplicationLogger.getLogger(ContextServiceImpl.class);


    /**
     * Service Feign pour l'appel de l'api
     */
    private ContextServiceFeign contextServiceFeign;
    
    /**
     * Constructeur
     * @param contextServiceFeign {@link ContextServiceFeign}
     * @param springSession Session Spring
     */
    public ContextServiceImpl(ContextServiceFeign contextServiceFeign, HttpSession springSession) {
    	this.contextServiceFeign = contextServiceFeign;
    	this.springSession = springSession;
    }
    
    public ApplicationContext getContext(UUID ctxId) throws IOException, ApiException {
        appLogger.initLog().level(LogLevel.INFO)
        .message(String.format("Récupération du context: %s", ctxId))
        .eventTyp(Constants.LOGS_EVT_TYPE_CONTEXT)
        .eventCod(Constants.LOGS_EVT_CODE_CONTEXT_GET)
        .log();

        var ctx9Context = this.contextServiceFeign.getContextRequest(Collections.singletonMap("context_id", ctxId.toString()));
        
        // Mapping de la réponse de la requête
        appLogger.initLog().level(LogLevel.INFO)
        .message(String.format("Récupération du context: %s --> OK", ctxId))
        .eventTyp(Constants.LOGS_EVT_TYPE_CONTEXT)
        .eventCod(Constants.LOGS_EVT_CODE_CONTEXT_GET)
        .log();
        
        return ctx9Context.toApplicationContext();
    }

    public Ctx9WriteContext setContext(ApplicationContext applicationContext) throws IOException, ApiException {
        appLogger.initLog().level(LogLevel.INFO)
        .message("Sauvegarde du contexte")
        .eventTyp(Constants.LOGS_EVT_TYPE_CONTEXT)
        .eventCod(Constants.LOGS_EVT_CODE_CONTEXT_POST)
        .log();
     
        MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
        map.add(Constants.USER_CONTEXT_PARAM, applicationContext.toJsonString());
        map.add(Constants.CLIENT_ID_PARAM, applicationContext.getClientId());

        var writeContext = this.contextServiceFeign.setContext(map);
        
        // Mapping de la réponse de la requête
        appLogger.initLog().level(LogLevel.INFO)
        .message(String.format("Sauvegarde du contexte %S--> OK", writeContext.getContext()))
        .eventTyp(Constants.LOGS_EVT_TYPE_CONTEXT)
        .eventCod(Constants.LOGS_EVT_CODE_CONTEXT_POST)
        .log();
        
        return writeContext;
    }

}
