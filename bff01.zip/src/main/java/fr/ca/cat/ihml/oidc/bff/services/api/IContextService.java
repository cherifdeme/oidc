package fr.ca.cat.ihml.oidc.bff.services.api;

import java.io.IOException;
import java.util.UUID;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.models.context.ApplicationContext;
import fr.ca.cat.ihml.oidc.bff.models.context.Ctx9WriteContext;

/**
 * interface pour le contexte
 *
 * @author ET02720
 */

public interface IContextService {
	
    /**
     * Retourne le contexte de l'application
     * 
     * @param ctxId Id du contexte
     * @return Le contexte de l'application
     * @throws IOException Fichier non trouvé
     * @throws ApiException Erreur lors de l'appel HTTP
     * @see {@link ApplicationContext} 
     */
	 public ApplicationContext getContext(UUID ctxId) throws IOException, ApiException;

    /**
     * Retourne le contexte de l'application
     * 
     * @param applicationContext Contexte à sauvegarder
     * @return Le contexte de l'application
     * @throws IOException Fichier non trouvé
     * @throws ApiException Erreur lors de l'appel HTTP
     * @see {@link ApplicationContext}
     */
	 public Ctx9WriteContext setContext(ApplicationContext applicationContext) throws IOException, ApiException;

}
