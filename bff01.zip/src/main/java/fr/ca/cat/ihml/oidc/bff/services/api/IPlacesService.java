package fr.ca.cat.ihml.oidc.bff.services.api;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.models.places.CR;
import fr.ca.cat.ihml.oidc.bff.models.places.DistributionEntity;
import fr.ca.cat.ihml.oidc.bff.models.places.Entity;

/**
 * interface pour l'api place
 *
 * @author ET02720
 */
public interface IPlacesService {

    /**
     * Retourne la liste des CR
     *
     * @return La liste des CR
     * @throws ApiException Erreur lors de l'appel HTTP
     * @see {@link CR}
     */
    public CR[] getCRList() throws ApiException;

    /**
     * Retourne la liste des villes d'une CR
     *
     * @param crId Id de la CR
     * @return La liste des villes d'une CR
     * @throws ApiException Erreur lors de l'appel HTTP
     * @see {@link Entity}
     */
    public Entity[] getCREntities(int crId) throws ApiException;

    /**
     * Retourne la liste des agences pour une ville d'une CR
     *
     * @param crId    L'Id de la CR
     * @param zipCode Le code postal de la ville
     * @return La liste des agences d'une ville d'une CR
     * @throws ApiException Erreur lors de l'appel HTTP
     * @see {@link DistributionEntity}
     */
    public DistributionEntity[] getCRAgencesList(int crId, int zipCode) throws ApiException;

}
