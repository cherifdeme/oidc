package fr.ca.cat.ihml.oidc.bff.services.api;

import java.util.HashMap;
import java.util.Map;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.feign.client.PlacesServiceFeign;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.models.places.CR;
import fr.ca.cat.ihml.oidc.bff.models.places.DistributionEntity;
import fr.ca.cat.ihml.oidc.bff.models.places.Entity;
import fr.ca.cat.ihml.oidc.bff.services.logs.ApplicationLogger;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import jakarta.annotation.PostConstruct;
import jakarta.servlet.http.HttpSession;

import org.springframework.stereotype.Service;

import io.micrometer.core.annotation.Timed;
import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.Timer;


/**
 * Service pour appeler les ressources de l'API Places
 * 
 * @author ET02720
 *
 */
@Service
public class PlacesServiceImpl extends ApiService implements IPlacesService {

    /**
     * Déclaration du logger de la classe
     */
    private static ApplicationLogger appLogger = ApplicationLogger.getLogger(PlacesServiceImpl.class);

    /**
     * Service Feign pour les appels de l'api
     */
    private PlacesServiceFeign placesServiceFeign;
    
    /**
     * Registry pour les metrics
     */
    private MeterRegistry meterRegistry;
    
    /**
     * Metrics pour connaitre le nombre d'appels à l'API /places/regionals_banks
     */
    @SuppressWarnings("java:S3749")
    private Counter getCRListCounter;
    
    /**
     * Constructeur
     * @param placesServiceFeign {@link PlacesServiceFeign}
     * @param meterRegistry {@link MeterRegistry}
     * @param springSession Session Spring
     */
    public PlacesServiceImpl(PlacesServiceFeign placesServiceFeign, MeterRegistry meterRegistry, HttpSession springSession) {
    	this.placesServiceFeign = placesServiceFeign;
    	this.meterRegistry = meterRegistry;
    	this.springSession = springSession;
    }

    /**
     * methode d'initialisation
     */
    @PostConstruct
    public void init() {
    	getCRListCounter = Counter
    		    .builder("places.getCRList")
    		    .description("Number of call to get CR List") // optional
    		    .register(meterRegistry);
    }

    @Timed(description = "Time to get CR List")
    public CR[] getCRList() throws ApiException {
    	// Incrementation du metrics pour compte le nombre d'appels à la méthode    	
    	getCRListCounter.increment();
    	
        appLogger.initLog().level(LogLevel.INFO)
        .message("Récupération de la list des CR")
        .eventTyp(Constants.LOGS_EVT_TYPE_API)
        .eventCod(Constants.LOGS_EVT_CODE_PLACES_GET_CR)
        .log();
        
        CR[] crs = this.placesServiceFeign.getCRListRequest();

        // Mapping de la réponse de la requête
        appLogger.initLog().level(LogLevel.INFO)
        .message("Récupération de la list des CR --> OK")
        .eventTyp(Constants.LOGS_EVT_TYPE_API)
        .eventCod(Constants.LOGS_EVT_CODE_PLACES_GET_CR)
        .log();
        return crs;
    }

    public Entity[] getCREntities(int crId) throws ApiException {
    	// Création d'une metric pour calculer le nombre d'appel à la liste des agences d'une CR et le tems passé dans la méthode
    	var timer = Timer.builder("places.getCREntities")
    			.description("Time to get CR Entities list")
    			.tag("crId", Integer.toString(crId))
    			.register(this.meterRegistry);
    	var sample = Timer.start(this.meterRegistry);
    	
        appLogger.initLog().level(LogLevel.INFO)
        .message(String.format("Récupération des villes de la CR: %d", crId))
        .eventTyp(Constants.LOGS_EVT_TYPE_API)
        .eventCod(Constants.LOGS_EVT_CODE_PLACES_GET_ENTITIES)
        .log();

        Entity[] entities =  this.placesServiceFeign.getCREntitiesRequest(crId);
        
        // Mapping de la réponse
        appLogger.initLog().level(LogLevel.INFO)
        .message(String.format("Récupération des villes de la CR: %d --> OK", crId))
        .eventTyp(Constants.LOGS_EVT_TYPE_API)
        .eventCod(Constants.LOGS_EVT_CODE_PLACES_GET_ENTITIES)
        .log();
        
        sample.stop(timer);
        
        return entities;
    }

    public DistributionEntity[] getCRAgencesList(int crId, int zipCode) throws ApiException {
        appLogger.initLog().level(LogLevel.INFO)
        .message(String.format("Récupération des agences de la CR: %s pour la ville %s", crId, zipCode))
        .eventTyp(Constants.LOGS_EVT_TYPE_API)
        .eventCod(Constants.LOGS_EVT_CODE_PLACES_GET_DISTRIBUTION_ENTITIES)
        .log();

        Map<String, Object> params = new HashMap<>();
        params.put("regional_bank_id",crId);
        params.put("zip_code",zipCode);
        
        DistributionEntity[] distributionEntities = this.placesServiceFeign.getDistributionEntitiesRequest(params);
        
        // Mapping de la réponse
        appLogger.initLog().level(LogLevel.INFO)
        .message(String.format("Récupération des agences de la CR: %s pour la ville %s --> OK", crId, zipCode))
        .eventTyp(Constants.LOGS_EVT_TYPE_API)
        .eventCod(Constants.LOGS_EVT_CODE_PLACES_GET_DISTRIBUTION_ENTITIES)
        .log();
        
        return distributionEntities;
    }
}
