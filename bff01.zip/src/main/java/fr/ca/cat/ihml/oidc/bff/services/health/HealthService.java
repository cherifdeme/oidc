package fr.ca.cat.ihml.oidc.bff.services.health;

import java.io.IOException;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.stereotype.Service;

import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.services.logs.ApplicationLogger;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;

/**
 * Service pour la gestion des probes
 * @author ET02720
 *
 */
@Service
public class HealthService {
	
    /**
     * Déclaration du logger de la classe
     */
    private static ApplicationLogger appLogger = ApplicationLogger.getLogger(HealthService.class);
	
	/**
	 * Variable pour une connexion à un serveur Redis
	 */
	@Value("${spring.data.redis.host:#{null}}")
	private String redisHost;
	
	/**
	 * Variable pour une connexion à un cluster Redis
	 */
	@Value("${spring.data.redis.cluster.nodes:#{null}}")
	private List<String> redisClusterNodes;
	
	/**
	 * Variable pour une connexion à un Redis Sentinel
	 */
	@Value("${spring.data.redis.sentinel.nodes:#{null}}")
	private List<String> redisSentinelNodes;
	
	/**
	 * Injection de la factory redis
	 */
	private RedisConnectionFactory redisConnectionFactory;
	
	public HealthService(RedisConnectionFactory redisConnectionFactory) {
		this.redisConnectionFactory = redisConnectionFactory;
	}

	/**
	 * Méthode de test de vie pour le Redis
	 * @return True si la connexion au Redis est active
	 * @throws IOException 
	 */
	public boolean isRedisOk() {
		
		var isOk = false;
		if (Objects.nonNull(redisHost)) {
			var redisConnection =  redisConnectionFactory.getConnection();
			isOk =  "PONG".equals(redisConnection.ping());
			redisConnection.close();
		} else if (Objects.nonNull(redisClusterNodes) && !redisClusterNodes.isEmpty()) {
			var redisClusterConnection =  redisConnectionFactory.getClusterConnection();
			isOk =  "PONG".equals(redisClusterConnection.ping());
			redisClusterConnection.close();
		} else if (Objects.nonNull(redisSentinelNodes) && !redisSentinelNodes.isEmpty()) {
			try {
				var redisSentinelConnection =  redisConnectionFactory.getSentinelConnection();
				isOk =  redisSentinelConnection.isOpen();
				redisSentinelConnection.close();				
			} catch (IOException e) {
		        appLogger.initLog().level(LogLevel.WARN)
		        .message("Erreur lors de la fermeture de la connexion au RedisSentinel")
		        .eventTyp(Constants.LOGS_EVT_TYPE_REDIS)
		        .eventCod(Constants.LOGS_EVT_CODE_REDIS_ERROR)
		        .log();				
			}

		} else {
	        appLogger.initLog().level(LogLevel.ERROR)
	        .message("Aucune paramètre de connexion Redis spécifié")
	        .eventTyp(Constants.LOGS_EVT_TYPE_REDIS)
	        .eventCod(Constants.LOGS_EVT_CODE_REDIS_ERROR)
	        .log();
		}
		return isOk;
	}
}
