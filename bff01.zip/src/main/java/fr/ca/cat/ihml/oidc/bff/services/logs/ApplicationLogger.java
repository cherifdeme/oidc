package fr.ca.cat.ihml.oidc.bff.services.logs;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import jakarta.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.security.core.context.SecurityContextHolder;

import fr.ca.cat.ihml.oidc.bff.models.logs.LogContext;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogMessage;
import fr.ca.cat.ihml.oidc.bff.models.security.auth.UserAuthenticated;
import fr.ca.cat.ihml.oidc.bff.models.security.user.UserDetails;
import fr.ca.cat.ihml.oidc.bff.utils.AppUtils;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;

public class ApplicationLogger {

    /**
     * Logger Slf4J
     */
	@SuppressWarnings("squid:S1312")
    private Logger logger;

    /**
     * Suavegarde du contexte de log par thread
     */
    private Map<String,LogContext> threadLogContextMap;    
    
    /**
     * Constructeur interne
     * 
     * @param clazz La classe qui loggue
     * @param httpSession La session http
     */
    private ApplicationLogger(@SuppressWarnings("rawtypes") Class clazz) {
        logger = LoggerFactory.getLogger(clazz);
        this.threadLogContextMap = new HashMap<>();
    }
	
    /**
     * Récupération du LogContext associé au Thread
     * @return LogContext
     */
    private LogContext getThreadLogContext() {
        return this.threadLogContextMap.get(Thread.currentThread().getName());
    }
    
    /**
     * Sauvegarde d'un LogContext dans la map des thread
     * @param logContext
     */
    private void storeLogContext(LogContext logContext) {
        this.threadLogContextMap.put(Thread.currentThread().getName(), logContext);
    }

    /**
     * Constructeur static du logger
     * 
     * @param clazz La classe qui loggue
     * @return ApplicationLogger
     * @see {@link ApplicationLogger}
     */
    public static ApplicationLogger getLogger(@SuppressWarnings("rawtypes") Class clazz) {
        return new ApplicationLogger(clazz);
    }
    
    /**
     * Ajout du message de log
     * 
     * @param message le message de log
     * @return ApplicationLogger
     */
    public ApplicationLogger message(String message) {
        MDC.put(Constants.LOG_MDC_MESSAGE, message);
        return this;
    }

    /**
     * Ajout du message de log
     * 
     * @param message le message de log
     * @return ApplicationLogger
     */
    public ApplicationLogger level(LogLevel level) {
        MDC.put(Constants.LOG_MDC_LEVEL, level.name());
        return this;
    }

    /**
     * Ajout de l'event cod
     * 
     * @param evtCod La valeur de l'event cod
     * @return ApplicationLogger
     */
    public ApplicationLogger eventCod(String evtCod) {
        getThreadLogContext().setEventCode(evtCod);
        return this;
    }

    /**
     * Ajout de l'event type
     * 
     * @param evtTyp La valeur de l'event type
     * @return ApplicationLogger
     */
    public ApplicationLogger eventTyp(String evtTyp) {
        getThreadLogContext().setEventType(evtTyp);
        return this;
    }

    /**
     * Ajout du sec event type
     * 
     * @param secEventTyp La valeur du sec event type
     * @return ApplicationLogger
     */
    public ApplicationLogger secEventTyp(String secEventTyp) {
        getThreadLogContext().setSecurityEventType(secEventTyp);
        return this;
    }

    /**
     * Ajout du user Id
     * 
     * @param userId La valeur du userId
     * @return ApplicationLogger
     */
    public ApplicationLogger userId(String userId) {
        getThreadLogContext().setUserId(userId);
        return this;
    }

    /**
     * Ajout du code uom
     * 
     * @param uomCod La valeur du code uomCod
     * @return ApplicationLogger
     */
    public ApplicationLogger uomCod(String uomCod) {
        getThreadLogContext().setUomCode(uomCod);
        return this;
    }

    /**
     * Ajout de l'Id app
     * 
     * @param appId La valeur de l'Id app
     * @return ApplicationLogger
     */
    public ApplicationLogger appId(String appId) {
        getThreadLogContext().setApplicationId(appId);
        return this;
    }

    /**
     * Ajout de l'Id du component
     * 
     * @param componentId La valeur de l'Id du component
     * @return ApplicationLogger
     */
    public ApplicationLogger componentId(String componentId) {
        getThreadLogContext().setComponentId(componentId);
        return this;
    }

    /**
     * Ajout du correlationtId
     * 
     * @param correlationtId La valeur du correlationtId
     * @return ApplicationLogger
     */
    public ApplicationLogger correlationId(String correlationId) {
        getThreadLogContext().setCorrelationId(correlationId);
        return this;
    }

    /**
     * Ajout du session id
     * 
     * @param paramSessionId La valeur du session id
     * @return ApplicationLogger
     */
    public ApplicationLogger sessionId(String sessionId) {
        getThreadLogContext().setSessionId(sessionId);
        return this;
    }

    /**
     * Ajout du profil
     * 
     * @param profil La valeur du profil
     * @return ApplicationLogger
     */
    public ApplicationLogger profil(String profil) {
        getThreadLogContext().setProfil(profil);
        return this;
    }

    /**
     * Ajout de l'instance
     * 
     * @param instance La valeur de l'instance
     * @return ApplicationLogger
     */
    public ApplicationLogger instanceName(String instanceName) {
        getThreadLogContext().setInstanceName(instanceName);
        return this;
    }

    /**
     * Ajout de l'uri
     * 
     * @param uri La valeur de l'uri
     * @return ApplicationLogger
     */
    public ApplicationLogger uri(String uri) {
        getThreadLogContext().setUri(uri);
        return this;
    }

    /**
     * Ajout du component type
     * 
     * @param componentType La valeur du component type
     * @return ApplicationLogger
     */
    public ApplicationLogger componentType(String componentType) {
        getThreadLogContext().setComponentType(componentType);
        return this;
    }

    /**
     * Ajout du terminal
     * 
     * @param terminal La valeur du terminal
     * @return ApplicationLogger
     */
    public ApplicationLogger terminal(String terminal) {
        getThreadLogContext().setTerminal(terminal);
        return this;
    }

    /**
     * Ajout de l'eds
     * 
     * @param eds La valeur de l'eds
     * @return ApplicationLogger
     */
    public ApplicationLogger eds(String eds) {
        getThreadLogContext().setEds(eds);
        return this;
    }

    /**
     * Ajout du poste operationel
     * 
     * @param operationalPostId La valeur du poste operationel
     * @return ApplicationLogger
     */
    public ApplicationLogger operationalPostId(String operationalPostId) {
        getThreadLogContext().setOperationalPostId(operationalPostId);
        return this;
    }

    /**
     * Ajout de la source
     * 
     * @param source La valeur de la source
     * @return ApplicationLogger
     */
    public ApplicationLogger source(String source) {
        getThreadLogContext().setSource(source);
        return this;
    }

    /**
     * Ajout de la stackTrace
     * 
     * @param stackTrace La valeur de la stackTrace
     * @return ApplicationLogger
     */
    public ApplicationLogger stackTrace(String stackTrace) {
        getThreadLogContext().setStackTrace(stackTrace);
        return this;
    }

    /**
     * Initialise une Loggue à partir d'un LogMessage
     * 
     * @param logMessage LogMessage
     * @return ApplicationLogger
     * @see {@link LogMessage}
     * 
     */
    public ApplicationLogger initLog(LogMessage logMessage) {
        // Creation Log Message
        message(logMessage.getMessage());
        level(logMessage.getLogLevel());
        
        // Sauvegarde du LogContext dans la map des threads
        this.storeLogContext(logMessage.getLogContext());
        
        
        // Création TimeStamp depuis le log message
        var logTimeStamp = ZonedDateTime.ofInstant(Instant.parse(logMessage.getTimeStamp()), ZoneOffset.UTC).truncatedTo(ChronoUnit.MILLIS);
        MDC.put(Constants.LOG_MDC_TIME, DateTimeFormatter.ISO_INSTANT.format(logTimeStamp));

        return this;
    }

    /**
     * Initialise une log
     * 
     * @return ApplicationLogger
     */
    public ApplicationLogger initLog() {    
        var logContext = new LogContext();

        // Ajout des valeurs des paramètres par défaut
        logContext.setApplicationId(Constants.LOGS_APP_ID);
        logContext.setComponentId(Constants.LOGS_COMPONENT_ID);
        logContext.setComponentType(Constants.LOGS_COMPONENT_TYPE);
        try {
            logContext.setInstanceName(InetAddress.getLocalHost().toString());
        } catch (UnknownHostException e) {
            // Nothing to do
        }
        
        // Sauvegarde du LogContext dans la map des threads
        this.storeLogContext(logContext);
        
        MDC.put(Constants.LOG_MDC_TIME, DateTimeFormatter.ISO_INSTANT.format(ZonedDateTime.now().truncatedTo(ChronoUnit.MILLIS)));

        return this;
    }

    /**
     * Logguer un LogMessage
     * 
     * @see {@link LogMessage}
     */
    public void log() {
        // Ajout du contexte
        this.setRequestContext();

        // Ajout des paramètres additionels
        MDC.put(Constants.LOG_MDC_APP_ID, getThreadLogContext().getApplicationId());
        MDC.put(Constants.LOG_MDC_COMPONENT_ID, getThreadLogContext().getComponentId());
        MDC.put(Constants.LOG_MDC_COMPONENT_TYPE, getThreadLogContext().getComponentType());
        MDC.put(Constants.LOG_MDC_CORR_ID, getThreadLogContext().getCorrelationId());
        MDC.put(Constants.LOG_MDC_EDS, getThreadLogContext().getEds());
        MDC.put(Constants.LOG_MDC_INSTANCE_NAME, getThreadLogContext().getInstanceName());
        MDC.put(Constants.LOG_MDC_LOG_EVENT_COD, getThreadLogContext().getEventCode());
        MDC.put(Constants.LOG_MDC_LOG_EVENT_TYP, getThreadLogContext().getEventType());
        MDC.put(Constants.LOG_MDC_LOG_SEC_EVENT_TYP, getThreadLogContext().getSecurityEventType());
        MDC.put(Constants.LOG_MDC_OPERATIONAL_POST_ID, getThreadLogContext().getOperationalPostId());
        MDC.put(Constants.LOG_MDC_PROFIL, getThreadLogContext().getProfil());
        MDC.put(Constants.LOG_MDC_SESS_ID, getThreadLogContext().getSessionId());
        MDC.put(Constants.LOG_MDC_SRC_CLIENT, getThreadLogContext().getSourceClient());
        MDC.put(Constants.LOG_MDC_SRC_CLIENT_ID, getThreadLogContext().getSourceClientId());
        MDC.put(Constants.LOG_MDC_STACK_TRACE, getThreadLogContext().getStackTrace());
        MDC.put(Constants.LOG_MDC_TERMINAL, getThreadLogContext().getTerminal());
        MDC.put(Constants.LOG_MDC_UOM_COD, getThreadLogContext().getUomCode());
        MDC.put(Constants.LOG_MDC_URI, getThreadLogContext().getUri());
        MDC.put(Constants.LOG_MDC_USR_ID, getThreadLogContext().getUserId());

        switch (LogLevel.valueOf(MDC.get(Constants.LOG_MDC_LEVEL))) {
            case DEBUG:
                logger.debug(MDC.get(Constants.LOG_MDC_MESSAGE));
                break;
            case ERROR, FATAL:
                logger.error(MDC.get(Constants.LOG_MDC_MESSAGE));
                break;
            case INFO, LOG:
                logger.info(MDC.get(Constants.LOG_MDC_MESSAGE));
                break;
            case TRACE:
                logger.trace(MDC.get(Constants.LOG_MDC_MESSAGE));
                break;
            case WARN:
                logger.warn(MDC.get(Constants.LOG_MDC_MESSAGE));
                break;
            default:
                break;
        }
        
        clear();
    }

    /**
     * Ajout du contexte global
     */
    private void setRequestContext() {
        try {
            Optional<HttpServletRequest> httpRequest = AppUtils.getCurrentHttpRequest();
            boolean hasRequest = Objects.nonNull(httpRequest) && httpRequest.isPresent();
            
            // Récupération du header idCorrelationId
            if (Objects.isNull(getThreadLogContext().getCorrelationId())) {
                getThreadLogContext().setCorrelationId(AppUtils.getCorrelationId());                
            }
            
            // Extraction des informations depuis la requête si on la connait
            if (hasRequest){
            	var request = httpRequest.get();
            	
            	// URI
            	getThreadLogContext().setUri(request.getRequestURI());
            	
                // Complétion des info de la requête depuis la session spring                	
            	if (Objects.isNull(getThreadLogContext().getSessionId())) {
                    // Ajout information de contexte de la session utilisateur
                    getThreadLogContext().setSessionId(request.getSession().getId());            		
            	}

            	var auth = SecurityContextHolder.getContext().getAuthentication();
            	
            	if (Objects.nonNull(auth) && UserAuthenticated.class.isAssignableFrom(auth.getClass())) {
            		var userDetails = (UserDetails) auth.getPrincipal();
            		getThreadLogContext().setUserId(userDetails.getId());
            		getThreadLogContext().setProfil(userDetails.getFpLabel());
            	}
            }

            
        } catch (IllegalStateException e) {
            // Cas lorsque la session http n'est pas initialisée. Appel en dehors d'un contexte requête
            // On catch juste l'erreur pour ne pas provoquer de plantage
        }

    }
    
    /**
     * Réinitialisation du logger
     */
    private void clear() {
        this.threadLogContextMap.remove(Thread.currentThread().getName());
        MDC.clear();
    }
}
