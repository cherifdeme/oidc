package fr.ca.cat.ihml.oidc.bff.services.logs;

import fr.ca.cat.ihml.oidc.bff.models.logs.LogClientConfiguration;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogMessage;

public interface ILogsService {

    /**
     * Traitement sur la réception d'une log provenant du client front end
     * 
     * @param clientLogConfiguration ClientLogConfiguration
     */
	public abstract void treatmentClientLog(LogMessage logMessage);
    
    /**
     * Sauvegarde de la configuration de log du client front end
     * 
     * @param clientLogConfiguration ClientLogConfiguration
     */
	public abstract void storeClientLogConfiguration(LogClientConfiguration clientLogConfiguration);

    /**
     * Récupération de la configuration du client front end
     * 
     * @return @see {@link LogClientConfiguration}
     */
	public abstract LogClientConfiguration getClientLogConfiguration();
	
}
