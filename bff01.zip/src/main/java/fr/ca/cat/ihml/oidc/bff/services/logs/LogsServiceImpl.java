package fr.ca.cat.ihml.oidc.bff.services.logs;

import fr.ca.cat.ihml.oidc.bff.models.logs.LogClientConfiguration;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogMessage;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import jakarta.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import fr.ca.cat.ihml.oidc.bff.cache.RedisCacheService;

/**
 * Service pour la gestion des Logs
 * @author ET02720
 *
 */
@Service
public class LogsServiceImpl implements ILogsService {

    /**
     * Injection du RefreshTokenCacheService
     */
    protected RedisCacheService redisCacheService;

    /**
     * Injection de la propriété du niveau de log du client front end
     */
    @Value("${log.client.level}")
    protected int clientLogLevel;

    /**
     * Injection de la propriété du niveau de log du server
     */
    @Value("${log.server.level}")
    protected int serverLogLevel;

    /**
     * Injection de la propriété de suppression dela console log du client front end
     */
    @Value("${log.disable.console.log}")
    protected boolean disableConsoleLog;

    /**
     * Déclaration du logger de la classe
     */
    private static ApplicationLogger appLogger = ApplicationLogger.getLogger(LogsServiceImpl.class);
    
    /**
     * Constructor
     * @param redisCacheService {@link RedisCacheService}
     */
    public LogsServiceImpl(RedisCacheService redisCacheService){
    	this.redisCacheService = redisCacheService;
    }

    /**
     * Initialisation de la classe
     */
    @PostConstruct
    public void init() {
        // Intialisation de la configuration de log si besoin
        if (!this.redisCacheService.isClientLogConfigurationExist()) {
            appLogger.initLog().level(LogLevel.INFO)
            .message("Configuration de log client non trouvée en base")
            .eventTyp(Constants.LOGS_EVT_TYPE_LOGS)
            .eventCod(Constants.LOGS_EVT_CODE_GET_LOGS_CONFIGURATION)
            .log();
            
            this.storeClientLogConfiguration(getDefaultClientLogConfiguration());
            
            appLogger.initLog().level(LogLevel.INFO)
            .message("Sauvegarde d'une configuration de log client par défaut")
            .eventTyp(Constants.LOGS_EVT_TYPE_LOGS)
            .eventCod(Constants.LOGS_EVT_CODE_GET_LOGS_CONFIGURATION)
            .log();
        }
    }

    public void treatmentClientLog(LogMessage logMessage) {
    	appLogger.initLog(logMessage).log();
    }

    public void storeClientLogConfiguration(LogClientConfiguration clientLogConfiguration) {
        appLogger.initLog().level(LogLevel.WARN)
        .eventTyp(Constants.LOGS_EVT_TYPE_LOGS)
        .eventCod(Constants.LOGS_EVT_CODE_SET_LOGS_CONFIGURATION)
        .message("Sauvegarde d'une configuration de log client")
        .log();
        
        this.redisCacheService.storeClientLogConfiguration(clientLogConfiguration);
        
        appLogger.initLog().level(LogLevel.WARN)
        .eventTyp(Constants.LOGS_EVT_TYPE_LOGS)
        .eventCod(Constants.LOGS_EVT_CODE_SET_LOGS_CONFIGURATION)
        .message("Sauvegarde d'une configuration de log client --> OK")
        .log();
    }

    public LogClientConfiguration getClientLogConfiguration() {
    	if (this.redisCacheService.isClientLogConfigurationExist()) {
            appLogger.initLog().level(LogLevel.DEBUG)
            .eventTyp(Constants.LOGS_EVT_TYPE_LOGS)
            .eventCod(Constants.LOGS_EVT_CODE_GET_LOGS_CONFIGURATION)
            .message("Récupération de la configuration de log client --> OK")
            .log();
            
    		return this.redisCacheService.getClientLogConfiguration();
        } else {
            appLogger.initLog().level(LogLevel.WARN)
            .eventTyp(Constants.LOGS_EVT_TYPE_LOGS)
            .eventCod(Constants.LOGS_EVT_CODE_GET_LOGS_CONFIGURATION)
            .message("Configuration de log client non trouvée")
            .log();
            
            var clientLogConfiguration = getDefaultClientLogConfiguration();
            this.storeClientLogConfiguration(clientLogConfiguration);
            
            appLogger.initLog().level(LogLevel.WARN)
            .eventTyp(Constants.LOGS_EVT_TYPE_LOGS)
            .eventCod(Constants.LOGS_EVT_CODE_SET_LOGS_CONFIGURATION)
            .message("Sauvegarde d'une configuration de log client par défaut").log();
            
            appLogger.initLog().level(LogLevel.DEBUG)
            .eventTyp(Constants.LOGS_EVT_TYPE_LOGS)
            .eventCod(Constants.LOGS_EVT_CODE_GET_LOGS_CONFIGURATION)
            .message("Récupération de la configuration de log client --> OK")
            .log();
            
            return clientLogConfiguration;
        }
    }

    /**
     * Génération de la configuration de log par défaut
     * 
     * @return @see {@link LogClientConfiguration}
     */
    private LogClientConfiguration getDefaultClientLogConfiguration() {
        var clientLogConfiguration = new LogClientConfiguration();
        clientLogConfiguration.setClientLoglevel(clientLogLevel);
        clientLogConfiguration.setServerLogLovel(serverLogLevel);
        clientLogConfiguration.setDisableConsoleLog(disableConsoleLog);

        return clientLogConfiguration;
    }

}
