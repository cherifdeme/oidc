package fr.ca.cat.ihml.oidc.bff.services.manifest;

import java.io.IOException;

import fr.ca.cat.ihml.oidc.bff.models.manifest.ApplicationManifest;

public interface IManifestService {

    /**
     * Récupération du manifest de l'application
     * 
     * @return Le manifest de l'application
     * @throws IOException
     * @see {@link ApplicationManifest}
     */
	public abstract ApplicationManifest getManifest();

}
