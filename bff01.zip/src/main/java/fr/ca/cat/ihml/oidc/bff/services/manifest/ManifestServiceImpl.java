package fr.ca.cat.ihml.oidc.bff.services.manifest;

import fr.ca.cat.ihml.oidc.bff.services.logs.ApplicationLogger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.models.manifest.ApplicationManifest;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;

/**
 * Classe le service gérant de manifest
 * 
 * @author ET02720
 *
 */
@Service
public class ManifestServiceImpl implements IManifestService {

    /**
     * Déclaration du logger de la classe
     */
    private static ApplicationLogger appLogger = ApplicationLogger.getLogger(ManifestServiceImpl.class);

    /**
     * Injection de la propriété qui référence au framework
     */
    @Value("${app.framework}")
    protected String framework;
    
    /**
     * Injection de la version qui référence au framework
     */
    @Value("${app.version}")
    protected String version;

    public ApplicationManifest getManifest() {
        appLogger.initLog().level(LogLevel.INFO)
        .message("Récupération du manifest")
        .eventTyp(Constants.LOGS_EVT_TYPE_API)
        .eventCod(Constants.LOGS_EVT_CODE_PLACES_GET_MANIFEST)
        .log();

        var appManifest = new ApplicationManifest();
        appManifest.setVersion(version);
        appManifest.setFramework(framework);
        
        appLogger.initLog().level(LogLevel.INFO)
        .message("Récupération du manifest --> OK")
        .eventTyp(Constants.LOGS_EVT_TYPE_API)
        .eventCod(Constants.LOGS_EVT_CODE_PLACES_GET_MANIFEST)
        .log();
        
        return appManifest;
    }
}
