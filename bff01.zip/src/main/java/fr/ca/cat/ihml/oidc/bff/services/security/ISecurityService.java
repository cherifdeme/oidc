package fr.ca.cat.ihml.oidc.bff.services.security;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import org.springframework.security.core.Authentication;
import org.springframework.util.MultiValueMap;

import fr.ca.cat.ihml.oidc.bff.models.security.user.UserDetails;

public interface ISecurityService {

    /**
     * Permet de récupérer un access token auprès de l'API AUC9
     * 
     * @param code Autorization Code renvoyée par la mire X Connect
     * @param redirectUrl Url de redirection de l'application founie à X Connect
     * @param csrfToken token pour la prévention CSRF
     * @param nmbCookieValue Valeur pour la connexion via NMB
     * @return la clé d'identification du refresh token
     * @throws ApiException Erreur lors d'un appel HTTP
     */
	public abstract String login(String code, String redirectUrl, String csrfToken, String nmbCookieValue) throws ApiException;
    
    /**
     * Gestion de la déconnexion en mode standalone
     * 
     * @param refreshTokenKey ID de "refresh session" fourni lors de la connexion
     * @throws ApiException Erreur lors d'appel HTTP
     */
	public abstract void standAloneLogout(String refreshTokenKey) throws ApiException;

    /**
     * Gestion de la déconnexion cible
     * 
     * @param body Contient le LogoutToken
     * @throws ApiException Erreur lors d'appel HTTP
     */ 
	public abstract boolean backChannelLogout(MultiValueMap<String, String> body) throws ApiException;

    /**
     * Permet le renouvellement de l'access token à partir du refresh token
     * 
     * @param refreshTokenKey Le refresh token
     * @param cookieSessionId L'id de la session à rafraichir
     * @throws ApiException Erreur lors d'appel HTTP
     */
	public abstract void refreshToken(String refreshTokenKey, String cookieSessionId) throws ApiException;

    /**
     * Retourne le user connecté avec la session
     * 
     * @param refreshCookie la valeur du refresh cookie 
     * @return Le user connecté
     * @throws ApiException
     * @see {@link UserDetails}
     */
	public abstract UserDetails getUserDetails(Authentication auth, String refreshCookie);

    /**
     * Generation du SHA256 de la session ID pour la verification CSRF lors de la connexion
     * 
     * @param value La valeur à encoder
     * @return La valeur encodée
     */
	public String generateCsrfToken(String value);
}
