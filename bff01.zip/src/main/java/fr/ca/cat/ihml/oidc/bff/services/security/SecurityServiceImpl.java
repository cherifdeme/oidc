package fr.ca.cat.ihml.oidc.bff.services.security;

import java.io.IOException;
import java.util.Base64;
import java.util.List;
import java.util.Objects;
import java.util.UUID;

import fr.ca.cat.ihml.oidc.bff.cache.RedisCacheService;
import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.feign.client.SecurityServiceFeign;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.models.security.auth.UserAuthenticated;
import fr.ca.cat.ihml.oidc.bff.models.security.tokens.IdToken;
import fr.ca.cat.ihml.oidc.bff.models.security.tokens.LogoutToken;
import fr.ca.cat.ihml.oidc.bff.models.security.tokens.RefreshToken;
import fr.ca.cat.ihml.oidc.bff.models.security.user.UserDetails;
import fr.ca.cat.ihml.oidc.bff.services.logs.ApplicationLogger;
import fr.ca.cat.ihml.oidc.bff.utils.AppUtils;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import jakarta.servlet.http.HttpSession;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.jose4j.jwa.AlgorithmConstraints.ConstraintType;
import org.jose4j.jwk.JsonWebKey;
import org.jose4j.jwt.consumer.ErrorCodes;
import org.jose4j.jwt.consumer.InvalidJwtException;
import org.jose4j.jwt.consumer.JwtConsumerBuilder;
import org.jose4j.lang.JoseException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.session.data.redis.RedisSessionRepository;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.fasterxml.jackson.core.type.TypeReference;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import io.micrometer.core.annotation.Timed;

/**
 * Service pour gérer la sécurité de l'application
 * 
 * @author ET02720
 *
 */
@Service
public class SecurityServiceImpl implements ISecurityService {

    /**
     * Déclaration du logger de la classe
     */
    private static ApplicationLogger appLogger = ApplicationLogger.getLogger(SecurityServiceImpl.class);
    
    /**
     * Injection de la propriété clientId de l'application
     */
    @Value("${security.clientID}")
    protected String clientId;
    
    /**
     * Inject de la propriété auc9 Url
     */
    @Value("${service.auc9}")
    protected String auc9Url;
    
    /**
     * Inject de la propriété auc9 Url Publique
     */
    @Value("${service.auc9.publique}")
    protected String auc9UrlPublique;
    
    /**
     * Inject de la propriété logoutToken
     */
    @Value("${security.logoutToken.name}")
    protected String logoutToken;
    
    /**
     * Inject de la propriété logoutToken event
     */
    @Value("${security.logoutToken.event}")
    protected String logoutTokenEvent;
    
    /**
     * Inject de la session HTTP
     */
    private HttpSession springSession;

    /**
     * Injection du client feign security
     */
    private SecurityServiceFeign securityServiceFeign;
    
    /**
     * Injection du RedisIndexedSessionRepository
     */
    private RedisSessionRepository redisSessionRepository;
    
    /**
     * Injection du RedisCacheService
     */
    protected RedisCacheService redisCacheService;
    
    /**
     * Constructor
     * @param springSession {@link HttpSession}
     * @param securityServiceFeign {@link SecurityServiceFeign}
     * @param redisCacheService {@link RedisCacheService}
     * @param redisSessionRepository {@link RedisSessionRepository}
     */
    public SecurityServiceImpl(HttpSession springSession, SecurityServiceFeign securityServiceFeign, RedisCacheService redisCacheService, RedisSessionRepository redisSessionRepository) {
    	this.springSession = springSession;
		this.securityServiceFeign = securityServiceFeign;
		this.redisCacheService = redisCacheService;
		this.redisSessionRepository = redisSessionRepository;
	}

    @Timed(description = "Time to log in application")
    public String login(String code, String redirectUrl, String csrfToken, String nmbCookieValue) throws ApiException {
        appLogger.initLog().level(LogLevel.DEBUG)
        .message("Demande de jeton OAuth pour la session " + code)
        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
        .eventCod(Constants.LOGS_EVT_CODE_AUTH_LOGIN_PROCESSING)
        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
        .log();
        
        // Gestion Cookie Nmb
        handleNmbCookieAndCsrfToken(csrfToken, nmbCookieValue);

        MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
        map.add(Constants.GRANT_TYPE_PARAM, Constants.AUTORIZATION_CODE_VALUE);
        map.add(Constants.SCOPE_PARAM, Constants.SCOPE_VALUE);
        map.add(Constants.CODE_PARAM, code);
        map.add(Constants.REDIRECT_URI_PARAM, redirectUrl);

        // Demand du OAuthToken
        var oAuthToken = this.securityServiceFeign.getOpenIdTokenRequest(map);

        // Vérification ID Token
        var idToken = checkIdTokenValidity(oAuthToken.getIdToken());

        // Extraction User depuis l'IdToken
        var user = this.getUserFromTokenId(idToken);
        
        // Sauvegarde de la date d'expiration dans REDIS
        this.springSession.setAttribute(Constants.EXPIRES_AT_KEY, AppUtils.delayFromNowToMilliseconds(oAuthToken.getExpiresIn()));
        
        // Sauvegarde du contexte de sécurité
        var auth = new UserAuthenticated(user, oAuthToken.getAccessToken());
        auth.setAuthenticated(true);
        SecurityContextHolder.getContext().setAuthentication(auth);

        // Sauvegarde de refresh token dans le cache REDIS
        appLogger.initLog().level(LogLevel.DEBUG)
        .message("SID: " + idToken.getSid())
        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
        .eventCod(Constants.LOGS_EVT_CODE_AUTH_LOGIN_PROCESSING)
        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
        .log();
        
        var refreshTokenKey = Objects.nonNull(idToken.getSid()) ? idToken.getSid() : UUID.randomUUID().toString();
        var refreshToken = new RefreshToken(oAuthToken.getRefreshToken(), springSession.getId());
        this.redisCacheService.storeRefreshToken(refreshTokenKey, refreshToken);

        appLogger.initLog().level(LogLevel.DEBUG)
        .message("Demande de jeton OAuth pour la session --> OK")
        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
        .eventCod(Constants.LOGS_EVT_CODE_AUTH_LOGIN_OK)
        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
        .log();
        
        return refreshTokenKey;
    }

    @Timed(description = "Time to log out from application")
    public void standAloneLogout(String refreshTokenKey) throws ApiException {
        appLogger.initLog().level(LogLevel.DEBUG)
        .message("Demande de déconnexion pour la session")
        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
        .eventCod(Constants.LOGS_EVT_CODE_AUTH_STDA_LOGOUT_PROCESSING)
        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
        .log();

        // Révocation du refresh token lié à la session
        this.revokeSessionStandAloneLogout(refreshTokenKey);

        appLogger.initLog().level(LogLevel.DEBUG)
        .message("Demande de déconnexion pour la session --> OK")
        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
        .eventCod(Constants.LOGS_EVT_CODE_AUTH_STDA_LOGOUT_OK)
        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
        .log();

        // Invalidation de la session spring
        this.springSession.invalidate();
    }

    @Timed(description = "Time to log out from application")
    public boolean backChannelLogout(MultiValueMap<String, String> body) throws ApiException {
        appLogger.initLog().level(LogLevel.DEBUG)
        .message("Demande de déconnexion backchannel")
        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
        .eventCod(Constants.LOGS_EVT_CODE_AUTH_BCK_CH_LOGOUT_PROCESSING)
        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
        .log();
    	
    	// Récupération de la clé logout_token
        List<String> logoutTokenStringList = body.get(logoutToken);
        
        if (Objects.nonNull(logoutTokenStringList) && !logoutTokenStringList.isEmpty()) {
        	var logoutTokenString = logoutTokenStringList.get(0);
            appLogger.initLog().level(LogLevel.DEBUG)
            .message(String.format("Demande de déconnexion pour la session en cours: %s", logoutTokenString.subSequence(0, 20)))
            .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
            .eventCod(Constants.LOGS_EVT_CODE_AUTH_BCK_CH_LOGOUT_PROCESSING)
            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
            .log();
            
            // Vérification logoutToken
            var logoutTken = checkLogoutTokenValidity(logoutTokenString);

            // Révocation du refresh token lié à la session
            this.revokeSessionBackChannelLogout(logoutTken);
            
            appLogger.initLog().level(LogLevel.DEBUG)
            .message("Demande de déconnexion pour la session --> OK")
            .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
            .eventCod(Constants.LOGS_EVT_CODE_AUTH_BCK_CH_LOGOUT_OK)
            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
            .log(); 
            
            return true;
        } else {

            appLogger.initLog().level(LogLevel.WARN)
            .message("Logout token non présent")
            .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
            .eventCod(Constants.LOGS_EVT_CODE_AUTH_BCK_CH_LOGOUT_KO)
            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH);
            
            return false;
        }

    }

    public void refreshToken(String refreshTokenKey, String cookieSessionId) throws ApiException {
        appLogger.initLog().level(LogLevel.DEBUG)
        .message(String.format("Récupération du refresh token pour la session et la clé %s", AppUtils.obfuscateUUIDString(refreshTokenKey)))
        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
        .eventCod(Constants.LOGS_EVT_CODE_REFRESH_TOKEN_PROCESSING)
        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_SESSION)
        .log();
        
        var refreshToken = this.getRefreshToken(refreshTokenKey);
        if (Objects.nonNull(refreshToken) && refreshToken.getSessionId().equals(cookieSessionId)) {

            MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
            map.add(Constants.GRANT_TYPE_PARAM, Constants.REFRESH_TOKEN_VALUE);
            map.add(Constants.SCOPE_PARAM, Constants.SCOPE_VALUE);
            map.add(Constants.REFRESH_TOKEN_PARAM, refreshToken.getToken());

            var oAuthToken = this.securityServiceFeign.getOpenIdTokenRequest(map);
            
            // Vérification Signature ID Token
            var idToken = checkIdTokenValidity(oAuthToken.getIdToken());
            
            // Extraction de l'utilisateur depuis l'IdToken
            var user = this.getUserFromTokenId(idToken);
            
            // Generation du state depuis le session ID
            user.setState(generateCsrfToken(this.springSession.getId()));
            
            // Sauvegarde de la date d'expiration dans la session (et donc REDIS)
            this.springSession.setAttribute(Constants.EXPIRES_AT_KEY, AppUtils.delayFromNowToMilliseconds(oAuthToken.getExpiresIn()));

            // Sauvegarde du contexte de sécurité
            var auth = new UserAuthenticated(user, oAuthToken.getAccessToken());
            auth.setAuthenticated(true);
            SecurityContextHolder.getContext().setAuthentication(auth);
            
            refreshToken.setSessionId(this.springSession.getId());
            this.redisCacheService.storeRefreshToken(refreshTokenKey, refreshToken);

            appLogger.initLog().level(LogLevel.DEBUG)
            .message(String.format("Renouvellement de l'access token pour la session et la clé %s --> OK", AppUtils.obfuscateUUIDString(refreshTokenKey)))
            .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
            .eventCod(Constants.LOGS_EVT_CODE_REFRESH_TOKEN_OK)
            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_SESSION)
            .log();
            
        } else if (Objects.nonNull(refreshToken) && !refreshToken.getSessionId().equals(cookieSessionId)) {
            throw new IllegalArgumentException(String.format("Le refresh token %s n'est pas valide pour la session", AppUtils.obfuscateUUIDString(refreshTokenKey)));
        } else {            
            throw new IllegalArgumentException(String.format("Le refresh token %s pour la session n'existe pas", AppUtils.obfuscateUUIDString(refreshTokenKey)));
        }

    }

    public UserDetails getUserDetails(Authentication auth, String refreshCookie) {
        appLogger.initLog().level(LogLevel.DEBUG)
        .message("Récupération des informations sur l'utilisateur de la session")
        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
        .eventCod(Constants.LOGS_EVT_CODE_GETTING_USER_CONNECTED)
        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_SESSION)
        .log();
        
        var user = new UserDetails();
        
        // On test si le refresh cookie existe toujours. Si non on invalide la session
        if (Objects.nonNull(refreshCookie) && !this.redisCacheService.isRefreshTokenKeyExist(refreshCookie)) {      
            appLogger.initLog().level(LogLevel.WARN)
            .message("Aucun refreshCookie trouvé pour cet utilisateur. --> on invalide la session")
            .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
            .eventCod(Constants.LOGS_EVT_CODE_NO_RT_FOR_SESSION)
            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_SESSION)
            .log();
            
            this.springSession.invalidate();
        	
        } else if (Objects.nonNull(auth) && Objects.nonNull(auth.getName())) {
        	user = (UserDetails) auth.getPrincipal();
        }
        
        // Generation du state depuis le session ID
        user.setState(generateCsrfToken(this.springSession.getId()));        	
        
        appLogger.initLog().level(LogLevel.DEBUG)
        .message("Récupération des informations sur l'utilisateur de la session --> OK")
        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
        .eventCod(Constants.LOGS_EVT_CODE_GETTING_USER_CONNECTED)
        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_SESSION)
        .log();

        return user;
    }    
    
    /**
     * Permet la revocation du refresh token lié à la session en cours en mode standAlone
     * 
     * @param refreshTokenKey Clé pour retrouver le refresh token dans le cache REDIS
     * @throws ApiException Erreur lors d'appel HTTP
     */
    protected void revokeSessionStandAloneLogout(String refreshTokenKey) throws ApiException {
        appLogger.initLog().level(LogLevel.DEBUG)
        .message(String.format("Revocation du refresh token pour la session et la clé %s", AppUtils.obfuscateUUIDString(refreshTokenKey)))
        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
        .eventCod(Constants.LOGS_EVT_CODE_REFRESH_STDA_TOKEN_REVOKING)
        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_SESSION)
        .log();

        // Récupération du refresh token
        var refreshToken = this.getRefreshToken(refreshTokenKey);

        if (Objects.nonNull(refreshToken)) {
            // Construction de la requête
            MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
            map.add(Constants.TOKEN_PARAM, refreshToken.getToken());

            // Execute request
            this.securityServiceFeign.getOpenIdRevokeTokenRequest(map);
            
            // Suppression de la clé dans le cache REDIS
            this.redisCacheService.deleteRefreshToken(refreshTokenKey);
            
            appLogger.initLog().level(LogLevel.DEBUG)
            .message(String.format("Revocation du refresh token pour la session et la clé %s --> OK", AppUtils.obfuscateUUIDString(refreshTokenKey)))
            .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
            .eventCod(Constants.LOGS_EVT_CODE_REFRESH_TOKEN_STDA_DELETING_OK)
            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_SESSION)
            .log();
        } else {
            appLogger.initLog().level(LogLevel.WARN)
            .message(String.format("Aucun refresh token trouvé pour la session et la clé %s", AppUtils.obfuscateUUIDString(refreshTokenKey)))
            .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
            .eventCod(Constants.LOGS_EVT_CODE_REFRESH_TOKEN_STDA_DELETING_NOT_FOUND)
            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_SESSION)
            .log();
        }
    }

    /**
     * Permet la revocation du refresh token lié à la session en cours en mode Back channel logout
     * 
     * @param logoutToken Token de logout
     */
    protected void revokeSessionBackChannelLogout(LogoutToken logoutToken) {
        appLogger.initLog().level(LogLevel.DEBUG)
        .message(String.format("Suppression des clés pour la session %s", AppUtils.obfuscateUUIDString(logoutToken.getSid())))
        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
        .eventCod(Constants.LOGS_EVT_CODE_REFRESH_TOKEN_REVOKING)
        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_SESSION)
        .log();

        // Récupération du refresh token
        var refreshToken = Objects.nonNull(logoutToken.getSid()) ? this.getRefreshToken(logoutToken.getSid()) : null;

        if (Objects.nonNull(refreshToken)) {
            // Construction de la requête
            // Suppression de la clé dans le cache REDIS
        	this.redisCacheService.deleteRefreshToken(logoutToken.getSid());
        	
        	// Suppression info de session redis
        	redisSessionRepository.deleteById(refreshToken.getSessionId());
            
            appLogger.initLog().level(LogLevel.DEBUG)
            .message(String.format("Suppression des clés pour la session %s --> OK", AppUtils.obfuscateUUIDString(logoutToken.getSid())))
            .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
            .eventCod(Constants.LOGS_EVT_CODE_REFRESH_TOKEN_BCK_CH_DELETING_OK)
            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_SESSION)
            .log();
        } else {
            appLogger.initLog().level(LogLevel.WARN)
            .message("Aucun refresh token trouvé pour la session")
            .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
            .eventCod(Constants.LOGS_EVT_CODE_REFRESH_TOKEN_BCK_CH_DELETING_NOT_FOUND)
            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_SESSION)
            .log();
        }
    }    

    /**
     * Retourne le refresh token lié à une clé
     * 
     * @param refreshTokenKey Clé pour retrouver le refresh token dansle cache REDIS (valeur obtenue à partie du cookie STATE)
     * @return La valeur du refresh token
     */
    protected RefreshToken getRefreshToken(String refreshTokenKey) {
        return this.redisCacheService.isRefreshTokenKeyExist(refreshTokenKey) ? this.redisCacheService.getRefreshToken(refreshTokenKey) : null;
    }
    
    /**
     * Gestion du token CSRF et cookie NMB lors du login
     * @param csrfToken le jeton CSRF
     * @param nmbCookieValue le cookie nmb
     * @throws ApiException Erreur si la vérification n'est pas bonne
     */
    private void handleNmbCookieAndCsrfToken(String csrfToken, String nmbCookieValue) throws ApiException {
    	
    	var isNmbCookieDifferentFromCsrfToken = !StringUtils.isBlank(nmbCookieValue) && !csrfToken.equals(generateCsrfToken(nmbCookieValue));
    	var isCsrfTokenFromSessionId = StringUtils.isBlank(nmbCookieValue) && !csrfToken.equals(generateCsrfToken(this.springSession.getId()));
    	
        if (isNmbCookieDifferentFromCsrfToken || isCsrfTokenFromSessionId) {
            // Vérification connexion NMB
            throw new ApiException(HttpStatus.UNAUTHORIZED.value(), Constants.ACCESS_UNAUTHORIZED_RESPONSES);
        }
    }

    /**
     * Permet d'extraire les informations de l'utilisateur à partir de Id token
     * du jeton
     * 
     * @param tokenId Le token Id du jeton OAuth
     * @return Les informations sur l'utilisateur
     * @see {@link UserDetails}
     */
    private UserDetails getUserFromTokenId(IdToken tokenId) {
        appLogger.initLog().level(LogLevel.DEBUG)
        .message("Récupération des informations sur l'utilisateur depuis le token id du jeton")
        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
        .eventCod(Constants.LOGS_EVT_CODE_GETTING_USER_CONNECTED)
        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_SESSION)
        .log();
        
        var user = new UserDetails();
        user.setId(tokenId.getSub());
        
        user.setState(generateCsrfToken(this.springSession.getId()));
        
        return user;
    }

    /**
     * Vérification de la validité de l'ID TOken
     * 
     * @param idTokenString L'ID Token à valider
     * @throws ApiException Erreur lors de l'appel HTTP
     */
    private IdToken checkIdTokenValidity(String idTokenString) throws ApiException {
        IdToken idToken = null;
        appLogger.initLog().level(LogLevel.DEBUG)
        .message("Vérification de la validité de l'id token")
        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
        .eventCod(Constants.LOGS_EVT_CODE_AUTH_CHECKING_ID_TOKEN)
        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
        .log();
        
        // Parsing du header du token pour récupérer l'algorithm de cryptage
        var tokenIdSplitHeader = idTokenString.split("\\.")[0];
        var tokenIdHeader = new String(Base64.getDecoder().decode(tokenIdSplitHeader.getBytes()));
        var jsonTokenIdHeader = JsonParser.parseString(tokenIdHeader);
        var kid = jsonTokenIdHeader.getAsJsonObject().get(Constants.KID_KEY).getAsString();
        var alg = jsonTokenIdHeader.getAsJsonObject().get(Constants.ALG_KEY).getAsString();

        // Appel de l'api pour récupérer la clé publique X Connect
        var publicKeys = this.securityServiceFeign.getPublicKey();

        // Parsing de la clé publique
        var jsonPublicKey = JsonParser.parseString(publicKeys);
        var keys = jsonPublicKey.getAsJsonObject().get(Constants.PUBLIC_KEYS).getAsJsonArray();
        
        var publicKey = "";
        for (JsonElement key: keys) {
            // On cherche la bonne clé
        	var keyId = key.getAsJsonObject().get(Constants.KID_KEY).getAsString();
        	var keyAlg = jsonTokenIdHeader.getAsJsonObject().get(Constants.ALG_KEY).getAsString();
            
            if (keyId.equals(kid) && keyAlg.equals(alg)) {
                publicKey = key.toString();
            }
        }
        
        if (StringUtils.isBlank(publicKey)) {
            appLogger.initLog().level(LogLevel.ERROR)
            .message("Aucune clé trouvé pour la validation de l'ID token")
            .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
            .eventCod(Constants.LOGS_EVT_CODE_AUTH_CHECKING_ID_TOKEN)
            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
            .log();
            
            throw new ApiException(HttpStatus.UNAUTHORIZED.value(), Constants.ACCESS_UNAUTHORIZED_RESPONSES);
        }

        try {
            // Vérification du token
        	var jwk = JsonWebKey.Factory.newJwk(publicKey);
        	var jwtConsumer = new JwtConsumerBuilder().
                    setRequireExpirationTime().
                    setExpectedAudience(clientId).
                    setVerificationKey(jwk.getKey()).
                    setJwsAlgorithmConstraints(ConstraintType.PERMIT, alg)
                    .build();

            jwtConsumer.processToClaims(idTokenString);
            
            appLogger.initLog().level(LogLevel.DEBUG)
            .message("Verification Id Token OK")
            .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
            .eventCod(Constants.LOGS_EVT_CODE_AUTH_CHECKING_ID_TOKEN)
            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
            .log();
            
            // Extraction Informations Id Token
            var tokenIdSplitContent = idTokenString.split("\\.")[1];
            var tokenIdContent = new String(Base64.getDecoder().decode(tokenIdSplitContent.getBytes()));
            
            idToken = AppUtils.jsonStringToObject(tokenIdContent, new TypeReference<IdToken>() {});

        } catch (InvalidJwtException e) {
        	var errorMessage = "";
            // Jeton expiré
            if (e.hasExpired()) {
                errorMessage = "Le JWT a expiré";
            }

            // Audiance invalide
            if (e.hasErrorCode(ErrorCodes.AUDIENCE_INVALID)) {
                errorMessage = "Le JWT a une mauvaise audiance";
            }
            appLogger.initLog().level(LogLevel.ERROR)
            .message(String.format("Id token invalide. %s", errorMessage))
            .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
            .eventCod(Constants.LOGS_EVT_CODE_AUTH_CHECKING_ID_TOKEN)
            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
            .log();
            
            throw new ApiException(HttpStatus.UNAUTHORIZED.value(), Constants.ACCESS_UNAUTHORIZED_RESPONSES);
        } catch (JoseException | IOException e) {
            appLogger.initLog().level(LogLevel.ERROR)
            .message(String.format("Id token invalide. %s", e.getMessage()))
            .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
            .eventCod(Constants.LOGS_EVT_CODE_AUTH_CHECKING_ID_TOKEN)
            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
            .log();
            
            throw new ApiException(HttpStatus.UNAUTHORIZED.value(), Constants.ACCESS_UNAUTHORIZED_RESPONSES);
        }
        
        return idToken;
    }
    

    /**
     * Vérification de la validité du Logout Token
     * 
     * @param logoutTokenString Logout Token
     * @throws ApiException Erreur lors de l'appel HTTP
     */
    private LogoutToken checkLogoutTokenValidity(String logoutTokenString) throws ApiException {
        LogoutToken logoutTkn = null;
        appLogger.initLog().level(LogLevel.DEBUG)
        .message("Vérification de la validité du logout token")
        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
        .eventCod(Constants.LOGS_EVT_CODE_AUTH_CHECKING_LOGOUT_TOKEN)
        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
        .log();
        
        // Parsing du header du token pour récupérer l'algorithm de cryptage
        var logoutTokenSplitHeader = logoutTokenString.split("\\.")[0];
        var logoutTokenHeader = new String(Base64.getDecoder().decode(logoutTokenSplitHeader.getBytes()));
        var jsonLogoutHeader = JsonParser.parseString(logoutTokenHeader);
        var kid = jsonLogoutHeader.getAsJsonObject().get(Constants.KID_KEY).getAsString();
        var alg = jsonLogoutHeader.getAsJsonObject().get(Constants.ALG_KEY).getAsString();

        // Appel de l'api pour récupérer la clé publique X Connect
        var publicKeys = this.securityServiceFeign.getPublicKey();

        // Parsing de la clé publique
        var jsonPublicKey = JsonParser.parseString(publicKeys);
        var keys = jsonPublicKey.getAsJsonObject().get(Constants.PUBLIC_KEYS).getAsJsonArray();
        
        var publicKey = "";
        for (JsonElement key: keys) {
            // On cherche la bonne clé
        	var keyId = key.getAsJsonObject().get(Constants.KID_KEY).getAsString();
        	var keyAlg = jsonLogoutHeader.getAsJsonObject().get(Constants.ALG_KEY).getAsString();
            
            if (keyId.equals(kid) && keyAlg.equals(alg)) {
                publicKey = key.toString();
            }
        }
        
        if (StringUtils.isBlank(publicKey)) {
            appLogger.initLog().level(LogLevel.ERROR)
            .message("Aucune clé trouvé pour la validation du logout token")
            .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
            .eventCod(Constants.LOGS_EVT_CODE_AUTH_CHECKING_LOGOUT_TOKEN)
            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
            .log();
            
            throw new ApiException(HttpStatus.BAD_REQUEST.value(), Constants.BAD_REQUEST_RESPONSES);
        }

        try {
            // Vérification du token
        	var jwk = JsonWebKey.Factory.newJwk(publicKey);
        	var jwtConsumer = new JwtConsumerBuilder().
                    setExpectedIssuer(auc9UrlPublique).
                    setVerificationKey(jwk.getKey()).
                    setSkipDefaultAudienceValidation().
                    setJwsAlgorithmConstraints(ConstraintType.PERMIT, alg)
                    .build();

            jwtConsumer.processToClaims(logoutTokenString);
            
            // Parsing contenu
            var logoutTokenSplitContent = logoutTokenString.split("\\.")[1];
            var logoutTokenContent = new String(Base64.getDecoder().decode(logoutTokenSplitContent.getBytes()));
            
            logoutTkn =  AppUtils.jsonStringToObject(logoutTokenContent, new TypeReference<LogoutToken>() {});
            
            // Vérification event
            if (!logoutTkn.getEvents().containsKey(logoutTokenEvent)) {
                appLogger.initLog().level(LogLevel.ERROR)
                .message("Logout Token event invalide")
                .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
                .eventCod(Constants.LOGS_EVT_CODE_AUTH_CHECKING_LOGOUT_TOKEN)
                .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
                .log();    
                
                throw new ApiException(HttpStatus.BAD_REQUEST.value(), Constants.BAD_REQUEST_RESPONSES);
            }
            
            // Vérification sid
            if (!this.redisCacheService.isRefreshTokenKeyExist(logoutTkn.getSid())) {
                appLogger.initLog().level(LogLevel.ERROR)
                .message("Logout Token sid non trouvé")
                .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
                .eventCod(Constants.LOGS_EVT_CODE_AUTH_CHECKING_LOGOUT_TOKEN)
                .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
                .log();    
                
                throw new ApiException(HttpStatus.NOT_FOUND.value(), Constants.SESSION_NOT_FOUND);           	
            }            
            
            appLogger.initLog().level(LogLevel.DEBUG)
            .message("Verification logout Token OK")
            .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
            .eventCod(Constants.LOGS_EVT_CODE_AUTH_CHECKING_LOGOUT_TOKEN)
            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
            .log();

        } catch (InvalidJwtException e) {
        	var errorMessage = e.getMessage();

            // Issuer invalide
            if (e.hasErrorCode(ErrorCodes.ISSUER_INVALID)) {
                errorMessage = "Le JWT a un mauvais issuer";
            }
            appLogger.initLog().level(LogLevel.ERROR)
            .message(String.format("Logout token invalide. %s", errorMessage))
            .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
            .eventCod(Constants.LOGS_EVT_CODE_AUTH_CHECKING_LOGOUT_TOKEN)
            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
            .log();
            
            throw new ApiException(HttpStatus.BAD_REQUEST.value(), Constants.BAD_REQUEST_RESPONSES);
        } catch (JoseException | IOException e) {
            appLogger.initLog().level(LogLevel.ERROR)
            .message(String.format("Logout token invalide. %s", e.getMessage()))
            .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
            .eventCod(Constants.LOGS_EVT_CODE_AUTH_CHECKING_LOGOUT_TOKEN)
            .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH)
            .log();
            
            throw new ApiException(HttpStatus.BAD_REQUEST.value(), Constants.BAD_REQUEST_RESPONSES);
        }
                
        return logoutTkn;
    }

    public String generateCsrfToken(String value) {
        return DigestUtils.sha256Hex(value);
    }
}
