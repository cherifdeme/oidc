package fr.ca.cat.ihml.oidc.bff.session;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Class descriptive pour les propriétés de session
 * @author ET02720
 *
 */
@ConfigurationProperties(prefix = "security.session.cookie")
public class CookieSerializerProperties {

	/**
	 * Pattern du domaine pour le cookie de session
	 */
	private String domainPattern;
	
	/**
	 * Chemin pour le cookie de session
	 */
	private String path;
	
	/**
	 * Attribut same site pour le cookie de session
	 */
	private String sameSite;
	
	/**
	 * Récupération du domaine pour le cookie de session
	 * @return Le domaine pour le cookie de session
	 */
	public String getDomainPattern() {
		return domainPattern;
	}	
	
	/**
	 * Spécification du domaine pour le cookie de session
	 * @param domainPattern Le nouveau domaine pour le cookie de session
	 */
	public void setDomainPattern(String domainPattern) {
		this.domainPattern = domainPattern;
	}	
	
	/**
	 * Récupération du chemin pour le cookie de session
	 * @return Le chemin pour le cookie de session
	 */
	public String getPath() {
		return path;
	}	
	
	/**
	 * Spécification du chemin pour le cookie de session
	 * @param path Le nouveau chemin pour le cookie de session
	 */
	public void setPath(String path) {
		this.path = path;
	}
	
	/**
	 * Récupération de l'attribut same site pour le cookie de session
	 * @return L'attribut same site pour le cookie de sessions
	 */
	public String getSameSite() {
		return sameSite;
	}
	
	/**
	 * Spécification de l'attribut same site pour le cookie de sessions
	 * @param sameSite
	 */
	public void setSameSite(String sameSite) {
		this.sameSite = sameSite;
	}
}
