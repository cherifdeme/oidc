package fr.ca.cat.ihml.oidc.bff.session;

import java.time.Duration;
import java.util.Objects;

import fr.ca.cat.ihml.oidc.bff.services.logs.ApplicationLogger;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.session.RedisSessionProperties;
import org.springframework.boot.autoconfigure.session.SessionProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.session.config.annotation.web.http.EnableSpringHttpSession;
import org.springframework.session.data.redis.RedisSessionRepository;
import org.springframework.session.data.redis.config.ConfigureRedisAction;
import org.springframework.session.web.http.CookieSerializer;
import org.springframework.session.web.http.DefaultCookieSerializer;

import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;

/**
 * Classe de configuration de spring session
 * 
 * @author ET02720
 *
 */
@Configuration
@EnableConfigurationProperties({SessionProperties.class, RedisSessionProperties.class, CookieSerializerProperties.class})
@EnableSpringHttpSession
public class RedisSessionConfiguration {
	
    /**
     * Déclaration du logger de la classe
     */
    private static ApplicationLogger appLogger = ApplicationLogger.getLogger(RedisSessionConfiguration.class);
	
    /**
     * Declaration des properties de configuration lié à la session {session.}
     */
	private final SessionProperties sessionProperties;
	
    /**
     * Declaration des properties de configuration lié à la gestion des cookies {security.session.cookie}
     */
	private final CookieSerializerProperties cookieSerializerProperties;

    /**
     * Declaration des properties de configuration lié à spring session redis {spring.session.redis}
     */
	private final RedisSessionProperties redisSessionProperties;

	/**
	 * Factory de connexion Redis
	 */
	private final RedisConnectionFactory redisConnectionFactory;
	
	/**
	 * Constructeur
	 * 
	 * @param sessionProperties properties de session
	 * @param redisSessionProperties prorperties de spring session Redis
	 * @param redisConnectionFactory redis connection factory
	 * @param cookieSerializerProperties properties de cookie
	 */
	public RedisSessionConfiguration(SessionProperties sessionProperties, RedisSessionProperties redisSessionProperties, ObjectProvider<RedisConnectionFactory> redisConnectionFactory, CookieSerializerProperties cookieSerializerProperties) {
		this.sessionProperties = sessionProperties;
		this.redisSessionProperties = redisSessionProperties;
		this.redisConnectionFactory = redisConnectionFactory.getObject();
		this.cookieSerializerProperties = cookieSerializerProperties;
	}
	
	/**
	 * Création d'un bean pour la gestion des operation avec Redis
	 * @return
	 */
	@Bean
	public RedisOperations<String, Object> sessionRedisOperations() {
		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
		redisTemplate.setConnectionFactory(this.redisConnectionFactory);
		redisTemplate.setKeySerializer(new StringRedisSerializer());
		redisTemplate.setHashKeySerializer(new StringRedisSerializer());
		return redisTemplate;
	}

	/**
	 * Création du bean pour la sauvegarde des informations de session dans le Redis
	 * Utilisation d'un RedisSessionRepository pour ne pas utiliser le pub/sub
	 * @param sessionRedisOperations
	 * @return
	 */
	@Bean
	public RedisSessionRepository sessionRepository(RedisOperations<String, Object> sessionRedisOperations) {
		var sessionRepository = new RedisSessionRepository(sessionRedisOperations);
		Duration timeout = this.sessionProperties.getTimeout();
		if (timeout != null) {
			sessionRepository.setDefaultMaxInactiveInterval(timeout);
		}
		sessionRepository.setRedisKeyNamespace(this.redisSessionProperties.getNamespace());
		sessionRepository.setFlushMode(this.redisSessionProperties.getFlushMode());
		sessionRepository.setSaveMode(this.redisSessionProperties.getSaveMode());
		return sessionRepository;
	}
	
    /**
     * Création du bean permettant la personnalisation du cookie de session
     * Spring
     * 
     * @return {@link CookieSerializer}
     */
    @Bean
    public CookieSerializer cookieSerializer() {
    	var serializer = new DefaultCookieSerializer();
        serializer.setCookieName(Constants.SESSION_ID_COOKIE);

        if (Objects.nonNull(cookieSerializerProperties.getPath())) {
            serializer.setCookiePath(cookieSerializerProperties.getPath());
        }

        if (Objects.nonNull(cookieSerializerProperties.getDomainPattern()) && !cookieSerializerProperties.getDomainPattern().isEmpty()) {
            serializer.setDomainNamePattern(cookieSerializerProperties.getDomainPattern());
        }
       
        serializer.setUseHttpOnlyCookie(true);
        serializer.setUseSecureCookie(true);
        serializer.setSameSite(cookieSerializerProperties.getSameSite());
        
        appLogger.initLog().level(LogLevel.INFO)
        .message(String.format("Configuration du cookie de session. DomainePattern: %s - Path: %s - HttpOnly: %s - Secure: true - SameSite: %s", cookieSerializerProperties.getDomainPattern(), cookieSerializerProperties.getPath(), true, cookieSerializerProperties.getSameSite()))
        .eventTyp(Constants.LOGS_EVT_TYPE_CONFIGURATION)
        .eventCod(Constants.LOGS_EVT_CODE_CONFIGURING_COOKIE_SESSION)
        .log();
        
        return serializer;
    }

    /**
     * Création du bean permettant de spécifier que spring n'effectue aucune
     * action de modification de configuration du REDIS
     * 
     * @return Un objet de configuration du REDIS
     * @see {@link ConfigureRedisAction}
     */
    @Bean
    public static ConfigureRedisAction configureRedisAction() {
        return ConfigureRedisAction.NO_OP;
    }  

}
