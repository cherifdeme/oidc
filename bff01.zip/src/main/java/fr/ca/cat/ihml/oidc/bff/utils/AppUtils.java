package fr.ca.cat.ihml.oidc.bff.utils;

import java.io.IOException;
import java.io.InputStream;
import java.security.*;
import java.security.cert.CertificateException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import jakarta.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import static fr.ca.cat.ihml.oidc.bff.feign.client.PlacesServiceFeign.appLogger;

/**
 * Classe contenant des methodes static utilitaire
 * 
 * @author ET02720
 *
 */
public class AppUtils {

    /**
     * Constructeur privé
     */
    private AppUtils() {
    }

    /**
     * Récupération de la requête en cours
     * 
     * @return {@link Optional<HttpServletRequest>}
     */
    public static Optional<HttpServletRequest> getCurrentHttpRequest() {
        return Optional.ofNullable(RequestContextHolder.getRequestAttributes()).filter(requestAttributes -> ServletRequestAttributes.class.isAssignableFrom(requestAttributes.getClass())).map(ServletRequestAttributes.class::cast).map(ServletRequestAttributes::getRequest);
    }

    /**
     * Récupération d'un correlationId soit depuis la requête soit on le créé
     * 
     * @return
     */
    public static String getCorrelationId() {
    	var correlationId = UUID.randomUUID().toString();

        // Récupération header correlationId si on vient d'une requêtre front
        Optional<HttpServletRequest> frontRequest = AppUtils.getCurrentHttpRequest();
        if (Objects.nonNull(frontRequest) && frontRequest.isPresent() && Objects.nonNull(frontRequest.get().getHeader(Constants.ID_CORRELATION_HEADER)) && !frontRequest.get().getHeader(Constants.ID_CORRELATION_HEADER).isEmpty()) {
            correlationId = frontRequest.get().getHeader(Constants.ID_CORRELATION_HEADER);
        }

        return correlationId;
    }

    /**
     * Permet la conversion d'un objet en chaine JSON
     * 
     * @param obj
     *            L'objet à convertir
     * @return La chaine JSON
     * @throws JsonProcessingException
     */
    public static String convertObjectToJsonString(Object obj) throws JsonProcessingException {
        if (Objects.isNull(obj)) {
            return null;
        }

        var mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);
        return mapper.writeValueAsString(obj);
    }

    /**
     * Convertir une string Json en objet
     * 
     * @param jsonString
     *            La chaine json
     * @param klass
     *            La classe de l'objet cible
     * @return L'objet cible
     * @throws IOException
     */
    public static <T> T jsonStringToObject(String jsonString, TypeReference<T> typeReference) throws IOException {
        if (Objects.isNull(jsonString)) {
            return null;
        }

        var objectMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return objectMapper.readValue(jsonString, typeReference);
    }

    /**
     * Permet de mettre en forme une chaine JSON
     * 
     * @param jsonString
     *            La chaine à mettre en forme
     * @return La chaine JSON mise à en forme
     * @throws IOException
     */
    public static String prettifyJsonString(String jsonString) throws IOException {
        if (Objects.isNull(jsonString)) {
            return null;
        }

        var mapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper.enable(SerializationFeature.INDENT_OUTPUT);
        var json = mapper.readValue(jsonString, Object.class);

        return convertObjectToJsonString(json);
    }

    /**
     * Convert a java object to Map
     * 
     * @param object
     *            Objet à convertir
     * @return Une map avec les propriétés de l'objet
     */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> objectToMap(Object object) {
    	var objectMapper = new ObjectMapper().configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        return objectMapper.convertValue(object, Map.class);
    }

    /**
     * Permet de retourner le timestamp en millisecondes depuis maintenant plus
     * un temps de délai
     * 
     * @param delay
     *            Le délai à rajouter à maintenant
     * @return Le timestamp en millisecondes
     */
    public static long delayFromNowToMilliseconds(int delay) {
        return LocalDateTime.now().plusSeconds(delay).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
    }

    /**
     * Permet de retourner une LocalDateTime à partir d'un timestamp en
     * millisecondes
     * 
     * @param dateMilliseconds
     *            Le timestam en millisecondes
     * @return Un objet LocalDateTime
     * @see {@link LocalDateTime}
     */
    public static LocalDateTime dateFromMilliseconds(long dateMilliseconds) {
        return LocalDateTime.ofInstant(Instant.ofEpochMilli(dateMilliseconds), ZoneId.systemDefault());
    }

    /**
     * Construction de la chaine pour spécifier un cookie
     * 
     * @param cookieName
     *            Nom du cookie
     * @param cookieValue
     *            Valeur du cookie
     * @param domain
     *            Domaine du cookie
     * @param path
     *            Chemin du cookie
     * @param httpOnly
     *            Protocol HTTPS
     * @param sameSite
     *            Précision sameSite
     * @param expired
     *            Expiration du cookie
     * @return Une chaine pour spécifier le cookie
     */
    public static String buildCookie(String cookieName, String cookieValue, String domain, String path, boolean httpOnly, String sameSite, boolean expired) {
    	var sb = new StringBuilder();

        // Ajout nom et valeur du cookie
        sb.append(String.format("%s=%s", cookieName, cookieValue));

        // Ajout du domain
        if (Objects.nonNull(domain) && !domain.isEmpty()) {
            sb.append(String.format("; domain=%s", domain));
        }

        // Ajout du path
        if (Objects.nonNull(path) && !path.isEmpty()) {
            sb.append(String.format("; path=%s", path));
        }

        // Ajout HttpOnly
        if (httpOnly) {
            sb.append("; HttpOnly");
        }
        
        // Secure
        sb.append("; Secure");

        // Ajout Same Site
        if (Objects.nonNull(sameSite) && !sameSite.isEmpty()) {
            sb.append(String.format("; SameSite=%s", sameSite));
        } else {
            sb.append("; SameSite=Lax");
        }

        // Ajout MaxAge
        if (expired) {
            sb.append("; Max-Age=0; Expires=Thu, 1 Jan 1970 00:00:00 GMT");
        }

        return sb.toString();
    }

    public static String obfuscateUUIDString(String uuidString) {
        return uuidString.replaceAll(".{20}$", "XXXXX");
    }

    public static Key loadKeyStore(String path, String pwd, String alias) throws ApiException {
        InputStream is = null;
        try {
            is = Thread.currentThread().getContextClassLoader().getResourceAsStream(path);
            if (null == is) {
                appLogger.initLog().level(LogLevel.ERROR).message(Constants.TRUSTSTORE_NOT_FOUND)
                        .eventTyp(Constants.LOGS_EVT_TYPE_AUTH)
                        .eventCod(Constants.LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED)
                        .secEventTyp(Constants.LOGS_SEC_EVT_TYPE_AUTH).log();
                throw new ApiException(HttpStatus.FORBIDDEN.value(), Constants.TRUSTSTORE_NOT_FOUND);
            }

            // obtenir le mot de passe de l'utilisateur et le flux d'entrée du fichier
            var password = pwd.toCharArray();

            final var ks = KeyStore.getInstance(Constants.KEY_STORE_INSTANCE);
            ks.load(is, password);
            return ks.getKey(alias, password);
        } catch (KeyStoreException | NoSuchAlgorithmException | UnrecoverableKeyException | CertificateException
                 | IOException e) {
            throw new ApiException(HttpStatus.FORBIDDEN.value(), Constants.TRUSTSTORE_NOT_FOUND);
        }
    }
}
