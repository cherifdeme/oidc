package fr.ca.cat.ihml.oidc.bff.utils;

/**
 * Classe permettant de centraliser les constantes du projet
 *
 * @author ET02720
 */
public class Constants {

    private Constants() {
        throw new IllegalStateException("Utility class");
    }

    // Redis Cache
    public static final String REFRESH_TOKEN_CACHE = "REFRESH_TOKEN_CACHE";
    public static final String LOGS_CONFIGURATION_CACHE = "LOGS_CONFIGURATION_CACHE";
    public static final String CACHE_LOGS_NULL = "Erreur lors de la récupération cache LOGS";
    public static final String CACHE_TOKEN_JWT_NULL = "Erreur recuperation du cache jwt";
    public static final String CACHE_USERINFOS_JWT_NULL = "Erreur recuperation cache user entitlements";
    public static final String CACHE_JWT_SUB_NULL = "Erreur recuperation sub dans le cache";
    public static final String TOKEN_JWT_CACHE = "TOKEN_JWT_CACHE";
    // Redis Keys
    public static final String EXPIRES_AT_KEY = "expires_at";
    public static final String LOGS_DEFAULT_CONF_CLIENT_KEY = "default";
    public static final String ID_TOKEN_SUB = "id_token_sub";

    public static final String JWT_TOKEN_PAYLOAD = "jwt_token_payload";
    public static final String TOKEN_JWT = "launch_jwt_token";
    public static final String CACHE_JWT_PAYLOAD_NULL = "erreur de recuperation du payload";

    // Request Headers
    public static final String BASIC_HEADER_VALUE = "Basic %s";
    public static final String CORRELATION_ID_HEADER = "correlationId";
    public static final String ID_CORRELATION_HEADER = "idCorrelation";

    // Request Cookie
    public static final String SESSION_REFRESH_COOKIE = "SESSION_REFRESH";
    public static final String SESSION_ID_COOKIE = "SESSION_ID";

    // Request Params
    public static final String GRANT_TYPE_PARAM = "grant_type";
    public static final String SCOPE_PARAM = "scope";
    public static final String CODE_PARAM = "code";
    public static final String REDIRECT_URI_PARAM = "redirect_uri";
    public static final String TOKEN_PARAM = "token";
    public static final String REFRESH_TOKEN_PARAM = "refresh_token";
    public static final String USER_CONTEXT_PARAM = "user_context";
    public static final String CLIENT_ID_PARAM = "client_id";
    public static final String STATE = "state";
    public static final String APPLICATION = "application";
    public static final String COUNT = "count";
    public static final String DELETED_VALUE = "deleted";
    public static final String SUB = "sub";

    // Request Params Value
    public static final String AUTORIZATION_CODE_VALUE = "authorization_code";
    public static final String REFRESH_TOKEN_VALUE = "refresh_token";
    public static final String SCOPE_VALUE = "openid";

    // Oauth Token
    public static final String PUBLIC_KEYS = "keys";
    public static final String ALG_KEY = "alg";
    public static final String KID_KEY = "kid";

    // CSRF
    public static final String XSRF_TOKEN_COOKIE = "XSRF-TOKEN";
    public static final String X_XSRF_TOKEN_HEADER = "X-XSRF-TOKEN";


    // Request Response
    public static final String ACCESS_UNAUTHORIZED_RESPONSES = "Identifiants de session invalides";
    public static final String BAD_REQUEST_RESPONSES = "Paramètres invalides";
    public static final String SESSION_NOT_FOUND = "Session non trouvée";

    // Logs
    public static final String LOGS_EVT_CODE_APPLICATION_STARTED = "APPLICATION_STARTED";
    public static final String LOGS_EVT_CODE_APPLICATION_STARTUP_FAILED = "APPLICATION_STARTUP_FAILED";
    public static final String LOGS_EVT_CODE_FILTER_START = "AUTH_FILTER_START";
    public static final String LOGS_EVT_CODE_AUTH_LOGIN_PROCESSING = "AUTH_LOGIN_PROCESSING";
    public static final String LOGS_EVT_CODE_AUTH_LOGIN_OK = "AUTH_LOGIN_OK";
    public static final String LOGS_EVT_CODE_AUTH_BCK_CH_LOGOUT_PROCESSING = "AUTH_BCK_CH_LOGOUT_PROCESSING";
    public static final String LOGS_EVT_CODE_AUTH_STDA_LOGOUT_PROCESSING = "AUTH_STDA_LOGOUT_PROCESSING";
    public static final String LOGS_EVT_CODE_AUTH_BCK_CH_LOGOUT_OK = "AUTH_BCK_CH_LOGOUT_OK";
    public static final String LOGS_EVT_CODE_AUTH_STDA_LOGOUT_OK = "AUTH_STDA_LOGOUT_OK";
    public static final String LOGS_EVT_CODE_AUTH_BCK_CH_LOGOUT_KO = "AUTH_BCK_CH_LOGOUT_KO";
    public static final String LOGS_EVT_CODE_AUTH_CHECKING_ID_TOKEN = "LOGS_EVT_CODE_AUTH_CHECKING_ID_TOKEN";
    public static final String LOGS_EVT_CODE_AUTH_CHECKING_LOGOUT_TOKEN = "LOGS_EVT_CODE_AUTH_CHECKING_LOGOUT_TOKEN";
    public static final String LOGS_EVT_CODE_SESSION_OK = "SESSION_OK";
    public static final String LOGS_EVT_CODE_SESSION_EXPIRED = "SESSION_EXPIRED";
    public static final String LOGS_EVT_CODE_REFRESH_TOKEN_OK = "REFRESH_TOKEN_OK";
    public static final String LOGS_EVT_CODE_REFRESH_TOKEN_NEEDED_ACCESS_TOKEN_EXPIRED = "REFRESH_TOKEN_NEEDED_ACCESS_TOKEN_EXPIRED";
    public static final String LOGS_EVT_CODE_REFRESH_TOKEN_PROCESSING = "REFRESH_TOKEN_PROCESSING";
    public static final String LOGS_EVT_CODE_REFRESH_TOKEN_REVOKING = "REFRESH_TOKEN_REVOKING";
    public static final String LOGS_EVT_CODE_REFRESH_STDA_TOKEN_REVOKING = "REFRESH_STDA_TOKEN_REVOKING";
    public static final String LOGS_EVT_CODE_REFRESH_TOKEN_STDA_DELETING_OK = "REFRESH_STDA_TOKEN_DELETING_OK";
    public static final String LOGS_EVT_CODE_REFRESH_TOKEN_BCK_CH_DELETING_OK = "REFRESH_TOKEN_BCK_CH_DELETING_OK";
    public static final String LOGS_EVT_CODE_REFRESH_TOKEN_STDA_DELETING_NOT_FOUND = "REFRESH_TOKEN_STDA_DELETING_NOT_FOUND";
    public static final String LOGS_EVT_CODE_REFRESH_TOKEN_BCK_CH_DELETING_NOT_FOUND = "REFRESH_TOKEN_BCK_CH_DELETING_NOT_FOUND";
    public static final String LOGS_EVT_CODE_REFRESH_TOKEN_KO = "REFRESH_TOKEN_KO";
    public static final String LOGS_EVT_CODE_GETTING_USER_CONNECTED = "GETTING_USER_CONNECTED";
    public static final String LOGS_EVT_CODE_NO_USER_FOR_SESSION = "NO_USER_FOR_SESSION";
    public static final String LOGS_EVT_CODE_NO_RT_FOR_SESSION = "NO_RT_FOR_SESSION";
    public static final String LOGS_EVT_CODE_CONFIGURING_REDIS_TOKEN_CACHE = "CONFIGURING_REDIS_TOKEN_CACHE";
    public static final String LOGS_EVT_CODE_CONFIGURING_REDIS_LOGS_CACHE = "CONFIGURING_REDIS_LOGS_CACHE";
    public static final String LOGS_EVT_CODE_CONFIGURING_COOKIE_SESSION = "CONFIGURING_COOKIE_SESSION";
    public static final String LOGS_EVT_CODE_API_ERROR = "API_ERROR";
    public static final String LOGS_EVT_CODE_API_RETRY = "API_RETRY";
    public static final String LOGS_EVT_CODE_CONTEXT_GET = "CONTEXT_GET";
    public static final String LOGS_EVT_CODE_CONTEXT_POST = "CONTEXT_POST";
    public static final String LOGS_EVT_CODE_PLACES_GET_CR = "PLACES_GET_CR";
    public static final String LOGS_EVT_CODE_PLACES_GET_CR_FALLBACK = "PLACES_GET_CR_FALLBACK";
    public static final String LOGS_EVT_CODE_PLACES_GET_CR_FALLBACK_CB_OPEN = "PLACES_GET_CR_FALLBACK_CB_OPEN";
    public static final String LOGS_EVT_CODE_PLACES_GET_DISTRIBUTION_ENTITIES = "PLACES_GET_DISTRIBUTION_ENTITIES";
    public static final String LOGS_EVT_CODE_PLACES_GET_DISTRIBUTION_ENTITIES_FALLBACK = "PLACES_GET_DISTRIBUTION_ENTITIES_FALLBACK";
    public static final String LOGS_EVT_CODE_PLACES_GET_DISTRIBUTION_ENTITIES_FALLBACK_CB_OPEN = "PLACES_GET_DISTRIBUTION_ENTITIES_FALLBACK_CB_OPEN";
    public static final String LOGS_EVT_CODE_PLACES_GET_ENTITIES = "PLACES_GET_ENTITIES";
    public static final String LOGS_EVT_CODE_PLACES_GET_ENTITIES_FALLBACK = "PLACES_GET_ENTITIES_FALLBACK";
    public static final String LOGS_EVT_CODE_PLACES_GET_ENTITIES_FALLBACK_CB_OPEN = "PLACES_GET_ENTITIES_FALLBACK_CB_OPEN";
    public static final String LOGS_EVT_CODE_PLACES_GET_MANIFEST = "GET_MANIFEST";
    public static final String LOGS_EVT_CODE_GET_LOGS_CONFIGURATION = "GET_LOGS_CONFIGURATION";
    public static final String LOGS_EVT_CODE_SET_LOGS_CONFIGURATION = "SET_LOGS_CONFIGURATION";
    public static final String LOGS_EVT_CODE_CSRF_FILTER_ACTIVATION = "CSRF_FILTER_ACTIVATION";
    public static final String LOGS_EVT_CODE_CSRF_VERIFICATION = "CSRF_VERIFICATION";
    public static final String LOGS_EVT_CODE_CSRF_ERROR = "CSRF_VERIFICATION_ERROR";
    public static final String LOGS_EVT_CODE_CLEANING_REDIS_SESSION = "CLEANING_REDIS_SESSION ";
    public static final String LOGS_EVT_CODE_REDIS_ERROR = "REDIS_ERROR";
    public static final String LOGS_EVT_TYPE_CONFIGURATION = "CONFIGURATION";
    public static final String LOGS_EVT_TYPE_APP_LIFECYCLE = "APP_LIFECYCLE";
    public static final String LOGS_EVT_TYPE_AUTH = "AUTH";
    public static final String LOGS_EVT_TYPE_CSRF = "CSRF";
    public static final String LOGS_EVT_TYPE_API = "API";
    public static final String LOGS_EVT_TYPE_LOGS = "LOGS";
    public static final String LOGS_EVT_TYPE_CONTEXT = "CONTEXT";
    public static final String LOGS_EVT_TYPE_REDIS = "REDIS";
    public static final String LOGS_SEC_EVT_TYPE_AUTH = "FONCTION_SECURITE_AUTHENTIFICATION";
    public static final String LOGS_SEC_EVT_TYPE_SESSION = "FONCTION_SECURITE_SESSION";
    public static final String LOGS_SEC_EVT_TYPE_CSRF = "FONCTION_SECURITE_CSRF";
    public static final String LOGS_APP_ID = "STANDALONE";
    public static final String LOGS_COMPONENT_ID = "ihml_bff_java";
    public static final String LOGS_COMPONENT_TYPE = "BFF";

    // Log MDC
    public static final String LOG_MDC_TIME = "time";
    public static final String LOG_MDC_LEVEL = "level";
    public static final String LOG_MDC_LOG_EVENT_COD = "event_cod";
    public static final String LOG_MDC_LOG_EVENT_TYP = "event_typ";
    public static final String LOG_MDC_LOG_SEC_EVENT_TYP = "sec_event_typ";
    public static final String LOG_MDC_USR_ID = "usr_id";
    public static final String LOG_MDC_UOM_COD = "uom_cod";
    public static final String LOG_MDC_APP_ID = "app_id";
    public static final String LOG_MDC_COMPONENT_ID = "component_id";
    public static final String LOG_MDC_CORR_ID = "corr_id";
    public static final String LOG_MDC_SESS_ID = "sess_id";
    public static final String LOG_MDC_SRC_CLIENT_ID = "src_client_id";
    public static final String LOG_MDC_PROFIL = "profil";
    public static final String LOG_MDC_INSTANCE_NAME = "instance_name";
    public static final String LOG_MDC_URI = "uri";
    public static final String LOG_MDC_COMPONENT_TYPE = "component_type";
    public static final String LOG_MDC_TERMINAL = "terminal";
    public static final String LOG_MDC_EDS = "eds";
    public static final String LOG_MDC_OPERATIONAL_POST_ID = "operational_post_id";
    public static final String LOG_MDC_STACK_TRACE = "stack_trace";
    public static final String LOG_MDC_SRC_CLIENT = "src_client";
    public static final String LOG_MDC_MESSAGE = "message";

    public static final String CACHE_REFRESH_TOKEN_NULL = "Erreur récupération cache REFRESH TOKEN";
    // OIDC MESSAGE
    public static final String TOKEN_NULL = "Le jeton de lancement est nul ou vide";

    public static final String ERROR_JETON_JWT = "Impossible de parser le jeton jwt";
    public static final String ERROR_DIFFERENT_SUB = "Les subs des jetons sont different";
    public static final String CERTIFICAT_VIDE = "Le certificat est vide";
    public static final String ALIAS_TRUSTSTORE_NOT_FOUND = "Alias introuvable dans le truststore";
    public static final String IMPOSSIBLE_DE_GÉNÉRER_LE_JWT = "Envoi de post message, impossible de générer le jwt";
    public static final String ALIAS_TRUSTSTORE_ROOT_NOT_FOUND = "Alias du root introuvable dans le truststore";
    public static final String BEGIN_JWT_CONTROL = "Debut de la verification du jeton jwt";
    public static final String CRL_CHARGED = "Fichier CRL chargé";
    public static final String CRL_GENERATION = "Generation du CRL";
    public static final String AES = "AES";
    public static final String DOWNLOADING_CRL_ERROR = "Impossible de charger le fichier CRL";
    public static final String DOWNLOADING_CRL = "Telechargement du CRL";
    public static final String TRUSTSTORE_NOT_FOUND = "Fichier du truststore introuvable";
    public static final String TRUSTSTORE_CHARGED = "TrustStore chargé";
    public static final String TRUSTSTORE_CLOSING_ERROR = "Probleme lors de la fermeture du truststore";
    public static final String KEY_STORE_INSTANCE = "PKCS12";
    public static final String CERTIFICATE_INSTANCE = "X.509";
    public static final String VALIDATED_WITH_AC = "certificat validé par l'AC";
    public static final String CERTIFICAT_NOT_VALIDATED_WITH_AC = "L'AC ne valide pas le certificat";
    public static final String CRL_GENERATION_ERROR = "Impossible de generer le CRL";
    public static final String INVALID_URI = "URI valide";
    public static final String OCSP_VERIFICATION_ERROR = "La vérification OCSP a échoué";
    public static final String OCSP_CERTIFICATE_NOT_REVOKED = "Certificat non revoqué";
    public static final String OCSP_SERVER_RESPONSE_ERROR = "Le répondeur OCSP a renvoyé une réponse OCSP non valide ou inconnue";
    public static final String OCSP_SERVER_TRY_LATER = "Erreur interne/essayez plus tard. Erreur de réponse OCSP: ";
    public static final String OCSP_SIGN_NOT_FOUND = "Signature invalide ou manquante. Erreur de réponse OCSP: ";
    public static final String OCSP_DEMAND_UNAUTHORIZED = "Demande non autorisée. Erreur de réponse OCSP: ";
    public static final String OCSP_REQUEST_INCORRECT = "La requête OCSP est incorrecte. Erreur de réponse OCSP: ";
    public static final String METHOD_TYPE = "POST";
    public static final String ERREUR_LORS_DU_CONTROLE_OCSP = "erreur lors du controle OCSP: ";
    public static final String OCSP_REVOCATION_STATE_ERROR = "Erreur de connexion, impossible d'obtenir"
            + " l'état de révocation du certificat à l'aide du répondeur OCSP \"%s\", code \"%d\"";
    public static final String BEGIN_DOWNLOAD_PUBLIC_KEY = "Telechargement de la clé publique";
    public static final String LOADING_ERROR = "Erreur lors du telechargement de la clé publique";
    public static final String OCSP_VERIFICATION_PROBLEM = "probleme lors de la verification de la revocation";
    public static final String SHA_INSTANCE = "SHA1PRNG";
    public static final String USER_DATA_SAVED = "Données utilisateur sauvegardé dans la session";
    public static final String JWT_TOKEN_VALID = "Jeton jwt valide";
    public static final String JWT_TOKEN_VALID_NO_REVOKED = "Jeton jwt valide et non revoqué";
    public static final String JWT_TOKEN_INVALID = "jwt de lancement invalide";
    public static final String JWT_TOKEN_EXPIRED = "le jeton jwt est expiré ";
    public static final String JWT_AUDIENCE_INCORRECT = "Audience incorrect: ";
    public static final String SIGN_INVALID = "La signature est invalide";
    public static final String SIGN_VALID = "La signature est correcte";
    public static final String JWT_LAUNCH_CONTEXT = "launch_context";
    public static final String USER_ENTITLEMENTS = "user_entitlements";
    public static final String UOM_CODE = "uom_code";
    public static final String ADDITIONAL_ELEMENT = "additional_element";
    public static final String USER_PROFILE = "user_profile";
    public static final String VERSION_ERROR = "La version du jeton jwt n'est pas supportée";
    public static final String SESSION_ID = "SESSION_ID";
    public static final String GET_USER_DATA = "Recuperation des données utilisateurs";
    public static final String DEFAULT_ERROR_TEMPLATE = "default_error";
    public static final String ENCRYPTION_ERROR = "probleme lors du chiffrement de la données sensible";
    public static final String CONTENT_TYPE = "Content-type";
    public static final String HEADER = "application/ocsp-request";
    public static final String CONTENT_LENGTH = "Content-length";
    public static final String LOAD_CERT = "recuperation du certificat";
    public static final String IMPOSSIBLE_DE_RECUPERER_LE_CERTIFICAT = "Impossible de recuperer le certificat";
    public static final String IMPOSSIBLE_DE_CHIFFRER_LE_POST_MESSAGE = "Impossible de chiffrer le post message";

    // Launcher param
    public static final String CORRELATION_ID = "correlation_id";
    public static final String REQUEST_VERSION = "request_version";
    public static final String IHM_LAUNCH_PARAMS = "ihm_launch_params";
    public static final String USER_IDP_HINT = "user_idp_hint";
    public static final String CONTEXT_INITIAL = "context_initial";
    public static final String REDIRECTION_ERROR = "Erreur lors de la redirection";

    // model attributes
    public static final String STATUS = "status";
    public static final String REQUESTEXCEPTIONTYPE = "requestExceptionType";
    public static final String REQUESTURI = "requestUri";
    public static final String REQUESTEXCEPTION = "requestException";
    public static final String REQUESTMESSAGE = "requestMessage";
    public static final String ERROR_TEMPLATE = "error";

    public static final String KEY_STORE_INTROUVABLE ="keyStore introuvable" ;
    // system prop
    public static final String HTTP_PROXYHOST = "http.proxyHost";
    public static final String HTTP_PROXYPORT = "http.proxyPort";
    public static final String HTTP_PROXYUSER = "http.proxyUser";
    public static final String HTTP_PROXY_PASS = "http.proxyPassword";
    public static final String ENCRYPTION_PRECESSING = "chiffrement de la donnée sensible en cours";
    public static final String GET_CERT_ERROR = "erreur lors de la recuperation du certificat";
    public static final String CERT_LOADED = "certificat pour le chiffrage recuperé";
    public static final String LOGS_EVT_CODE_SECURED_DATA_ENCRYPTION = "ENCRYPTION_PROCESSING";
    public static final String LOGS_SEC_EVT_TYPE_ENCRYPTION = "FONCTION_SECURITE_DATA_ENCRYPTION";
    public static final String LOGS_EVT_TYPE_SECURED_DATA_ENCRYPTION = "SECURED_DATA_ENCRYPTION";
}
