package fr.ca.cat.ihml.oidc.bff.cache;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

import java.time.Duration;

import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.test.util.ReflectionTestUtils;

@DisplayName("RedisCacheConfig")
@Tag("Service")
@Tag("Unit")
@ExtendWith(MockitoExtension.class)
class RedisCacheConfigTest {
	
	@InjectMocks
	private RedisCacheConfig redisCacheConfig;

	@Mock
	private RedisConnectionFactory redisConnectionFactory;

	@BeforeEach
	void setUp() throws Exception {
		ReflectionTestUtils.setField(redisCacheConfig, "redisCachePrefix", "ihml:s1247");
		ReflectionTestUtils.setField(redisCacheConfig, "refreshTokenCacheTtl", Duration.ofMinutes(120));
		ReflectionTestUtils.setField(redisCacheConfig, "logsConfigurationCacheTtl", Duration.ofMinutes(120));
	}
	

	@Test
	@DisplayName("Cas nominal")
	void testCacheManagerInit() {
		// ACTION
		CacheManager cacheManager = redisCacheConfig.cacheManager(redisConnectionFactory);
		
		// TEST
		assertThat(cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE), notNullValue(Cache.class));
		assertThat(cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE).getName(), is(Constants.REFRESH_TOKEN_CACHE));
		assertThat(cacheManager.getCache(Constants.LOGS_CONFIGURATION_CACHE), notNullValue(Cache.class));
		assertThat(cacheManager.getCache(Constants.LOGS_CONFIGURATION_CACHE).getName(), is(Constants.LOGS_CONFIGURATION_CACHE));

	}

}
