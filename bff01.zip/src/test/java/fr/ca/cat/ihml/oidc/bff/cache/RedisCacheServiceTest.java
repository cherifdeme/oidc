package fr.ca.cat.ihml.oidc.bff.cache;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import fr.ca.cat.ihml.oidc.bff.models.logs.LogClientConfiguration;
import fr.ca.cat.ihml.oidc.bff.models.security.tokens.RefreshToken;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.cache.Cache;
import org.springframework.cache.Cache.ValueWrapper;

import org.springframework.cache.CacheManager;

@DisplayName("RedisCacheService")
@Tag("Service")
@Tag("Unit")
@ExtendWith(MockitoExtension.class)
class RedisCacheServiceTest {

	@InjectMocks
	private RedisCacheService redisCacheService;

	@Mock
	private CacheManager cacheManager;

	@Mock
	private Cache cache;

	@Mock
	private ValueWrapper valueWrapper;

	@Nested
	@Tag("RefreshToken")
	@DisplayName("RefreshToken")
	class WhenRefreshToken {
		@Test
		@DisplayName("Stockage du refresh token")
		void testStoreRefreshToken() {
			// --- CONFIG -- //
			String key = "redisKey";
			EasyRandom generator = new EasyRandom();
			RefreshToken refreshToken = generator.nextObject(RefreshToken.class);
			when(cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE)).thenReturn(cache);
			doNothing().when(cache).put(key, refreshToken);

			// --- ACTION -- //
			redisCacheService.storeRefreshToken(key, refreshToken);

			// --- TEST -- //
			// Mock
			verify(cacheManager, times(2)).getCache(Constants.REFRESH_TOKEN_CACHE);
			verify(cache).put(key, refreshToken);
		}
		
		@Test
		@DisplayName("Stockage du refresh token - Cache REFRESH TOKEN null")
		void testStoreRefreshTokenCacheNull() {
			// --- CONFIG -- //
			String key = "redisKey";
			EasyRandom generator = new EasyRandom();
			RefreshToken refreshToken = generator.nextObject(RefreshToken.class);
			when(cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE)).thenReturn(null);

			// --- ACTION -- //
			IllegalArgumentException e = assertThrows(IllegalArgumentException .class, () -> redisCacheService.storeRefreshToken(key, refreshToken));

			// --- TEST -- //
			// Mock
			assertThat(e.getMessage(), is(Constants.CACHE_REFRESH_TOKEN_NULL));
		}

		@Test
		@DisplayName("Existence du refresh token")
		void testIsRefreshTokenKeyExistTrue() {
			// --- CONFIG -- //
			String key = "redisKey";
			when(cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE)).thenReturn(cache);
			when(cache.get(key)).thenReturn(valueWrapper);

			// --- ACTION -- //
			boolean tokenExist = redisCacheService.isRefreshTokenKeyExist(key);

			// --- TEST -- //
			// Mock
			verify(cacheManager, times(2)).getCache(Constants.REFRESH_TOKEN_CACHE);
			verify(cache).get(key);

			// Method return
			assertTrue(tokenExist);
		}
		
		@Test
		@DisplayName("Existence du refresh token - Cache REFRESH TOKEN null")
		void testIsRefreshTokenKeyExistTrueCacheNull() {
			// --- CONFIG -- //
			String key = "redisKey";
			when(cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE)).thenReturn(null);

			// --- ACTION -- //
			IllegalArgumentException e = assertThrows(IllegalArgumentException .class, () -> redisCacheService.isRefreshTokenKeyExist(key));

			// --- TEST -- //
			// Mock
			assertThat(e.getMessage(), is(Constants.CACHE_REFRESH_TOKEN_NULL));
		}

		@Test
		@DisplayName("Non existence du refresh token")
		void testIsRefreshTokenKeyExistFalse() {
			// --- CONFIG -- //
			String key = "redisKey";
			when(cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE)).thenReturn(cache);
			when(cache.get(key)).thenReturn(null);

			// --- ACTION -- //
			boolean tokenExist = redisCacheService.isRefreshTokenKeyExist(key);

			// --- TEST -- //
			// Mock
			verify(cacheManager, times(2)).getCache(Constants.REFRESH_TOKEN_CACHE);
			verify(cache).get(key);

			// Method return
			assertFalse(tokenExist);
		}

		@Test
		@DisplayName("Récupération du refresh token")
		void testGetRefreshToken() {
			// --- CONFIG -- //
			String key = "redisKey";
			EasyRandom generator = new EasyRandom();
			RefreshToken refreshToken = generator.nextObject(RefreshToken.class);
			when(cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE)).thenReturn(cache);
			when(cache.get(key, RefreshToken.class)).thenReturn(refreshToken);

			// --- ACTION -- //
			RefreshToken refreshTokenValue = redisCacheService.getRefreshToken(key);

			// --- TEST -- //
			// Mock
			verify(cacheManager, times(2)).getCache(Constants.REFRESH_TOKEN_CACHE);
			verify(cache).get(key, RefreshToken.class);

			// Method return
			assertThat(refreshTokenValue, is(refreshToken));
		}
		
		@Test
		@DisplayName("Récupération du refresh token - Cache REFRESH_TOKEN null")
		void testGetRefreshTokenCacheNull() {
			// --- CONFIG -- //
			String key = "redisKey";
			when(cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE)).thenReturn(null);

			// --- ACTION -- //
			IllegalArgumentException e = assertThrows(IllegalArgumentException .class, () -> redisCacheService.getRefreshToken(key));

			// --- TEST -- //
			// Mock
			assertThat(e.getMessage(), is(Constants.CACHE_REFRESH_TOKEN_NULL));
		}

		@Test
		@DisplayName("Suppression du refresh token")
		void testDeleteRefreshToken() {
			// --- CONFIG -- //
			String key = "redisKey";
			when(cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE)).thenReturn(cache);
			doNothing().when(cache).evict(key);

			// --- ACTION -- //
			redisCacheService.deleteRefreshToken(key);

			// --- TEST -- //
			// Mock
			verify(cacheManager, times(2)).getCache(Constants.REFRESH_TOKEN_CACHE);
			verify(cache).evict(key);
		}
		
		@Test
		@DisplayName("Suppression du refresh token - Cache REFRESH TOKEN null")
		void testDeleteRefreshTokenCacheNull() {
			// --- CONFIG -- //
			String key = "redisKey";
			when(cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE)).thenReturn(null);

			// --- ACTION -- //
			IllegalArgumentException e = assertThrows(IllegalArgumentException .class, () -> redisCacheService.deleteRefreshToken(key));

			// --- TEST -- //
			// Mock
			assertThat(e.getMessage(), is(Constants.CACHE_REFRESH_TOKEN_NULL));
		}
	}

	@Nested
	@Tag("ClientLogConfiguration")
	@Tag("Log")
	@DisplayName("ClientLogConfiguration")
	class WhenClientLogConfiguration {
		@Test
		@DisplayName("Stockage configuration log client")
		void testStoreClientLogConfiguration() {
			// --- CONFIG -- //
			EasyRandom generator = new EasyRandom();
			LogClientConfiguration logClientConfiguration = generator.nextObject(LogClientConfiguration.class);
			when(cacheManager.getCache(Constants.LOGS_CONFIGURATION_CACHE)).thenReturn(cache);
			doNothing().when(cache).put(Constants.LOGS_DEFAULT_CONF_CLIENT_KEY, logClientConfiguration);

			// --- ACTION -- //
			redisCacheService.storeClientLogConfiguration(logClientConfiguration);

			// --- TEST -- //
			// Mock
			verify(cacheManager, times(2)).getCache(Constants.LOGS_CONFIGURATION_CACHE);
			verify(cache).put(Constants.LOGS_DEFAULT_CONF_CLIENT_KEY, logClientConfiguration);
		}
		
		@Test
		@DisplayName("Stockage configuration log client - Cache LOGS null")
		void testStoreClientLogConfigurationCacheNull() {
			// --- CONFIG -- //
			EasyRandom generator = new EasyRandom();
			LogClientConfiguration logClientConfiguration = generator.nextObject(LogClientConfiguration.class);
			when(cacheManager.getCache(Constants.LOGS_CONFIGURATION_CACHE)).thenReturn(null);

			// --- ACTION -- //
			IllegalArgumentException e = assertThrows(IllegalArgumentException .class, () -> redisCacheService.storeClientLogConfiguration(logClientConfiguration));

			// --- TEST -- //
			// Mock
			assertThat(e.getMessage(), is(Constants.CACHE_LOGS_NULL));
		}

		@Test
		@DisplayName("Existence de la configuration log client")
		void testIsClientLogConfigurationExistTrue() {
			// --- CONFIG -- //
			when(cacheManager.getCache(Constants.LOGS_CONFIGURATION_CACHE)).thenReturn(cache);
			when(cache.get(Constants.LOGS_DEFAULT_CONF_CLIENT_KEY)).thenReturn(valueWrapper);

			// --- ACTION -- //
			boolean clientLogConfigurationExist = redisCacheService.isClientLogConfigurationExist();

			// --- TEST -- //
			// Mock
			verify(cacheManager, times(2)).getCache(Constants.LOGS_CONFIGURATION_CACHE);
			verify(cache).get(Constants.LOGS_DEFAULT_CONF_CLIENT_KEY);

			// Method return
			assertTrue(clientLogConfigurationExist);
		}
		
		@Test
		@DisplayName("Existence de la configuration log client - Cache LOGS null")
		void testIsClientLogConfigurationExistTrueCacheNull() {
			// --- CONFIG -- //
			when(cacheManager.getCache(Constants.LOGS_CONFIGURATION_CACHE)).thenReturn(null);

			// --- ACTION -- //
			IllegalArgumentException e = assertThrows(IllegalArgumentException .class, () -> redisCacheService.isClientLogConfigurationExist());

			// --- TEST -- //
			// Mock
			assertThat(e.getMessage(), is(Constants.CACHE_LOGS_NULL));
		}

		@Test
		@DisplayName("Non existence de la configuration log client")
		void testIsClientLogConfigurationExistFalse() {
			// --- CONFIG -- //
			when(cacheManager.getCache(Constants.LOGS_CONFIGURATION_CACHE)).thenReturn(cache);
			when(cache.get(Constants.LOGS_DEFAULT_CONF_CLIENT_KEY)).thenReturn(null);

			// --- ACTION -- //
			boolean clientLogConfigurationExist = redisCacheService.isClientLogConfigurationExist();

			// --- TEST -- //
			// Mock
			verify(cacheManager, times(2)).getCache(Constants.LOGS_CONFIGURATION_CACHE);
			verify(cache).get(Constants.LOGS_DEFAULT_CONF_CLIENT_KEY);

			// Method return
			assertFalse(clientLogConfigurationExist);
		}
		
		@Test
		@DisplayName("Non existence de la configuration log client - Cache LOGS null")
		void testIsClientLogConfigurationExistFalseCacheNull() {
			// --- CONFIG -- //
			when(cacheManager.getCache(Constants.LOGS_CONFIGURATION_CACHE)).thenReturn(null);

			// --- ACTION -- //
			IllegalArgumentException e = assertThrows(IllegalArgumentException .class, () -> redisCacheService.isClientLogConfigurationExist());

			// --- TEST -- //
			// Mock
			assertThat(e.getMessage(), is(Constants.CACHE_LOGS_NULL));
		}

		@Test
		@DisplayName("Récupération de la configuration log client")
		void testGetClientLogConfiguration() {
			// --- CONFIG -- //
			EasyRandom generator = new EasyRandom();
			LogClientConfiguration logClientConfiguration = generator.nextObject(LogClientConfiguration.class);
			when(cacheManager.getCache(Constants.LOGS_CONFIGURATION_CACHE)).thenReturn(cache);
			when(cache.get(Constants.LOGS_DEFAULT_CONF_CLIENT_KEY, LogClientConfiguration.class))
					.thenReturn(logClientConfiguration);

			// --- ACTION -- //
			LogClientConfiguration logClientConfigurationValue = redisCacheService.getClientLogConfiguration();

			// --- TEST -- //
			// Mock
			verify(cacheManager, times(2)).getCache(Constants.LOGS_CONFIGURATION_CACHE);
			verify(cache).get(Constants.LOGS_DEFAULT_CONF_CLIENT_KEY, LogClientConfiguration.class);

			// Method return
			assertThat(logClientConfigurationValue, is(logClientConfiguration));
		}
		
		@Test
		@DisplayName("Récupération de la configuration log client - Cache LOGS null")
		void testGetClientLogConfigurationCacheNull() {
			// --- CONFIG -- //
			when(cacheManager.getCache(Constants.LOGS_CONFIGURATION_CACHE)).thenReturn(null);

			// --- ACTION -- //
			IllegalArgumentException e = assertThrows(IllegalArgumentException .class, () -> redisCacheService.getClientLogConfiguration());

			// --- TEST -- //
			// Mock
			assertThat(e.getMessage(), is(Constants.CACHE_LOGS_NULL));
		}

	}

}
