package fr.ca.cat.ihml.oidc.bff.controllers;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.UUID;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.models.context.Ctx9WriteContext;
import fr.ca.cat.ihml.oidc.bff.services.api.ContextServiceImpl;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import fr.ca.cat.ihml.oidc.bff.models.context.ApplicationContext;

@DisplayName("ContextController")
@Tag("Controller")
@Tag("Unit")
@Tag("Context")
@ExtendWith(MockitoExtension.class)
class ContextControllerTest {

    @InjectMocks
    private ContextController contextController;

    @Mock
    private ContextServiceImpl contextService;
    
    @Nested
    @DisplayName("Récupération du contexte")
    class GetContext {
        @Test
        @DisplayName("Cas nominal")
        void testGetContext() throws IOException, ApiException {
            // --- CONFIG -- //
            ApplicationContext appContext = new ApplicationContext();
            appContext.setClientId(UUID.randomUUID().toString());
            appContext.setRegionalBankId("847");
            appContext.setZipCode("44115");

            UUID ctxId = UUID.randomUUID();
            when(contextService.getContext(ctxId)).thenReturn(appContext);

            // --- ACTION -- //
            ResponseEntity<ApplicationContext> response = contextController.getContext(ctxId);

            // --- TEST -- //
            // Mock
            verify(contextService).getContext(ctxId);

            // HTTP Status
            assertThat(response.getStatusCode().value(), is(200));

            // Set-Cookie Header
            assertThat(response.getBody().getClientId(), is(appContext.getClientId()));
            assertThat(response.getBody().getRegionalBankId(), is(appContext.getRegionalBankId()));
            assertThat(response.getBody().getZipCode(), is(appContext.getZipCode()));
        }

        @Test()
        @DisplayName("Gestion ApiException - Pas de context Id")
        void testGetContextApiException() throws ApiException, IOException {
            // --- CONFIG -- //
            UUID ctxId = UUID.randomUUID();
            when(contextService.getContext(ctxId)).thenThrow(new ApiException(404, "ContextId not found"));

            // --- ACTION -- //
            ApiException e = assertThrows(ApiException.class, () -> contextController.getContext(ctxId));
            assertThat(e.getMessage(), is("ContextId not found"));
            assertThat(e.getStatusCode(), is(404));
        }    	
    }

    @Nested
    @DisplayName("Sauvegarde du contexte")
    class SetContext {
        @Test
        @DisplayName("Cas nominal")
        void testSetContext() throws IOException, ApiException {
            // --- CONFIG -- //
            ApplicationContext appContext = new ApplicationContext();
            appContext.setClientId(UUID.randomUUID().toString());
            appContext.setRegionalBankId("847");
            appContext.setZipCode("44115");

            Ctx9WriteContext ctx9WriteContext = new Ctx9WriteContext();
            ctx9WriteContext.setContext(UUID.randomUUID().toString());

            when(contextService.setContext(appContext)).thenReturn(ctx9WriteContext);

            // --- ACTION -- //
            ResponseEntity<Ctx9WriteContext> response = contextController.setContext(appContext);

            // --- TEST -- //
            // Mock
            verify(contextService).setContext(appContext);

            // HTTP Status
            assertThat(response.getStatusCode().value(), is(200));

            // Set-Cookie Header
            assertThat(response.getBody().getContext(), is(ctx9WriteContext.getContext()));
        }

        @Test()
        @DisplayName("Gestion ApiException - Sauvegarde en erreur")
        void testSetContextApiException() throws ApiException, IOException {
            // --- CONFIG -- //
            ApplicationContext appContext = new ApplicationContext();
            appContext.setClientId(UUID.randomUUID().toString());
            appContext.setRegionalBankId("847");
            appContext.setZipCode("44115");
            when(contextService.setContext(appContext)).thenThrow(new ApiException(500, "Error when saving context"));

            // --- ACTION -- //
            ApiException e = assertThrows(ApiException.class, () -> contextController.setContext(appContext));
            assertThat(e.getMessage(), is("Error when saving context"));
            assertThat(e.getStatusCode(), is(500));
        }    	
    }


}
