package fr.ca.cat.ihml.oidc.bff.controllers;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import fr.ca.cat.ihml.oidc.bff.controllers.HealthCheckController;
import fr.ca.cat.ihml.oidc.bff.services.health.HealthService;

@DisplayName("HealthCheck")
@Tag("Controller")
@Tag("Unit")
@Tag("Healthcheck")
@ExtendWith(MockitoExtension.class)
class HealthCheckControllerTest {

	@InjectMocks
	private HealthCheckController healthCheckController;

    @Mock
    private HealthService healthService;


	@Test
	@DisplayName("Cas nominal")
	void testCasNominal() {
		// --- CONFIG -- //
		when(healthService.isRedisOk()).thenReturn(true);

		// --- ACTION -- //
		ResponseEntity<String> response = healthCheckController.alive();

		// --- TEST -- //
		// Mock
		verify(healthService).isRedisOk();

		// HTTP Status
		assertThat(response.getStatusCode().value(), is(200));

		// Set-Cookie Header
		assertThat(response.getBody(), is("Healthy"));
	}
	
	@Test
	@DisplayName("Connexion redis KO")
	void testConnexionRedisKoDbOk() {
		// --- CONFIG -- //
		when(healthService.isRedisOk()).thenReturn(false);

		// --- ACTION -- //
		ResponseEntity<String> response = healthCheckController.alive();

		// --- TEST -- //
		// Mock
		verify(healthService).isRedisOk();

		// HTTP Status
		assertThat(response.getStatusCode().value(), is(500));

		// Set-Cookie Header
		assertThat(response.getBody(), is("Dead"));
	}
}
