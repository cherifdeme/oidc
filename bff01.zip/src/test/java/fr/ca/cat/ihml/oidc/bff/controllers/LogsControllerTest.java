package fr.ca.cat.ihml.oidc.bff.controllers;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import fr.ca.cat.ihml.oidc.bff.models.logs.LogClientConfiguration;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogMessage;
import fr.ca.cat.ihml.oidc.bff.services.logs.ApplicationLogger;
import fr.ca.cat.ihml.oidc.bff.services.logs.LogsServiceImpl;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

@DisplayName("LogsController")
@Tag("Controller")
@Tag("Unit")
@Tag("Logs")
@ExtendWith(MockitoExtension.class)
class LogsControllerTest {

    @InjectMocks
    private LogsController logsController;
    
    @Mock
    private LogsServiceImpl logsService;
    
    @Mock
    private ApplicationLogger appLogger;
	
	@Test
	@DisplayName("Réception d'une log depuis le Front End")
	void testPostLogs() {
		// --- CONFIG -- //
		EasyRandom generator = new EasyRandom();		
		LogMessage logMessage = generator.nextObject(LogMessage.class);
		
		doNothing().when(logsService).treatmentClientLog(logMessage);
		// --- ACTION -- //
		ResponseEntity<Void> response = logsController.postLogs(logMessage);
		
		// --- TEST -- //
		// Mock
		verify(logsService).treatmentClientLog(logMessage);
		
		// HTTP Status
		assertThat(response.getStatusCode().value(), is(200));
	}

	@Test
	@DisplayName("Récupération de la configuration de la log cliente")
	void testGetClientLogConfiguration() {
		// --- CONFIG -- //
		LogClientConfiguration logClientConfiguration = new LogClientConfiguration();
		logClientConfiguration.setClientLoglevel(5);
		logClientConfiguration.setDisableConsoleLog(false);
		logClientConfiguration.setServerLogLovel(1);
		
		when(logsService.getClientLogConfiguration()).thenReturn(logClientConfiguration);
		
		// --- ACTION -- //
		ResponseEntity<LogClientConfiguration> response = logsController.getClientLogConfiguration();
		
		// --- TEST -- //
		// Mock
		verify(logsService).getClientLogConfiguration();
		
		// HTTP Status
		assertThat(response.getStatusCode().value(), is(200));
		
		// Set-Cookie Header
		assertThat(response.getBody().getClientLoglevel(), is(logClientConfiguration.getClientLoglevel()));
		assertThat(response.getBody().getServerLogLovel(), is(logClientConfiguration.getServerLogLovel()));
		assertThat(response.getBody().isDisableConsoleLog(), is(logClientConfiguration.isDisableConsoleLog()));
	}

	@Test
	@DisplayName("Sauvegarde de la configuration de la log cliente")
	void testSetClientLogConfiguration() {
		// --- CONFIG -- //
		LogClientConfiguration logClientConfiguration = new LogClientConfiguration();
		logClientConfiguration.setClientLoglevel(5);
		logClientConfiguration.setDisableConsoleLog(false);
		logClientConfiguration.setServerLogLovel(1);
		
		doNothing().when(logsService).storeClientLogConfiguration(logClientConfiguration);
		
		// --- ACTION -- //
		ResponseEntity<Void> response = logsController.setClientLogConfiguration(logClientConfiguration);
		
		// --- TEST -- //
		// Mock
		verify(logsService).storeClientLogConfiguration(logClientConfiguration);
		
		// HTTP Status
		assertThat(response.getStatusCode().value(), is(200));
	}

}
