package fr.ca.cat.ihml.oidc.bff.controllers;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import fr.ca.cat.ihml.oidc.bff.models.manifest.ApplicationManifest;
import fr.ca.cat.ihml.oidc.bff.services.manifest.ManifestServiceImpl;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

@DisplayName("ManifestController")
@Tag("Controller")
@Tag("Unit")
@Tag("Manifest")
@ExtendWith(MockitoExtension.class)
class ManifestControllerTest {

    @InjectMocks
    private ManifestController manifestController;
    
    @Mock
    private ManifestServiceImpl manifestService;
	
	@Test
	@DisplayName("Récupération du manifest")
	void testGetManifest() {
		// --- CONFIG -- //
		ApplicationManifest applicationManifest = new ApplicationManifest();
		applicationManifest.setFramework("Spring Boot");
		applicationManifest.setVersion("3.0.3");
		when(manifestService.getManifest()).thenReturn(applicationManifest);
		
		// --- ACTION -- //
		ResponseEntity<ApplicationManifest> response = manifestController.getManifest();
		
		// --- TEST -- //
		
		// Mock
		verify(manifestService).getManifest();
		
		// HTTP Status
		assertThat(response.getStatusCode().value(), is(200));
		
		// Set-Cookie Header
		assertThat(response.getBody().getFramework(), is(applicationManifest.getFramework()));
		assertThat(response.getBody().getVersion(), is(applicationManifest.getVersion()));
	}

}
