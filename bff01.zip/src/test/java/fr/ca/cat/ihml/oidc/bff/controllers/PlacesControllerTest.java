package fr.ca.cat.ihml.oidc.bff.controllers;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.models.places.CR;
import fr.ca.cat.ihml.oidc.bff.models.places.DistributionEntity;
import fr.ca.cat.ihml.oidc.bff.models.places.Entity;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import fr.ca.cat.ihml.oidc.bff.services.api.PlacesServiceImpl;

@DisplayName("PlacesController")
@Tag("Controller")
@Tag("Unit")
@Tag("Places")
@ExtendWith(MockitoExtension.class)
class PlacesControllerTest {

    @InjectMocks
    private PlacesController placesController;
    
    @Mock
    private PlacesServiceImpl placesService;
    
    @Nested
    @DisplayName("Liste des CR")
    class WithCrList {
    	
        @Test
        @DisplayName("Cas nominal")
    	void testGetPlaces() throws IOException, ApiException {
    		// --- CONFIG -- //
    		EasyRandom generator = new EasyRandom();
    		List<CR> crsList = generator.objects(CR.class, 3).collect(Collectors.toList());
    		CR[] crs = new CR[crsList.size()];
    		crs = crsList.toArray(crs);
    		when(placesService.getCRList()).thenReturn(crs);
    		
    		// --- ACTION -- //
    		ResponseEntity<CR[]> response = placesController.getCRList();
    		
    		// --- TEST -- //
    		
    		// Mock
    		verify(placesService).getCRList();
    		
    		// HTTP Status
    		assertThat(response.getStatusCode().value(), is(200));
    		
    		// Set-Cookie Header
    		assertThat(response.getBody().length, is(crs.length));
    		assertThat(response.getBody()[0], is(crs[0]));
    		assertThat(response.getBody()[1], is(crs[1]));
    		assertThat(response.getBody()[2], is(crs[2]));
    	}
    	
    	@Test()
    	@DisplayName("Gestion ApiException - Récupération en erreur")
    	void testGetPlacesApiException() throws IOException, ApiException {
    		// --- CONFIG -- //
    		when(placesService.getCRList()).thenThrow(new ApiException(500, "Erreur lors de la recuperation de la liste des CR"));
    		
    		// --- ACTION -- //
    		ApiException e = assertThrows(ApiException.class, () -> placesController.getCRList());
    		assertThat(e.getMessage(), is("Erreur lors de la recuperation de la liste des CR"));
    		assertThat(e.getStatusCode(), is(500));
    	}    	
    }

    @Nested
    @DisplayName("Liste des entités")
    class WithCREntities {
    	
    	@Test
    	@DisplayName("Cas nominal")
    	void testGetCREntities() throws IOException, ApiException {
    		// --- CONFIG -- //
    		EasyRandom generator = new EasyRandom();
    		List<Entity> entityList = generator.objects(Entity.class, 3).collect(Collectors.toList());
    		Entity[] entities = new Entity[entityList.size()];
    		entities = entityList.toArray(entities);
    		when(placesService.getCREntities(847)).thenReturn(entities);
    		
    		// --- ACTION -- //
    		ResponseEntity<Entity[]> response = placesController.getCREntities(847);
    		
    		// --- TEST -- //
    		
    		// Mock
    		verify(placesService).getCREntities(847);
    		
    		// HTTP Status
    		assertThat(response.getStatusCode().value(), is(200));
    		
    		// Set-Cookie Header
    		assertThat(response.getBody().length, is(entities.length));
    		assertThat(response.getBody()[0], is(entities[0]));
    		assertThat(response.getBody()[1], is(entities[1]));
    		assertThat(response.getBody()[2], is(entities[2]));
    	}
    	
    	@Test()
    	@DisplayName("Gestion ApiException - Récupération en erreur")
    	void testGetCREntitiesApiException() throws IOException, ApiException {
    		// --- CONFIG -- //
    		when(placesService.getCREntities(847)).thenThrow(new ApiException(500, "Erreur lors de la recuperation de la liste des entités de la CR 847"));
    		
    		// --- ACTION -- //
    		ApiException e = assertThrows(ApiException.class, () -> placesController.getCREntities(847));
    		assertThat(e.getMessage(), is("Erreur lors de la recuperation de la liste des entités de la CR 847"));
    		assertThat(e.getStatusCode(), is(500));
    	}
   	
    }
    
    @Nested
    @DisplayName("Liste des DistributionEntity")
    class WithDistributionEntity {
    	
    	@Test
    	@DisplayName("Cas nominal")
    	void testGetCRAgencesList() throws IOException, ApiException {
    		// --- CONFIG -- //
    		EasyRandom generator = new EasyRandom();
    		List<DistributionEntity> distributionEntitiyList = generator.objects(DistributionEntity.class, 3).collect(Collectors.toList());
    		DistributionEntity[] distributionEntities = new DistributionEntity[distributionEntitiyList.size()];
    		distributionEntities = distributionEntitiyList.toArray(distributionEntities);
    		when(placesService.getCRAgencesList(847, 44115)).thenReturn(distributionEntities);
    		
    		// --- ACTION -- //
    		ResponseEntity<DistributionEntity[]> response = placesController.getCRAgencesList(847, 44115);
    		
    		// --- TEST -- //
    		
    		// Mock
    		verify(placesService).getCRAgencesList(847, 44115);
    		
    		// HTTP Status
    		assertThat(response.getStatusCode().value(), is(200));
    		
    		// Set-Cookie Header
    		assertThat(response.getBody().length, is(distributionEntities.length));
    		assertThat(response.getBody()[0], is(distributionEntities[0]));
    		assertThat(response.getBody()[1], is(distributionEntities[1]));
    		assertThat(response.getBody()[2], is(distributionEntities[2]));
    	}
    	
    	@Test()
    	@DisplayName("Gestion ApiException - Récupération en erreur")
    	void testGetCRAgencesListApiException() throws IOException, ApiException {
    		// --- CONFIG -- //
    		when(placesService.getCRAgencesList(847, 44115)).thenThrow(new ApiException(500, "Erreur lors de la recuperation de la liste des agences de la CR 847 et de la ville 44115"));
    		
    		// --- ACTION -- //
    		ApiException e = assertThrows(ApiException.class, () -> placesController.getCRAgencesList(847, 44115));
    		assertThat(e.getMessage(), is("Erreur lors de la recuperation de la liste des agences de la CR 847 et de la ville 44115"));
    		assertThat(e.getStatusCode(), is(500));    		
    	}    	
    }
}
