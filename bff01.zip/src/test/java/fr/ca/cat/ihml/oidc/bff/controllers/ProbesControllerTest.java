package fr.ca.cat.ihml.oidc.bff.controllers;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.ResponseEntity;

import fr.ca.cat.ihml.oidc.bff.controllers.ProbesController;
import fr.ca.cat.ihml.oidc.bff.services.health.HealthService;

@DisplayName("ProbesController")
@Tag("Controller")
@Tag("Unit")
@Tag("Probes")
@ExtendWith(MockitoExtension.class)
class ProbesControllerTest {

    @InjectMocks
    private ProbesController probesController;
    
    @Mock
    private HealthService healthService;

	@Test
	@DisplayName("Bff Ready")
	void testReady() throws IOException {
		// --- CONFIG -- //
		when(healthService.isRedisOk()).thenReturn(true);
		
		// --- ACTION -- //
		ResponseEntity<String> response = probesController.ready();
		
		// --- TEST -- //
		
		// Mock
		verify(healthService).isRedisOk();
		
		// HTTP Status
		assertThat(response.getStatusCode().value(), is(200));
		
		// Set-Cookie Header
		assertThat(response.getBody(), is("Ready"));
	}
	
	@Test
	@DisplayName("Bff Not Ready")
	void testNotReady() throws IOException {
		// --- CONFIG -- //
		when(healthService.isRedisOk()).thenReturn(false);
		
		// --- ACTION -- //
		ResponseEntity<String> response = probesController.ready();
		
		// --- TEST -- //
		
		// Mock
		verify(healthService).isRedisOk();
		
		// HTTP Status
		assertThat(response.getStatusCode().value(), is(500));
		
		// Set-Cookie Header
		assertThat(response.getBody(), is("Not Ready"));
	}

	@Test
	@DisplayName("Bff Alive")
	void testAlive() {
		// --- ACTION -- //
		ResponseEntity<String> response = probesController.alive();
		
		// --- TEST -- //
		// HTTP Status
		assertThat(response.getStatusCode().value(), is(200));
		
		// Set-Cookie Header
		assertThat(response.getBody(), is("Alive"));
	}

}
