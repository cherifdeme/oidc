package fr.ca.cat.ihml.oidc.bff.controllers;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.List;
import java.util.UUID;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.models.security.auth.UserAuthenticated;
import fr.ca.cat.ihml.oidc.bff.models.security.user.UserDetails;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import jakarta.servlet.http.HttpServletRequest;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import fr.ca.cat.ihml.oidc.bff.services.security.SecurityServiceImpl;

@DisplayName("SecurityController")
@Tag("Controller")
@Tag("Unit")
@Tag("Security")
@ExtendWith(MockitoExtension.class)
class SecurityControllerTest {
	
    @InjectMocks
    private SecurityController securityController;
    
    @Mock
    private SecurityServiceImpl securityService;
    
    @Mock
    private HttpServletRequest request;

    @Value("${secret.cookie}")
    private String secretCookieName;
    
    @BeforeEach
	void setUp() {
		ReflectionTestUtils.setField(securityController, "path", "/path");
		ReflectionTestUtils.setField(securityController, "sameSite", "None");
		ReflectionTestUtils.setField(securityController, "secretCookie", secretCookieName);
		ReflectionTestUtils.setField(securityController, "request", request);
	}
    
    @Nested
    @DisplayName("Login")
    class WithLogin {
    	
    	@Test
    	@DisplayName("Cas nominal")
    	void testLogin() throws ApiException, IOException {
    		// --- CONFIG -- //
    		String azCode = UUID.randomUUID().toString();
    		String refreshToken = UUID.randomUUID().toString();
    		String csrfToken = UUID.randomUUID().toString();
    		String redirectUrl = "http://redirecturl";
    		when(securityService.login(azCode, redirectUrl, csrfToken, null)).thenReturn(refreshToken);
    		when(request.getServerName()).thenReturn("cookieDomain");
    		
    		// --- ACTION -- //
    		ResponseEntity<Void> response = securityController.login(azCode, redirectUrl, csrfToken, null);
    		
    		// --- TEST -- //
    		
    		// Mock
    		verify(securityService).login(azCode, redirectUrl, csrfToken, null);
    		verify(request).getServerName();
    		
    		// HTTP Status
    		assertThat(response.getStatusCode().value(), is(200));
    		
    		// Set-Cookie Header
    		List<String> setCookieHeader = response.getHeaders().get("Set-Cookie");
    		assertThat(setCookieHeader.size(), is(1));
    		assertThat(setCookieHeader.get(0), containsString(String.format("%s=%s; domain=cookieDomain; path=/path; HttpOnly; Secure; SameSite=None", Constants.SESSION_REFRESH_COOKIE, refreshToken)));
    	}
    	
    	@Test
    	@DisplayName("Cookie secret présent")
    	void testLoginSecretCookiePresent() throws ApiException, IOException {
    		// --- CONFIG -- //
    		String azCode = UUID.randomUUID().toString();
    		String refreshToken = UUID.randomUUID().toString();
    		String csrfToken = UUID.randomUUID().toString();
    		String redirectUrl = "http://redirecturl";
    		String secretCookie = UUID.randomUUID().toString();
    		when(securityService.login(azCode, redirectUrl, csrfToken, secretCookie)).thenReturn(refreshToken);
    		when(request.getServerName()).thenReturn("cookieDomain");
    		
    		// --- ACTION -- //
    		ResponseEntity<Void> response = securityController.login(azCode, redirectUrl, csrfToken, secretCookie);
    		
    		// --- TEST -- //
    		
    		// Mock
    		verify(securityService).login(azCode, redirectUrl, csrfToken, secretCookie);
    		verify(request, times(2)).getServerName();
    		
    		// HTTP Status
    		assertThat(response.getStatusCode().value(), is(200));
    		
    		// Set-Cookie Header
    		List<String> setCookieHeader = response.getHeaders().get("Set-Cookie");
    		assertThat(setCookieHeader.size(), is(2));
    		assertThat(setCookieHeader.get(0), containsString(String.format("%s=%s; domain=cookieDomain; path=/path; HttpOnly; Secure; SameSite=None", Constants.SESSION_REFRESH_COOKIE, refreshToken)));
    		assertThat(setCookieHeader.get(1), containsString(String.format("%s=%s; domain=cookieDomain; path=/path; HttpOnly; Secure; SameSite=None", secretCookieName, "deleted")));
    	}
    	
    	@Test()
    	@DisplayName("Gestion ApiException - Identifians invalides")
    	void testLoginApiException() throws ApiException, IOException {
    		// --- CONFIG -- //
    		String azCode = UUID.randomUUID().toString();
    		String redirectUrl = "http://redirecturl";
    		String csrfToken = UUID.randomUUID().toString();
    		when(securityService.login(azCode, redirectUrl, csrfToken, null)).thenThrow(new ApiException(401, "Identifiants Invalides"));
    		
    		// --- ACTION -- //
    		ApiException e = assertThrows(ApiException.class, () -> securityController.login(azCode, redirectUrl, csrfToken, null));
    		assertThat(e.getMessage(), is("Identifiants Invalides"));
    		assertThat(e.getStatusCode(), is(401));
    	}    	
    }

    @Nested
    @DisplayName("Standalone logout")
    class WithStandaloneLogout {
    	
    	@Test
    	@DisplayName("Cas nominal")
    	void testStandAloneLogout() throws IOException, ApiException {
    		// --- CONFIG -- //
    		String refreskCookie = UUID.randomUUID().toString();
    		doNothing().when(securityService).standAloneLogout(refreskCookie);
    		when(request.getServerName()).thenReturn("cookieDomain");
    		
    		// --- ACTION -- //
    		ResponseEntity<Void> response = securityController.standAloneLogout(refreskCookie);
    		
    		// --- TEST -- //
    		// Mock
    		verify(securityService).standAloneLogout(refreskCookie);
    		verify(request).getServerName();
    		
    		// HTTP Status
    		assertThat(response.getStatusCode().value(), is(200));
    		
    		// Suppression cookie refresh
    		List<String> setCookieHeader = response.getHeaders().get("Set-Cookie");
    		assertThat(setCookieHeader.size(), is(1));
    		assertThat(setCookieHeader.get(0), containsString(String.format("%s=%s; domain=cookieDomain; path=/path; HttpOnly; Secure; SameSite=None", Constants.SESSION_REFRESH_COOKIE, "deleted")));
    	}
    	
    	@Test()
    	@DisplayName("Gestion ApiException - Paramétres invalides")
        void testStandAloneLogoutKO() throws IOException, ApiException {
            // --- CONFIG -- //
    		String refreskCookie = UUID.randomUUID().toString();
            doThrow(new ApiException(400, "Paramétres invalides")).when(securityService).standAloneLogout(refreskCookie);
            
            // --- ACTION -- //
    		ApiException e = assertThrows(ApiException.class, () -> securityController.standAloneLogout(refreskCookie));
    		assertThat(e.getMessage(), is("Paramétres invalides"));
    		assertThat(e.getStatusCode(), is(400));
            
            // --- TEST -- //
            // Mock
            verify(securityService).standAloneLogout(refreskCookie);
        }
   	
    }
    
    @Nested
    @DisplayName("Back Channel logout")
    class WithBackChannelLogout {
		
	 	@Test
	 	@DisplayName("Cas nominal")
		void testBackChannelLogout() throws IOException, ApiException {
			// --- CONFIG -- //
			MultiValueMap<String,String> body = new LinkedMultiValueMap<>();
			body.add("logout_token", "logoutToken");
			when(securityService.backChannelLogout(body)).thenReturn(true);
			
			// --- ACTION -- //
			ResponseEntity<Void> response = securityController.backChannelLogout(body);
			
			// --- TEST -- //
			// Mock
			verify(securityService).backChannelLogout(body);
			
			// HTTP Status
			assertThat(response.getStatusCode().value(), is(200));
		}
		
		@Test()
		@DisplayName("Gestion ApiException - Paramétres invalides")
	    void testBackChannelLogoutKO() throws IOException, ApiException {
	        // --- CONFIG -- //
			MultiValueMap<String,String> body = new LinkedMultiValueMap<>();
	        body.add("dummy", "dummy");
	        doThrow(new ApiException(400, "Paramétres invalides")).when(securityService).backChannelLogout(body);
	        
	        // --- ACTION -- //
    		ApiException e = assertThrows(ApiException.class, () -> securityController.backChannelLogout(body));
    		assertThat(e.getMessage(), is("Paramétres invalides"));
    		assertThat(e.getStatusCode(), is(400));
	        
	        // --- TEST -- //
	        // Mock
	        verify(securityService).backChannelLogout(body);
	    }
		
		@Test()
		@DisplayName("Gestion ApiException - Session non trouvée")
	    void testBackChannelLogoutSidNotFound() throws IOException, ApiException {
	        // --- CONFIG -- //
			MultiValueMap<String,String> body = new LinkedMultiValueMap<>();
	        body.add("dummy", "dummy");
	        doThrow(new ApiException(404, "Session non trouvée")).when(securityService).backChannelLogout(body);
	        
	        // --- ACTION -- //
    		ApiException e = assertThrows(ApiException.class, () -> securityController.backChannelLogout(body));
    		assertThat(e.getMessage(), is("Session non trouvée"));
    		assertThat(e.getStatusCode(), is(404));
	        
	        // --- TEST -- //
	        // Mock
	        verify(securityService).backChannelLogout(body);
	    }
		
		@Test
		@DisplayName("Logout token non présent")
	    void testBackChannelLogoutLogoutTokenNotFound() throws IOException, ApiException {
	        // --- CONFIG -- //
			MultiValueMap<String,String> body = new LinkedMultiValueMap<>();
	        body.add("dummy", "dummy");
	        when(securityService.backChannelLogout(body)).thenReturn(false);
	        
	        // --- ACTION -- //
	        ResponseEntity<Void> response = securityController.backChannelLogout(body);
	        
	        // --- TEST -- //
	        // Mock
	        verify(securityService).backChannelLogout(body);
	        
	        // HTTP Status
	        assertThat(response.getStatusCode().value(), is(404));
	    }   	
    	
    }
    
    @Nested
    @DisplayName("User details")
    class WithGetUserConnected {
    	
    	@Test
    	@DisplayName("Cas nominal")
    	void testGetUserConnected() {
    		// --- CONFIG -- //
    	    UserDetails user = new UserDetails();
    		user.setId(UUID.randomUUID().toString());
    		user.setFpLabel("postFonctionnel");
    		user.setState(UUID.randomUUID().toString());
    		UserAuthenticated auth = new UserAuthenticated(user, UUID.randomUUID().toString());
    		String refreshCookieValue = UUID.randomUUID().toString();
    		when(securityService.getUserDetails(auth, refreshCookieValue)).thenReturn(user);
    		
    		// --- ACTION -- //
    		ResponseEntity<UserDetails> response = securityController.getUserDetails(auth, refreshCookieValue); 
    		
    		// --- TEST -- //
    		// Mock
    		verify(securityService).getUserDetails(auth, refreshCookieValue);
    		
    		// HTTP Status
    		assertThat(response.getStatusCode().value(), is(200));
    		
    		// Body
    		assertThat(response.getBody().getId(), is(user.getId()));
    		assertThat(response.getBody().getFpLabel(), is(user.getFpLabel()));		
    		assertThat(response.getBody().getState(), is(user.getState()));   
    		assertThat(response.getBody().getRoles().size(), is(0)); 
    	}
    	
    	@Test
    	@DisplayName("Suppression refresh cookie")
    	void testGetUserConnectedDeleteRefrehCookie() {
    		// --- CONFIG -- //
    		UserDetails user = new UserDetails();
    		user.setId(null);
    		user.setFpLabel(null);
    		user.setState(UUID.randomUUID().toString());
    		UserAuthenticated auth = new UserAuthenticated(user, UUID.randomUUID().toString());
    		String refreshCookieValue = UUID.randomUUID().toString();
    		when(securityService.getUserDetails(auth, refreshCookieValue)).thenReturn(user);
    		when(request.getServerName()).thenReturn("cookieDomain");
    		
    		// --- ACTION -- //
    		ResponseEntity<UserDetails> response = securityController.getUserDetails(auth, refreshCookieValue); 
    		
    		// --- TEST -- //
    		// Mock
    		verify(securityService).getUserDetails(auth, refreshCookieValue);
    		verify(request).getServerName();
    		
    		// HTTP Status
    		assertThat(response.getStatusCode().value(), is(200));	

    		// Suppression cookie refresh
    		List<String> setCookieHeader = response.getHeaders().get("Set-Cookie");
    		assertThat(setCookieHeader.size(), is(1));
    		assertThat(setCookieHeader.get(0), containsString(String.format("%s=%s; domain=cookieDomain; path=/path; HttpOnly; Secure; SameSite=None", Constants.SESSION_REFRESH_COOKIE, "deleted")));
    	}
    	
    	@Test
    	@DisplayName("Aucun utilisateur et aucun refresh cookie")
    	void testGetUserConnectedUserNullAndRefreshCookieNull() {
    		// --- CONFIG -- //
    		UserDetails user = new UserDetails();
    		user.setId(null);
    		user.setFpLabel(null);
    		user.setState(UUID.randomUUID().toString());
    		when(securityService.getUserDetails(null, null)).thenReturn(user);
    		
    		// --- ACTION -- //
    		ResponseEntity<UserDetails> response = securityController.getUserDetails(null, null); 
    		
    		// --- TEST -- //
    		// Mock
    		verify(securityService).getUserDetails(null, null);
    		
    		// HTTP Status
    		assertThat(response.getStatusCode().value(), is(200));	

    		// Suppression cookie refresh
    		assertThat(response.getHeaders().size(), is(0));
    	} 
    	
    }

}
