package fr.ca.cat.ihml.oidc.bff.exceptions;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.when;

import java.util.HashSet;
import java.util.Set;

import fr.ca.cat.ihml.oidc.bff.models.http.ErrorResponse;
import fr.ca.cat.ihml.oidc.bff.models.validator.ValidationErrorResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;
import jakarta.validation.Path;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.ServletWebRequest;

@DisplayName("RestResponseEntityExceptionHandler")
@Tag("Exception")
@Tag("Unit")
@ExtendWith(MockitoExtension.class)
class RestResponseEntityExceptionHandlerTest {
	
	@InjectMocks
	private RestResponseEntityExceptionHandler entityExceptionHandler;
	
	private ServletWebRequest request;
	
	@Mock
	private HttpServletRequest httpRequest;
	
	@Mock
	private HttpSession session;
	
	@Mock
	private ConstraintViolation<?> constraintViolation;
	
	@Mock
	private Path path;
	
	@BeforeEach
	void setUp() {
		request = new ServletWebRequest(httpRequest);
	}

	@Test
	@DisplayName("Exception generique")
	void testGenericException() {
		// --- CONFIG -- //
		RuntimeException ex = new RuntimeException("Message exception");
        when(httpRequest.getRequestURI()).thenReturn("/api/uri");

		// --- ACTION -- //
		ErrorResponse resp = entityExceptionHandler.onRuntimeException(ex, request);

		// --- TEST -- //
		assertThat(resp.getStatus(), is(500));
		assertThat(resp.getMessage(), is(ex.getMessage()));
	}
	
	@Test
	@DisplayName("ApiException")
	void testApiException() {
		// --- CONFIG -- //
		ApiException ex = new ApiException(HttpStatus.UNAUTHORIZED.value(), "Message exception");

        when(httpRequest.getRequestURI()).thenReturn("/api/uri");

		// --- ACTION -- //
		ResponseEntity<ErrorResponse> resp = entityExceptionHandler.onApiException(ex, request);

		// --- TEST -- //
		assertThat(resp.getBody().getMessage(), is(ex.getMessage()));
		assertThat(resp.getBody().getStatus(), is(ex.getStatusCode()));
	}
	
	@Test
	@DisplayName("ConstraintViolationException")
	void testConstraintViolationException() {
		// --- CONFIG -- //
		Set<ConstraintViolation<?>> constraintViolations = new HashSet<ConstraintViolation<?>>();
		constraintViolations.add(constraintViolation);
		
		when(constraintViolation.getMessage()).thenReturn("Properties format violation");
		when(constraintViolation.getPropertyPath()).thenReturn(path);
		when(path.toString()).thenReturn("/user/name");
		ConstraintViolationException ex = new ConstraintViolationException(constraintViolations);

		// --- ACTION -- //
        ValidationErrorResponse validationErrorResponse = entityExceptionHandler.onConstraintValidationException(ex);

		// --- TEST -- //
		assertThat(validationErrorResponse.getViolations().get(0).getMessage(), is("Properties format violation"));
	}

}
