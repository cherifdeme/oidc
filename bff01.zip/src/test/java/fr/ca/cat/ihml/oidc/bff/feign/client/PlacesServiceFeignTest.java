package fr.ca.cat.ihml.oidc.bff.feign.client;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.spy;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.models.places.CR;
import fr.ca.cat.ihml.oidc.bff.models.places.DistributionEntity;
import fr.ca.cat.ihml.oidc.bff.models.places.Entity;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;

@DisplayName("PlacesService")
@Tag("Feign")
@Tag("Unit")
@ExtendWith(MockitoExtension.class)
class PlacesServiceFeignTest {
	
	private PlacesServiceFeign placesServiceFeign;
	
	@Mock
	private CallNotPermittedException callNotPermitedExecption;
	

	@BeforeEach
	void setUp() throws Exception {
		placesServiceFeign = Mockito.spy(PlacesServiceFeign.class);
	}

	@Nested
	@DisplayName("GetCRListRequestFallback")
	class WithGetCRListRequestFallback {
		
		@Test
		@DisplayName("ApiException")
		void testGetCRListRequestFallbackApiException() {
			// CONFIG
			ApiException e = new ApiException(404, "Ressource not found");			
			
			// ACTION
			CR[] crs= placesServiceFeign.getCRListRequestFallback(e);
			
			// TEST
			assertThat(crs.length, is(0));
		}
		
		@Test
		@DisplayName("CallNotPermittedException")
		void testGetCRListRequestFallbackCallNotPermittedException() {
			
			// ACTION
			CR[] crs= placesServiceFeign.getCRListRequestFallback(callNotPermitedExecption);
			
			// TEST
			assertThat(crs.length, is(0));
		}	
	}
	
	@Nested
	@DisplayName("GetCREntitiesRequestFallback")
	class WithGetCREntitiesRequestFallback {
		
		@Test
		@DisplayName("ApiException")
		void testGetCRListRequestFallbackApiException() {
			// CONFIG
			ApiException e = new ApiException(404, "Ressource not found");			
			
			// ACTION
			Entity[] enties= placesServiceFeign.getCREntitiesRequestFallback(e);
			
			// TEST
			assertThat(enties.length, is(0));
		}
		
		@Test
		@DisplayName("CallNotPermittedException")
		void testGetCRListRequestFallbackCallNotPermittedException() {
			
			// ACTION
			Entity[] enties= placesServiceFeign.getCREntitiesRequestFallback(callNotPermitedExecption);
			
			// TEST
			assertThat(enties.length, is(0));
		}	
	}
	
	@Nested
	@DisplayName("GetDistributionEntitiesRequestFallback")
	class WithGetDistributionEntitiesRequestFallback {
		
		@Test
		@DisplayName("ApiException")
		void testGetCRListRequestFallbackApiException() {
			// CONFIG
			ApiException e = new ApiException(404, "Ressource not found");			
			
			// ACTION
			DistributionEntity[] distributionEntities= placesServiceFeign.getDistributionEntitiesRequestFallback(e);
			
			// TEST
			assertThat(distributionEntities.length, is(0));
		}
		
		@Test
		@DisplayName("CallNotPermittedException")
		void testGetCRListRequestFallbackCallNotPermittedException() {
			
			// ACTION
			DistributionEntity[] distributionEntities= placesServiceFeign.getDistributionEntitiesRequestFallback(callNotPermitedExecption);
			
			// TEST
			assertThat(distributionEntities.length, is(0));
		}	
	}


}
