package fr.ca.cat.ihml.oidc.bff.feign.config;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import feign.Contract;
import fr.ca.cat.ihml.oidc.bff.feign.error.ClientFeignErrorDecoder;


@DisplayName("GenericClientFeignConfig")
@Tag("Feign")
@Tag("Unit")
@ExtendWith(MockitoExtension.class)
class GenericClientFeignConfigTest {
	
	@InjectMocks
	private GenericClientFeignConfig genericClientFeignConfig;

	@BeforeEach
	void setUp() throws Exception {
	}

	@Test
	@DisplayName("ClientFeignErrorDecoder")
	void testClientFeignErrorDecoder() {
		// ACTION
		ClientFeignErrorDecoder errorDecoder = genericClientFeignConfig.clientFeignErrorDecoder();
		
		// TEST
		assertThat(errorDecoder, notNullValue());
	}
	
	@Test
	@DisplayName("FeignContract")
	void testFeignContract() {
		// ACTION
		Contract contract = genericClientFeignConfig.feignContract();
		
		// TEST
		assertThat(contract instanceof Contract.Default, is(true));
	}

}
