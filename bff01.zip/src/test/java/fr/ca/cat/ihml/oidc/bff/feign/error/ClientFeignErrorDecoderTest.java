package fr.ca.cat.ihml.oidc.bff.feign.error;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.Charset;
import java.util.Collection;
import java.util.HashMap;

import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import feign.Request;
import feign.Request.HttpMethod;
import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import feign.RequestTemplate;
import feign.Response;
import feign.RetryableException;

@DisplayName("ClientFeignErrorDecoder")
@Tag("Feign")
@Tag("Unit")
@ExtendWith(MockitoExtension.class)
class ClientFeignErrorDecoderTest {
	
	ClientFeignErrorDecoder clientFeignErrorDecoder;
	
	@BeforeEach
	void setUp() throws Exception {
		clientFeignErrorDecoder = new ClientFeignErrorDecoder();
	}
	
	@Test
	@DisplayName("RetryException")
	void testRetryException() throws IOException {
		// CONFIG
		Request request = Request.create(HttpMethod.GET, "/api/dummy", new HashMap<String, Collection<String>>(), null, null, new RequestTemplate());
		Response response = Response.builder()
				.request(request)
				.status(429)
				.body("Too many request", Charset.defaultCharset())
				.reason("Too many request")
				.build();		
		
		// ACTION
		RetryableException ex = (RetryableException) clientFeignErrorDecoder.decode("Invoker", response);
		
		// TEST
		assertThat(ex.status(), is(429));
		assertThat(ex.getMessage(), is("Too many request"));
		assertThat(ex.method(), is(HttpMethod.GET));
		assertThat(ex.request(), is(request));
	}
	
	@Test
	@DisplayName("ApiException")
	void testApiException() throws IOException {
		// CONFIG
		Request request = Request.create(HttpMethod.GET, "/api/dummy", new HashMap<String, Collection<String>>(), null, null, new RequestTemplate());
		Response response = Response.builder()
				.request(request)
				.status(500)
				.body("Server erreur", Charset.defaultCharset())
				.reason("Server erreur")
				.build();		
		
		// ACTION
		ApiException ex = (ApiException) clientFeignErrorDecoder.decode("Invoker", response);
		
		// TEST
		assertThat(ex.getStatusCode(), is(500));
		assertThat(ex.getMessage(), is("Server erreur"));
	}
	
	@Test
	@DisplayName("BodyReadingException")
	void testBodyReadingException() throws IOException {
		// CONFIG
		Request request = Request.create(HttpMethod.GET, "/api/dummy", new HashMap<String, Collection<String>>(), null, null, new RequestTemplate());
		Response response = Response.builder()
				.request(request)
				.status(500)
				.body("Server erreur", Charset.defaultCharset())
				.reason("Server erreur")
				.build();		
		
		// ACTION
		try (MockedStatic<IOUtils> ioUtilsMock = Mockito.mockStatic(IOUtils.class)) {
			ioUtilsMock.when(() -> IOUtils.toString(any(Reader.class))).thenThrow(new IOException("Error reading response body"));
			
			ApiException ex = (ApiException) clientFeignErrorDecoder.decode("Invoker", response);
			
			// TEST
			assertThat(ex.getStatusCode(), is(500));
			assertThat(ex.getMessage(), is("Server error"));
		}

	}
}
