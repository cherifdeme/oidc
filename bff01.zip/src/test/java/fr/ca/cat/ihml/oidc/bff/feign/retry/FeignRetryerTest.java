package fr.ca.cat.ihml.oidc.bff.feign.retry;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Collection;
import java.util.HashMap;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import feign.Request;
import feign.Request.HttpMethod;
import feign.RequestTemplate;
import feign.RetryableException;
import feign.Retryer;

@DisplayName("FeignRetryer")
@Tag("Feign")
@Tag("Unit")
class FeignRetryerTest {
	
	private FeignRetryer feignRetryer;

	@BeforeEach
	void setUp() throws Exception {
		feignRetryer = new FeignRetryer(4, 500L);
	}

	@DisplayName("Cas nominal")
	@Test
	void testRetry() {
		// CONFIG
		Request request = Request.create(HttpMethod.GET, "/api/dummy", new HashMap<String, Collection<String>>(), null, null, new RequestTemplate());
		RetryableException e = new RetryableException(500, "Server Error", HttpMethod.GET, 10L, request);
		
		// ACTION
		feignRetryer.continueOrPropagate(e);
		feignRetryer.continueOrPropagate(e);
		feignRetryer.continueOrPropagate(e);
		feignRetryer.continueOrPropagate(e);
		RetryableException ex = assertThrows(RetryableException.class, () -> feignRetryer.continueOrPropagate(e));
		
		// TEST
		assertThat(ex, is(e));
	}
	
	@DisplayName("Clone")
	@Test
	void testClone() {
		// CONFIG
		Request request = Request.create(HttpMethod.GET, "/api/dummy", new HashMap<String, Collection<String>>(), null, null, new RequestTemplate());
		RetryableException e = new RetryableException(500, "Server Error", HttpMethod.GET, 10L, request);
		
		// ACTION
		Retryer retryerClone = feignRetryer.clone();
		retryerClone.continueOrPropagate(e);
		retryerClone.continueOrPropagate(e);
		retryerClone.continueOrPropagate(e);
		retryerClone.continueOrPropagate(e);
		RetryableException ex = assertThrows(RetryableException.class, () -> retryerClone.continueOrPropagate(e));
		
		// TEST
		assertThat(ex, is(e));
	}
	
	@DisplayName("Constructeur par défaut")
	@Test
	void testDefaultConstructor() {
		// CONFIG
		Request request = Request.create(HttpMethod.GET, "/api/dummy", new HashMap<String, Collection<String>>(), null, null, new RequestTemplate());
		RetryableException e = new RetryableException(500, "Server Error", HttpMethod.GET, 10L, request);
		feignRetryer = new FeignRetryer();
		
		// ACTION
		feignRetryer.continueOrPropagate(e);
		RetryableException ex = assertThrows(RetryableException.class, () -> feignRetryer.continueOrPropagate(e));
		
		// TEST
		assertThat(ex, is(e));
	}

}
