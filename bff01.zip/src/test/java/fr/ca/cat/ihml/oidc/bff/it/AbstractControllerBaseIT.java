package fr.ca.cat.ihml.oidc.bff.it;

import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import fr.ca.cat.ihml.oidc.bff.Application;
import fr.ca.cat.ihml.oidc.bff.it.configuration.RedisConfiguration;
import fr.ca.cat.ihml.oidc.bff.it.configuration.WireMockConfiguration;

@ExtendWith(SpringExtension.class)
@SpringBootTest(webEnvironment = WebEnvironment.DEFINED_PORT, classes = {Application.class, RedisConfiguration.class, WireMockConfiguration.class})
public abstract class AbstractControllerBaseIT {
}
