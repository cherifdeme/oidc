package fr.ca.cat.ihml.oidc.bff.it;

import static io.restassured.RestAssured.get;
import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.is;

import fr.ca.cat.ihml.oidc.bff.models.context.Ctx9WriteContext;
import fr.ca.cat.ihml.oidc.bff.models.security.user.UserDetails;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import fr.ca.cat.ihml.oidc.bff.utils.TestConstants;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import fr.ca.cat.ihml.oidc.bff.models.context.ApplicationContext;
import io.restassured.http.ContentType;
import io.restassured.http.Cookies;
import io.restassured.http.Header;
import io.restassured.response.Response;

@DisplayName("ContextController")
@Tag("Context")
@Tag("Integration")
class ContextContollerIT extends AbstractControllerBaseIT {

	@Nested
	@DisplayName("GetContext")
	class WithGetContext {

		@Test
		@DisplayName("Cas nominal")
		void testGetContext() {
			String redirectUrl = "http://localhost/authorize";

			// Premiére requéte pour avoir un session id
			Response response = get("/api/security/user").
					then().
					assertThat().statusCode(200).
					and().extract().response();

			// Récupération du state
			String state = response.getBody().as(UserDetails.class).getState();

			// Passage cookie é la prochaine requéte
			Cookies cookies = new Cookies(response.getDetailedCookie(Constants.SESSION_ID_COOKIE), response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));

			// Login
			response = given().
					cookies(cookies).
					queryParam(Constants.CODE_PARAM, TestConstants.AZ_CODE_GOOD).
					queryParam(Constants.REDIRECT_URI_PARAM, redirectUrl).
					queryParam(Constants.STATE, state).
					when().
					get("/api/security/login").
					then().
					assertThat().statusCode(200).
					and().extract().response();

			// Context
			cookies = new Cookies(cookies.get(Constants.SESSION_ID_COOKIE), response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE), response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));

			ApplicationContext appContext = given().
					cookies(cookies).
					when().get("/api/context/1e98251d-b4c4-42ee-8f80-451f88d74aa1").
					then().
					assertThat().statusCode(200).
					and().extract().as(ApplicationContext.class);

			assertThat(appContext.getClientId(), is("62c11279475b0a9987a62f5e2794e9914e3740ac59f933059d043cd0a3d7fe50"));
			assertThat(appContext.getRegionalBankId(), is("813"));
			assertThat(appContext.getZipCode(), is("13090"));

			// Header CSRF
			Header csrfHeader = new Header("X-XSRF-TOKEN", response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).getValue());

			cookies = new Cookies();

			// Logout
			given().
					cookies(cookies).
					contentType(ContentType.URLENC).
					header(csrfHeader).
					body(SecurityControllerIT.getLogoutToken()).
					when().
					post("/api/security/backloggedout").
					then().
					assertThat().statusCode(200).
					and().extract().response();
		}

		@Test
		@DisplayName("Authentifié aucun refresh cookie")
		void testGetContextAuthenticatedButNoRefreshCookie() {
			String redirectUrl = "http://localhost/authorize";

			// Premiére requéte pour avoir un session id
			Response response = get("/api/security/user").then().and().assertThat().statusCode(200).and().extract().response();

			// Récupération du state
			String state = response.getBody().as(UserDetails.class).getState();

			// Passage cookie é la prochaine requéte
			Cookies cookies = new Cookies(response.getDetailedCookie(Constants.SESSION_ID_COOKIE), response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));

			// Login
			response = given().
					cookies(cookies).
					queryParam(Constants.CODE_PARAM, TestConstants.AZ_CODE_GOOD).
					queryParam(Constants.REDIRECT_URI_PARAM, redirectUrl).
					queryParam(Constants.STATE, state).
					when().
					get("/api/security/login").
					then().
					assertThat().statusCode(200).
					and().extract().response();

			// Context
			cookies = new Cookies(cookies.get(Constants.SESSION_ID_COOKIE), response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));

			// Call api without cookie SESSION_REFRESH
			given().
					cookies(cookies).
					when().
					get("/api/context/1e98251d-b4c4-42ee-8f80-451f88d74aa1").
					then().
					assertThat().statusCode(401);

			cookies = new Cookies(cookies.get(Constants.SESSION_ID_COOKIE), response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE), response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));

			// Header CSRF
			Header csrfHeader = new Header("X-XSRF-TOKEN", response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).getValue());

			cookies = new Cookies();

			// Logout
			given().
					cookies(cookies).
					contentType(ContentType.URLENC).
					header(csrfHeader).
					body(SecurityControllerIT.getLogoutToken()).
					when().
					post("/api/security/backloggedout").
					then().
					assertThat().statusCode(200).
					and().extract().response();

		}

	}


	@Nested
	@DisplayName("SetContext")
	class WithSetContext {

		@Test
		@DisplayName("Cas nominal")
		void testSetContext() {
			String redirectUrl = "http://localhost/authorize";

			// Premiére requéte pour avoir un session id
			Response response = get("/api/security/user").
					then().
					assertThat().statusCode(200).
					and().extract().response();

			// Récupération du state
			String state = response.getBody().as(UserDetails.class).getState();

			// Passage cookie é la prochaine requéte
			Cookies cookies = new Cookies(response.getDetailedCookie(Constants.SESSION_ID_COOKIE), response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));

			// Login
			response = given().
					cookies(cookies).
					queryParam(Constants.CODE_PARAM, TestConstants.AZ_CODE_GOOD).
					queryParam(Constants.REDIRECT_URI_PARAM, redirectUrl).
					queryParam(Constants.STATE, state).
					when().
					get("/api/security/login").
					then().
					assertThat().statusCode(200).
					and().extract().response();

			// Context
			cookies = new Cookies(cookies.get(Constants.SESSION_ID_COOKIE), response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE), response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));

			// Header CSRF
			Header csrfHeader = new Header("X-XSRF-TOKEN", cookies.get(Constants.XSRF_TOKEN_COOKIE).getValue());

			ApplicationContext appContext = new ApplicationContext();
			appContext.setClientId("62c11279475b0a9987a62f5e2794e9914e3740ac59f933059d043cd0a3d7fe50");
			appContext.setRegionalBankId("881");
			appContext.setZipCode("74000");

			Ctx9WriteContext ctx9WriteContext = given().
					cookies(cookies).
					header(csrfHeader).
					contentType(ContentType.JSON).
					body(appContext).
					when().
					post("/api/context").
					then().
					assertThat().statusCode(200).
					and().extract().as(Ctx9WriteContext.class);

			assertThat(ctx9WriteContext.getContext(), is("1e98251d-b4c4-42ee-8f80-451f88d74aa1"));

			cookies = new Cookies();

			// Logout
			given().
					cookies(cookies).
					header(csrfHeader).
					contentType(ContentType.URLENC).
					body(SecurityControllerIT.getLogoutToken()).
					when().
					post("/api/security/backloggedout").
					then().
					assertThat().statusCode(200).
					and().extract().response();
		}

		@Test
		@DisplayName("CSRF KO")
		void testSetContextCsrfKo() {
			String redirectUrl = "http://localhost/authorize";

			// Premiére requéte pour avoir un session id
			Response response = get("/api/security/user").then().and().assertThat().statusCode(200).and().extract().response();

			// Récupération du state
			String state = response.getBody().as(UserDetails.class).getState();

			// Passage cookie é la prochaine requéte
			Cookies cookies = new Cookies(response.getDetailedCookie(Constants.SESSION_ID_COOKIE), response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));

			// Login
			response = given().
					cookies(cookies).
					queryParam(Constants.CODE_PARAM, TestConstants.AZ_CODE_GOOD).
					queryParam(Constants.REDIRECT_URI_PARAM, redirectUrl).
					queryParam(Constants.STATE, state).
					when().
					get("/api/security/login").
					then().
					assertThat().statusCode(200).
					and().extract().response();

			// Context
			cookies = new Cookies(cookies.get(Constants.SESSION_ID_COOKIE), response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE), response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));

			ApplicationContext appContext = new ApplicationContext();
			appContext.setClientId("62c11279475b0a9987a62f5e2794e9914e3740ac59f933059d043cd0a3d7fe50");
			appContext.setRegionalBankId("881");
			appContext.setZipCode("74000");

			given().
					cookies(cookies).
					contentType(ContentType.JSON).
					body(appContext).
					when().
					post("/api/context").
					then().
					assertThat().statusCode(405);

			// Header CSRF
			Header csrfHeader = new Header("X-XSRF-TOKEN", cookies.get(Constants.XSRF_TOKEN_COOKIE).getValue());

			cookies = new Cookies();

			// Logout
			given().
					cookies(cookies).
					contentType(ContentType.URLENC).
					header(csrfHeader).
					body(SecurityControllerIT.getLogoutToken()).
					when().
					post("/api/security/backloggedout").
					then().
					assertThat().statusCode(200).
					and().extract().response();
		}

		@Test
		@DisplayName("Non authentifié")
		void testGetContextNotAuthenticated() {
			// Call api without cookie
			get("/api/context/1e98251d-b4c4-42ee-8f80-451f88d74aa1").then().assertThat().statusCode(401);

		}

		@Test
		@DisplayName("Violation de contrainte")
		void testSetContextConstraintViolation() {
			String redirectUrl = "http://localhost/authorize";

			// Premiére requéte pour avoir un session id
			Response response = get("/api/security/user").
					then().
					assertThat().statusCode(200).
					and().extract().response();

			// Récupération du state
			String state = response.getBody().as(UserDetails.class).getState();

			// Passage cookie é la prochaine requéte
			Cookies cookies = new Cookies(response.getDetailedCookie(Constants.SESSION_ID_COOKIE), response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));

			// Login
			response = given().
					cookies(cookies).
					queryParam(Constants.CODE_PARAM, TestConstants.AZ_CODE_GOOD).
					queryParam(Constants.REDIRECT_URI_PARAM, redirectUrl).
					queryParam(Constants.STATE, state).
					when().
					get("/api/security/login").
					then().
					assertThat().statusCode(200).
					and().extract().response();

			// Context
			cookies = new Cookies(cookies.get(Constants.SESSION_ID_COOKIE), response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE), response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));

			// Header CSRF
			Header csrfHeader = new Header("X-XSRF-TOKEN", response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).getValue());

			ApplicationContext appContext = new ApplicationContext();

			given().
					cookies(cookies).
					contentType(ContentType.JSON).
					header(csrfHeader).
					body(appContext).
					when().
					post("/api/context").
					then().
					assertThat().statusCode(400).
					body("violations.fieldName", hasItems("clientId", "regionalBankId", "zipCode"));

			cookies = new Cookies();

			// Logout
			given().
					cookies(cookies).
					contentType(ContentType.URLENC).
					header(csrfHeader).
					body(SecurityControllerIT.getLogoutToken()).
					when().
					post("/api/security/backloggedout").
					then().
					assertThat().statusCode(200).
					and().extract().response();
		}
	}
}