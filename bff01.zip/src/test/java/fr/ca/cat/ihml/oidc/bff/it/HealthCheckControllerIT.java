package fr.ca.cat.ihml.oidc.bff.it;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.is;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import fr.ca.cat.ihml.oidc.bff.it.configuration.RedisConfiguration;

@DisplayName("HealthCheckController")
@Tag("HealthCheck")
@Tag("Integration")	
class HealthCheckControllerIT extends AbstractControllerBaseIT {

	@Autowired
	RedisConfiguration redisConfiguration;
		
	@Test
	@DisplayName("Cas nominal")
	void testReady() {
		//--- TEST ---//
		given().port(8081)
		.get("/health/healthcheck").then()
		.and().assertThat().statusCode(200)
		.and().body("status", is("UP"));
	}
	
	@Test
	@DisplayName("KO")
	void testReadykO() {
		redisConfiguration.getRedisServer().stop();
		
		//--- TEST ---//
		given().port(8081)
		.get("/health/healthcheck").then()
		.and().assertThat().statusCode(503)
		.and().body("status", is("DOWN"));
		
		redisConfiguration.getRedisServer().start();
		
		//--- TEST ---//
		given().port(8081)
		.get("/health/healthcheck").then()
		.and().assertThat().statusCode(200)
		.and().body("status", is("UP"));
	}		
}
