package fr.ca.cat.ihml.oidc.bff.it;

import static io.restassured.RestAssured.get;
import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.is;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import fr.ca.cat.ihml.oidc.bff.models.logs.LogClientConfiguration;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogContext;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogMessage;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import io.restassured.http.ContentType;
import io.restassured.http.Cookies;
import io.restassured.http.Header;
import io.restassured.response.Response;

@DisplayName("LogsContoller")
@Tag("Logs")
@Tag("Integration")
class LogsContollerIT extends AbstractControllerBaseIT {
	
	@Nested
	@DisplayName("Config")	
	class withConfig {
		
		@Test
		@DisplayName("Cas nominal")	
		void testConfigLogs() {
	        // Premiére requéte pour avoir un session id
	        Response response = get("/api/security/user").
	                then().
	                    assertThat().statusCode(200).
	                    and().extract().response();	
			
			// Test default configuration
			LogClientConfiguration logClientConfiguration = get("/api/logs/configuration").then()
			.and().statusCode(200)
			.and().extract().as(LogClientConfiguration.class);
			
			// Logs
			assertThat(logClientConfiguration.getClientLoglevel(), is(5));
			assertThat(logClientConfiguration.getServerLogLovel(), is(5));
			assertThat(logClientConfiguration.isDisableConsoleLog(), is(true));
			
			logClientConfiguration = new LogClientConfiguration();
			logClientConfiguration.setClientLoglevel(2);
			logClientConfiguration.setServerLogLovel(3);
			logClientConfiguration.setDisableConsoleLog(false);
			
	        Cookies cookies = new Cookies(response.getDetailedCookie(Constants.SESSION_ID_COOKIE), response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));

	        // Header CSRF
	        Header csrfHeader = new Header("X-XSRF-TOKEN", cookies.get(Constants.XSRF_TOKEN_COOKIE).getValue());
			
			// Modification log
			given()
				.cookies(cookies)
				.header(csrfHeader)
				.body(logClientConfiguration)
				.contentType(ContentType.JSON).
			when()
				.post("/api/logs/configuration").then().assertThat().statusCode(200);
			
			// Logs
			LogClientConfiguration logClientConfigurationModified = get("/api/logs/configuration").then()
			.and().statusCode(200)
			.and().extract().as(LogClientConfiguration.class);
			
			// Test lecture log modifiée
			assertThat(logClientConfigurationModified.getClientLoglevel(), is(logClientConfiguration.getClientLoglevel()));
			assertThat(logClientConfigurationModified.getServerLogLovel(), is(logClientConfiguration.getServerLogLovel()));
			assertThat(logClientConfigurationModified.isDisableConsoleLog(), is(logClientConfiguration.isDisableConsoleLog()));
		}
		
		   
		@Test
		@DisplayName("Violation de contrainte")
		void testConfigConstraintViolation() {
	        // Premiére requéte pour avoir un session id
	        Response response = get("/api/security/user").
	                then().
	                    assertThat().statusCode(200).
	                    and().extract().response();	
		
			LogClientConfiguration logClientConfiguration = new LogClientConfiguration();
			logClientConfiguration.setClientLoglevel(8);
			logClientConfiguration.setServerLogLovel(-1);
			logClientConfiguration.setDisableConsoleLog(false);		       
		       
			Cookies cookies = new Cookies(response.getDetailedCookie(Constants.SESSION_ID_COOKIE), response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));
			
			// Header CSRF
			Header csrfHeader = new Header("X-XSRF-TOKEN", cookies.get(Constants.XSRF_TOKEN_COOKIE).getValue());
		    
			// Modification log
			given()
				.cookies(cookies)
				.header(csrfHeader)
				.body(logClientConfiguration)
				.contentType(ContentType.JSON).
			when()
				.post("/api/logs/configuration").then().assertThat().statusCode(400).
				body("violations.fieldName", hasItems("clientLoglevel", "serverLogLovel"));
		
		}
	}

	@Nested
	@DisplayName("Send log")	
	class WithSendLogs {
		
		@Test
		@DisplayName("Cas nominal")
		void testSendLogs() {
	        // Premiére requéte pour avoir un session id
	        Response response = get("/api/security/user").
	                then().
	                    assertThat().statusCode(200).
	                    and().extract().response();		
			
			// Create log config
			LogMessage logMessage = new LogMessage();
			logMessage.setFileName("Test.js");
			logMessage.setLevel(3);
			logMessage.setLineNumber("35");
			logMessage.setMessage("Erreur dans le code");
			logMessage.setTimeStamp(Instant.now().toString());
			
			LogContext logContext = new LogContext();
			logContext.setComponentId("FRONT ANGULAR");
			logContext.setComponentType("FRONT");
			logContext.setTerminal("TERMINAL");
			
			String additionalString = "{\"event_cod\":\"LOGS_FRONT\",\"event_typ\":\"LOGS\",\"usr_id\":\"\",\"uom_cod\":\"\",\"app_id\":\"STANDALONE\",\"component_id\":\"ANGULAR\",\"corr_id\":\"4d9da8e1-33dc-4221-bd5c-2ed4b1206400\",\"sess_id\":\"\",\"src_client_id\":\"IHML-S1247\",\"profil\":\"\",\"instance_name\":\"\",\"uri\":\"\",\"component_type\":\"FRONT\",\"terminal\":\"Chrome\",\"eds\":\"\",\"operational_post_id\":\"\",\"source\":\"TestPageComponent func onTestBasicLog\",\"stack_trace\":\"\",\"src_client\":\"IHML-S1247\"}";
			List<String> listAdditional = new ArrayList<>();
			listAdditional.add(additionalString);
			logMessage.setAdditional(listAdditional);
			
	        Cookies cookies = new Cookies(response.getDetailedCookie(Constants.SESSION_ID_COOKIE), response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));

	        // Header CSRF
	        Header csrfHeader = new Header("X-XSRF-TOKEN", response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).getValue());
			
			given()
				.cookies(cookies)
				.header(csrfHeader)
				.body(logMessage)
				.contentType(ContentType.JSON).
			when()
				.post("/api/logs/send").then().assertThat().statusCode(200);		
		}
		
		@Test
		@DisplayName("Violation de contrainte")
		void testSendLogsConstraintViolation() {
	        // Premiére requéte pour avoir un session id
	        Response response = get("/api/security/user").
	                then().
	                    assertThat().statusCode(200).
	                    and().extract().response();	
			
		    // Create log config
		    LogMessage logMessage = new LogMessage();
		    logMessage.setFileName("Test.js");
		    logMessage.setLevel(8);
		    logMessage.setLineNumber("35");
		    logMessage.setMessage("Erreur dans le code");
		    logMessage.setTimeStamp(Instant.now().toString());
		    
		    LogContext logContext = new LogContext();
		    logContext.setComponentId("FRONT ANGULAR");
		    logContext.setComponentType("FRONT");
		    logContext.setTerminal("TERMINAL");
		    
		    String additionalString = "{\"event_cod\":\"LOGS_FRONT\",\"event_typ\":\"LOGS\",\"usr_id\":\"\",\"uom_cod\":\"\",\"app_id\":\"STANDALONE\",\"component_id\":\"ANGULAR\",\"corr_id\":\"4d9da8e1-33dc-4221-bd5c-2ed4b1206400\",\"sess_id\":\"\",\"src_client_id\":\"IHML-S1247\",\"profil\":\"\",\"instance_name\":\"\",\"uri\":\"\",\"component_type\":\"FRONT\",\"terminal\":\"Chrome\",\"eds\":\"\",\"operational_post_id\":\"\",\"source\":\"TestPageComponent func onTestBasicLog\",\"stack_trace\":\"\",\"src_client\":\"IHML-S1247\"}";
		    List<String> listAdditional = new ArrayList<>();
		    listAdditional.add(additionalString);
		    logMessage.setAdditional(listAdditional);
		    
	        Cookies cookies = new Cookies(response.getDetailedCookie(Constants.SESSION_ID_COOKIE), response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));

	        // Header CSRF
	        Header csrfHeader = new Header("X-XSRF-TOKEN", cookies.get(Constants.XSRF_TOKEN_COOKIE).getValue());
		    
		    given()
				.cookies(cookies)
				.header(csrfHeader)
		    	.body(logMessage)
		    	.contentType(ContentType.JSON).
		    when()
		    	.post("/api/logs/send").then().assertThat().statusCode(400).
		    	body("violations.fieldName", hasItems("level"));
		}		
	}
}
