package fr.ca.cat.ihml.oidc.bff.it;

import static io.restassured.RestAssured.get;
import static org.hamcrest.Matchers.is;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@DisplayName("ManifestController")
@Tag("Manifest")
@Tag("Integration")
class ManifestContollerIT extends AbstractControllerBaseIT {

	@Test
	@DisplayName("Récupération de manifest")
	void testGetManifest() {
		//--- TEST ---//
		get("/api/manifest").then()
		.and().assertThat().statusCode(200)
		.body("version", is("test"))
		.body("framework", is("Java Spring Boot 3"));
	}

}
