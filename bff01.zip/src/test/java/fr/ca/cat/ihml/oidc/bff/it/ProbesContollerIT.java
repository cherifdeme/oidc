package fr.ca.cat.ihml.oidc.bff.it;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.is;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import fr.ca.cat.ihml.oidc.bff.it.configuration.RedisConfiguration;

@DisplayName("ProbesContoller")
@Tag("Probes")
@Tag("Integration")
class ProbesContollerIT extends AbstractControllerBaseIT {

	@Autowired
	RedisConfiguration redisConfiguration;
	
	@Nested
	@DisplayName("Alive")	
	class WithAlive {
		
		@Test
		@DisplayName("Cas nominal")
		void testAlive() {
			//--- TEST ---//
			given().port(8081)
			.get("/health/liveness").then()
			.and().assertThat().statusCode(200)
			.and().body("status", is("UP"));
		}		
	}
	
	@Nested
	@DisplayName("Ready")	
	class WithReady {
		
		@Test
		@DisplayName("Cas nominal")
		void testReady() {
			//--- TEST ---//
			given().port(8081)
			.get("/health/readiness").then()
			.and().assertThat().statusCode(200)
			.and().body("status", is("UP"));
		}	
	}
}
