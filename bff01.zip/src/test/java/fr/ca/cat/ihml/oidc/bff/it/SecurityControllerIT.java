package fr.ca.cat.ihml.oidc.bff.it;

import static io.restassured.RestAssured.get;
import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.hasItems;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.matchesRegex;
import static org.hamcrest.Matchers.not;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.UUID;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;

import fr.ca.cat.ihml.oidc.bff.models.security.user.UserDetails;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import fr.ca.cat.ihml.oidc.bff.utils.TestConstants;
import io.restassured.http.ContentType;
import io.restassured.http.Cookie;
import io.restassured.http.Cookies;
import io.restassured.http.Header;
import io.restassured.response.Response;

@DisplayName("SecurityController")
@Tag("Security")
@Tag("Integration")
class SecurityControllerIT extends AbstractControllerBaseIT {

	/**
	 * Injection de la propriété clientId de l'application
	 */
	@Value("${security.clientID}")
	protected String clientId;

	/**
	 * Injection de la propriété secretId de l'application
	 */
	@Value("${security.secretID}")
	protected String secretId;

	/**
	 * Injection de la propriété pour spécifié le path pour le cookie de
	 * session Spring
	 */
	@Value("${security.session.cookie.path}")
	private String path;

	private String domain = "localhost";

	/**
	 * Injection du SameSite du cookie
	 * Default Value Lax
	 */
	@Value("${security.session.cookie.samesite}")
	private String cookieSameSite;

	/**
	 * Injection de la variable pour la propriété du nom du cookie secret (SSO application mobile)
	 */
	@Value("${secret.cookie}")
	private String secretCookie;

	@Nested
	@DisplayName("Cinématique compléte")
	class WithFullCinematic {

		@Test
		@DisplayName("Login - User Connecter - Standalone logout")
		void testLoginAndGetUserConnectedAndStandAloneLogout() {
			String redirectUrl = "http://localhost/authorize";

			// Premiére requéte pour avoir un session id
			Response response = get("/api/security/user").then().
					and().assertThat().statusCode(200).
					and().assertThat().body("id", nullValue()).
					and().extract().response();

			// Récupération du state
			String state = response.getBody().as(UserDetails.class).getState();

			// Vérification cookie SESSION_ID
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getValue(), matchesRegex(".{1,}"));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getDomain(), is(domain));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getPath(), is(path));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getSameSite(), is(cookieSameSite));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).isHttpOnly(), is(true));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).isSecured(), is(true));

			// Passage cookie é la prochaine requéte
			Cookies cookies = new Cookies(response.getDetailedCookie(Constants.SESSION_ID_COOKIE), response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));

			// Login
			response = given().
					cookies(cookies).
					queryParam(Constants.CODE_PARAM, TestConstants.AZ_CODE_GOOD).
					queryParam(Constants.REDIRECT_URI_PARAM, redirectUrl).
					queryParam(Constants.STATE, state).
					when().
					get("/api/security/login").
					then().
					assertThat().statusCode(200).
					and().extract().response();

			// Vérification Cookie SESSION_REFRESH
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getValue(), matchesRegex("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getDomain(), is(domain));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getPath(), is(path));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getSameSite(), is(cookieSameSite));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).isHttpOnly(), is(true));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).isSecured(), is(true));

			// Vérification Cookie XSRF-TOKEN
			assertThat(response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).getValue(), matchesRegex("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"));
			assertThat(response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).getDomain(), is(domain));
			assertThat(response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).getPath(), is(path));
			assertThat(response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).getSameSite(), is(cookieSameSite));
			assertThat(response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).isHttpOnly(), is(false));
			assertThat(response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).isSecured(), is(true));

			// Get User
			cookies = new Cookies(cookies.get(Constants.SESSION_ID_COOKIE),response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE), response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));
			given().
					cookies(cookies).
					when().
					get("/api/security/user").
					then().
					assertThat().statusCode(200).
					and().assertThat().body("id", is("OX60001")).
					and().assertThat().body("state", is(state));

			// Header CSRF
			Header csrfHeader = new Header("X-XSRF-TOKEN", response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).getValue());

			// Logout
			response = given().
					cookies(cookies).
					contentType(ContentType.URLENC).
					header(csrfHeader).
					body(SecurityControllerIT.getLogoutToken()).
					when().
					post("/api/security/standalonelogout").
					then().
					assertThat().statusCode(200).
					and().extract().response();

			//assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getValue(), is(""));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getDomain(), is(domain));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getPath(), is(path));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getSameSite(), is(cookieSameSite));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).isHttpOnly(), is(true));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).isSecured(), is(true));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getMaxAge(), is(0L));

			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getValue(), is("deleted"));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getDomain(), is(domain));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getPath(), is(path));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getSameSite(), is(cookieSameSite));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).isHttpOnly(), is(true));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).isSecured(), is(true));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getMaxAge(), is(0L));

			Cookie sessionCookie = new Cookie.Builder(Constants.SESSION_ID_COOKIE, Base64.getEncoder().encodeToString(UUID.randomUUID().toString().getBytes())).build();
			cookies = new Cookies(sessionCookie);

			// User connected 200
			given().
					cookies(cookies).
					when().
					get("/api/security/user").
					then().
					assertThat().statusCode(200).
					and().assertThat().body("id", nullValue()).
					and().assertThat().body("state", not(nullValue()));
		}

		@Test
		@DisplayName("Login - User Connecter - Back channel logout")
		void testLoginAndGetUserConnectedAndBackChannelLogout() {
			String redirectUrl = "http://localhost/authorize";

			// Premiére requéte pour avoir un session id
			Response response = get("/api/security/user").then().
					and().assertThat().statusCode(200).
					and().assertThat().body("id", nullValue()).
					and().extract().response();

			// Récupération du state
			String state = response.getBody().as(UserDetails.class).getState();

			// SESSION_ID_COOKIE
			Cookie sessionIdCookie = response.getDetailedCookie(Constants.SESSION_ID_COOKIE);

			// Vérification cookie SESSION_ID
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getValue(), matchesRegex(".{1,}"));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getDomain(), is(domain));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getPath(), is(path));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getSameSite(), is(cookieSameSite));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).isHttpOnly(), is(true));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).isSecured(), is(true));

			// Passage cookie é la prochaine requéte
			Cookies cookies = new Cookies(sessionIdCookie, response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));

			// Login
			response = given().
					cookies(cookies).
					queryParam(Constants.CODE_PARAM, TestConstants.AZ_CODE_GOOD).
					queryParam(Constants.REDIRECT_URI_PARAM, redirectUrl).
					queryParam(Constants.STATE, state).
					when().
					get("/api/security/login").
					then().
					assertThat().statusCode(200).
					and().extract().response();

			// SESSION_REFRESH_COOKIE
			Cookie refreshCookie = response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE);

			// Vérification Cookie SESSION_REFRESH
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getValue(), matchesRegex("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getDomain(), is(domain));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getPath(), is(path));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getSameSite(), is(cookieSameSite));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).isHttpOnly(), is(true));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).isSecured(), is(true));

			// Vérification Cookie XSRF-TOKEN
			assertThat(response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).getValue(), matchesRegex("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"));
			assertThat(response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).getDomain(), is(domain));
			assertThat(response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).getPath(), is(path));
			assertThat(response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).getSameSite(), is(cookieSameSite));
			assertThat(response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).isHttpOnly(), is(false));
			assertThat(response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).isSecured(), is(true));

			// Get User
			cookies = new Cookies(sessionIdCookie, refreshCookie, response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));
			given().
					cookies(cookies).
					when().
					get("/api/security/user").
					then().
					assertThat().statusCode(200).
					and().assertThat().body("id", is("OX60001")).
					and().assertThat().body("state", is(state));

			// Header CSRF
			Header csrfHeader = new Header("X-XSRF-TOKEN", response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).getValue());

			cookies = new Cookies();

			// Logout
			given().
					cookies(cookies).
					contentType(ContentType.URLENC).
					header(csrfHeader).
					body(SecurityControllerIT.getLogoutToken()).
					when().
					post("/api/security/backloggedout").
					then().
					assertThat().statusCode(200).
					and().extract().response();

			cookies = new Cookies(sessionIdCookie, refreshCookie, response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));

			// User connected 200
			response = given().
					cookies(cookies).
					when().
					get("/api/security/user").
					then().
					assertThat().statusCode(200).
					and().assertThat().body("id", nullValue()).
					and().assertThat().body("state", not(nullValue())).
					and().extract().response();

			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getValue(), is("deleted"));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getDomain(), is(domain));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getPath(), is(path));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getSameSite(), is(cookieSameSite));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).isHttpOnly(), is(true));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).isSecured(), is(true));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getMaxAge(), is(0L));
		}

		@Test
		@DisplayName("Login New ma banque - User Connecter - backChannel logout")
		void testLoginNmbAndGetUserConnectedAndLogout() throws UnsupportedEncodingException {
			String redirectUrl = "http://localhost/authorize";

			// Premiére requéte pour avoir un session id
			Response response = get("/api/security/user").then().
					and().assertThat().statusCode(200).
					and().assertThat().body("id", nullValue()).
					and().extract().response();

			// Récupération du state
			String state = response.getBody().as(UserDetails.class).getState();

			// SESSION_ID_COOKIE
			Cookie sessionIdCookie = response.getDetailedCookie(Constants.SESSION_ID_COOKIE);

			// Vérification cookie SESSION_ID
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getValue(), matchesRegex(".{1,}"));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getDomain(), is(domain));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getPath(), is(path));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getSameSite(), is(cookieSameSite));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).isHttpOnly(), is(true));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).isSecured(), is(true));

			// Passage cookie é la prochaine requéte "
			String cookieNmbValue = new String(Base64.getDecoder().decode(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getValue()), StandardCharsets.UTF_8);
			Cookie nmbCookie = new Cookie.Builder("secret", cookieNmbValue).build();
			Cookies cookies = new Cookies(sessionIdCookie, response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE), nmbCookie);

			// Login
			response = given().
					cookies(cookies).
					queryParam(Constants.CODE_PARAM, TestConstants.AZ_CODE_GOOD).
					queryParam(Constants.REDIRECT_URI_PARAM, redirectUrl).
					queryParam(Constants.STATE, state).
					when().
					get("/api/security/login").
					then().
					assertThat().statusCode(200).
					and().extract().response();

			// SESSION_REFRESH_COOKIE
			Cookie refreshCookie = response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE);

			// Vérification Cookie SESSION_REFRESH
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getValue(), matchesRegex("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getDomain(), is(domain));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getPath(), is(path));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getSameSite(), is(cookieSameSite));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).isHttpOnly(), is(true));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).isSecured(), is(true));

			// Vérification Cookie XSRF-TOKEN
			assertThat(response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).getValue(), matchesRegex("[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}"));
			assertThat(response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).getDomain(), is(domain));
			assertThat(response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).getPath(), is(path));
			assertThat(response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).getSameSite(), is(cookieSameSite));
			assertThat(response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).isHttpOnly(), is(false));
			assertThat(response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).isSecured(), is(true));

			// Vérification Cookie secret
			assertThat(response.getDetailedCookie(secretCookie).getValue(), is("deleted"));

			// Get User
			cookies = new Cookies(sessionIdCookie, response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE), response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));
			given().
					cookies(cookies).
					when().
					get("/api/security/user").
					then().
					assertThat().statusCode(200).
					and().assertThat().body("id", is("OX60001")).
					and().assertThat().body("state", is(state));

			// Header CSRF
			Header csrfHeader = new Header("X-XSRF-TOKEN", response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE).getValue());

			cookies = new Cookies();

			// Logout
			given().
					cookies(cookies).
					contentType(ContentType.URLENC).
					header(csrfHeader).
					body(SecurityControllerIT.getLogoutToken()).
					when().
					post("/api/security/backloggedout").
					then().
					assertThat().statusCode(200).
					and().extract().response();

			cookies = new Cookies(sessionIdCookie, refreshCookie, response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));

			// User connected 200
			response = given().
					cookies(cookies).
					when().
					get("/api/security/user").
					then().
					assertThat().statusCode(200).
					and().assertThat().body("id", nullValue()).
					and().assertThat().body("state", not(nullValue())).
					and().extract().response();

			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getValue(), is("deleted"));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getDomain(), is(domain));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getPath(), is(path));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getSameSite(), is(cookieSameSite));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).isHttpOnly(), is(true));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).isSecured(), is(true));
			assertThat(response.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE).getMaxAge(), is(0L));
		}
	}

	@Nested
	@DisplayName("Login Erreur")
	class WithLoginError {

		@Test
		@DisplayName("Mauvais AZ Code")
		void testLoginBadAzCode() {
			String redirectUrl = "http://localhost/authorize";
			// Premiére requéte pour avoir un session id
			Response response = get("/api/security/user").then().
					and().assertThat().statusCode(200).
					and().assertThat().body("id", nullValue()).
					and().extract().response();

			// Get state
			String state = response.getBody().as(UserDetails.class).getState();

			// Vérification cookie SESSION_ID
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getValue(), matchesRegex(".{1,}"));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getDomain(), is(domain));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getPath(), is(path));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getSameSite(), is(cookieSameSite));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).isHttpOnly(), is(true));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).isSecured(), is(true));

			// Extract Cookie SESSION_ID
			Cookies cookies = new Cookies(response.getDetailedCookie(Constants.SESSION_ID_COOKIE), response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));

			// Login
			response = given().
					cookies(cookies).
					queryParam(Constants.CODE_PARAM, TestConstants.AZ_CODE_BAD).
					queryParam(Constants.REDIRECT_URI_PARAM, redirectUrl).
					queryParam(Constants.STATE, state).
					when().
					get("/api/security/login").
					then().
					assertThat().statusCode(400).
					and().extract().response();

			assertThat(response.getCookie(Constants.SESSION_REFRESH_COOKIE), is(nullValue()));
		}

		@Test
		@DisplayName("Mauvais state")
		void testLoginBadState() {
			String redirectUrl = "http://localhost/authorize";
			// Premiére requéte pour avoir un session id
			Response response = get("/api/security/user").then().
					and().assertThat().statusCode(200).
					and().assertThat().body("id", nullValue()).
					and().extract().response();

			// Vérification cookie SESSION_ID
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getValue(), matchesRegex(".{1,}"));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getDomain(), is(domain));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getPath(), is(path));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getSameSite(), is(cookieSameSite));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).isHttpOnly(), is(true));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).isSecured(), is(true));

			// Extract Cookie SESSION_ID
			Cookies cookies = new Cookies(response.getDetailedCookie(Constants.SESSION_ID_COOKIE), response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));

			// Login
			given().
					cookies(cookies).
					queryParam(Constants.CODE_PARAM, TestConstants.AZ_CODE_BAD).
					queryParam(Constants.REDIRECT_URI_PARAM, redirectUrl).
					queryParam(Constants.STATE, UUID.randomUUID().toString()).
					when().
					get("/api/security/login").
					then().
					assertThat().statusCode(401).
					and().extract().response();
		}

		@Test
		@DisplayName("Violation de contrainte")
		void testLoginConstraintViolations() {
			String redirectUrl = "url";
			// Premiére requéte pour avoir un session id
			Response response = get("/api/security/user").then().
					and().assertThat().statusCode(200).
					and().assertThat().body("id", nullValue()).
					and().extract().response();

			// Vérification cookie SESSION_ID
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getValue(), matchesRegex(".{1,}"));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getDomain(), is(domain));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getPath(), is(path));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getSameSite(), is(cookieSameSite));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).isHttpOnly(), is(true));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).isSecured(), is(true));

			// Extract Cookie SESSION_ID
			Cookies cookies = new Cookies(response.getDetailedCookie(Constants.SESSION_ID_COOKIE), response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));

			// Login
			given().
					cookies(cookies).
					queryParam(Constants.CODE_PARAM, "").
					queryParam(Constants.REDIRECT_URI_PARAM, redirectUrl).
					queryParam(Constants.STATE, "").
					when().
					get("/api/security/login").
					then().
					assertThat().statusCode(400).
					body("violations.fieldName", hasItems("login.code", "login.redirectUri", "login.state"));

		}


		@Test
		@DisplayName("New ma banque KO")
		void testLoginNmbKo() {
			String redirectUrl = "http://localhost/authorize";
			// Premiére requéte pour avoir un session id
			Response response = get("/api/security/user").then().
					and().assertThat().statusCode(200).
					and().assertThat().body("id", nullValue()).
					and().extract().response();

			// Vérification cookie SESSION_ID
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getValue(), matchesRegex(".{1,}"));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getDomain(), is(domain));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getPath(), is(path));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).getSameSite(), is(cookieSameSite));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).isHttpOnly(), is(true));
			assertThat(response.getDetailedCookie(Constants.SESSION_ID_COOKIE).isSecured(), is(true));

			// Extract Cookie SESSION_ID
			Cookie nmbCookie = new Cookie.Builder("secret", "BadValue").build();
			Cookies cookies = new Cookies(response.getDetailedCookie(Constants.SESSION_ID_COOKIE), response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE), nmbCookie);

			// Login
			given().
					cookies(cookies).
					queryParam(Constants.CODE_PARAM, TestConstants.AZ_CODE_GOOD).
					queryParam(Constants.REDIRECT_URI_PARAM, redirectUrl).
					queryParam(Constants.STATE, UUID.randomUUID().toString()).
					when().
					get("/api/security/login").
					then().
					assertThat().statusCode(401);

		}
	}

	static String getLogoutToken() {
		return "logout_token=eyJraWQiOiJjYXRzLWlobWwtZGVtbyIsImFsZyI6IlJTMjU2In0.eyJpc3MiOiJodHRwOi8vbG9jYWxob3N0OjgwODkvYXV0aGVudGlmaWNhdGlvbl9jb2xsYWJvcmF0ZXVyL3YyIiwianRpIjoiYVpoaHdhODZlWkYwTU56RXZMcUlvQSIsInN1YiI6Ik9YNjAwMDEiLCJzaWQiOiIyNTIzOGNlZC0wNzI1LTRkMjAtYmJmZC1kMDU1OWViMWY4NGEiLCJldmVudHMiOnsiaHR0cDovL3NjaGVtYXMub3BlbmlkLm5ldC9ldmVudC9iYWNrY2hhbm5lbC1sb2dvdXQiOltdfX0.V35p8FW-XdYq6NbIuUihiQLxANe4NH-u07H637kDom9j23a8jHhEoRzwNYB1IAgvVDdBqeGfMqXg5e_DE98VFro0tccZNJQRLquoWzXnMmiZ2-048aPrK3OU81u_yauQegVppqhbZAV6wO5b2DH4WO9wrvKPoZ-LjPx3Nwavhf9ZjVSZm_XVG7xknkmzxpu1T9M-LeFyr6bYobXJ1421ejBAiJEnGwEOyixOw38A-NPJ1R-_IMclQ5cbcXUUW2gg_3AzbyH0zr5iR6DbhyCbHxGQnfVYRxK5i4000_yvVXbTC35HbcFpfbeVuiNf1GvxxMsNCStnBuR5-wFQ35Cg_A";
	}
}