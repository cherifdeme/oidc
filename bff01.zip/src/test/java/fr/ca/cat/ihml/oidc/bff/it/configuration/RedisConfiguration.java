package fr.ca.cat.ihml.oidc.bff.it.configuration;



import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.TestConfiguration;

import redis.embedded.RedisServer;

@TestConfiguration
public class RedisConfiguration {
    private RedisServer redisServer;
 
	public RedisConfiguration(@Value("${spring.data.redis.port}") final int redisPort) {

        this.redisServer = new RedisServer(redisPort);
    }

    @PostConstruct
    public void postConstruct() {
        redisServer.start();
    }

    @PreDestroy
    public void preDestroy() {
        redisServer.stop();
    }

    public RedisServer getRedisServer() {
		return redisServer;
	}
}
