package fr.ca.cat.ihml.oidc.bff.it.configuration;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;

import org.springframework.boot.test.context.TestConfiguration;

import com.github.tomakehurst.wiremock.WireMockServer;

@TestConfiguration
public class WireMockConfiguration {
    private WireMockServer wireMockServer;

    public WireMockConfiguration() {
    	this.wireMockServer = new WireMockServer(8089);
    }

    @PostConstruct
    public void postConstruct() {
    	this.wireMockServer.start();
    }

    @PreDestroy
    public void preDestroy() {
    	this.wireMockServer.stop();
    }
}
