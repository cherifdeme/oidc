package fr.ca.cat.ihml.oidc.bff.it.jwt;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import fr.ca.cat.ihml.oidc.bff.it.AbstractControllerBaseIT;
import fr.ca.cat.ihml.oidc.bff.models.http.Message;

import io.restassured.http.ContentType;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;

class MessageEncryptionControllerIT extends AbstractControllerBaseIT {

    @Test
    @DisplayName("integration - chiffrage d'un message")
    void testEncrypt() throws JsonProcessingException {

        final var jsonMessage = "{\"message\":\"pasdebraspasdechocolat\"}";
        final var mapper = new ObjectMapper();
        final var json = mapper.readValue(jsonMessage, Message.class);

        final var response = given()
                .contentType(ContentType.JSON)
                .body(json)
                .when()
                .post("/api/encrypt/message")
                .then()
                .assertThat().statusCode(200)
                .and().extract().response();

        assertThat(((String)response.getBody().as(Message.class).getMessage()).split("\\.").length, Matchers.equalToObject(5));
    }
}
