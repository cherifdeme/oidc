package fr.ca.cat.ihml.oidc.bff.it.jwt;

import fr.ca.cat.ihml.oidc.bff.it.AbstractControllerBaseIT;
import io.restassured.response.Response;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Value;

import java.io.IOException;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;

class PublicKeyExposureControllerIT extends AbstractControllerBaseIT {
    @Value("${public.key.path}")
    private String publicKeyPath;

    @Test
    @DisplayName("integration - telechargement de la clé publique")
    void testDownload() throws IOException {

        final var inputStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(publicKeyPath);
        final var data = inputStream.readAllBytes();

        final var response = given()
                .when()
                .get("/api/public/cert")
                .then()
                .assertThat().statusCode(200)
                .and().extract().response();

        assertThat(response.getBody().asByteArray(), Matchers.equalTo(data));
    }
}