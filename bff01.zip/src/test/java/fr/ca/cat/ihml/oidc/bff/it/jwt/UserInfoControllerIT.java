package fr.ca.cat.ihml.oidc.bff.it.jwt;

import fr.ca.cat.ihml.oidc.bff.it.AbstractControllerBaseIT;
import fr.ca.cat.ihml.oidc.bff.models.security.user.UserDetails;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import fr.ca.cat.ihml.oidc.bff.utils.TestConstants;
import io.restassured.http.Cookies;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.get;
import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.nullValue;

class UserInfoControllerIT extends AbstractControllerBaseIT {

    @Test
    @DisplayName("integration - recuperation des données du user")
    void testGetUserInfos() throws Exception {
        final Map<String, String> body = new HashMap<>();

        body.put("request_version", "3");
        body.put("correlation_id", "test");
        body.put("ihm_launch_params", "eyJ4NWMiOlsiTUlJRlVEQ0NCRGlnQXdJQkFnSU5BTGtORVhJREFobTFVTFwvelN6QU5CZ2txaGtpRzl3MEJBUXNGQURDQmhqRUxNQWtHQTFVRUJoTUNSbEl4SGpBY0JnTlZCQW9NRlVOeVpXUnBkQ0JCWjNKcFkyOXNaU0JIY205MWNERWFNQmdHQTFVRUN3d1JVSEpwZG1GMFpTQkhjbTkxY0NCUVMwa3hGekFWQmdOVkJBc01EakF3TURJZ056ZzBOakE0TkRFMk1TSXdJQVlEVlFRRERCbERRU0JEY21Wa2FYUWdRV2R5YVdOdmJHVWdVMlZ5ZG1WeU1CNFhEVEl4TVRFeE56RXdOVGd6TjFvWERUSTFNVEV4TmpFd05Ua3pOMW93Z1lveEN6QUpCZ05WQkFZVEFrWlNNUjR3SEFZRFZRUUtEQlZEY21Wa2FYUWdRV2R5YVdOdmJHVWdSM0p2ZFhBeEdqQVlCZ05WQkFzTUVWQnlhWFpoZEdVZ1IzSnZkWEFnVUV0Sk1RMHdDd1lEVlFRTERBUkRRVlJUTVJjd0ZRWURWUVFMREE1SlF6QTBMVWxJVFVVdFZFVlRWREVYTUJVR0ExVUVBd3dPU1VNd05DMUpTRTFGTFZSRlUxUXdnZ0VpTUEwR0NTcUdTSWIzRFFFQkFRVUFBNElCRHdBd2dnRUtBb0lCQVFDOFU3M2cxOEU4ejJHNzdiU2lSWUJkaWhUXC81eGxRcU9MenFYQTR5NW1ZY3NQQzFlclRPc1hqcldRXC8wVCtoSkVTNFo3c3c4TVJXM1QwditXcUROSmxwU0VQRE5SSEJmalZLM25DMTFzbWJKU0pTaFRaYzJnYlJTVFpFMDNGZnFaMXJUMytIXC9nS2owbzQ5WWEwU2hFdXRiTEpIUzhOY3VyTUt6aVAwRVwvVzZrSkwzcGsyZDJHejNJcHdLclZxVkRZbmdlSnNTQnR6a3pqODk4dTRYbkhqNDVXSnBYcmxZaGk4Rk5GQnBCaFVqMm9QUFRUSjJ5VVhWUUNNc1pyWjd0S1ozendPYU5odzAweU00dnBnMFVTbjVMMHAzN0VcL2t0NVp3STF3bitWOEhZUFZ6SlwvVytxeVZqZlA4YUtIWnhQTXZOUjY5T3NIZXJubEN3dUZWMFBYVkRBZ01CQUFHamdnRzFNSUlCc1RBZEJnTlZIUTRFRmdRVTNaYXh1MG04dloxMWhKMWZsZ0VBdm1PVDRUY3dId1lEVlIwakJCZ3dGb0FVbFBsNmE4dFBsMk5oZ1FVamFzZ1pMNzRMZWV3d0Z3WURWUjBnQkJBd0RqQU1CZ29xZ1hvQmdqd0JBUVlCTUNBR0ExVWRKUUVCXC93UVdNQlFHQ0NzR0FRVUZCd01DQmdnckJnRUZCUWNEQVRBT0JnTlZIUThCQWY4RUJBTUNCYUF3R1FZRFZSMFJCQkl3RUlJT2FXTXdOQzFwYUcxbExYUmxjM1F3VmdZRFZSMGZCRTh3VFRCTG9FbWdSNFpGYUhSMGNEb3ZMMk55YkMxd2NtbDJMWEJyYVM1amNtVmthWFF0WVdkeWFXTnZiR1V1Wm5JdlkzSnNMME5CUTNKbFpHbDBRV2R5YVdOdmJHVlRaWEoyWlhJdVkzSnNNSUd3QmdnckJnRUZCUWNCQVFTQm96Q0JvREJkQmdnckJnRUZCUWN3QW9aUmFIUjBjRG92TDJOaGFYTnpkV1Z5Y3kxd2NtbDJMWEJyYVM1amNtVmthWFF0WVdkeWFXTnZiR1V1Wm5JdlkyRnBjM04xWlhKekwwTkJRM0psWkdsMFFXZHlhV052YkdWVFpYSjJaWEl1Y0Rkak1EOEdDQ3NHQVFVRkJ6QUJoak5vZEhSd09pOHZiMk56Y0Mxd2NtbDJMWEJyYVM1amNtVmthWFF0WVdkeWFXTnZiR1V1Wm5JdmIyTnpjQzl6WlhKMlpYSXdEUVlKS29aSWh2Y05BUUVMQlFBRGdnRUJBRUFHXC8rUWc2dXpkcUt2XC8zV0pHb2R0TUZzNHc1bW43UElIQXJ2SDNEeWI3cFwvR1wva0lLRGtVS2lncnowYjFvUURteDJTMFo3QmNKK1JjM1pLUm1sWlVtNHZ5VXVlUUdqeTRlNDRvMml2MWtJN3FrQWV5aGRoXC9KeU9FTGcrbWZoekhPUmoyNzlhbzJONFhGRzFBbnJmWkg4dmY5NnRsclhaTUh1TFpNTVZOQ1JqdWJKOG9Sb3dqK0R1ME5rbHdoOGdjVUIzeStFN0VrTGNOc1p5MHIyXC9rMXJxM0dINDdYQ3dQVFBsMWppcUR5S3Fkb2orNnltbThmUE5jakppMDUzUFJ6dFNOeTFnQjhhVld1RWg5enRRXC9EUjFMVStNb1F3Z3ZHOVJRXC85cWtZaWR0ZFwvcTZFb2ZCdEIxb1JTOW1GNVArS2QwSkE1V1JRR3FyeFd4UGNSSTdjPSJdLCJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJodHRwczovL2NvbGxhYi5jYS1kZXZ0dS16cWRhMC5jcmVkaXQtYWdyaWNvbGUuZnIvUzEyMzUtVUEwMi91YV9paG1mX29pZGNfZGVtby8xLjAvcmVzdC91YV9paG1mX29pZGNfZGVtby9vaWRjIiwic3ViIjoiT1g2MDAwMSIsImlhdCI6MTY2MjQ0OTIwNCwiZXhwIjoxNjYyNDYzNjA0LCJhdWQiOlsiZmFuZm91ZSIsIms4cyIsImNoZXJpZiJdLCJqdGkiOiJmNWFkOTljOC0wNzk2LTRmYjQtYmMyNi03M2I2YTBlMDY5MzAiLCJsYXVuY2hfY29udGV4dCI6eyJ0YXJnZXRfZnVuY3Rpb24iOiJkZW1vX29pZGMiLCJ0YXJnZXRfb3JpZ2luIjoiaHR0cHM6Ly9jb2xsYWIuY2EtZGV2dHUtenFkYTAuY3JlZGl0LWFncmljb2xlLmZyIiwic291cmNlX2FwcF9uYW1lIjoidWFfaWhtZl9kZW1vX29pZGMiLCJzb3VyY2VfYXBwX3JldHVybl91cmkiOm51bGwsInVzZXJfZW50aXRsZW1lbnRzIjpbeyJ1b21fY29kZSI6Ijg3ODAwIiwidXNlcl9wcm9maWxlIjoiZ3JlYyIsImFkZGl0aW9uYWxfZWxlbWVudCI6W3sibmFtZSI6ImRlbW8iLCJ2YWx1ZSI6ImZhbmZvdWVXYXNIZXJlIn1dfV19LCJwYXJhbWV0ZXJzIjp7InBhcnRlbmFpcmUiOnsiaWRwYXJ0IjoibW9jayBpZHBhcnQgZnJvbSBwdWMgNCBvaWRjIn0sImNvbnRyYXQiOnsiaWRjdHJhIjoibW9jayBpZGN0cmEgZnJvbSBwdWMgNCBvaWRjIn19fQ.bmBZClYiMRuz2KpzJRiyhx3b9qK8c4pJhdX7SZrd4B1IGtKrjmECn2Ijg0X_lV41E4JG8eVCkMz-eP0crlyP8oDHSsTb7xf3wSkdi-WDqTkALwBEnuru6KnKXBHwx0ZlH08pZ0vzHH-6MGWOzGz0isWpshPL1_6bUW5YgmPSl_XF27Ygi5z9fRZcG8uP8XIIFGASsKIbDwA9Jy9eIUSgZY85eWdv2U_oocQuu-8jFd01-Vso8J9piygoV17g1YQCMUTAE-mAvlTrT2WwQlhz_kNw--crcLy7nbyqhYGGRiUKW2y3-r7w7b14cCgUVFfTdFZBQjqYkZjMX1PdX119gg");
        body.put("user_idp_hint", "test");
        body.put("context_initial", "test");

        final var redirectUrl = "http://localhost/authorize";

        // Premiére requéte pour avoir un session id
        var response = get("/api/security/user").then()
                .and().assertThat().statusCode(200)
                .and().assertThat().body("id", nullValue())
                .and().assertThat().body("fpLabel", nullValue())
                .and().extract().response();

        // Récupération du state
        final var state = response.getBody().as(UserDetails.class).getState();

        // Passage cookie é la prochaine requéte
        final var cookies = new Cookies(response.getDetailedCookie(Constants.SESSION_ID_COOKIE), response.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));

        // Login
        final var loginResponse = given().
                cookies(cookies)
                .queryParam(Constants.CODE_PARAM, TestConstants.AZ_CODE_GOOD)
                .queryParam(Constants.REDIRECT_URI_PARAM, redirectUrl)
                .queryParam(Constants.STATE, state)
                .when()
                .get("/api/security/login")
                .then()
                .assertThat().statusCode(200)
                .and().extract().response();

        // Get User
        final var loginCookies = new Cookies(cookies.get(Constants.SESSION_ID_COOKIE), loginResponse.getDetailedCookie(Constants.SESSION_REFRESH_COOKIE), loginResponse.getDetailedCookie(Constants.XSRF_TOKEN_COOKIE));

        given()
                .cookies(loginCookies)
                .contentType(io.restassured.http.ContentType.URLENC)
                .formParams(body)
                .when()
                .post("/api/launcher/entrypoint")
                .then()
                .assertThat().statusCode(302);

        given()
                .cookies(loginCookies)
                .get("/api/control/token")
                .then()
                .assertThat().statusCode(200);

        final var result = given()
                .cookies(loginCookies)
                .queryParam(Constants.CODE_PARAM, TestConstants.AZ_CODE_GOOD)
                .queryParam(Constants.REDIRECT_URI_PARAM, redirectUrl)
                .queryParam(Constants.STATE, state)
                .contentType("application/json")
                .get("/api/infos/users")
                .then()
                .assertThat().statusCode(200)
                .and().extract().response();
    }
}