package fr.ca.cat.ihml.oidc.bff.jwt;

import fr.ca.cat.ihml.oidc.bff.cache.RedisCacheService;
import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.jwt.controllers.MessageEncryptionController;
import fr.ca.cat.ihml.oidc.bff.jwt.services.messages.EncryptionMessageService;
import fr.ca.cat.ihml.oidc.bff.models.http.Message;
import jakarta.servlet.http.HttpServletRequest;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;

import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.net.URISyntaxException;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.when;

@DisplayName("MessageEncryptionController")
@Tag("Controller")
@Tag("Unit")
@ExtendWith(MockitoExtension.class)
class MessageEncryptionControllerTest {
    EncryptionMessageService encryptionMessageService;
    @Mock
    HttpServletRequest request;
    @Mock
    RedisCacheService redisCacheService;

    @BeforeEach
    void setup() throws URISyntaxException, ApiException {
        encryptionMessageService = new EncryptionMessageService();
        encryptionMessageService.setPublicKeyUrl("https://d1-s0550-rten.hpr.caas.ca-ts.group.gca/S1235-UA02/ihmf_appl_mock/certs/ic04-ihme-test.2025.cer");
        encryptionMessageService.getPublicKey();
        encryptionMessageService.setAlias("ic04-ihme-oidc-demo");
        encryptionMessageService.setPwd("0f2eb5a0899f874ced4e1a174a50b157");
        encryptionMessageService.setPrivateKeyFile("ic04-ihme-oidc-demo.p12");
        encryptionMessageService.laodPrivateKey();
    }

    @Test
    @DisplayName("chiffrement du message")
    void testEncrypt() throws ApiException {

        when(request.getRequestURL()).thenReturn(new StringBuffer("https://localhost:8080/api/encrypt/message"));
        when(redisCacheService.getSub()).thenReturn("OX60001");
        final var controller = new MessageEncryptionController(encryptionMessageService, redisCacheService);
        final var message = new Message("La douceur du miel ne console pas de la piqûre de l'abeille");
        final var encrypted = controller.encrypt(message, request);
        assertThat(((String) encrypted.getBody().getMessage()).split("\\.").length, Matchers.equalToObject(5));
    }
}
