package fr.ca.cat.ihml.oidc.bff.security;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.matchesPattern;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.UUID;

import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;

@DisplayName("CsrfFilter")
@Tag("Security")
@Tag("Unit")
@ExtendWith(MockitoExtension.class)
class CsrfFilterTest {

    private CsrfFilter csrfFilter;
    
    @Mock
    private FilterConfig filterConfig;	
    
    @Mock
    private HttpServletRequest request;
    
    @Mock
    private HttpServletResponse response;
	
    @Mock
    private PrintWriter writer;
    
    @Mock
    private FilterChain filterChain;   
    
    @BeforeEach
	void setUp() {
		csrfFilter = new CsrfFilter("/path", "None", "/security/**");
	}
	
	@Test
	@DisplayName("CSRF URL OK")
	void testIsUrlCsrfRequiredTrue() throws ServletException {
		// --- CONFIG --- //
		when(request.getServletPath()).thenReturn("/places");
		
		
		// --- ACTION -- //
		boolean matchPattern = csrfFilter.isUrlCsrfRequired(request);
		
		// --- TEST -- //
		
		// Value
		assertThat(matchPattern, is(true));
	}
	
	@Test
	@DisplayName("CSRF URL OK")
	void testIsUrlCsrfRequiredFalse() throws ServletException {
		// --- CONFIG --- //
		when(request.getServletPath()).thenReturn("/security/user");
		
		
		// --- ACTION -- //
		boolean matchPattern = csrfFilter.isUrlCsrfRequired(request);
		
		// --- TEST -- //
		
		// Value
		assertThat(matchPattern, is(false));
	}

	@Test
	@DisplayName("Cas nominal")
	void testDoFilterCsrfOK() throws ServletException, IOException {
		// --- CONFIG --- //
		when(request.getServletPath()).thenReturn("/places");
		String csrfToken = UUID.randomUUID().toString();
		Cookie csrfCookie = new Cookie("XSRF-TOKEN", csrfToken);
		when(request.getHeader("X-XSRF-TOKEN")).thenReturn(csrfToken);
		when(request.getCookies()).thenReturn(new Cookie[]{csrfCookie});	
		when(request.getMethod()).thenReturn(HttpMethod.POST.toString());
		when(request.getServerName()).thenReturn("cookieDomain");
		
		ArgumentCaptor<String> responseCookieString = ArgumentCaptor.forClass(String.class);
		doNothing().when(response).setHeader(eq("Set-Cookie"), responseCookieString.capture());
		
		// --- ACTION -- //
		csrfFilter.doFilter(request, response, filterChain);
		
		// --- TEST -- //
		
		// Value
		// Mock
		assertThat(responseCookieString.getValue(), matchesPattern("XSRF-TOKEN=[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}; domain=cookieDomain; path=\\/path; Secure; SameSite=None"));
		verify(response).setHeader("Set-Cookie", responseCookieString.getValue());
		verify(filterChain).doFilter(request, response);
		verify(request).getServerName();
	}
	
	@Test
	@DisplayName("Cas POST Ko")
	void testDoFilterCsrfKOPOST() throws ServletException, IOException {
		// --- CONFIG --- //
		when(request.getServletPath()).thenReturn("/places");
		String csrfToken = UUID.randomUUID().toString();
		Cookie csrfCookie = new Cookie("XSRF-TOKEN", UUID.randomUUID().toString());
		when(request.getHeader("X-XSRF-TOKEN")).thenReturn(csrfToken);
		when(request.getCookies()).thenReturn(new Cookie[]{csrfCookie});	
		when(request.getMethod()).thenReturn(HttpMethod.POST.toString());
		
		// --- ACTION -- //
		csrfFilter.doFilter(request, response, filterChain);
		
		// --- TEST -- //
		
		// Value
		// Mock
		verify(response, times(0)).setHeader(eq("Set-Cookie"), any(String.class));
		verify(filterChain, times(0)).doFilter(request, response);
		verify(response).sendError(HttpStatus.FORBIDDEN.value(), HttpStatus.FORBIDDEN.getReasonPhrase());
	}
	
	@Test
	@DisplayName("Cas DELETE Ko")
	void testDoFilterCsrfKODELETE() throws ServletException, IOException {
		// --- CONFIG --- //
		when(request.getServletPath()).thenReturn("/places");
		String csrfToken = UUID.randomUUID().toString();
		Cookie csrfCookie = new Cookie("XSRF-TOKEN", UUID.randomUUID().toString());
		when(request.getHeader("X-XSRF-TOKEN")).thenReturn(csrfToken);
		when(request.getCookies()).thenReturn(new Cookie[]{csrfCookie});	
		when(request.getMethod()).thenReturn(HttpMethod.DELETE.toString());
		
		// --- ACTION -- //
		csrfFilter.doFilter(request, response, filterChain);
		
		// --- TEST -- //
		
		// Value
		// Mock
		verify(response, times(0)).setHeader(eq("Set-Cookie"), any(String.class));
		verify(filterChain, times(0)).doFilter(request, response);
		verify(response).sendError(HttpStatus.FORBIDDEN.value(), HttpStatus.FORBIDDEN.getReasonPhrase());
	}
	
	@Test
	@DisplayName("Cas no Cookie Ko")
	void testDoFilterCsrfKONoCookie() throws ServletException, IOException {
		// --- CONFIG --- //
		when(request.getServletPath()).thenReturn("/places");
		String csrfToken = UUID.randomUUID().toString();
		when(request.getHeader("X-XSRF-TOKEN")).thenReturn(csrfToken);
		when(request.getCookies()).thenReturn(new Cookie[]{});	
		when(request.getMethod()).thenReturn(HttpMethod.POST.toString());
				
		// --- ACTION -- //
		csrfFilter.doFilter(request, response, filterChain);
		
		// --- TEST -- //
		
		// Value
		// Mock
		verify(response, times(0)).setHeader(eq("Set-Cookie"), any(String.class));
		verify(filterChain, times(0)).doFilter(request, response);
		verify(response).sendError(HttpStatus.FORBIDDEN.value(), HttpStatus.FORBIDDEN.getReasonPhrase());
	}
	
	@Test
	@DisplayName("Cas No Header Ko")
	void testDoFilterCsrfKONoHeader() throws ServletException, IOException {
		// --- CONFIG --- //
		when(request.getServletPath()).thenReturn("/places");
		Cookie csrfCookie = new Cookie("XSRF-TOKEN", UUID.randomUUID().toString());
		when(request.getCookies()).thenReturn(new Cookie[]{csrfCookie});	
		when(request.getMethod()).thenReturn(HttpMethod.DELETE.toString());
		
		// --- ACTION -- //
		csrfFilter.doFilter(request, response, filterChain);
		
		// --- TEST -- //
		
		// Value
		// Mock
		verify(response, times(0)).setHeader(eq("Set-Cookie"), any(String.class));
		verify(filterChain, times(0)).doFilter(request, response);
		verify(response).sendError(HttpStatus.FORBIDDEN.value(), HttpStatus.FORBIDDEN.getReasonPhrase());
	}
	
	@Test
	@DisplayName("Cas GET Ok")
	void testDoFilterCsrfOKGET() throws ServletException, IOException {
		// --- CONFIG --- //
		when(request.getServletPath()).thenReturn("/places");
		when(request.getMethod()).thenReturn(HttpMethod.GET.toString());
		when(request.getServerName()).thenReturn("cookieDomain");
		
		ArgumentCaptor<String> responseCookieString = ArgumentCaptor.forClass(String.class);
		doNothing().when(response).setHeader(eq("Set-Cookie"), responseCookieString.capture());
		
		// --- ACTION -- //
		csrfFilter.doFilter(request, response, filterChain);
		
		// --- TEST -- //
		
		// Value
		// Mock
		assertThat(responseCookieString.getValue(), matchesPattern("XSRF-TOKEN=[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}; domain=cookieDomain; path=\\/path; Secure; SameSite=None"));
		verify(response).setHeader("Set-Cookie", responseCookieString.getValue());
		verify(filterChain).doFilter(request, response);
		verify(request).getServerName();
	}
	
	@Test
	@DisplayName("Cas HEAD Ok")
	void testDoFilterCsrfOKHEAD() throws ServletException, IOException {
		// --- CONFIG --- //
		when(request.getServletPath()).thenReturn("/places");
		when(request.getMethod()).thenReturn(HttpMethod.HEAD.toString());
		when(request.getServerName()).thenReturn("cookieDomain");
		
		ArgumentCaptor<String> responseCookieString = ArgumentCaptor.forClass(String.class);
		doNothing().when(response).setHeader(eq("Set-Cookie"), responseCookieString.capture());
		
		// --- ACTION -- //
		csrfFilter.doFilter(request, response, filterChain);
		
		// --- TEST -- //
		
		// Value
		// Mock
		assertThat(responseCookieString.getValue(), matchesPattern("XSRF-TOKEN=[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}; domain=cookieDomain; path=\\/path; Secure; SameSite=None"));
		verify(response).setHeader("Set-Cookie", responseCookieString.getValue());
		verify(filterChain).doFilter(request, response);
		verify(request).getServerName();
	}
	
	@Test
	@DisplayName("Cas Empty Header Ko")
    void testDoFilterCsrfEmptyHeader() throws ServletException, IOException {
        // --- CONFIG --- //
        when(request.getServletPath()).thenReturn("/places");
        Cookie csrfCookie = new Cookie("XSRF-TOKEN", UUID.randomUUID().toString());
        when(request.getHeader("X-XSRF-TOKEN")).thenReturn("");
        when(request.getCookies()).thenReturn(new Cookie[]{csrfCookie});    
        when(request.getMethod()).thenReturn(HttpMethod.DELETE.toString());
        
        // --- ACTION -- //
        csrfFilter.doFilter(request, response, filterChain);
        
        // --- TEST -- //
        
        // Value
        // Mock
        verify(response, times(0)).setHeader(eq("Set-Cookie"), any(String.class));
        verify(filterChain, times(0)).doFilter(request, response);
		verify(response).sendError(HttpStatus.FORBIDDEN.value(), HttpStatus.FORBIDDEN.getReasonPhrase());
    }
	
	@Test
	@DisplayName("Cas Empty Cookie Ko")
    void testInnerDoFilterCsrfEmptyCookie() throws ServletException, IOException {
        // --- CONFIG --- //
       String csrfToken = UUID.randomUUID().toString();
        when(request.getServletPath()).thenReturn("/places");
        Cookie csrfCookie = new Cookie("XSRF-TOKEN", "");
        when(request.getHeader("X-XSRF-TOKEN")).thenReturn(csrfToken);
        when(request.getCookies()).thenReturn(new Cookie[]{csrfCookie});    
        when(request.getMethod()).thenReturn(HttpMethod.DELETE.toString());
        
        // --- ACTION -- //
        csrfFilter.doFilter(request, response, filterChain);
        
        // --- TEST -- //
        
        // Value
        // Mock
        verify(response, times(0)).setHeader(eq("Set-Cookie"), any(String.class));
        verify(filterChain, times(0)).doFilter(request, response);
		verify(response).sendError(HttpStatus.FORBIDDEN.value(), HttpStatus.FORBIDDEN.getReasonPhrase());
    }
	
	@Test
	@DisplayName("Cas Spaces Header Ko")
    void testInnerDoFilterCsrfSpacesHeader() throws ServletException, IOException {
        // --- CONFIG --- //
        when(request.getServletPath()).thenReturn("/places");
        Cookie csrfCookie = new Cookie("XSRF-TOKEN", "");
        when(request.getHeader("X-XSRF-TOKEN")).thenReturn("   ");
        when(request.getCookies()).thenReturn(new Cookie[]{csrfCookie});    
        when(request.getMethod()).thenReturn(HttpMethod.DELETE.toString());
        
        // --- ACTION -- //
        csrfFilter.doFilter(request, response, filterChain);
        
        // --- TEST -- //
        
        // Value
        // Mock
        verify(response, times(0)).setHeader(eq("Set-Cookie"), any(String.class));
        verify(filterChain, times(0)).doFilter(request, response);
		verify(response).sendError(HttpStatus.FORBIDDEN.value(), HttpStatus.FORBIDDEN.getReasonPhrase());
    }
	
    @Test
    @DisplayName("Cas Spaces Cookie Ko")
    void testInnerDoFilterCsrfSpacesCookie() throws ServletException, IOException {
        // --- CONFIG --- //
       String csrfToken = UUID.randomUUID().toString();
        when(request.getServletPath()).thenReturn("/places");
        Cookie csrfCookie = new Cookie("XSRF-TOKEN", "   ");
        when(request.getHeader("X-XSRF-TOKEN")).thenReturn(csrfToken);
        when(request.getCookies()).thenReturn(new Cookie[]{csrfCookie});    
        when(request.getMethod()).thenReturn(HttpMethod.DELETE.toString());
        
        // --- ACTION -- //
        csrfFilter.doFilter(request, response, filterChain);
        
        // --- TEST -- //
        
        // Value
        // Mock
        verify(response, times(0)).setHeader(eq("Set-Cookie"), any(String.class));
        verify(filterChain, times(0)).doFilter(request, response);
		verify(response).sendError(HttpStatus.FORBIDDEN.value(), HttpStatus.FORBIDDEN.getReasonPhrase());
    }
    
    @Test
    @DisplayName("Cas Spaces Header et Cookie Ko")
    void testInnerDoFilterCsrfSpacesCookieHeader() throws ServletException, IOException {
        // --- CONFIG --- //
        when(request.getServletPath()).thenReturn("/places");
        Cookie csrfCookie = new Cookie("XSRF-TOKEN", "   ");
        when(request.getHeader("X-XSRF-TOKEN")).thenReturn("   ");
        when(request.getCookies()).thenReturn(new Cookie[]{csrfCookie});    
        when(request.getMethod()).thenReturn(HttpMethod.DELETE.toString());
        
        // --- ACTION -- //
        csrfFilter.doFilter(request, response, filterChain);
        
        // --- TEST -- //
        
        // Value
        // Mock
        verify(response, times(0)).setHeader(eq("Set-Cookie"), any(String.class));
        verify(filterChain, times(0)).doFilter(request, response);
		verify(response).sendError(HttpStatus.FORBIDDEN.value(), HttpStatus.FORBIDDEN.getReasonPhrase());
    }
}
