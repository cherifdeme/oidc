package fr.ca.cat.ihml.oidc.bff.security;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.PrintWriter;

import fr.ca.cat.ihml.oidc.bff.models.http.ErrorResponse;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.AuthenticationException;

import fr.ca.cat.ihml.oidc.bff.utils.AppUtils;

@DisplayName("Http401EnttryPoint")
@Tag("Security")
@Tag("Unit")
@ExtendWith(MockitoExtension.class)
class Http401EnttryPointTest {

    @InjectMocks
    private Http401EnttryPoint http401EnttryPoint;
    
    @Mock
    private HttpServletRequest request;
    
    @Mock
    private HttpServletResponse response;
    
    @Mock
    private AuthenticationException authException;
    
    @Mock
    private PrintWriter writer;

	@Test
	@DisplayName("Cas nominal")
	void testCommence() throws IOException, ServletException {
		// --- CONFIG -- //
		ArgumentCaptor<Integer> responseStatusArgumentCaptor = ArgumentCaptor.forClass(Integer.class);
		doNothing().when(response).setStatus(responseStatusArgumentCaptor.capture());
		
		when(response.getWriter()).thenReturn(writer);
		
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setStatus(HttpStatus.UNAUTHORIZED.value());
		errorResponse.setMessage("Identifiants invalides");
		String jsonResponseBody = AppUtils.convertObjectToJsonString(errorResponse);
		doNothing().when(writer).write(jsonResponseBody);
		
		// --- ACTION -- //
		http401EnttryPoint.commence(request, response, authException);
		
		// --- TEST -- //
		verify(response).setStatus(HttpStatus.UNAUTHORIZED.value());
		verify(response).setContentType(MediaType.APPLICATION_JSON_VALUE);
		verify(writer).write(jsonResponseBody);

	}

}
