package fr.ca.cat.ihml.oidc.bff.security;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.UUID;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.models.security.auth.UserAuthenticated;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import org.jeasy.random.EasyRandom;
import org.jose4j.base64url.Base64;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.context.SecurityContextHolder;

import fr.ca.cat.ihml.oidc.bff.services.security.SecurityServiceImpl;
import fr.ca.cat.ihml.oidc.bff.utils.AppUtils;

@DisplayName("SessionAuthenticationFilter")
@Tag("Security")
@Tag("Unit")
@ExtendWith(MockitoExtension.class)
class SessionAuthenticationFilterTest {
	
    private SessionAuthenticationFilter sessionAuthenticationFilter;
    
    @Mock
    private HttpServletRequest request;
    
    @Mock
    private HttpServletResponse response;
    
    @Mock
    private SecurityServiceImpl securityService;
    
    @Mock
    private HttpSession session;
    
    @Mock
    private FilterChain filterChain;
    
	@BeforeEach
	void setUp() {
		SecurityContextHolder.getContext().setAuthentication(null);
		sessionAuthenticationFilter = new SessionAuthenticationFilter(securityService, 30);
	}

	@Test
	@DisplayName("Cas nominal")
	void testCasNominal() throws ServletException, IOException {
		// --- CONFIG -- //
		EasyRandom generator = new EasyRandom();
		UserAuthenticated auth = generator.nextObject(UserAuthenticated.class);
		SecurityContextHolder.getContext().setAuthentication(auth);
		Cookie refreshCookie = new Cookie(Constants.SESSION_REFRESH_COOKIE, UUID.randomUUID().toString());
		Cookie sessionIdCookie = new Cookie(Constants.SESSION_ID_COOKIE, Base64.encode(UUID.randomUUID().toString().getBytes()));
		Cookie[] cookies = new Cookie[] {sessionIdCookie, refreshCookie};
		
		when(request.getCookies()).thenReturn(cookies);
		when(request.getSession()).thenReturn(session);
		when(session.getAttribute(Constants.EXPIRES_AT_KEY)).thenReturn(AppUtils.delayFromNowToMilliseconds(31));
		
		// --- ACTION -- //
		sessionAuthenticationFilter.doFilter(request, response, filterChain);
		
		// --- TEST -- //
		verify(session).getAttribute(Constants.EXPIRES_AT_KEY);
		verify(filterChain).doFilter(request, response);
		assertThat(SecurityContextHolder.getContext().getAuthentication(), is(auth));
	}
	
	@Test
	@DisplayName("Session Expirée avec refresh token")
	void testSessionExpiredWitRefreshToken() throws ServletException, IOException, ApiException {
		// --- CONFIG -- //
		EasyRandom generator = new EasyRandom();
		UserAuthenticated auth = generator.nextObject(UserAuthenticated.class);
		SecurityContextHolder.getContext().setAuthentication(auth);
		Cookie refreshCookie = new Cookie(Constants.SESSION_REFRESH_COOKIE, UUID.randomUUID().toString());
		Cookie sessionIdCookie = new Cookie(Constants.SESSION_ID_COOKIE, Base64.encode(UUID.randomUUID().toString().getBytes()));
		Cookie[] cookies = new Cookie[] {sessionIdCookie, refreshCookie};
		
		when(request.getCookies()).thenReturn(cookies);
		when(request.getSession()).thenReturn(session);

		when(session.getAttribute(Constants.EXPIRES_AT_KEY)).thenReturn(AppUtils.delayFromNowToMilliseconds(15));
		doNothing().when(securityService).refreshToken(refreshCookie.getValue(), new String(Base64.decode(sessionIdCookie.getValue())));
		
		// --- ACTION -- //
		sessionAuthenticationFilter.doFilter(request, response, filterChain);
		
		// --- TEST -- //
		verify(session).getAttribute(Constants.EXPIRES_AT_KEY);
		verify(securityService).refreshToken(refreshCookie.getValue(), new String(Base64.decode(sessionIdCookie.getValue())));
		verify(filterChain).doFilter(request, response);
		
		assertThat(SecurityContextHolder.getContext().getAuthentication(), is(auth));
	}
	
	@Test
	@DisplayName("Session Expirée avec refresh token")
	void testSessionExpiredNoExpirationKey() throws ServletException, IOException, ApiException {
		// --- CONFIG -- //
		EasyRandom generator = new EasyRandom();
		UserAuthenticated auth = generator.nextObject(UserAuthenticated.class);
		SecurityContextHolder.getContext().setAuthentication(auth);
		Cookie refreshCookie = new Cookie(Constants.SESSION_REFRESH_COOKIE, UUID.randomUUID().toString());
		Cookie sessionIdCookie = new Cookie(Constants.SESSION_ID_COOKIE, Base64.encode(UUID.randomUUID().toString().getBytes()));
		Cookie[] cookies = new Cookie[] {sessionIdCookie, refreshCookie};
		
		when(request.getCookies()).thenReturn(cookies);
		when(request.getSession()).thenReturn(session);
		when(session.getAttribute(Constants.EXPIRES_AT_KEY)).thenReturn(null);
		doNothing().when(securityService).refreshToken(refreshCookie.getValue(), new String(Base64.decode(sessionIdCookie.getValue())));
		
		// --- ACTION -- //
		sessionAuthenticationFilter.doFilter(request, response, filterChain);
		
		// --- TEST -- //
		verify(session).getAttribute(Constants.EXPIRES_AT_KEY);
		verify(securityService).refreshToken(refreshCookie.getValue(), new String(Base64.decode(sessionIdCookie.getValue())));
		verify(filterChain).doFilter(request, response);
		
		assertThat(SecurityContextHolder.getContext().getAuthentication(), is(auth));
	}
	
	@Test
	@DisplayName("Session Expirée aucun refresh token")
	void testSessionExpiredNoRefreshToken() throws ServletException, IOException, ApiException {
		// --- CONFIG -- //
		EasyRandom generator = new EasyRandom();
		UserAuthenticated auth = generator.nextObject(UserAuthenticated.class);
		SecurityContextHolder.getContext().setAuthentication(auth);
		Cookie sessionIdCookie = new Cookie(Constants.SESSION_ID_COOKIE, Base64.encode(UUID.randomUUID().toString().getBytes()));
		Cookie[] cookies = new Cookie[] {sessionIdCookie};
		
		when(request.getCookies()).thenReturn(cookies);
		when(request.getSession()).thenReturn(session);
		when(session.getAttribute(Constants.EXPIRES_AT_KEY)).thenReturn(AppUtils.delayFromNowToMilliseconds(15));
		
		// --- ACTION -- //
		sessionAuthenticationFilter.doFilter(request, response, filterChain);
		
		// --- TEST -- //
		verify(session).getAttribute(Constants.EXPIRES_AT_KEY);
		verify(securityService, times(0)).refreshToken(any(String.class), eq(new String(Base64.decode(sessionIdCookie.getValue()))));
		verify(filterChain).doFilter(request, response);
		
		assertThat(SecurityContextHolder.getContext().getAuthentication(), nullValue());
	}
	
	@Test
	@DisplayName("Session Expirée aucun cookie session")
	void testSessionExpiredNoSessionCookie() throws ServletException, IOException, ApiException {
		// --- CONFIG -- //
		EasyRandom generator = new EasyRandom();
		UserAuthenticated auth = generator.nextObject(UserAuthenticated.class);
		SecurityContextHolder.getContext().setAuthentication(auth);
		Cookie refreshCookie = new Cookie(Constants.SESSION_REFRESH_COOKIE, UUID.randomUUID().toString());
		Cookie[] cookies = new Cookie[] {refreshCookie};
		
		when(request.getCookies()).thenReturn(cookies);
		when(request.getSession()).thenReturn(session);
		when(session.getAttribute(Constants.EXPIRES_AT_KEY)).thenReturn(AppUtils.delayFromNowToMilliseconds(15));
		
		// --- ACTION -- //
		sessionAuthenticationFilter.doFilter(request, response, filterChain);
		
		// --- TEST -- //
		verify(session).getAttribute(Constants.EXPIRES_AT_KEY);
		verify(securityService, times(0)).refreshToken(eq(refreshCookie.getValue()), any(String.class));
		verify(filterChain).doFilter(request, response);
		
		assertThat(SecurityContextHolder.getContext().getAuthentication(), nullValue());
	}
	
	@Test
	@DisplayName("Session Expirée exeception refresh token")
	void testSessionExpiredExceptionRefresh() throws ServletException, IOException, ApiException {
		// --- CONFIG -- //
		EasyRandom generator = new EasyRandom();
		UserAuthenticated auth = generator.nextObject(UserAuthenticated.class);
		SecurityContextHolder.getContext().setAuthentication(auth);
		Cookie refreshCookie = new Cookie(Constants.SESSION_REFRESH_COOKIE, UUID.randomUUID().toString());
		Cookie sessionIdCookie = new Cookie(Constants.SESSION_ID_COOKIE, Base64.encode(UUID.randomUUID().toString().getBytes()));
		Cookie[] cookies = new Cookie[] {sessionIdCookie, refreshCookie};
		
		when(request.getCookies()).thenReturn(cookies);
		when(request.getSession()).thenReturn(session);
		when(session.getAttribute(Constants.EXPIRES_AT_KEY)).thenReturn(AppUtils.delayFromNowToMilliseconds(15));
		doThrow(new ApiException(500, "Erreur lors du refresh token")).when(securityService).refreshToken(refreshCookie.getValue(), new String(Base64.decode(sessionIdCookie.getValue())));
		
		// --- ACTION -- //
		sessionAuthenticationFilter.doFilter(request, response, filterChain);
		
		// --- TEST -- //
		verify(session).getAttribute(Constants.EXPIRES_AT_KEY);
		verify(securityService).refreshToken(refreshCookie.getValue(), new String(Base64.decode(sessionIdCookie.getValue())));
		verify(filterChain).doFilter(request, response);
		
		assertThat(SecurityContextHolder.getContext().getAuthentication(), nullValue());
	}

}
