package fr.ca.cat.ihml.oidc.bff.services.api;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.Collections;
import java.util.Map;
import java.util.UUID;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.feign.client.ContextServiceFeign;
import fr.ca.cat.ihml.oidc.bff.models.context.ApplicationContext;
import fr.ca.cat.ihml.oidc.bff.models.context.Ctx9ReadContext;
import fr.ca.cat.ihml.oidc.bff.models.context.Ctx9WriteContext;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import jakarta.servlet.http.HttpSession;

import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

@DisplayName("ContextService")
@Tag("Context")
@Tag("Service")
@Tag("Unit")
@ExtendWith(MockitoExtension.class)
class ContextServiceTest {
	
    @InjectMocks
    private ContextServiceImpl contextService;
    
    @Mock
    private HttpSession session;
    
    @Mock
    private ContextServiceFeign contextFeignService;
	
	@Nested
	@DisplayName("Get Context")
	class whenGetContext {
		@Test
		@DisplayName("Récupération du context")
		void testGetContext() throws IOException, ApiException {
			// --- CONFIG -- //
			UUID ctxId = UUID.randomUUID();		
			Ctx9ReadContext ctx9Context = new Ctx9ReadContext();
			ctx9Context.setContext("{\"regional_bank_id\":\"881\", \"zip_code\":\"44115\", \"client_id\":\"123456789fsdfdsg\"}");
			//when(session.getAttribute(Constants.ACCESS_TOKEN_KEY)).thenReturn("access_token");
			
			ArgumentCaptor<Map<String, Object>> httpRequestArgumentCaptor = ArgumentCaptor.forClass(Map.class);
			when(contextFeignService.getContextRequest(httpRequestArgumentCaptor.capture())).thenReturn(ctx9Context);
			
			
			// --- ACTION -- //
			ApplicationContext appContext = contextService.getContext(ctxId);
			
			// --- TEST -- //
			
			// Mock
			assertThat(httpRequestArgumentCaptor.getValue().get("context_id"), is(ctxId.toString()));

			// Value
			assertThat(appContext.getClientId(), is("123456789fsdfdsg"));
			assertThat(appContext.getRegionalBankId(), is("881"));
			assertThat(appContext.getZipCode(), is("44115"));
		}
		
		@Test
		@DisplayName("ApiException")
		void testGetContextApiException() throws IOException, ApiException {
			// --- CONFIG -- //
			UUID ctxId = UUID.randomUUID();		
			Ctx9ReadContext ctx9Context = new Ctx9ReadContext();
			ctx9Context.setContext("{\"regional_bank_id\":\"881\", \"zip_code\":\"44115\", \"client_id\":\"123456789fsdfdsg\"}");
			//when(session.getAttribute(Constants.ACCESS_TOKEN_KEY)).thenReturn("access_token");
			
			doThrow(new ApiException(500, "Erreur appel API")).when(contextFeignService).getContextRequest(Collections.singletonMap("context_id", ctxId.toString()));
			
			// --- ACTION -- //
			ApiException e = assertThrows(ApiException.class, () -> contextService.getContext(ctxId));
			 
			// --- TEST -- //

			// Value
			assertThat(e.getStatusCode(), is(500));
			assertThat(e.getMessage(), is("Erreur appel API"));
		}
	}

	@Nested
	@DisplayName("Set Context")
	class whenSetContext {
		
		@Test
		@DisplayName("Sauvegarde du context")
		void testSetContext() throws IOException, ApiException {
			// --- CONFIG -- //
			EasyRandom generator = new EasyRandom();
			ApplicationContext applicationContext = generator.nextObject(ApplicationContext.class);
			
			Ctx9WriteContext writeContext = new Ctx9WriteContext();
			writeContext.setContext("{\"context_id\":\"123456789123456789\"}");
			
			ArgumentCaptor<MultiValueMap<String, Object>> httpRequestArgumentCaptor = ArgumentCaptor.forClass(MultiValueMap.class);
			when(contextFeignService.setContext(httpRequestArgumentCaptor.capture())).thenReturn(writeContext);
		
			
			// --- ACTION -- //
			Ctx9WriteContext writeContextReturn = contextService.setContext(applicationContext);
			
			// --- TEST -- //
			
			// Mock
			assertThat(httpRequestArgumentCaptor.getValue().get("user_context").get(0), is(applicationContext.toJsonString()));
			assertThat(httpRequestArgumentCaptor.getValue().get("client_id").get(0), is(applicationContext.getClientId()));

			// Value
			assertThat(writeContextReturn.getContext(), is("{\"context_id\":\"123456789123456789\"}"));
		}	
		
		@Test
		@DisplayName("ApiException")
		void testApiException() throws IOException, ApiException {
			// --- CONFIG -- //
			EasyRandom generator = new EasyRandom();
			ApplicationContext applicationContext = generator.nextObject(ApplicationContext.class);
			
			Ctx9WriteContext writeContext = new Ctx9WriteContext();
			writeContext.setContext("{\"context_id\":\"123456789123456789\"}");
			
	        MultiValueMap<String, Object> map = new LinkedMultiValueMap<>();
	        map.add(Constants.USER_CONTEXT_PARAM, applicationContext.toJsonString());
	        map.add(Constants.CLIENT_ID_PARAM, applicationContext.getClientId());
			doThrow(new ApiException(500, "Erreur appel API")).when(contextFeignService).setContext(map);
		
			
			// --- ACTION -- //
			ApiException e = assertThrows(ApiException.class, () ->contextService.setContext(applicationContext));
			
			// --- TEST -- //

			assertThat(e.getStatusCode(), is(500));
			assertThat(e.getMessage(), is("Erreur appel API"));
		}	
	}




}
