package fr.ca.cat.ihml.oidc.bff.services.api;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.feign.client.PlacesServiceFeign;
import fr.ca.cat.ihml.oidc.bff.models.places.CR;
import fr.ca.cat.ihml.oidc.bff.models.places.DistributionEntity;
import fr.ca.cat.ihml.oidc.bff.models.places.Entity;
import jakarta.servlet.http.HttpSession;

import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

import io.micrometer.core.instrument.simple.SimpleMeterRegistry;

@DisplayName("PlacesService")
@Tag("Places")
@Tag("Service")
@Tag("Unit")
@ExtendWith(MockitoExtension.class)
class PlacesServiceTest {
	
    @InjectMocks
    private PlacesServiceImpl placesService;
    
    @Mock
    private HttpSession session;
    
    @Mock
    private PlacesServiceFeign placesServiceFeign;
    
	@BeforeEach
	void setUp() throws Exception {
		ReflectionTestUtils.setField(placesService, "meterRegistry", new SimpleMeterRegistry());
	}
	
	@Nested
	@DisplayName("Get CR List")
	class WhenGetCRList {
		
		@Test
		@DisplayName("Récupération liste CR")
		void testGetCRList() throws ApiException {
			// --- CONFIG -- //
			
			EasyRandom generator = new EasyRandom();
			List<CR> crsList = generator.objects(CR.class, 3).collect(Collectors.toList());
			CR[] crs = new CR[crsList.size()];
			crs = crsList.toArray(crs);
			when(placesServiceFeign.getCRListRequest()).thenReturn(crs);
			
			// --- ACTION -- //
			placesService.init();
			CR[] crsReturn = placesService.getCRList();
			
			// --- TEST -- //

			// Value
			assertThat(crsReturn.length, is(crs.length));
			assertThat(crsReturn[0], is(crs[0]));
		}
		
		@Test
		@DisplayName("ApiException")
		void testApiException() throws ApiException {
			// --- CONFIG -- //
			
			EasyRandom generator = new EasyRandom();
			List<CR> crsList = generator.objects(CR.class, 3).collect(Collectors.toList());
			CR[] crs = new CR[crsList.size()];
			crs = crsList.toArray(crs);
			doThrow(new ApiException(500, "Erreur appel API")).when(placesServiceFeign).getCRListRequest();
			
			// --- ACTION -- //
			placesService.init();
			ApiException e = assertThrows(ApiException.class, () -> placesService.getCRList());
			
			// --- TEST -- //

			// Value
			assertThat(e.getStatusCode(), is(500));
			assertThat(e.getMessage(), is("Erreur appel API"));
		}
	}

	@Nested
	@DisplayName("Get CR Entities")
	class WhenGetCREntities {

		@Test
		@DisplayName("Récupération liste des entités")
		void testGetCREntities() throws ApiException {
			// --- CONFIG -- //
			
			EasyRandom generator = new EasyRandom();
			List<Entity> entityList = generator.objects(Entity.class, 3).collect(Collectors.toList());
			Entity[] entities = new Entity[entityList.size()];
			entities = entityList.toArray(entities);
			ArgumentCaptor<Integer> httpRequestArgumentCaptor = ArgumentCaptor.forClass(Integer.class);
			when(placesServiceFeign.getCREntitiesRequest(httpRequestArgumentCaptor.capture())).thenReturn(entities);
			
			// --- ACTION -- //
			Entity[] entitiesReturn = placesService.getCREntities(881);
			
			// --- TEST -- //
			
			// Mock
			assertThat(httpRequestArgumentCaptor.getValue(), is(881));
			
			// Value
			assertThat(entitiesReturn.length, is(entities.length));
			assertThat(entitiesReturn[0], is(entities[0]));
			assertThat(entitiesReturn[1], is(entities[1]));
		}
		
		@Test
		@DisplayName("ApiException")
		void testApiException() throws ApiException {
			// --- CONFIG -- //
			
			EasyRandom generator = new EasyRandom();
			List<Entity> entityList = generator.objects(Entity.class, 3).collect(Collectors.toList());
			Entity[] entities = new Entity[entityList.size()];
			entities = entityList.toArray(entities);

			doThrow(new ApiException(500, "Erreur appel API")).when(placesServiceFeign).getCREntitiesRequest(881);
			
			// --- ACTION -- //
			ApiException e = assertThrows(ApiException.class, () -> placesService.getCREntities(881));
			
			// --- TEST -- //
			assertThat(e.getStatusCode(), is(500));
			assertThat(e.getMessage(), is("Erreur appel API"));
		}
	}

	@Nested
	@DisplayName("Get CR Agences List")
	class WhenGetCRAgencesList {
		@Test
		@DisplayName("Récupération liste des agences")
		void testGetCRAgencesList() throws ApiException {
			// --- CONFIG -- //
		
			EasyRandom generator = new EasyRandom();
			List<DistributionEntity> distributionEntitiyList = generator.objects(DistributionEntity.class, 3).collect(Collectors.toList());
			DistributionEntity[] distributionEntities = new DistributionEntity[distributionEntitiyList.size()];
			distributionEntities = distributionEntitiyList.toArray(distributionEntities);
		
			ArgumentCaptor<Map<String, Object>> httpRequestArgumentCaptorCR = ArgumentCaptor.forClass(Map.class);
			when(placesServiceFeign.getDistributionEntitiesRequest(httpRequestArgumentCaptorCR.capture())).thenReturn(distributionEntities);
		
			
			// --- ACTION -- //
			DistributionEntity[] distributionEntitiesReturn = placesService.getCRAgencesList(881, 74580);
			
			// --- TEST -- //
			
			// Mock
			assertThat(httpRequestArgumentCaptorCR.getValue().get("regional_bank_id"), is(881));
			assertThat(httpRequestArgumentCaptorCR.getValue().get("zip_code"), is(74580));
			
			// Value
			assertThat(distributionEntitiesReturn.length, is(distributionEntities.length));
			assertThat(distributionEntitiesReturn[0], is(distributionEntities[0]));
			assertThat(distributionEntitiesReturn[1], is(distributionEntities[1]));
		}
		
		@Test
		@DisplayName("ApiException")
		void testApiException() throws ApiException {
			// --- CONFIG -- //
		
			EasyRandom generator = new EasyRandom();
			List<DistributionEntity> distributionEntitiyList = generator.objects(DistributionEntity.class, 3).collect(Collectors.toList());
			DistributionEntity[] distributionEntities = new DistributionEntity[distributionEntitiyList.size()];
			distributionEntities = distributionEntitiyList.toArray(distributionEntities);
		
	        Map<String, Object> params = new HashMap<>();
	        params.put("regional_bank_id",881);
	        params.put("zip_code",74580);
	        
			doThrow(new ApiException(500, "Erreur appel API")).when(placesServiceFeign).getDistributionEntitiesRequest(params);
			
			// --- ACTION -- //
			ApiException e = assertThrows(ApiException.class, () -> placesService.getCRAgencesList(881, 74580));
			
			// --- TEST -- //
			
			assertThat(e.getStatusCode(), is(500));
			assertThat(e.getMessage(), is("Erreur appel API"));
		}
	}



}
