package fr.ca.cat.ihml.oidc.bff.services.health;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.redis.connection.RedisClusterConnection;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.RedisSentinelConnection;
import org.springframework.test.util.ReflectionTestUtils;

import fr.ca.cat.ihml.oidc.bff.services.health.HealthService;

@DisplayName("HealthService")
@Tag("Health")
@Tag("Service")
@Tag("Unit")
@ExtendWith(MockitoExtension.class)
class HealthServiceTest {
	
    @InjectMocks
    private HealthService healthService;
    
    @Mock
    private RedisConnectionFactory redisConnectionFactory;
    
    @Mock
    private RedisConnection redisConnection;
    
    @Mock
    private RedisClusterConnection redisClusterConnection;
    
    @Mock
    private RedisSentinelConnection redisSentinelConnection;

    @Nested
    @DisplayName("Redis")
    class WithRedis {
    	
    	@Test
    	@DisplayName("Connexion locale OK")
    	void testLocalConnectionOK() {
    		// CONFIG
    		ReflectionTestUtils.setField(healthService, "redisHost","localhost");
    		when(redisConnectionFactory.getConnection()).thenReturn(redisConnection);
    		when(redisConnection.ping()).thenReturn("PONG");
    		
    		// ACTION
    		boolean isRedisOk = healthService.isRedisOk();
    		
    		// TEST
    		verify(redisConnection).ping();
    		assertThat(isRedisOk, is(true));
    	}   
    	
    	@Test
    	@DisplayName("Connexion locale KO")
    	void testLocalConnectionKO() {
    		// CONFIG
    		ReflectionTestUtils.setField(healthService, "redisHost", "localhost");
    		when(redisConnectionFactory.getConnection()).thenReturn(redisConnection);
    		when(redisConnection.ping()).thenReturn("");
    		
    		// ACTION
    		boolean isRedisOk = healthService.isRedisOk();
    		
    		// TEST
    		verify(redisConnection).ping();
    		assertThat(isRedisOk, is(false));
    	} 
    	
    	@Test
    	@DisplayName("Connexion cluster OK")
    	void testClusterConnectionOK() {
    		// CONFIG
    		ReflectionTestUtils.setField(healthService, "redisHost", null);
    		ReflectionTestUtils.setField(healthService, "redisClusterNodes", List.of("node1:node2", "node2:port2"));
    		when(redisConnectionFactory.getClusterConnection()).thenReturn(redisClusterConnection);
    		when(redisClusterConnection.ping()).thenReturn("PONG");
    		
    		// ACTION
    		boolean isRedisOk = healthService.isRedisOk();
    		
    		// TEST
    		verify(redisClusterConnection).ping();
    		assertThat(isRedisOk, is(true));
    	} 
    	
    	@Test
    	@DisplayName("Connexion cluster KO")
    	void testClusterConnectionKO() {
    		// CONFIG
    		ReflectionTestUtils.setField(healthService, "redisHost", null);
    		ReflectionTestUtils.setField(healthService, "redisClusterNodes", List.of("node1:node2", "node2:port2"));
    		when(redisConnectionFactory.getClusterConnection()).thenReturn(redisClusterConnection);
    		when(redisClusterConnection.ping()).thenReturn("");
    		
    		// ACTION
    		boolean isRedisOk = healthService.isRedisOk();
    		
    		// TEST
    		verify(redisClusterConnection).ping();
    		assertThat(isRedisOk, is(false));
    	} 
    	
    	@Test
    	@DisplayName("Connexion sentinel OK")
    	void testSentinelConnectionOK() throws IOException {
    		// CONFIG
    		ReflectionTestUtils.setField(healthService, "redisHost", null);
    		ReflectionTestUtils.setField(healthService, "redisClusterNodes", null);
    		ReflectionTestUtils.setField(healthService, "redisSentinelNodes", List.of("node1:node2", "node2:port2"));
    		when(redisConnectionFactory.getSentinelConnection()).thenReturn(redisSentinelConnection);
    		when(redisSentinelConnection.isOpen()).thenReturn(true);
    		
    		// ACTION
    		boolean isRedisOk = healthService.isRedisOk();
    		
    		// TEST
    		verify(redisSentinelConnection).isOpen();
    		verify(redisSentinelConnection).close();
    		assertThat(isRedisOk, is(true));
    	} 
    	
    	@Test
    	@DisplayName("Connexion cluster ko")
    	void testSentinelConnectionKo() throws IOException {
    		// CONFIG
    		ReflectionTestUtils.setField(healthService, "redisHost", null);
    		ReflectionTestUtils.setField(healthService, "redisClusterNodes", null);
    		ReflectionTestUtils.setField(healthService, "redisSentinelNodes", List.of("node1:node2", "node2:port2"));
    		when(redisConnectionFactory.getSentinelConnection()).thenReturn(redisSentinelConnection);
    		when(redisSentinelConnection.isOpen()).thenReturn(false);
    		
    		// ACTION
    		boolean isRedisOk = healthService.isRedisOk();
    		
    		// TEST
    		verify(redisSentinelConnection).isOpen();
    		verify(redisSentinelConnection).close();
    		assertThat(isRedisOk, is(false));
    	} 
    	
    	@Test
    	@DisplayName("Connexion sentinel no nodes")
    	void testSentinelNoNodes() {
    		// CONFIG
    		ReflectionTestUtils.setField(healthService, "redisHost", null);
    		ReflectionTestUtils.setField(healthService, "redisClusterNodes", null);
    		ReflectionTestUtils.setField(healthService, "redisSentinelNodes", List.of());
    		
    		// ACTION
    		boolean isRedisOk = healthService.isRedisOk();
    		
    		// TEST
    		assertThat(isRedisOk, is(false));
    	} 
    	
    	@Test
    	@DisplayName("Connexion sentinel IOException on close")
    	void testSentinelConnectionIOException() throws IOException {
    		// CONFIG
    		ReflectionTestUtils.setField(healthService, "redisHost", null);
    		ReflectionTestUtils.setField(healthService, "redisClusterNodes", null);
    		ReflectionTestUtils.setField(healthService, "redisSentinelNodes", List.of("node1:node2", "node2:port2"));
    		when(redisConnectionFactory.getSentinelConnection()).thenReturn(redisSentinelConnection);
    		when(redisSentinelConnection.isOpen()).thenReturn(false);
    		doThrow(new IOException("Erreur closing sentinel connection")).when(redisSentinelConnection).close();
    		
    		// ACTION
    		boolean isRedisOk = healthService.isRedisOk();
    		
    		// TEST
    		verify(redisSentinelConnection).isOpen();
    		verify(redisSentinelConnection).close();
    		assertThat(isRedisOk, is(false));
    	} 
    	
    	@Test
    	@DisplayName("Connexion no nodes no local")
    	void testConnectionNodes() {
    		// CONFIG
    		ReflectionTestUtils.setField(healthService, "redisHost", null);
    		ReflectionTestUtils.setField(healthService, "redisClusterNodes", List.of());
    		ReflectionTestUtils.setField(healthService, "redisSentinelNodes", List.of());
    		
    		// ACTION
    		boolean isRedisOk = healthService.isRedisOk();
    		
    		// TEST
    		assertThat(isRedisOk, is(false));
    	} 
    	
    	@Test
    	@DisplayName("Connexion no parameters")
    	void testConnectionNoParemeters() {
    		// CONFIG
    		ReflectionTestUtils.setField(healthService, "redisHost", null);
    		ReflectionTestUtils.setField(healthService, "redisClusterNodes", null);
    		ReflectionTestUtils.setField(healthService, "redisSentinelNodes", null);
    		
    		// ACTION
    		boolean isRedisOk = healthService.isRedisOk();
    		
    		// TEST
    		assertThat(isRedisOk, is(false));
    	} 
    }
}
