package fr.ca.cat.ihml.oidc.bff.services.logs;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

import fr.ca.cat.ihml.oidc.bff.models.logs.LogLevel;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogMessage;
import fr.ca.cat.ihml.oidc.bff.models.security.auth.UserAuthenticated;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.test.util.ReflectionTestUtils;

import fr.ca.cat.ihml.oidc.bff.utils.AppUtils;

@DisplayName("ApplicationLogger")
@Tag("Logs")
@Tag("Unit")
@ExtendWith(MockitoExtension.class)
class ApplicationLoggerTest {
    
    @Mock
    private Logger logger;
    
    @Mock
    private HttpServletRequest request;
    
    @Mock
    private HttpSession session;

	@Test
	@DisplayName("Init")
	void testInitLog() {
		// --- CONFIG -- //
		ApplicationLogger appLogger = ApplicationLogger.getLogger(ApplicationLoggerTest.class);
		ReflectionTestUtils.setField(appLogger, "logger", logger);
		EasyRandom generator = new EasyRandom();
		LogMessage logMessage  = generator.nextObject(LogMessage.class);
		logMessage.setLevel(0);
		logMessage.setTimeStamp(String.valueOf(Instant.now().toString()));
		
		// --- ACTION -- //
        appLogger.initLog(logMessage)
        .level(LogLevel.WARN)
        .log();
		
		// --- TEST -- //		
		// Mock
        verify(logger).warn(logMessage.getMessage());
	}
	
	@Nested
	@DisplayName("Log Level")
	class WithLog {
		
		@Test
		@DisplayName("Debug")
		void testLogDebug() {
			// --- CONFIG -- //
			ApplicationLogger appLogger = ApplicationLogger.getLogger(ApplicationLoggerTest.class);
			ReflectionTestUtils.setField(appLogger, "logger", logger);
			doNothing().when(logger).debug("Log message");
			
			
			// --- ACTION -- //
	        appLogger.initLog()
	        .level(LogLevel.DEBUG)
	        .message("Log message")
	        .log();
			
			// --- TEST -- //
			
			// Mock
	        verify(logger).debug("Log message");
		}
		
		@Test
		@DisplayName("Info")
		void testLogInfo() {
			// --- CONFIG -- //
			ApplicationLogger appLogger = ApplicationLogger.getLogger(ApplicationLoggerTest.class);
			ReflectionTestUtils.setField(appLogger, "logger", logger);
			doNothing().when(logger).info("Log message");
			
			
			// --- ACTION -- //
	        appLogger.initLog()
	        .level(LogLevel.INFO)
	        .message("Log message")
	        .log();
			
			// --- TEST -- //
			
			// Mock
	        verify(logger).info("Log message");
		}
		
		@Test
		@DisplayName("Error")
		void testLogError() {
			// --- CONFIG -- //
			ApplicationLogger appLogger = ApplicationLogger.getLogger(ApplicationLoggerTest.class);
			ReflectionTestUtils.setField(appLogger, "logger", logger);
			doNothing().when(logger).error("Log message");
			
			
			// --- ACTION -- //
	        appLogger.initLog()
	        .level(LogLevel.ERROR)
	        .message("Log message")
	        .log();
			
			// --- TEST -- //
			
			// Mock
	        verify(logger).error("Log message");
		}
		
		@Test
		@DisplayName("Fatal")
		void testLogFatal() {
			// --- CONFIG -- //
			ApplicationLogger appLogger = ApplicationLogger.getLogger(ApplicationLoggerTest.class);
			ReflectionTestUtils.setField(appLogger, "logger", logger);
			doNothing().when(logger).error("Log message");
			
			
			// --- ACTION -- //
	        appLogger.initLog()
	        .level(LogLevel.FATAL)
	        .message("Log message")
	        .log();
			
			// --- TEST -- //
			
			// Mock
	        verify(logger).error("Log message");
		}
		
		@Test
		@DisplayName("Log")
		void testLogLog() {
			// --- CONFIG -- //
			ApplicationLogger appLogger = ApplicationLogger.getLogger(ApplicationLoggerTest.class);
			ReflectionTestUtils.setField(appLogger, "logger", logger);
			doNothing().when(logger).info("Log message");
			
			
			// --- ACTION -- //
	        appLogger.initLog()
	        .level(LogLevel.LOG)
	        .message("Log message")
	        .log();
			
			// --- TEST -- //
			
			// Mock
	        verify(logger).info("Log message");
		}
		
		@Test
		@DisplayName("Trace")
		void testLogTrace() {
			// --- CONFIG -- //
			ApplicationLogger appLogger = ApplicationLogger.getLogger(ApplicationLoggerTest.class);
			ReflectionTestUtils.setField(appLogger, "logger", logger);
			doNothing().when(logger).trace("Log message");
			
			
			// --- ACTION -- //
	        appLogger.initLog()
	        .level(LogLevel.TRACE)
	        .message("Log message")
	        .log();
			
			// --- TEST -- //
			
			// Mock
	        verify(logger).trace("Log message");
		}
		
		@Test
		@DisplayName("Warn")
		void testLogWarn() {
			// --- CONFIG -- //
			ApplicationLogger appLogger = ApplicationLogger.getLogger(ApplicationLoggerTest.class);
			ReflectionTestUtils.setField(appLogger, "logger", logger);
			doNothing().when(logger).warn("Log message");
			
			
			// --- ACTION -- //
	        appLogger.initLog()
	        .level(LogLevel.WARN)
	        .message("Log message")
	        .log();
			
			// --- TEST -- //
			
			// Mock
	        verify(logger).warn("Log message");
		}		
	}
	
	@Test
	@DisplayName("Trace de tous les champs")
	void testFullField() {
		// --- CONFIG -- //
		ApplicationLogger appLogger = ApplicationLogger.getLogger(ApplicationLoggerTest.class);
		ReflectionTestUtils.setField(appLogger, "logger", logger);
		doNothing().when(logger).debug("Log message");
		
		
		// --- ACTION -- //
        appLogger.initLog()
        .appId("appId")
        .componentId("componentId")
        .componentType("componentType")
        .correlationId(UUID.randomUUID().toString())
        .eds("eds")
        .eventCod("evtCod")
        .eventTyp("evtTyp")
        .instanceName("instanceName")
        .level(LogLevel.DEBUG)
        .message("Log message")
        .operationalPostId("operationalPostId")
        .profil("profil")
        .secEventTyp("secEventTyp")
        .sessionId(UUID.randomUUID().toString())
        .source("source")
        .stackTrace("stackTrace")
        .terminal("terminal")
        .uomCod("uomCod")
        .userId("userId")
        .log();
		
		// --- TEST -- //
		
		// Mock
        verify(logger).debug("Log message");
	}
	
	@Test
	@DisplayName("Utilisation HttRequest")
	void testFullFieldWithRequest() {
		// --- CONFIG -- //
		String sessionId = UUID.randomUUID().toString();
		EasyRandom generator = new EasyRandom();
		UserAuthenticated auth = generator.nextObject(UserAuthenticated.class);
		SecurityContextHolder.getContext().setAuthentication(auth);
		
		ApplicationLogger appLogger = ApplicationLogger.getLogger(ApplicationLoggerTest.class);
		ReflectionTestUtils.setField(appLogger, "logger", logger);
		doNothing().when(logger).debug("Log message");
		
		try (MockedStatic<AppUtils> appUtilsMock = Mockito.mockStatic(AppUtils.class)) {
			
		}
		
		when(request.getRequestURI()).thenReturn("/api/places");
		when(request.getSession()).thenReturn(session);
		
		when(session.getId()).thenReturn(sessionId);
		
		// --- ACTION -- //
		try (MockedStatic<AppUtils> appUtilsMock = Mockito.mockStatic(AppUtils.class)) {
			appUtilsMock.when(AppUtils::getCurrentHttpRequest).thenReturn(Optional.of(request));
			
	        appLogger.initLog()
	        .appId("appId")
	        .componentId("componentId")
	        .componentType("componentType")
	        .correlationId(UUID.randomUUID().toString())
	        .eds("eds")
	        .eventCod("evtCod")
	        .eventTyp("evtTyp")
	        .instanceName("instanceName")
	        .level(LogLevel.DEBUG)
	        .message("Log message")
	        .operationalPostId("operationalPostId")
	        .profil("profil")
	        .secEventTyp("secEventTyp")
	        .source("source")
	        .stackTrace("stackTrace")
	        .terminal("terminal")
	        .uomCod("uomCod")
	        .userId("userId")
	        .log();
			
			// --- TEST -- //
			
			// Mock
	        verify(request).getRequestURI();
	        verify(request).getSession();
	        verify(session).getId();
	        verify(logger).debug("Log message");
		}

	}
}
