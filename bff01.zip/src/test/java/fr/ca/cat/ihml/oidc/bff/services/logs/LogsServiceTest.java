package fr.ca.cat.ihml.oidc.bff.services.logs;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import fr.ca.cat.ihml.oidc.bff.cache.RedisCacheService;
import fr.ca.cat.ihml.oidc.bff.models.logs.LogClientConfiguration;
import org.jeasy.random.EasyRandom;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

@DisplayName(" LogsService")
@Tag("Logs")
@Tag("Service")
@Tag("Unit")
@ExtendWith(MockitoExtension.class)
class LogsServiceTest {

    @InjectMocks
    private LogsServiceImpl logsService;
    
    @Mock
    private RedisCacheService redisCacheService;

	@BeforeEach
	void setUp() {
		ReflectionTestUtils.setField(logsService, "clientLogLevel", 2);
		ReflectionTestUtils.setField(logsService, "serverLogLevel", 3);
		ReflectionTestUtils.setField(logsService, "disableConsoleLog", true);
	}
	
	@Nested
	@DisplayName("Init configuration")
	class WithRedis {

		@Test
		@DisplayName("Redis false")
		void testInitConfRedisFalse() {
			// --- CONFIG -- //
			when(redisCacheService.isClientLogConfigurationExist()).thenReturn(false);
			ArgumentCaptor<LogClientConfiguration> argumentCaptor = ArgumentCaptor.forClass(LogClientConfiguration.class);
	        doNothing().when(redisCacheService).storeClientLogConfiguration(argumentCaptor.capture());
			
			// --- ACTION -- //
			logsService.init();
			
			// --- TEST -- //
			
			// Mock
			assertThat(argumentCaptor.getValue().getClientLoglevel(), is(2));
			assertThat(argumentCaptor.getValue().getServerLogLovel(), is(3));
			assertThat(argumentCaptor.getValue().isDisableConsoleLog(), is(true));
		}
		
		@Test
		@DisplayName("Redis true")
		void testInitConfRedisTrue() {
			// --- CONFIG -- //
			when(redisCacheService.isClientLogConfigurationExist()).thenReturn(true);
			
			// --- ACTION -- //
			logsService.init();
			
			// --- TEST -- //
			
			// Mock
			verify(redisCacheService, times(0)).storeClientLogConfiguration(any());
		}		
	}

	@Nested
	@DisplayName("ClientLogConfiguration")
	class WithClientLogConfiguration {
		
		@Test
		@DisplayName("Sauvegarde configuration log cliente")
		void testStoreClientLogConfiguration() {
			// --- CONFIG -- //
			EasyRandom generator = new EasyRandom();
			LogClientConfiguration logClientConfiguration = generator.nextObject(LogClientConfiguration.class);
			doNothing().when(redisCacheService).storeClientLogConfiguration(logClientConfiguration);
			
			// --- ACTION -- //
			logsService.storeClientLogConfiguration(logClientConfiguration);
			
			// --- TEST -- //
			
			// Mock
			verify(redisCacheService).storeClientLogConfiguration(logClientConfiguration);
		}

		@Test
		@DisplayName("Récupération configuration log cliente existe")
		void testGetClientLogConfigurationExist() {
			// --- CONFIG -- //
			EasyRandom generator = new EasyRandom();
			LogClientConfiguration logClientConfiguration = generator.nextObject(LogClientConfiguration.class);
			when(redisCacheService.getClientLogConfiguration()).thenReturn(logClientConfiguration);
			when(redisCacheService.isClientLogConfigurationExist()).thenReturn(true);
			
			// --- ACTION -- //
			LogClientConfiguration logClientConfigurationReturn =  logsService.getClientLogConfiguration();
			
			// --- TEST -- //
			
			// Mock
			assertThat(logClientConfigurationReturn.getClientLoglevel(), is(logClientConfiguration.getClientLoglevel()));
			assertThat(logClientConfigurationReturn.getServerLogLovel(), is(logClientConfiguration.getServerLogLovel()));
			assertThat(logClientConfigurationReturn.isDisableConsoleLog(), is(logClientConfiguration.isDisableConsoleLog()));
		}
		
		@Test
		@DisplayName("Récupération configuration log cliente n'existe pas")
		void testGetClientLogConfigurationDoesntExisto() {
			// --- CONFIG -- //
			when(redisCacheService.isClientLogConfigurationExist()).thenReturn(false);
			
			// --- ACTION -- //
			LogClientConfiguration logClientConfigurationReturn =  logsService.getClientLogConfiguration();
			
			// --- TEST -- //
			
			// Mock
			assertThat(logClientConfigurationReturn.getClientLoglevel(), is(2));
			assertThat(logClientConfigurationReturn.getServerLogLovel(), is(3));
			assertThat(logClientConfigurationReturn.isDisableConsoleLog(), is(true));
		}		
	}
}
