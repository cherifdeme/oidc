package fr.ca.cat.ihml.oidc.bff.services.manifest;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;

import fr.ca.cat.ihml.oidc.bff.models.manifest.ApplicationManifest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.util.ReflectionTestUtils;

@DisplayName("ManifestService")
@Tag("Manifest")
@Tag("Service")
@Tag("Unit")
@ExtendWith(MockitoExtension.class)
class ManifestServiceTest {

	@InjectMocks
    private ManifestServiceImpl manifestService;

	@BeforeEach
	void setUp() {
		ReflectionTestUtils.setField(manifestService, "framework", "Spring Boot");
		ReflectionTestUtils.setField(manifestService, "version", "3.0.3");
	}

	@Test
	@DisplayName("Récupération manifest")
	void testGetManifest() {
		// --- ACTION -- //
		ApplicationManifest appManifest = manifestService.getManifest();
		
		// --- TEST -- //
		
		// Mock
		assertThat(appManifest.getFramework(), is("Spring Boot"));
		assertThat(appManifest.getVersion(), is("3.0.3"));
	}

}
