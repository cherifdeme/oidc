package fr.ca.cat.ihml.oidc.bff.services.security;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.UUID;

import fr.ca.cat.ihml.oidc.bff.exceptions.ApiException;
import fr.ca.cat.ihml.oidc.bff.feign.client.SecurityServiceFeign;
import fr.ca.cat.ihml.oidc.bff.models.security.auth.UserAuthenticated;
import fr.ca.cat.ihml.oidc.bff.models.security.tokens.LogoutToken;
import fr.ca.cat.ihml.oidc.bff.models.security.tokens.OAuthToken;
import fr.ca.cat.ihml.oidc.bff.models.security.tokens.RefreshToken;
import fr.ca.cat.ihml.oidc.bff.models.security.user.UserDetails;
import fr.ca.cat.ihml.oidc.bff.utils.Constants;
import jakarta.servlet.http.HttpSession;

import org.apache.commons.codec.digest.DigestUtils;
import org.jeasy.random.EasyRandom;
import org.jose4j.jwk.RsaJsonWebKey;
import org.jose4j.jwk.RsaJwkGenerator;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jws.JsonWebSignature;
import org.jose4j.jwt.JwtClaims;
import org.jose4j.lang.JoseException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.session.data.redis.RedisSessionRepository;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import fr.ca.cat.ihml.oidc.bff.cache.RedisCacheService;
import fr.ca.cat.ihml.oidc.bff.utils.AppUtils;

@DisplayName("SecurityService")
@Tag("Security")
@Tag("Service")
@Tag("Unit")
@ExtendWith(MockitoExtension.class)
class SecurityServiceTest {

	@InjectMocks
	private SecurityServiceImpl securityService;

	@Mock
	private RedisCacheService redisCacheService;

	@Mock
	private HttpSession session;
	
	@Mock
	private SecurityServiceFeign securityFeignService;
	
	@Mock
    private RedisSessionRepository redisSessionRepository;
	
	private RsaJsonWebKey rsaKey1;
	private RsaJsonWebKey rsaKey2;
	
	private String clientId = "ZtOsfk9n6Rqy79fojBkJkmIX66eymtjMtTmaDE66WJsTbjzbwnobvbb6Xbl5TN4g";
	private String sid = "25238ced-0725-4d20-bbfd-d0559eb1f84a";

	@BeforeEach
	void setUp() {
		rsaKey1 = getRSAKey("keyId1");
		rsaKey2 = getRSAKey("keyId2");
		ReflectionTestUtils.setField(securityService, "clientId", clientId);
		ReflectionTestUtils.setField(securityService, "logoutToken", "logout_token");
		ReflectionTestUtils.setField(securityService, "logoutTokenEvent", "http://schemas.openid.net/event/backchannel-logout");
		ReflectionTestUtils.setField(securityService, "auc9Url", "http://localhost:8089/authentification_collaborateur/v2");
		ReflectionTestUtils.setField(securityService, "redisSessionRepository", redisSessionRepository);
	}
	
	@Nested
	@DisplayName("Login")
	class WithLogin {
		
		@Test
		@DisplayName("Cas nominal")
		void testLogin() throws IOException, ApiException {
			// --- CONFIG -- //
			String code = UUID.randomUUID().toString();
			String sessionId = UUID.randomUUID().toString();
			when(session.getId()).thenReturn(sessionId);
			ArgumentCaptor<Long> longArgumentCaptor = ArgumentCaptor.forClass(Long.class);
			doNothing().when(session).setAttribute(eq(Constants.EXPIRES_AT_KEY), longArgumentCaptor.capture());

			OAuthToken oAuthToken = getOAuthToken(clientId, rsaKey1);

			ArgumentCaptor<MultiValueMap<String, Object>> httpRequestArgumentCaptor = ArgumentCaptor.forClass(MultiValueMap.class);
			when(securityFeignService.getOpenIdTokenRequest(httpRequestArgumentCaptor.capture())).thenReturn(oAuthToken);
			when(securityFeignService.getPublicKey()).thenReturn(getPublicKey(rsaKey1));

			ArgumentCaptor<String> refreshTokenKeyArgumentCaptor = ArgumentCaptor.forClass(String.class);
			ArgumentCaptor<RefreshToken> refreshTokenArgumentCaptor = ArgumentCaptor.forClass(RefreshToken.class);
			doNothing().when(redisCacheService).storeRefreshToken(refreshTokenKeyArgumentCaptor.capture(),	refreshTokenArgumentCaptor.capture());

			// --- ACTION -- //
			String refreshTokenKey = securityService.login(code, "redirect_url", DigestUtils.sha256Hex(sessionId), null);

			// --- TEST -- //

			// Mock
			verify(securityFeignService).getOpenIdTokenRequest(httpRequestArgumentCaptor.getValue());
			assertThat(httpRequestArgumentCaptor.getValue().get(Constants.GRANT_TYPE_PARAM).get(0),	is(Constants.AUTORIZATION_CODE_VALUE));
			assertThat(httpRequestArgumentCaptor.getValue().get(Constants.SCOPE_PARAM).get(0), is(Constants.SCOPE_VALUE));
			assertThat(httpRequestArgumentCaptor.getValue().get(Constants.CODE_PARAM).get(0), is(code));
			assertThat(httpRequestArgumentCaptor.getValue().get(Constants.REDIRECT_URI_PARAM).get(0), is("redirect_url"));

			verify(session).setAttribute(Constants.EXPIRES_AT_KEY, longArgumentCaptor.getValue());


			verify(securityFeignService).getPublicKey();
			verify(redisCacheService).storeRefreshToken(refreshTokenKeyArgumentCaptor.getValue(),refreshTokenArgumentCaptor.getValue());

			// Value
			assertThat(refreshTokenKey, is(refreshTokenKeyArgumentCaptor.getValue()));
			assertThat(refreshTokenArgumentCaptor.getValue().getToken(), is(oAuthToken.getRefreshToken()));
			
	        UserAuthenticated auth = (UserAuthenticated) SecurityContextHolder.getContext().getAuthentication();
	        assertThat(auth.getCredentials(), is(oAuthToken.getAccessToken()));
	        assertThat(auth.getName(), is("OX60001"));
	        assertThat(auth.getPrincipal().getId(), is("OX60001"));
	        assertThat(auth.getPrincipal().getState(), is(DigestUtils.sha256Hex(sessionId)));
		}
		
		@Test
		@DisplayName("New ma banque")
	    void testLoginNmb() throws IOException, ApiException {
	        // --- CONFIG -- //
	        String code = UUID.randomUUID().toString();
	        String sessionId = UUID.randomUUID().toString();
	        String cookieNmb = UUID.randomUUID().toString();
	        when(session.getId()).thenReturn(sessionId);
	        
	        ArgumentCaptor<Long> longArgumentCaptor = ArgumentCaptor.forClass(Long.class);
	        doNothing().when(session).setAttribute(eq(Constants.EXPIRES_AT_KEY), longArgumentCaptor.capture());
	        
	        OAuthToken oAuthToken = getOAuthToken(clientId, rsaKey1);

	        ArgumentCaptor<MultiValueMap<String, Object>> httpRequestArgumentCaptor = ArgumentCaptor.forClass(MultiValueMap.class);
	        when(securityFeignService.getOpenIdTokenRequest(httpRequestArgumentCaptor.capture())).thenReturn(oAuthToken);
	        when(securityFeignService.getPublicKey()).thenReturn(getPublicKey(rsaKey1));

	        ArgumentCaptor<String> refreshTokenKeyArgumentCaptor = ArgumentCaptor.forClass(String.class);
	        ArgumentCaptor<RefreshToken> refreshTokenArgumentCaptor = ArgumentCaptor.forClass(RefreshToken.class);
	        doNothing().when(redisCacheService).storeRefreshToken(refreshTokenKeyArgumentCaptor.capture(),  refreshTokenArgumentCaptor.capture());

	        // --- ACTION -- //
	        String refreshTokenKey = securityService.login(code, "redirect_url", DigestUtils.sha256Hex(cookieNmb), cookieNmb);

	        // --- TEST -- //

	        // Mock
	        verify(securityFeignService).getOpenIdTokenRequest(httpRequestArgumentCaptor.getValue());
	        assertThat(httpRequestArgumentCaptor.getValue().get(Constants.GRANT_TYPE_PARAM).get(0), is(Constants.AUTORIZATION_CODE_VALUE));
	        assertThat(httpRequestArgumentCaptor.getValue().get(Constants.SCOPE_PARAM).get(0), is(Constants.SCOPE_VALUE));
	        assertThat(httpRequestArgumentCaptor.getValue().get(Constants.CODE_PARAM).get(0), is(code));
	        assertThat(httpRequestArgumentCaptor.getValue().get(Constants.REDIRECT_URI_PARAM).get(0), is("redirect_url"));

	        verify(session).setAttribute(Constants.EXPIRES_AT_KEY, longArgumentCaptor.getValue());
	    	
	        verify(securityFeignService).getPublicKey();
	        verify(redisCacheService).storeRefreshToken(refreshTokenKeyArgumentCaptor.getValue(),refreshTokenArgumentCaptor.getValue());

	        // Value
	        assertThat(refreshTokenKey, is(refreshTokenKeyArgumentCaptor.getValue()));
	        assertThat(refreshTokenArgumentCaptor.getValue().getToken(), is(oAuthToken.getRefreshToken()));
	        
	        UserAuthenticated auth = (UserAuthenticated) SecurityContextHolder.getContext().getAuthentication();
	        assertThat(auth.getCredentials(), is(oAuthToken.getAccessToken()));
	        assertThat(auth.getName(), is("OX60001"));
	        assertThat(auth.getPrincipal().getId(), is("OX60001"));
	        assertThat(auth.getPrincipal().getState(), is(DigestUtils.sha256Hex(sessionId)));
	    }		
		
	    @Test
	    @DisplayName("New ma banque KO")
	    void testLoginKoNmb() throws ApiException {
	        // --- CONFIG -- //
	        String code = UUID.randomUUID().toString();
	        String cookieNmb = UUID.randomUUID().toString();
	        
	        // --- ACTION -- //
	        ApiException e = assertThrows(ApiException.class, () -> securityService.login(code, "redirect_url", DigestUtils.sha256Hex("badSHA"), cookieNmb));
    		assertThat(e.getMessage(), is(Constants.ACCESS_UNAUTHORIZED_RESPONSES));
    		assertThat(e.getStatusCode(), is(HttpStatus.UNAUTHORIZED.value()));
	    }
	    
		@Test
		@DisplayName("Erreur CSRF")
	    void testCsrfError() throws IOException, ApiException {
	        // --- CONFIG -- //
	        String code = UUID.randomUUID().toString();
	        String sessionId = UUID.randomUUID().toString();
	        when(session.getId()).thenReturn(sessionId);

	        // --- ACTION -- //
	        ApiException e = assertThrows(ApiException.class, () -> securityService.login(code, "redirect_url", "state", null));
    		assertThat(e.getMessage(), is(Constants.ACCESS_UNAUTHORIZED_RESPONSES));
    		assertThat(e.getStatusCode(), is(HttpStatus.UNAUTHORIZED.value()));
	    }
		
		@Test
		@DisplayName("Mauvais token Id")
		void testBadTokenId() throws IOException, ApiException {
			// --- CONFIG -- //
			String code = UUID.randomUUID().toString();
			String sessionId = UUID.randomUUID().toString();
			when(session.getId()).thenReturn(sessionId);
			
			OAuthToken oAuthToken = getOAuthToken("badClientId", rsaKey1);

			ArgumentCaptor<MultiValueMap<String, Object>> httpRequestArgumentCaptor = ArgumentCaptor.forClass(MultiValueMap.class);
			when(securityFeignService.getOpenIdTokenRequest(httpRequestArgumentCaptor.capture())).thenReturn(oAuthToken);
			when(securityFeignService.getPublicKey()).thenReturn(getPublicKey(rsaKey1));

			// --- ACTION -- //
	        ApiException e = assertThrows(ApiException.class, () -> securityService.login(code, "redirect_url", DigestUtils.sha256Hex(sessionId), null));
    		assertThat(e.getMessage(), is(Constants.ACCESS_UNAUTHORIZED_RESPONSES));
    		assertThat(e.getStatusCode(), is(HttpStatus.UNAUTHORIZED.value()));
		}
		
		@Test
		@DisplayName("Mauvaise clé publique")
	    void testBadPublicKeyId() throws ApiException {
	        // --- CONFIG -- //
	        String code = UUID.randomUUID().toString();
	        String sessionId = UUID.randomUUID().toString();
	        when(session.getId()).thenReturn(sessionId);

	        OAuthToken oAuthToken = getOAuthToken(clientId, rsaKey2);

	        ArgumentCaptor<MultiValueMap<String, Object>> httpRequestArgumentCaptor = ArgumentCaptor.forClass(MultiValueMap.class);
	        when(securityFeignService.getOpenIdTokenRequest(httpRequestArgumentCaptor.capture())).thenReturn(oAuthToken);
	        when(securityFeignService.getPublicKey()).thenReturn(getPublicKey(rsaKey1));

	        // --- ACTION -- //
	        ApiException e = assertThrows(ApiException.class, () ->  securityService.login(code, "redirect_url", DigestUtils.sha256Hex(sessionId), null));
    		assertThat(e.getMessage(), is(Constants.ACCESS_UNAUTHORIZED_RESPONSES));
    		assertThat(e.getStatusCode(), is(HttpStatus.UNAUTHORIZED.value()));
	    }
	}

	@Nested
	@DisplayName("Standalone logout")
	class WithStandaloneLogout {

		@Test
		@DisplayName("Cas nominal")
		void testStandAloneLogout() throws ApiException {
			// --- CONFIG -- //
			RefreshToken refreshToken = new RefreshToken();
			refreshToken.setSessionId(UUID.randomUUID().toString());
			refreshToken.setToken(UUID.randomUUID().toString());
			when(redisCacheService.isRefreshTokenKeyExist("sid")).thenReturn(true);
			when(redisCacheService.getRefreshToken("sid")).thenReturn(refreshToken);
			doNothing().when(redisCacheService).deleteRefreshToken("sid");

			// --- ACTION -- //
			securityService.standAloneLogout("sid");

			// --- TEST -- //

			verify(redisCacheService).isRefreshTokenKeyExist("sid");
			verify(redisCacheService).getRefreshToken("sid");
			verify(redisCacheService).deleteRefreshToken("sid");
			verify(session).invalidate();
		}
		
		@Test
		@DisplayName("Revoke session")
		void testRevokeSessionStandAloneLogout() throws ApiException {
			// --- CONFIG -- //
		    String refreshTokenKey = UUID.randomUUID().toString();

			RefreshToken refreshToken = new RefreshToken();
			refreshToken.setSessionId(UUID.randomUUID().toString());
			refreshToken.setToken(UUID.randomUUID().toString());
			when(redisCacheService.isRefreshTokenKeyExist(refreshTokenKey)).thenReturn(true);
			when(redisCacheService.getRefreshToken(refreshTokenKey)).thenReturn(refreshToken);
			doNothing().when(redisCacheService).deleteRefreshToken(refreshTokenKey);

			// --- ACTION -- //
			securityService.revokeSessionStandAloneLogout(refreshTokenKey);

			// --- TEST -- //

			verify(redisCacheService).isRefreshTokenKeyExist(refreshTokenKey);
			verify(redisCacheService).getRefreshToken(refreshTokenKey);
			verify(redisCacheService).deleteRefreshToken(refreshTokenKey);
		}
		
		@Test
		@DisplayName("Revoke session non trouvée")
		void testRevokeSessionStandAloneLogoutNotFound() throws IOException, ApiException {
			// --- CONFIG -- //
		    String refreshTokenKey = UUID.randomUUID().toString();

			when(redisCacheService.isRefreshTokenKeyExist(refreshTokenKey)).thenReturn(false);

			// --- ACTION -- //
			securityService.revokeSessionStandAloneLogout(refreshTokenKey);

			// --- TEST -- //

			// Mock
			verify(redisCacheService).isRefreshTokenKeyExist(refreshTokenKey);
			verify(redisCacheService, times(0)).getRefreshToken(refreshTokenKey);
			verify(redisCacheService, times(0)).deleteRefreshToken(refreshTokenKey);
		}
	}
	
	@Nested
	@DisplayName("BackChannel logout")
	class WithBackChannelLogout {
		
		@Test
		@DisplayName("Cas nominal")
		void testBackChannelLogout() throws ApiException {
			// --- CONFIG -- //
			String refreshTokenKey = generateLogoutToken(clientId, rsaKey1);
			RefreshToken refreshToken = new RefreshToken();
			refreshToken.setSessionId(UUID.randomUUID().toString());
			refreshToken.setToken(UUID.randomUUID().toString());
			doNothing().when(redisSessionRepository).deleteById(refreshToken.getSessionId());
			when(redisCacheService.isRefreshTokenKeyExist(sid)).thenReturn(true);
			when(redisCacheService.getRefreshToken(sid)).thenReturn(refreshToken);
			doNothing().when(redisCacheService).deleteRefreshToken(sid);
		    when(securityFeignService.getPublicKey()).thenReturn(getPublicKey(rsaKey1));
		    
			// --- ACTION -- //
		    MultiValueMap<String,String> body = new LinkedMultiValueMap<>();
		    body.add(securityService.logoutToken, refreshTokenKey);
			boolean found = securityService.backChannelLogout(body);

			// --- TEST -- //
			verify(redisCacheService, times(2)).isRefreshTokenKeyExist(sid);
			verify(redisCacheService).getRefreshToken(sid);
			verify(redisCacheService).deleteRefreshToken(sid);
			verify(redisSessionRepository).deleteById(refreshToken.getSessionId());
			
			assertThat(found, is(true));
		}
		
		@Test
		@DisplayName("Aucun logout token")
	    void testBackChannelLogoutNoLogoutToken() throws ApiException {
	        // --- CONFIG -- //
	        RefreshToken refreshToken = new RefreshToken();
	        refreshToken.setSessionId(UUID.randomUUID().toString());
	        refreshToken.setToken(UUID.randomUUID().toString());

	        // --- ACTION -- //
	        MultiValueMap<String,String> body = new LinkedMultiValueMap<>();
	        boolean found = securityService.backChannelLogout(body);
	        
	        assertThat(found, is(false));
	    }
		
		@Test
		@DisplayName("Aucune clé logout token")
		void testBackChannelLogoutKeyNotFoud() throws ApiException {
			// --- CONFIG -- //
		   	String refreshTokenKey = generateLogoutToken(clientId, rsaKey1);
			RefreshToken refreshToken = new RefreshToken();
			refreshToken.setSessionId(UUID.randomUUID().toString());
			refreshToken.setToken(UUID.randomUUID().toString());
		    when(securityFeignService.getPublicKey()).thenReturn(getPublicKey(rsaKey2));
		    
			// --- ACTION -- //
		    MultiValueMap<String,String> body = new LinkedMultiValueMap<>();
		    body.add(securityService.logoutToken, refreshTokenKey);
	        ApiException e = assertThrows(ApiException.class, () ->  securityService.backChannelLogout(body));
    		assertThat(e.getMessage(), is(Constants.BAD_REQUEST_RESPONSES));
    		assertThat(e.getStatusCode(), is(HttpStatus.BAD_REQUEST.value()));
		}
		
		@Test
		@DisplayName("Sid non trouvé")
		void testBackChannelLogoutSidNotFoud() throws ApiException {
			// --- CONFIG -- //
		   	String refreshTokenKey = generateLogoutToken(clientId, rsaKey1);
			RefreshToken refreshToken = new RefreshToken();
			refreshToken.setSessionId(UUID.randomUUID().toString());
			refreshToken.setToken(UUID.randomUUID().toString());
			when(redisCacheService.isRefreshTokenKeyExist(sid)).thenReturn(false);
		    when(securityFeignService.getPublicKey()).thenReturn(getPublicKey(rsaKey1));
		    
			// --- ACTION -- //
		    MultiValueMap<String,String> body = new LinkedMultiValueMap<>();
		    body.add(securityService.logoutToken, refreshTokenKey);
	        ApiException e = assertThrows(ApiException.class, () ->  securityService.backChannelLogout(body));
    		assertThat(e.getMessage(), is(Constants.SESSION_NOT_FOUND));
    		assertThat(e.getStatusCode(), is(HttpStatus.NOT_FOUND.value()));
		}	
		
		@Test
		@DisplayName("Revoke session")
		void testRevokeSessionBackChannelLogout() {
			// --- CONFIG -- //
		    EasyRandom generator = new EasyRandom();
			LogoutToken refreshTokenKey = generator.nextObject(LogoutToken.class);

			RefreshToken refreshToken = new RefreshToken();
			refreshToken.setSessionId(UUID.randomUUID().toString());
			refreshToken.setToken(UUID.randomUUID().toString());
			doNothing().when(redisSessionRepository).deleteById(refreshToken.getSessionId());
			when(redisCacheService.isRefreshTokenKeyExist(refreshTokenKey.getSid())).thenReturn(true);
			when(redisCacheService.getRefreshToken(refreshTokenKey.getSid())).thenReturn(refreshToken);
			doNothing().when(redisCacheService).deleteRefreshToken(refreshTokenKey.getSid());

			// --- ACTION -- //
			securityService.revokeSessionBackChannelLogout(refreshTokenKey);

			// --- TEST -- //
			verify(redisCacheService).isRefreshTokenKeyExist(refreshTokenKey.getSid());
			verify(redisCacheService).getRefreshToken(refreshTokenKey.getSid());
			verify(redisCacheService).deleteRefreshToken(refreshTokenKey.getSid());
			verify(redisSessionRepository).deleteById(refreshToken.getSessionId());
		}
		
		@Test
		@DisplayName("Revoke session non trouvée")
		void testRevokeSessionBackChannelLogoutNotFound() throws IOException, ApiException {
			// --- CONFIG -- //
	        EasyRandom generator = new EasyRandom();
	        LogoutToken refreshTokenKey = generator.nextObject(LogoutToken.class);

			when(redisCacheService.isRefreshTokenKeyExist(refreshTokenKey.getSid())).thenReturn(false);

			// --- ACTION -- //
			securityService.revokeSessionBackChannelLogout(refreshTokenKey);

			// --- TEST -- //

			// Mock
			verify(redisCacheService).isRefreshTokenKeyExist(refreshTokenKey.getSid());
			verify(redisCacheService, times(0)).getRefreshToken(refreshTokenKey.getSid());
			verify(redisCacheService, times(0)).deleteRefreshToken(refreshTokenKey.getSid());
		}
	}

	@Nested
	@DisplayName("Refresh token")
	class WithRefreshToken {
		
		@Test
		@DisplayName("Cas nominal")
		void testRefreshTokenOK() throws IOException, ApiException {
			// --- CONFIG -- //
			String refreshTokenKey = UUID.randomUUID().toString();
			String sessionId = UUID.randomUUID().toString();

			ArgumentCaptor<Long> longArgumentCaptor = ArgumentCaptor.forClass(Long.class);
			doNothing().when(session).setAttribute(eq(Constants.EXPIRES_AT_KEY), longArgumentCaptor.capture());

			when(session.getId()).thenReturn(sessionId);
				
			OAuthToken oAuthToken = getOAuthToken(clientId, rsaKey1);
			ArgumentCaptor<MultiValueMap<String, Object>> httpRequestArgumentCaptor = ArgumentCaptor.forClass(MultiValueMap.class);
			when(securityFeignService.getOpenIdTokenRequest(httpRequestArgumentCaptor.capture())).thenReturn(oAuthToken);
			when(securityFeignService.getPublicKey()).thenReturn(getPublicKey(rsaKey1));
			
			ArgumentCaptor<String> refreshTokenKeyArgumentCaptor = ArgumentCaptor.forClass(String.class);
			ArgumentCaptor<RefreshToken> refreshTokenArgumentCaptor = ArgumentCaptor.forClass(RefreshToken.class);
			doNothing().when(redisCacheService).storeRefreshToken(refreshTokenKeyArgumentCaptor.capture(), refreshTokenArgumentCaptor.capture());

			RefreshToken refreshToken = new RefreshToken();
			refreshToken.setSessionId(sessionId);
			refreshToken.setToken(UUID.randomUUID().toString());
			when(redisCacheService.isRefreshTokenKeyExist(refreshTokenKey)).thenReturn(true);
			when(redisCacheService.getRefreshToken(refreshTokenKey)).thenReturn(refreshToken);

			// --- ACTION -- //
			securityService.refreshToken(refreshTokenKey, sessionId);

			// --- TEST -- //

			// Mock
			assertThat(httpRequestArgumentCaptor.getValue().get(Constants.GRANT_TYPE_PARAM).get(0),	is(Constants.REFRESH_TOKEN_VALUE));
			assertThat(httpRequestArgumentCaptor.getValue().get(Constants.SCOPE_PARAM).get(0), is(Constants.SCOPE_VALUE));
			assertThat(httpRequestArgumentCaptor.getValue().get(Constants.REFRESH_TOKEN_PARAM).get(0),	is(refreshToken.getToken()));

			verify(session).setAttribute(Constants.EXPIRES_AT_KEY, longArgumentCaptor.getValue());

			verify(securityFeignService).getPublicKey();
			verify(redisCacheService).isRefreshTokenKeyExist(refreshTokenKey);
			verify(redisCacheService, times(1)).getRefreshToken(refreshTokenKey);
			verify(redisCacheService).storeRefreshToken(refreshTokenKeyArgumentCaptor.getValue(), refreshTokenArgumentCaptor.getValue());
			
	        UserAuthenticated auth = (UserAuthenticated) SecurityContextHolder.getContext().getAuthentication();
	        assertThat(auth.getCredentials(), is(oAuthToken.getAccessToken()));
	        assertThat(auth.getName(), is("OX60001"));
	        assertThat(auth.getPrincipal().getId(), is("OX60001"));
	        assertThat(auth.getPrincipal().getState(), is(DigestUtils.sha256Hex(sessionId)));
		}

		@Test
		@DisplayName("Refresh token cookie différent de session Id")
		void testRefreshTokenSessionCookieDifferentFromSessionID() throws IOException, ApiException {
			// --- CONFIG -- //
			String refreshTokenKey = UUID.randomUUID().toString();
			String cookieValue = UUID.randomUUID().toString();

			RefreshToken refreshToken = new RefreshToken();
			refreshToken.setSessionId(UUID.randomUUID().toString());
			refreshToken.setToken(UUID.randomUUID().toString());
			when(redisCacheService.isRefreshTokenKeyExist(refreshTokenKey)).thenReturn(true);
			when(redisCacheService.getRefreshToken(refreshTokenKey)).thenReturn(refreshToken);

			// --- ACTION -- //
			IllegalArgumentException e = assertThrows(IllegalArgumentException.class, () -> securityService.refreshToken(refreshTokenKey, cookieValue));
    		assertThat(e.getMessage(), is(String.format("Le refresh token %s n'est pas valide pour la session", AppUtils.obfuscateUUIDString(refreshTokenKey))));
		}

		@Test
		@DisplayName("Refresh token n'existe pas")
		void testRefreshTokenDoesntExist() throws IOException, ApiException {
			// --- CONFIG -- //
			String refreshTokenKey = UUID.randomUUID().toString();
			String cookieValue = UUID.randomUUID().toString();

			when(redisCacheService.isRefreshTokenKeyExist(refreshTokenKey)).thenReturn(false);

			// --- ACTION -- //
			IllegalArgumentException e = assertThrows(IllegalArgumentException.class, () -> securityService.refreshToken(refreshTokenKey, cookieValue));
    		assertThat(e.getMessage(), is(String.format("Le refresh token %s pour la session n'existe pas", AppUtils.obfuscateUUIDString(refreshTokenKey))));
		}

		@Test
		@DisplayName("Récupération refresh token")
		void testGetRefreshToken() {
			// --- CONFIG -- //
			String refreshTokenKey = UUID.randomUUID().toString();

			RefreshToken refreshToken = new RefreshToken();
			refreshToken.setSessionId(UUID.randomUUID().toString());
			refreshToken.setToken(UUID.randomUUID().toString());
			when(redisCacheService.isRefreshTokenKeyExist(refreshTokenKey)).thenReturn(true);
			when(redisCacheService.getRefreshToken(refreshTokenKey)).thenReturn(refreshToken);

			// --- ACTION -- //
			RefreshToken refreshTokenValue = securityService.getRefreshToken(refreshTokenKey);

			// --- TEST -- //
			verify(redisCacheService).isRefreshTokenKeyExist(refreshTokenKey);
			verify(redisCacheService).getRefreshToken(refreshTokenKey);

			assertThat(refreshTokenValue, is(refreshToken));
		}		
	}


	@Nested
	@DisplayName("GetUserConnected")
	class WithGetUserConnected {
		
		@Test
		@DisplayName("Cas nominal")
		void testGetUserConnectedOK() {
			// --- CONFIG -- //
			EasyRandom generator = new EasyRandom();
			UserAuthenticated auth = generator.nextObject(UserAuthenticated.class);
			String refreshToken = UUID.randomUUID().toString();
			when(redisCacheService.isRefreshTokenKeyExist(refreshToken)).thenReturn(true);
			String sessionId = UUID.randomUUID().toString();
			when(session.getId()).thenReturn(sessionId);			

			// --- ACTION -- //
			UserDetails user = securityService.getUserDetails(auth, refreshToken);

			// --- TEST -- //
			verify(redisCacheService).isRefreshTokenKeyExist(refreshToken);

			assertThat(user, is(auth.getPrincipal()));
			assertThat(user.getState(), is(auth.getPrincipal().getState()));
		}

		@Test
		@DisplayName("Utilisateur non trouvé")
		void testGetUserConnectedNotFound() {
			// --- CONFIG -- //
			String refreshToken = UUID.randomUUID().toString();
			when(redisCacheService.isRefreshTokenKeyExist(refreshToken)).thenReturn(true);
			String sessionId = UUID.randomUUID().toString();
			when(session.getId()).thenReturn(sessionId);

			// --- ACTION -- //
			UserDetails user = securityService.getUserDetails(null, refreshToken);

			// --- TEST -- //
			verify(redisCacheService).isRefreshTokenKeyExist(refreshToken);

			assertThat(user.getId(), nullValue());
			assertThat(user.getFpLabel(), nullValue());
			assertThat(user.getState(), is(DigestUtils.sha256Hex(sessionId)));
		}
		
		@Test
		@DisplayName("Refresh token non trouvé")
		void testGetUserConnectedRefreshTokenNotFound() {
			// --- CONFIG -- //
			String refreshToken = UUID.randomUUID().toString();
			when(redisCacheService.isRefreshTokenKeyExist(refreshToken)).thenReturn(false);
			String sessionId = UUID.randomUUID().toString();
			when(session.getId()).thenReturn(sessionId);

			// --- ACTION -- //
			UserDetails user = securityService.getUserDetails(null, refreshToken);

			// --- TEST -- //
			verify(redisCacheService).isRefreshTokenKeyExist(refreshToken);
			verify(session).invalidate();

			assertThat(user.getId(), nullValue());
			assertThat(user.getFpLabel(), nullValue());
			assertThat(user.getState(), is(DigestUtils.sha256Hex(sessionId)));
		}		
	}

    
    @Test
    void testDummy() throws ApiException {
        // --- CONFIG -- //
        System.out.println(getPublicKey(rsaKey1));
        System.out.println(generateIdToken(clientId, rsaKey1));
        System.out.println(generateLogoutToken(clientId, rsaKey1));
    }
    
	private OAuthToken getOAuthToken(String audience, RsaJsonWebKey rsaKey) {
		OAuthToken oAuthToken = new OAuthToken();

		oAuthToken.setAccessToken("access_token");

		oAuthToken.setExpiresIn(540);

		oAuthToken.setIdToken(generateIdToken(audience, rsaKey));

		oAuthToken.setRefreshToken("25238ced-0725-4d20-bbfd-d0559eb1f84a");
		oAuthToken.setType("Bearer");
		return oAuthToken;
	}

	private String getPublicKey(RsaJsonWebKey rsaKey) {
		return "{'keys':[" + rsaKey.toJson() + "]}";
	}

	private RsaJsonWebKey getRSAKey(String keyId) {
		RsaJsonWebKey rsaJsonWebKey;
		try {
			rsaJsonWebKey = RsaJwkGenerator.generateJwk(2048);

			rsaJsonWebKey.setKeyId(keyId);
			rsaJsonWebKey.setAlgorithm(AlgorithmIdentifiers.RSA_USING_SHA256);
			
			return rsaJsonWebKey;
		} catch (JoseException e) {
			fail();
			return null;
		}
	}

	private String generateIdToken(String audience, RsaJsonWebKey rsaKey) {

		JwtClaims claims = new JwtClaims();
		claims.setIssuer("sender");
		claims.setAudience(audience);
		claims.setExpirationTimeMinutesInTheFuture(525600);
		claims.setGeneratedJwtId();
		claims.setIssuedAtToNow();
		claims.setNotBeforeMinutesInThePast(2);
		claims.setSubject("subject");
		claims.setClaim("sub", "OX60001");
		claims.setClaim("sid", sid);
		
		JsonElement json = JsonParser.parseString(claims.toJson());		
		JsonElement fp = JsonParser.parseString("{\"label\":\"fp\"}");
		json.getAsJsonObject().add("functional_post", fp);

		JsonWebSignature jws = new JsonWebSignature();
		jws.setPayload(json.toString());
		jws.setKey(rsaKey.getPrivateKey());
		jws.setKeyIdHeaderValue(rsaKey.getKeyId());
		jws.setAlgorithmHeaderValue(AlgorithmIdentifiers.RSA_USING_SHA256);

		try {
			return jws.getCompactSerialization();
		} catch (JoseException e) {
			fail();
			return null;
		}
	}
	
	private String generateLogoutToken(String audience, RsaJsonWebKey rsaKey) {

        JwtClaims claims = new JwtClaims();
        claims.setIssuer("http://localhost:8089/authentification_collaborateur/v2");
        claims.setGeneratedJwtId();
        claims.setClaim("sid", sid);
        
        JsonElement json = JsonParser.parseString(claims.toJson());     
        JsonElement events = JsonParser.parseString("{\"http://schemas.openid.net/event/backchannel-logout\":{}}");
        json.getAsJsonObject().add("events", events);
    
        JsonWebSignature jws = new JsonWebSignature();
        jws.setPayload(json.toString());
        jws.setKey(rsaKey.getPrivateKey());
        jws.setKeyIdHeaderValue(rsaKey.getKeyId());
        jws.setAlgorithmHeaderValue(AlgorithmIdentifiers.RSA_USING_SHA256);
    
        try {
            return jws.getCompactSerialization();
        } catch (JoseException e) {
            fail();
            return null;
        }
    }

}
