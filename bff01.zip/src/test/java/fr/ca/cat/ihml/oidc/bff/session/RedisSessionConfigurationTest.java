package fr.ca.cat.ihml.oidc.bff.session;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.mockito.Mockito.when;

import java.time.Duration;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.session.RedisSessionProperties;
import org.springframework.boot.autoconfigure.session.SessionProperties;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.session.FlushMode;
import org.springframework.session.SaveMode;
import org.springframework.session.data.redis.RedisSessionRepository;
import org.springframework.session.data.redis.config.ConfigureRedisAction;
import org.springframework.session.web.http.CookieSerializer;

@DisplayName("RedisSessionConfiguration")
@Tag("Redis")
@Tag("Session")
@Tag("Unit")
@ExtendWith(MockitoExtension.class)
class RedisSessionConfigurationTest {
	
    @Mock
	private SessionProperties sessionProperties;
	
    @Mock
	private CookieSerializerProperties cookieSerializerProperties;

    @Mock
	private RedisSessionProperties redisSessionProperties;

    @Mock
	private ObjectProvider<RedisConnectionFactory> redisConnectionFactory;
    
    @InjectMocks
    private RedisSessionConfiguration redisSessionConfiguration;

	@BeforeEach
	void setUp() throws Exception {
		redisSessionConfiguration = new RedisSessionConfiguration(sessionProperties, redisSessionProperties, redisConnectionFactory, cookieSerializerProperties);
	}

	@Test
	@DisplayName("RessionRedisOperation")
	void testRessionRedisOperations() {
		// ACTION
		RedisTemplate<String, Object> operations = (RedisTemplate<String, Object>) redisSessionConfiguration.sessionRedisOperations();
		
		// TEST
		assertThat(operations.getConnectionFactory(), is(redisConnectionFactory.getObject()));
		assertThat(operations.getHashKeySerializer() instanceof StringRedisSerializer, is(true));
		assertThat(operations.getKeySerializer() instanceof StringRedisSerializer, is(true));
	}
	
	@Test
	@DisplayName("SessionRepository")
	void testSessionRepository() {
		// CONFIG
		when(sessionProperties.getTimeout()).thenReturn(Duration.ofMinutes(1));
		when(redisSessionProperties.getNamespace()).thenReturn("namespace");
		when(redisSessionProperties.getSaveMode()).thenReturn(SaveMode.ON_SET_ATTRIBUTE);
		when(redisSessionProperties.getFlushMode()).thenReturn(FlushMode.IMMEDIATE);
		RedisOperations<String, Object> operations = (RedisTemplate<String, Object>) redisSessionConfiguration.sessionRedisOperations();
		
		// ACTION
		RedisSessionRepository sessionRepository = redisSessionConfiguration.sessionRepository(operations);
		
		// TEST
		assertThat(sessionRepository.getSessionRedisOperations(), is(operations));
	}
	
	@Test
	@DisplayName("CookieSerializer")
	void testCookieSerializer() {
		// CONFIG
		when(cookieSerializerProperties.getDomainPattern()).thenReturn("(.*)");
		when(cookieSerializerProperties.getPath()).thenReturn("/");
		when(cookieSerializerProperties.getSameSite()).thenReturn("Strcit");
		
		// ACTION
		CookieSerializer cookieSerializer = redisSessionConfiguration.cookieSerializer();
		
		// TEST
		assertThat(cookieSerializer, notNullValue());
	}
	
	@Test
	void testConfigureRedisAction() {		
		// ACTION
		ConfigureRedisAction redisAction = RedisSessionConfiguration.configureRedisAction();
		
		// TEST
		assertThat(redisAction, is(ConfigureRedisAction.NO_OP));
	}

}
