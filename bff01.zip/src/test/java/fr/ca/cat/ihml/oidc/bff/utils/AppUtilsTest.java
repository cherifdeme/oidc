package fr.ca.cat.ihml.oidc.bff.utils;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.oneOf;
import static org.junit.Assert.assertNull;

import java.io.IOException;
import java.util.Map;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;

import fr.ca.cat.ihml.oidc.bff.models.manifest.ApplicationManifest;

@DisplayName("AppUtils")
@Tag("Utils")
@Tag("Unit")
@ExtendWith(MockitoExtension.class)
class AppUtilsTest {
	
	@Test
	@DisplayName("Convertion objet en strig json")
	void testConvertObjectToJsonString() throws JsonProcessingException {
		// -- CONFIG -- //
		ApplicationManifest applicationManifest = new ApplicationManifest();
		applicationManifest.setFramework("framework");
		applicationManifest.setVersion("version");
		
		// --- ACTION -- //
		String jsonString = AppUtils.convertObjectToJsonString(applicationManifest);
		
		// --- TEST -- //
		// Value
		assertThat(jsonString, is(oneOf(
				"{\r\n  \"version\" : \"version\",\r\n  \"framework\" : \"framework\"\r\n}",
				"{\n  \"version\" : \"version\",\n  \"framework\" : \"framework\"\n}"
		)));
	}
	
	@Test
	@DisplayName("Convertion objet en string json objet null")
	void testConvertObjectToJsonStringNullObject() throws JsonProcessingException {
		// --- ACTION -- //
		String jsonString = AppUtils.convertObjectToJsonString(null);
		
		// --- TEST -- //
		// Value
		assertNull(jsonString);
	}
	
	@Test
	@DisplayName("Convertion json en objet")
	void testJsonStringToObject() throws IOException {
		// -- CONFIG -- //
		
		// --- ACTION -- //
		ApplicationManifest applicationManifest = AppUtils.jsonStringToObject("{\"version\" : \"version\", \"framework\" : \"framework\"}", new TypeReference<ApplicationManifest>() {
        });
		
		// --- TEST -- //
		// Value
		assertThat(applicationManifest.getFramework(), is("framework"));
		assertThat(applicationManifest.getVersion(), is("version"));
	}
	
	@Test
	@DisplayName("Convertion json en objet json null")
	void testJsonStringToObjectNullObject() throws IOException {
		// --- ACTION -- //
		ApplicationManifest applicationManifest = AppUtils.jsonStringToObject(null, new TypeReference<ApplicationManifest>() {
        });
		
		// --- TEST -- //
		// Value
		assertNull(applicationManifest);
	}
	
	@Test
	@DisplayName("Prettify json")
	void testPrettifyJsonString() throws IOException {
		// -- CONFIG -- //
		
		// --- ACTION -- //
		String jsonString = AppUtils.prettifyJsonString("{\"version\" : \"version\", \"framework\" : \"framework\"}");
		
		// --- TEST -- //
		// Value
		assertThat(jsonString, is(oneOf(
				"{\r\n  \"version\" : \"version\",\r\n  \"framework\" : \"framework\"\r\n}",
				"{\n  \"version\" : \"version\",\n  \"framework\" : \"framework\"\n}"
		)));
	}
	
	@Test
	@DisplayName("Prettify json objet null")
	void testPrettifyJsonStringNullObject() throws IOException {
		// -- CONFIG -- //
		
		// --- ACTION -- //
		String jsonString = AppUtils.prettifyJsonString(null);
		
		// --- TEST -- //
		// Value
		assertNull(jsonString);
	}
	
	@Test
	@DisplayName("Objet en map")
	void testObjectToMap() throws IOException {
		// -- CONFIG -- //
		ApplicationManifest applicationManifest = new ApplicationManifest();
		applicationManifest.setFramework("framework");
		applicationManifest.setVersion("version");
		
		// --- ACTION -- //
		Map<String, Object> mapObject = AppUtils.objectToMap(applicationManifest);
		
		// --- TEST -- //
		// Value
		assertThat(mapObject.get("framework"), is("framework"));
		assertThat(mapObject.get("version"), is("version"));
		assertNull(mapObject.get("dummy"));
	}

	@Test
	@DisplayName("Construction cookie basic")
	void testBuildCookieBasic() {
		// --- CONFIG -- //
		String cookieName = "cookieName";
		String cookieValue = "cookieValue";
		String domain = "domain";
		String path = "path";
		String sameSite = "None";
		boolean expired = false;
		
		// --- CONFIG -- //		
		String cookieString = AppUtils.buildCookie(cookieName, cookieValue, domain, path, true, sameSite, expired);
		
		// --- TEST -- //
		// Value
		assertThat(cookieString, is(String.format("%s=%s; domain=%s; path=%s; HttpOnly; Secure; SameSite=%s", cookieName, cookieValue, domain, path, sameSite)));
	}
	
	@Test
	@DisplayName("Construction cookie no Lax")
	void testBuildCookieNoLax() {
		// --- CONFIG -- //
		String cookieName = "cookieName";
		String cookieValue = "cookieValue";
		String domain = "domain";
		String path = "path";
		boolean expired = false;
		
		// --- CONFIG -- //		
		String cookieString = AppUtils.buildCookie(cookieName, cookieValue, domain, path, true, null, expired);
		
		// --- TEST -- //
		// Value
		assertThat(cookieString, is(String.format("%s=%s; domain=%s; path=%s; HttpOnly; Secure; SameSite=Lax", cookieName, cookieValue, domain, path)));
	}
	
	@Test
	@DisplayName("Construction cookie expiré")
	void testBuildCookieExpired() {
		// --- CONFIG -- //
		String cookieName = "cookieName";
		String cookieValue = "cookieValue";
		String domain = "domain";
		String path = "path";
		String sameSite = "None";
		boolean expired = true;
		
		// --- ACTION -- //		
		String cookieString = AppUtils.buildCookie(cookieName, cookieValue, domain, path, true, sameSite, expired);
		
		// --- TEST -- //
		// Value
		assertThat(cookieString, is(String.format("%s=%s; domain=%s; path=%s; HttpOnly; Secure; SameSite=%s; Max-Age=0; Expires=Thu, 1 Jan 1970 00:00:00 GMT", cookieName, cookieValue, domain, path, sameSite)));
	}
	
	@Test
	@DisplayName("Construction cookie domaine vide ou null")
	void testBuildDomainEmptyorNull() {
		// --- CONFIG -- //
		String cookieName = "cookieName";
		String cookieValue = "cookieValue";
		String domain = "";
		String path = "path";
		String sameSite = "None";
		boolean expired = false;
		
		// --- ACTION -- //		
		String cookieString = AppUtils.buildCookie(cookieName, cookieValue, domain, path, true, sameSite, expired);
		String cookieString2 = AppUtils.buildCookie(cookieName, cookieValue, null, path, true, sameSite, expired);
		
		// --- TEST -- //
		// Value
		assertThat(cookieString, is(String.format("%s=%s; path=%s; HttpOnly; Secure; SameSite=%s", cookieName, cookieValue, path, sameSite)));
		assertThat(cookieString2, is(String.format("%s=%s; path=%s; HttpOnly; Secure; SameSite=%s", cookieName, cookieValue, path, sameSite)));
	}
	
	@Test
	@DisplayName("Construction cookie path vide ou null")
	void testBuildPathEmptyorNull() {
		// --- CONFIG -- //
		String cookieName = "cookieName";
		String cookieValue = "cookieValue";
		String domain = "domain";
		String path = "";
		String sameSite = "None";
		boolean expired = false;
		
		// --- ACTION -- //		
		String cookieString = AppUtils.buildCookie(cookieName, cookieValue, domain, path, true, sameSite, expired);
		String cookieString2 = AppUtils.buildCookie(cookieName, cookieValue, domain, null, true, sameSite, expired);
		
		// --- TEST -- //
		// Value
		assertThat(cookieString, is(String.format("%s=%s; domain=%s; HttpOnly; Secure; SameSite=%s", cookieName, cookieValue, domain, sameSite)));
		assertThat(cookieString2, is(String.format("%s=%s; domain=%s; HttpOnly; Secure; SameSite=%s", cookieName, cookieValue, domain, sameSite)));
	}
	
	@Test
	@DisplayName("Construction cookie samesite vide ou null")
	void testBuildSameSiteEmptyorNull() {
		// --- CONFIG -- //
		String cookieName = "cookieName";
		String cookieValue = "cookieValue";
		String domain = "domain";
		String path = "path";
		String sameSite = "";
		boolean expired = false;
		
		// --- ACTION -- //		
		String cookieString = AppUtils.buildCookie(cookieName, cookieValue, domain, path, true, sameSite, expired);
		String cookieString2 = AppUtils.buildCookie(cookieName, cookieValue, domain, path, true, null, expired);
		
		// --- TEST -- //
		// Value
		assertThat(cookieString, is(String.format("%s=%s; domain=%s; path=%s; HttpOnly; Secure; SameSite=Lax", cookieName, cookieValue, domain, path)));
		assertThat(cookieString2, is(String.format("%s=%s; domain=%s; path=%s; HttpOnly; Secure; SameSite=Lax", cookieName, cookieValue, domain, path)));
	}

	@Test
	@DisplayName("Ofuscation UUID")
	void testObfuscateUUIDString() {
		// --- ACTION -- //
		String uuid = "60ccdffb-ba0f-4012-ab72-9e9683d51673";
		String obfuscate = AppUtils.obfuscateUUIDString(uuid);
		
		// --- TEST -- //
		// Value
		assertThat(obfuscate, is("60ccdffb-ba0f-40XXXXX"));
	}

}
