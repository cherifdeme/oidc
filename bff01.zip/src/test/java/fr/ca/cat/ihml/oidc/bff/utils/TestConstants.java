package fr.ca.cat.ihml.oidc.bff.utils;

public class TestConstants {
	// AZ Code
	public static String AZ_CODE_GOOD = "dd6df8a8-368b-42ba-b180-a9eb2fa58346";
	public static String AZ_CODE_BAD = "6ea9f8c6-ba1d-4de8-873d-287c6963f39a";

}
