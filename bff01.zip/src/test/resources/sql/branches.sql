CREATE TABLE Branches (
  Id INTEGER NOT NULL AUTO_INCREMENT,
  Groupe varchar(50) NOT NULL,
  Application varchar(50) NOT NULL,
  Eds varchar(12) DEFAULT NULL,
  Poste varchar(20) DEFAULT NULL,
  Cr varchar(10) DEFAULT NULL,
  Branche varchar(200) NOT NULL,
  PRIMARY KEY (Id)
);

INSERT INTO Branches (Id,Groupe,Application,Eds,Poste,Cr,Branche) VALUES 
(2,'UA','S0528',NULL,NULL,NULL,'r1-s0528-ua.p0072-uat')
,(42513,'UA','S0188',NULL,NULL,NULL,'r1-s0188-ua.p0025-uat')
,(156574,'UA','S0612',NULL,NULL,NULL,'r1-s0612-ua.p0043-uat')
,(166096,'UA','TEST1',NULL,NULL,NULL,'r2-s0550-wiremock.p0042-uat/default')
,(166097,'UA','TEST1',NULL,NULL,'88200','r2-s0550-wiremock.p0042-uat/cr')
,(166101,'UA','TEST1',NULL,'XAZQT0016001',NULL,'r2-s0550-wiremock.p0042-uat/posteop')
,(168889,'UA','S0184',NULL,NULL,NULL,'r1-s0184-ua.p0022-uat')
,(208663,'UA','S0662',NULL,NULL,NULL,'r1-s0662-ua.p0033-uat')
,(211880,'SRV','TEST1',NULL,NULL,NULL,'r2-s1134-wiremock.p0039-uat/default')
,(211881,'SRV','TEST1',NULL,NULL,'88200','r2-s1134-wiremock.p0039-uat/cr')
;
INSERT INTO Branches (Id,Groupe,Application,Eds,Poste,Cr,Branche) VALUES 
(211882,'SRV','TEST1',NULL,'XAZQT0016001',NULL,'r2-s1134-wiremock.p0039-uat/posteop')
,(212775,'UA','S1813',NULL,NULL,NULL,'r1-s1813-ua.p0277-uat')
,(224853,'UA','S0776',NULL,NULL,NULL,'r1-s0776-ua.p0197-uat')
,(225793,'UA','S1520',NULL,NULL,NULL,'r1-s1520-ua.p0157-uat')
,(225794,'UA','S1522',NULL,NULL,NULL,'r1-s1522-ua.p0158-uat')
,(225795,'UA','S1653',NULL,NULL,NULL,'r1-s1653-ua.p0157-uat')
,(225947,'UA','S1654',NULL,NULL,NULL,'r1-s1654-ua.p0161-uat')
,(226621,'UA','S1631',NULL,NULL,NULL,'r1-s1631-ua.p0429-uat')
,(229407,'UA','S0160',NULL,NULL,NULL,'r1-s0160-ua.p0048-uat')
,(230113,'SRV','services',NULL,NULL,NULL,'zur10-medsmedc.ca-technologies.fr')
;
INSERT INTO Branches (Id,Groupe,Application,Eds,Poste,Cr,Branche) VALUES 
(230114,'SRV','services',NULL,NULL,'87800','zur20-medsmedc.ca-technologies.fr')
,(230115,'SRV','services',NULL,NULL,'86800','zur30-medsmedc.ca-technologies.fr')
;