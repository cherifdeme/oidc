# Application blanche - Front End Angular

Ce projet contient les sources Front End Angular de l'application blanche de la filière IHM Light

## Wiki
Un wiki d'explication de la filière est présent à cette endroit: [Wiki IHM Light](https://ttp10-pord.ca-technologies.fr/xwiki/bin/view/Filieres%20de%20developpement/Frontend/IHM%20Light/)

## Releases
### 2.5.0
* Suppression PF

### 2.2.1

* Modification du bouton "ouvrir une application avec transfert de contexte", qui redirige vers l'application de formation s2156
* Mise à jour de l'image Debian

### 2.2.0

* Montée de version Angular 14
* Mise à jour des dépendances

### 2.1.8

* Ajout démonstration utilisation base de données
* Ajout de bouton de déconnexion application et simulation déconnexion portail
* Ajout redirection vers la mire si erreur 401

### 2.1.7

* Ajout cinématique Back Channel Logout avec properties


### 2.1.6

* Traitement retour audit de sécurité


### 2.1.5

* Amelioration de la gestion token csrf pour authentification avec la mire X Connect


### 2.1.4

* Mise en place token csrf pour authentification avec la mire X Connect
* Ajout de l'url swagger sur la page d'accueil

### 2.1.3

* Initialisation du read me du projet
* Contient la démonstration des patterns
    * Connexion à une application
    * Déconnexion d'une application
    * Persistance de session
    * Appel d'API
    * Transfert de contexte
    * Traçabilité et log
