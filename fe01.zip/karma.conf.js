// Karma config file, see link for more information
// https://karma-runner.github.io/1.0/config/configuration-file.html

module.exports = function (config) {
  config.set({
    basePath: '',
    frameworks: ['jasmine', '@angular-devkit/build-angular'],
    plugins: [
      require('karma-jasmine'),
      require('karma-chrome-launcher'),
      require('karma-jasmine-html-reporter'),
      require('karma-coverage'),
      require('karma-junit-reporter'),
      require('karma-sonarqube-unit-reporter'),
      require('@angular-devkit/build-angular/plugins/karma')
    ],
    client: {
      clearContext: false // leave Jasmine Spec Runner output visible in browser
    },
    jasmineHtmlReporter: {
      suppressAll: true // removes the duplicated traces
    },
    coverageReporter: {
      dir: require('path').join(__dirname, './coverage'),
      subdir: '.',
      reporters: [
        { type: 'html' },
        { type: 'text-summary', file: 'text-summary.txt' },
        { type: 'cobertura' }, // couverture à publier dans GitLab
        { type: 'lcovonly' } // couverture à publier dans SonarQube
      ]
    },
    junitReporter: { // résultat de tests à publier dans GitLab
      outputDir: './tests',
      outputFile: 'junit-test-results.xml',
      useBrowserName: false,
    },
    sonarQubeUnitReporter: { // résultat de tests à publier dans GitLab
      sonarQubeVersion: 'LATEST',
      outputFile: 'tests/junit-test-results-sonarqube.xml',
      overrideTestDescription: true,
      testPaths: ['./src'],
      testFilePattern: '.spec.ts', // Attention bien spécifier cette option sinon le rapport n'a pas le champ "path" en mode fullPath (qui est demandé par sonar)
      useBrowserName: false
    },
    reporters: ['progress', 'kjhtml', 'junit', 'sonarqubeUnit'],
    port: 9876,
    colors: true,
    logLevel: config.LOG_INFO,
    autoWatch: true,
    retryLimit: 5,
    browsers: ["ChromeHeadlessNoSandbox"],
    customLaunchers: {
      ChromeHeadlessNoSandbox: {
        base: "ChromeHeadless",
        browserDisconnectTimeout: 10000,
        browserDisconnectTolerance: 3,
        browserNoActivityTimeout: 60000,
        flags: [
          "--headless",
          "--disable-gpu",
          "--disable-translate",
          "--disable-extensions",
          "--no-sandbox",
        ],
      },
    },
    singleRun: true,
  });
};
