import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { ContainerComponent } from './components/container/container.component';
import { HomeComponent } from './components/home/home.component';
import { AuthGuard } from './auth/auth.guard';
import { ErrorComponent } from './components/error/error.component';
import { ProfileComponent } from './components/profile/profile.component';
import { AuthorizeComponent } from './components/authorize/authorize.component';

/**
 * Tableau de routage de l'application
 */
const routes: Routes = [
  {
    path: '',
    children: [
      { path: '', redirectTo: '/home', pathMatch: 'full' },
      { path: 'authorize', component: AuthorizeComponent },
      { path: 'error', component: ErrorComponent },
      { path: 'profile', component: ProfileComponent },
      {
        path: 'home',
        component: HomeComponent,
        canActivate: [AuthGuard],
        data: { isSecure: true },
      },
      // Redirection à la page d'accueil si la route demandé n'existe pas
      { path: '**', redirectTo: '/home' },
    ],
    component: ContainerComponent,
  },
];

/**
 * Module de routage des urls de l'application
 */
@NgModule({
  declarations: [],
  imports: [CommonModule, RouterModule.forRoot(routes, { useHash: false })],
  exports: [RouterModule],
})
export class AppRoutingModule {}
