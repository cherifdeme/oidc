import { Component } from '@angular/core';
import { OIDCService } from './services/oidc.service';

/**
 * Composant principale de l'application
 */
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  loaded: Promise<boolean>;
  constructor(private oidcService: OIDCService) {
    this.oidcService.controlToken().subscribe((response: any) => {
      if (response.status === 403) {
        const message = {
          version: 1,
          message_type: 'end_failure',
          failure_detail: {
            id: 'mockFailure',
            exception_type: 'Business',
            label: response.message,
            criticite: 2,
            errors_list: [],
          },
        };
        window.parent.postMessage(JSON.stringify(message), '*');
      }
      this.loaded = Promise.resolve(true);
    });
  }
}
