import { HttpClientModule } from '@angular/common/http';
import { ErrorHandler, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import {MatCheckboxModule} from '@angular/material/checkbox';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { LoggerModule, NgxLoggerLevel } from 'ngx-logger';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthGuard } from './auth/auth.guard';
import { AuthorizeComponent } from './components/authorize/authorize.component';
import { ContainerComponent } from './components/container/container.component';
import { ProfileComponent } from './components/profile/profile.component';
import { ErrorComponent } from './components/error/error.component';
import { HomeComponent } from './components/home/home.component';
import { GlobalErrorHandler } from './handlers/global-error.handler';
import {
  appConfigurationProvider,
  requestInterceptorProvider,
} from './providers/app.provider';
import { AppEffectsModule } from './redux/effects/app.effects';
import { AppReduxModule } from './redux/modules/appredux.module';
import { AppInitService } from './services/app-init.service';
import { AuthService } from './services/auth.service';
import { ContextService } from './services/context.service';
import { HttpService } from './services/http.service';
import { LogService } from './services/log.service';
import { OIDCService } from './services/oidc.service';
import { SecurityService } from './services/security.service';
import { NotificationService } from './services/notification.service';
import { CookieService } from 'ngx-cookie-service';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { ToastrModule } from 'ngx-toastr';

/**
 * Module principal de l'application
 */
@NgModule({
  declarations: [
    AppComponent,
    ContainerComponent,
    AuthorizeComponent,
    HomeComponent,
    ProfileComponent,
    ErrorComponent,
  ],
  imports: [
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    BrowserModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatCheckboxModule,
    MatTableModule,
    MatToolbarModule,
    MatSidenavModule,
    MatButtonModule,
    MatDividerModule,
    FormsModule,
    MatProgressSpinnerModule,
    StoreDevtoolsModule.instrument({
      maxAge: 25,
      logOnly: false,
      features: {
        pause: false,
        lock: true,
        persist: true,
      },
    }),
    AppReduxModule,
    AppEffectsModule,
    AppRoutingModule,
    HttpClientModule,
    LoggerModule.forRoot({
      serverLoggingUrl: null,
      level: NgxLoggerLevel.INFO,
      serverLogLevel: NgxLoggerLevel.OFF,
      disableConsoleLogging: false,
    }),
  ],
  providers: [
    AppInitService,
    appConfigurationProvider,
    requestInterceptorProvider,
    AuthGuard,
    HttpService,
    NotificationService,
    AuthService,
    LogService,
    SecurityService,
    OIDCService,
    ContextService,
    CookieService,
    { provide: ErrorHandler, useClass: GlobalErrorHandler },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
