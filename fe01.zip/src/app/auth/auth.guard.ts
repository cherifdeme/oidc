import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, RouterStateSnapshot } from '@angular/router';
import * as _ from 'lodash';
import Constants from '../../const';
import { getPathInfos } from '../../utils';
import { AuthService } from '../services/auth.service';

/**
 * Guard pour sécurisé les pages
 */
@Injectable()
export class AuthGuard implements CanActivate {

    constructor(
        private authService: AuthService
    ) { }
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
        // Récupération des paramètres de la requête
        const queryParamsMap = getPathInfos(location.search).searchParams;

        // Sauvegarde canal si présent
        if (_.has(queryParamsMap, Constants.ROUTES.PARAMS.CANAL) && _.includes(["INTER", "INTRA"], queryParamsMap[Constants.ROUTES.PARAMS.CANAL])) {
            this.authService.storeCanal(queryParamsMap[Constants.ROUTES.PARAMS.CANAL]);
        }

        // Test si on n'a pas de context Id et si la route demandée n'est pas sécurisée
        const noContextNoSecure = !route.data.isSecure && !_.has(queryParamsMap, Constants.ROUTES.PARAMS.ID_CONTEXT);
        if (this.authService.authenticated || noContextNoSecure) {
            // si on est authentifié ou si on n'a pas besoin de sécurité. On donne accès à la page
            return true;
        } else {
            // Si ce n'est pas le cas on demande à effectué la cinématique de login
            this.authService.login(state.url);
            return false;
        }
    }
}
