import { Component, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { Evenement, Message, MessageType } from '../../models/postmessage';
import { AppState } from '../../redux/state/app.state';
import * as PostMessageSelectors from '../../redux/selectors/pm.selector';


/**
 * Composant pour démontrer la gestion des post messages
 */
@Component({
    selector: 'app-com-post-message',
    templateUrl: './com-post-message.component.html',
    styleUrls: ['./com-post-message.component.scss']
})
export class ComPostMessageComponent implements OnInit {

    // Redux Variable
    ELEMENT_DATAS: Message[] = [];

    // Inner variable
    inputData = '';
    selectedMessageType: string = null;
    versionMessageType = '1';
    selectedEventId: string = null;

    // Listener manager
    subs = [];

    // Mat table
    displayedColumns: string[] = ['eventId', 'messageType', 'version', 'data'];

    messageTypes: MessageType[] = [
        { name: 'FunctionalEvent', version: '1' },
        { name: 'EndSuccess', version: '1' }

    ];

    evenements: Evenement[] = [
        { eventId: 'other' },
        { eventId: 'loadUa' }

    ];

    constructor(private store: Store<AppState>) { }

    ngOnInit() {
        this.inputData = JSON.stringify({ 'idUa': 'RIBC' })
        this.subs.push(this.store.pipe(select(PostMessageSelectors.selectMessages)).subscribe((listMessage: Message[]) => {
            if (listMessage.length > 0) {
                this.ELEMENT_DATAS = listMessage;
            }
        }));

    }

    /**
     * Listener appelé lors du click sur le bouton pour envoyer le message
     */
    onClick() {
        const message: Message = {
            data: this.inputData,
            eventId: this.selectedEventId,
            messageType: this.selectedMessageType,
            version: this.versionMessageType
        };
        window.parent.postMessage(JSON.stringify(message), '*');
    }

    /**
     * Listener appelé lorsque l'on change le type de message
     * @param messageType Le type de message selectionné
     */
    onMTChange(messageType: string) {
        this.selectedMessageType = messageType;
    }

    /**
     * Listener appelé lorsque l'on change l'évènement
     * @param eventId L'évènement selectionné
     */
    onEventChange(eventId: string) {
        this.selectedEventId = eventId;
    }


}
