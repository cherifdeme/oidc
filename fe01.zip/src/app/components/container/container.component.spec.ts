import { TestBed } from '@angular/core/testing';
import { ContainerComponent } from './container.component';

describe('ContainerComponent', () => {

  it('should be equel', () => {
    expect("A").toContain("A");
  });
});
