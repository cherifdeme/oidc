import {
  Component,
  HostListener,
  OnDestroy,
  OnInit,
  ViewChild,
  Injectable,
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import * as _ from 'lodash';
import { ManifestState } from 'src/app/redux/state/manifest.state';
import Constants from '../../../const';
import { environment } from '../../../environments/environment';
import { User } from '../../models/user';
import * as ContextActions from '../../redux/actions/context.actions';
import * as UIActions from '../../redux/actions/ui.actions';
import * as ManifestSelectors from '../../redux/selectors/manifest.selector';
import * as UserSelectors from '../../redux/selectors/session.selector';
import * as UISelectors from '../../redux/selectors/ui.selector';
import { AppState } from '../../redux/state/app.state';
import { AuthService } from '../../services/auth.service';
import { BreakpointObserver } from '@angular/cdk/layout';
import { MatSidenav } from '@angular/material/sidenav';

/**
 * Composant principal englobant tous les autres
 */
@Component({
  selector: 'app-container',
  templateUrl: './container.component.html',
  styleUrls: ['./container.component.scss'],
})
@Injectable()
export class ContainerComponent implements OnInit, OnDestroy {
  // Redux Variable
  title: string;
  backgroundColor: string;
  user: User;
  activeMenu = Constants.MENUS.HOME;
  manifest: ManifestState;
  message: any;
  // Inner variable
  userLoggedIn = false;
  idCtx = null;
  envLoaded = false;

  // Listener manager
  subs = [];
  @ViewChild('sidenav', { static: false }) sidenav: MatSidenav;
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private authService: AuthService,
    private store: Store<AppState>,
    private observer: BreakpointObserver
  ) {
    this.route.params.subscribe((params) => {
      if (params['accountid']) {
        console.log(params['accountid']); // use it where you need
      }
    });
  }

  ngOnInit() {
    // Initialisation redux
    this.subs.push(
      this.store
        .pipe(select(UISelectors.selectTitle))
        .subscribe((title: string) => {
          this.title = title;
        })
    );
    this.subs.push(
      this.store
        .pipe(select(UISelectors.selectBackgroundColor))
        .subscribe((backgroundColor: string) => {
          this.backgroundColor = backgroundColor;
        })
    );
    this.subs.push(
      this.store
        .pipe(select(UISelectors.selectTab))
        .subscribe((activeMenu: string) => {
          this.activeMenu = activeMenu;
        })
    );
    this.subs.push(
      this.store
        .pipe(select(UserSelectors.selectUser))
        .subscribe((user: User) => {
          this.user = user;
        })
    );
    this.subs.push(
      this.store
        .pipe(select(ManifestSelectors.selectManifestState))
        .subscribe((manifest: ManifestState) => {
          this.manifest = manifest;
        })
    );

    // Récupération des query params
    this.route.queryParamMap.subscribe((params) => {
      this.idCtx = params.get(Constants.ROUTES.PARAMS.ID_CONTEXT) || null;

      // Récupération du context si besoin
      if (!_.isEmpty(this.idCtx)) {
        this.store.dispatch(ContextActions.getContext({ idCtx: this.idCtx }));
      }
    });

    // Selection du menu originel
    this.selectMenuItem();

    // Chargement initial de l'environnement de l'application
    if (!this.envLoaded) {
      this.loadEnvironment();
    }
  }

  /**
   * Appelé lorsque la page n'est plus affichée
   */
  ngOnDestroy() {
    this.subs.forEach((sub) => {
      sub.unsubscribe();
    });
  }

  /**
   * Selection du menu depuis l'url
   */
  selectMenuItem() {
    this.activeMenu = this.router.url.split('/')[1];
  }
  // -----------------
  // Listeners
  // -----------------

  /**
   * Listener pour la selection d'un item de menu
   * @param menuItem Menu selectionné
   */
  onMenuItemClicked(menuItem) {
    this.activeMenu = menuItem;
  }

  /**
   * Listener pour la déconnexion
   */
  onLogoutStda() {
     this.authService.logout(Constants.AUTH.LOGOUT_BCK_CHNL);
  }

  /**
   * Déchargement de la page
   */
  @HostListener('window:beforeunload')
  onBeforeUnload() {
    if (!_.isEmpty(this.user)) {
      // si on est connecté on fait la déconnexion
      console.log('BeforeUnload:logoff');
      navigator.sendBeacon(`${environment.apiBasePath}/security/logout`);
    }
  }
  ngAfterViewInit() {
    this.observer.observe(['(max-width: 900px)']).subscribe((res) => {
      if (res.matches) {
        this.sidenav.mode = 'over';
        this.sidenav.close();
      } else {
        this.sidenav.mode = 'side';
        this.sidenav.open();
      }
    });
  }

  // -----------------
  // Api
  // -----------------

  /**
   * Chargement de l'environnement de l'application
   */
  loadEnvironment() {
    // Récupération du titre de l'application depuis la configuration
    this.store.dispatch(UIActions.setTitle({ title: environment.title }));

    // Récupération du background du bandaeu de navigation de l'application depuis la configuration
    this.store.dispatch(
      UIActions.setBackgroundColor({
        backgroundColor: environment.backgroundColor,
      })
    );
    this.envLoaded = true;
  }
}
