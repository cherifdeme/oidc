import { Component, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { Branches, Caisses } from 'src/app/models/database';
import { AppState } from '../../redux/state/app.state';
import * as DatabaseSelector from '../../redux/selectors/database.selector';
import * as DatabaseActions from '../../redux/actions/database.actions';
import * as _ from 'lodash';

/**
 * Composant affichant l'onglet Accueil
 */
@Component({
    selector: 'app-database',
    templateUrl: './database.component.html',
    styleUrls: ['./database.component.scss']
})
export class DatabaseComponent implements OnInit {
    // inner variables
    application : string;
    listCaisses: Caisses[] = [];
    listBranches: Branches[] = [];
    inputErrorDisplay: boolean = false;

    TABLE_DISPLAY: any = {
        CAISSES: 'CAISSES',
        BRANCHES: 'BRANCHES'
    }

    tableDisplayed: string;
    displayedColumns: string[] = []


    // Listener manager
    subs = [];

    constructor(private store: Store<AppState>) {
        this.tableDisplayed = this.TABLE_DISPLAY.CAISSES;
     }

    ngOnInit() {
        // Initialisation redux
        this.subs.push(this.store.pipe(select(DatabaseSelector.selectCaisses)).subscribe((listCaisses: Caisses[]) => {
            this.listCaisses = listCaisses;
        }));
        this.subs.push(this.store.pipe(select(DatabaseSelector.selectBranches)).subscribe((listBranches: Branches[]) => {
            this.listBranches = listBranches;
        }));
    }

    // -----------------
    // Listeners
    // -----------------

    onApplicationChange(application: string) {
        this.application = application;
    }

    onSearchCaisses() {
        this.inputErrorDisplay = false;
        if (_.isEmpty(this.application)) {
            this.inputErrorDisplay = true;
        } else {
            this.displayedColumns = ['application', 'codeCr', 'branche', 'poste'];
            this.tableDisplayed = this.TABLE_DISPLAY.CAISSES
            this.store.dispatch(DatabaseActions.getCaisses({ application: this.application }));
        }
    }

    onSearchBranches() {
        this.inputErrorDisplay = false;
        if (_.isEmpty(this.application)) {
            this.inputErrorDisplay = true;
        } else {
            this.displayedColumns = ['application', 'cr', 'branche', 'poste'];
            this.tableDisplayed = this.TABLE_DISPLAY.BRANCHES
            this.store.dispatch(DatabaseActions.getBranches({ application: this.application }));
        }
    }

}
