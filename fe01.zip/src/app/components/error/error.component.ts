import { Component, OnInit } from "@angular/core";
import { select, Store } from "@ngrx/store";
import { AppState } from "src/app/redux/state/app.state";
import { AuthService } from "src/app/services/auth.service";
import Constants from "src/const";
import * as UISelectors from "../../redux/selectors/ui.selector";
import { Action, UIError } from "../../redux/state/ui.state";

/**
 * Composant affiché lorsqu'un erreur intervient dans l'application
 */
@Component({
  selector: "app-error",
  templateUrl: "./error.component.html",
  styleUrls: ["./error.component.scss"],
})
export class ErrorComponent implements OnInit {
  // Redux variable
  lastError: UIError;

  // Listener manager
  subs = [];

  constructor(
    private authService: AuthService,
    private store: Store<AppState>
  ) {}

  ngOnInit() {
    // Initialisation redux
    this.subs.push(
      this.store
        .pipe(select(UISelectors.selectLastError))
        .subscribe((lastError: UIError) => {
          this.lastError = lastError;
        })
    );
  }

  // Listener
  onErrorActionClick() {
    if (this.lastError.errorAction.action === Action.Deconnexion) {
      this.authService.logout(Constants.AUTH.LOGOUT_STDA);
    }
  }
}
