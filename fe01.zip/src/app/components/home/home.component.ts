import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import Constants from '../../../const';
import { select, Store } from '@ngrx/store';
import { AppState } from '../../redux/state/app.state';
import * as UIActions from '../../redux/actions/ui.actions';
import { ManifestState } from '../../redux/state/manifest.state';
import * as ManifestSelectors from '../../redux/selectors/manifest.selector';
import { MessageType, Alert } from '../../models/postmessage';
import { ContainerComponent } from '../container/container.component';
import { NotificationService } from '../../services/notification.service';
import { OIDCService } from '../../services/oidc.service';
import { HttpResponse } from '@angular/common/http';

/**
 * Composant affichant l'onglet Accueil
 */
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  @ViewChild('messageText', { static: true }) messageText: ElementRef;
  
  // Redux Variable
  manifest: ManifestState;
  secure = false;
  userInfos: any;

  // Inner varialbe
  swaggerUrl: string;
  toaterMessage: String;

  subs = [];

  messageTypes: MessageType[] = [
    { name: 'end_success', version: '1' },
    { name: 'end_failure', version: '1' },
    { name: 'end_abort', version: '1' },
    { name: 'step_begin', version: '1' },
    { name: 'step_end', version: '1' },
    { name: 'window_active', version: '1' },
    { name: 'functional_event', version: '1' },
    { name: 'send_help_id', version: '1' },
    { name: 'iframe_resize', version: '1' },
  ];

  ALERTS: Alert[] = [
    {
      type: 'success',
      message: 'This is an success alert',
    },
    {
      type: 'info',
      message: 'This is an info alert',
    },
  ];
  message: any;

  constructor(
    private store: Store<AppState>,
    public user: ContainerComponent,
    private notifyService: NotificationService,
    private oidcService: OIDCService
  ) {}

  ngOnInit() {
    this.message = new Object();

    // Initialisation redux
    this.subs.push(
      this.store
        .pipe(select(ManifestSelectors.selectManifestState))
        .subscribe((manifest: ManifestState) => {
          this.manifest = manifest;
        })
    );
    // Spécifie que l'onglet Home a été clické
    this.store.dispatch(
      UIActions.setActiveMenu({ activeMenu: Constants.MENUS.HOME })
    );
  }

  /**
   * Listener appelé lors du click sur le bouton pour envoyer le message
   */
  onClick() {
    if (this.messageText.nativeElement.value === '') {
      this.notifyService.showError('le message est vide!', 'Erreur de saisie');
    } else {
      window.parent.postMessage(this.messageText.nativeElement.value, '*');
      this.notifyService.showSuccess(
        'Message envoyé avec succes !',
        'Confirmation'
      );
    }
  }
/*
*listener du checkbox, appelle le service de chiffrement du message
*/
  onChangeCheckBox(){
    if (this.messageText.nativeElement.value !== '') {
        const json = JSON.parse(this.messageText.nativeElement.value);

      if(json.data !== undefined && this.secure){
        this.getEncryptedMessage(json);
      }
      else if(!this.secure){
        delete json.data['secure_content'];
        this.messageText.nativeElement.value = JSON.stringify(json);
      }
    } 
  }

/**
 *listener du checkbox, appelle le service de chiffrement du message
 */
  getEncryptedMessage(json: any){
    this.oidcService.encryptSecureData({'message': json.data.content}).subscribe((response: HttpResponse<any>) => {
      json.data.secure_content = response['message'];
      this.messageText.nativeElement.value = JSON.stringify(json);
    });
  }

  /**
   * Listener appelé lorsque l'on change le type de message
   * @param messageType Le type de message selectionné
   */
  onMTChange(messageType: string) {
    this.messageText.nativeElement.value = '';

    switch (messageType) {
      case 'end_failure':
        this.message = {
          version: 1,
          message_type: 'end_failure',
          failure_detail: {
            id: 'mockFailure',
            exception_type: 'Business',
            label: 'pas de bras pas de chocolat',
            criticite: 2,
            errors_list: [],
          },
        };
        break;
      case 'end_success':
        this.message = {
          version: 1,
          message_type: 'end_success',
          data: { version: '001', content: {} },
        };
        break;
      case 'end_abort':
        this.message = {
          version: 1,
          message_type: 'end_abort',
          data: { version: '001', content: {} },
        };
        break;
      case 'step_begin':
        this.message = {
          version: 1,
          message_type: 'step_begin',
          step_id: 'mockStep',
          data: { version: '001', content: {} },
        };
        break;
      case 'step_end':
        this.message = {
          version: 1,
          message_type: 'step_end',
          step_id: 'mockStep',
          data: { version: '001', content: {} },
        };
        break;
      case 'window_active':
        this.message = {
          version: 1,
          message_type: 'window_active',
          data: { version: '001', content: {} },
        };
        break;
      case 'functional_event':
        this.message = {
          version: 1,
          message_type: 'functional_event',
          event_id: 'mockFunctionalEvent',
          data: { version: '001', content: {} },
        };
        break;
      case 'send_help_id':
        this.message = {
          version: 1,
          message_type: 'send_help_id',
          help_id: 'mockHelpId',
        };
        break;
      case 'iframe_resize':
        this.message = {
          version: 1,
          message_type: 'iframe_resize',
          productor_frame_height: 572,
        };
        break;
      default:
        this.message.data = { version: 1, content:{}, correlation_id: '' };
    }

    if(this.secure && this.message.data !== undefined){
      this.getEncryptedMessage(this.message);
    }
    this.messageText.nativeElement.value = JSON.stringify(this.message);
  }
}
