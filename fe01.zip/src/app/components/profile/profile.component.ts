import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import Constants from '../../../const';
import { select, Store } from '@ngrx/store';
import { AppState } from '../../redux/state/app.state';
import * as UIActions from '../../redux/actions/ui.actions';
import { ManifestState } from '../../redux/state/manifest.state';
import * as ManifestSelectors from '../../redux/selectors/manifest.selector';
import { MessageType, Alert } from '../../models/postmessage';
import { ContainerComponent } from '../container/container.component';
import { NotificationService } from '../../services/notification.service';
import { OIDCService } from '../../services/oidc.service';

export interface AdditionalElement {
  name: string;
  value: string;
}

export interface UserInfos {
  uomCode: string;
  userProfile: string;
  additionalElement: AdditionalElement[];
}

/**
 * Composant affichant l'onglet profile
 */
@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss'],
})
export class ProfileComponent implements OnInit {
  @ViewChild('messageText', { static: true }) messageText: ElementRef;

  userInfos: UserInfos = {
    uomCode: '',
    userProfile: '',
    additionalElement: [
      { name: '', value: '' },
      { name: '', value: '' },
      { name: '', value: '' },
    ],
  };

  displayedColumns: string[] = ['name', 'value'];

  // Redux Variable
  manifest: ManifestState;

  // Inner varialbe
  swaggerUrl: string;

  toaterMessage: String;

  subs = [];

  ALERTS: Alert[] = [
    {
      type: 'success',
      message: 'This is an success alert',
    },
    {
      type: 'info',
      message: 'This is an info alert',
    },
  ];

  message: any;

  constructor(
    private store: Store<AppState>,
    public user: ContainerComponent,
    private notifyService: NotificationService,
    private service: OIDCService
  ) {}

  ngOnInit() {
    this.message = new Object();
    // Initialisation redux
    this.subs.push(
      this.store
        .pipe(select(ManifestSelectors.selectManifestState))
        .subscribe((manifest: ManifestState) => {
          this.manifest = manifest;
        })
    );

    // Spécifie que l'onglet Home a été clické
    this.store.dispatch(
      UIActions.setActiveMenu({ activeMenu: Constants.MENUS.HOME })
    );
    this.service.getUserInfos().subscribe((response: any) => {
      if (response !== null) {
        this.userInfos = response;
      }
    });
  }
}
