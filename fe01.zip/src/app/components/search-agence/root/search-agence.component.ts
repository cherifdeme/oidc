import { Component, OnDestroy, OnInit } from '@angular/core';
import { select, Store } from '@ngrx/store';
import * as _ from 'lodash';
import { NGXLogger } from 'ngx-logger';
import Constants from '../../../../const';
import { environment } from '../../../../environments/environment';
import { Context, SavedContext } from '../../../models/context';
import { CR, DistributionEntity, Entity } from '../../../models/places';
import * as ContextActions from '../../../redux/actions/context.actions';
import * as PlacesActions from '../../../redux/actions/places.actions';
import * as UIActions from '../../../redux/actions/ui.actions';
import * as ContextSelectors from '../../../redux/selectors/context.selector';
import * as PlacesSelectors from '../../../redux/selectors/places.selector';
import { AppState } from '../../../redux/state/app.state';
import { ContextService } from '../../../services/context.service';
import { LogService } from '../../../services/log.service';
import { PlatformLocation } from '@angular/common';
/**
 * Composant parent gérant la page d'affichage des agences
 */
@Component({
    selector: 'app-search-agence',
    templateUrl: './search-agence.component.html',
    styleUrls: ['./search-agence.component.scss']
})
export class SearchAgenceComponent implements OnInit, OnDestroy {

    // Inner variable
    listCR: CR[] = [];
    entities: Entity[] = [];
    distributionEntities: DistributionEntity[] = [];
    selectedCR: CR = null;
    selectedEntity: Entity = null;
    context: Context = null;

    // Listener manager
    subs = [];

    constructor(private store: Store<AppState>, 
        private contextService: ContextService, 
        private logger: NGXLogger,
        private logService: LogService,
        private location: PlatformLocation) { }

    ngOnInit() {
        // Spécifie que l'onglet Home a été clické
        this.store.dispatch(UIActions.setActiveMenu({ activeMenu: Constants.MENUS.AGENCES }));

        // Initialisation redux
        this.subs.push(this.store.pipe(select(ContextSelectors.selectContextState)).subscribe((context: Context) => {
            this.context = context;
        }));
        this.subs.push(this.store.pipe(select(PlacesSelectors.selectCRList)).subscribe((listCR: CR[]) => {
            this.listCR = listCR;

            // Si une CR est sélectionnée dans le contexte
            if (!_.isNull(this.context) && !_.isNull(this.context.regional_bank_id)) {
                this.store.dispatch(PlacesActions.selectCRById({ crId: this.context.regional_bank_id }));

                // Récupération de la liste des Entités de la CR sélectionnée
                this.store.dispatch(PlacesActions.getEntitiesList({ selectedCrId: this.context.regional_bank_id }));

                // Reset de la CR dans le context
                this.store.dispatch(ContextActions.resetContextCR());
            }
        }));
        this.subs.push(this.store.pipe(select(PlacesSelectors.selectEntitiesList)).subscribe((entities: Entity[]) => {
            this.entities = entities;

            // Si une CR est sélectionnée dans le contexte
            if (!_.isNull(this.context) && !_.isNull(this.context.zip_code)) {
                this.store.dispatch(PlacesActions.selectEntityByZipCode({ entityZipCode: this.context.zip_code }));

                // Récupération de la liste des Entités de la CR sélectionnée
                this.store.dispatch(PlacesActions.getDistributionEntities({ selectedCrId: this.selectedCR.regional_bank_id, selectedEntityZipCode: this.context.zip_code }));

                // Reset du code postal dans le context
                this.store.dispatch(ContextActions.resetContextEntity());
            }
        }));
        this.subs.push(this.store.pipe(select(PlacesSelectors.selectDistributionEntities)).subscribe((distributionEntities: DistributionEntity[]) => {
            this.distributionEntities = distributionEntities;
        }));
        this.subs.push(this.store.pipe(select(PlacesSelectors.selectSelectCR)).subscribe((selectedCR: CR) => {
            this.selectedCR = selectedCR;
        }));
        this.subs.push(this.store.pipe(select(PlacesSelectors.selectEntity)).subscribe((selectedEntity: Entity) => {
            this.selectedEntity = selectedEntity;
        }));

        // Récupération de la liste des CR
        this.store.dispatch(PlacesActions.getCRList());
    }

    /**
     * Appelé lorsque la page n'est plus affichée
     */
    ngOnDestroy() {
        this.subs.forEach(sub => {
            sub.unsubscribe();
        });
    }

    // -----------------
    // Listeners
    // -----------------

    /**
     * Listener appelé lorsque l'on change la CR selectionnée
     * @param selectedCRId L'id de la CR selectionnée
     */
    onCRChange(selectedCRId: string) {

        // Remise à zero des listes et de selections
        this.store.dispatch(PlacesActions.setDistributionEntities({ distributionEntiesList: [] }));
        this.store.dispatch(PlacesActions.setEntitiesList({ entiesList: [] }));
        this.store.dispatch(PlacesActions.selectEntityByZipCode({ entityZipCode: null }));
        this.store.dispatch(PlacesActions.selectDistributionEntityById({ distributionEntityId: null }));

        // Sauvegarde de la CR sélectionnée
        this.store.dispatch(PlacesActions.selectCRById({ crId: selectedCRId }));

        if (selectedCRId !== '') {
            // Récupération de la liste des Entités de la CR sélectionnée
            this.store.dispatch(PlacesActions.getEntitiesList({ selectedCrId: selectedCRId }));
        }

    }

    /**
     * Listener appelé lorsque l'on change la ville sélectionnée
     * @param selectedEntityZipCode Le code postal de la ville selectionnée
     */
    onEntityChange(selectedEntityZipCode: string) {

        // Remise à zero des listes et de selections
        this.store.dispatch(PlacesActions.setDistributionEntities({ distributionEntiesList: [] }));
        this.store.dispatch(PlacesActions.selectDistributionEntityById({ distributionEntityId: null }));

        // Sauvegarde du zip code l'entité sélectionnée
        this.store.dispatch(PlacesActions.selectEntityByZipCode({ entityZipCode: selectedEntityZipCode }));

        if (selectedEntityZipCode !== '') {
            // Récupération de la liste des agences
            this.store.dispatch(PlacesActions.getDistributionEntities({ selectedCrId: this.selectedCR.regional_bank_id, selectedEntityZipCode: selectedEntityZipCode }));
        }
    }

    /**
     * Listener sur le lien pour ouvrir l'application React
     */
    onOpenApplication() {
        // Détermination de retour
        const regExp = new RegExp(environment.remoteUrlRegex);
        const remoteUrl = this.location.getBaseHrefFromDOM().replace(regExp, environment.remoteUrl);

        // Sauvegarde du contexte
        const context: Context = {
            client_id: environment.remoteClientId,
            regional_bank_id: this.selectedCR.regional_bank_id,
            zip_code: `${this.selectedEntity.zip_code}`
        };

        this.contextService.setContext(context).subscribe((savedContext: SavedContext) => {
            window.open(`${remoteUrl}/${Constants.ROUTES.REMOTE_APP.AGENCES}?idCtx=${savedContext.context_id}`);
        });
    }

}
