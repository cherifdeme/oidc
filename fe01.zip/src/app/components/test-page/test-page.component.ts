import { Component, OnInit } from '@angular/core';
import { LogService } from 'src/app/services/log.service';
import { LogLevel, LogContext, DefaultLogContext } from 'src/app/models/log';

@Component({
  selector: 'app-test-page',
  templateUrl: './test-page.component.html',
  styleUrls: ['./test-page.component.scss']
})
export class TestPageComponent implements OnInit {

  constructor(private logService: LogService) { }

  ngOnInit() {
  }

  onTestBasicLog() {
    this.logService.log(LogLevel.DEBUG, '****  Debug Log message ');
    this.logService.log(LogLevel.LOG, '**** Default log message ');
    this.logService.log(LogLevel.WARN, '**** Warning log message');
    // Log de type Error avec appel service bff de log
    const logContext: LogContext = new DefaultLogContext();
    logContext.source = 'TestPageComponent func onTestBasicLog';
    this.logService.log(LogLevel.ERROR, '**** Error message', logContext);

  }

  onTestHandleError() {
      // test error Handler
      this.logService.log(LogLevel.WARN, '**** test error Handler');
      const babies = null;
      if (babies.age === '1') {
          // ras plantage
      }
    }

}
