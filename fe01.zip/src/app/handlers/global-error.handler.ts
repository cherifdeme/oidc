import { ErrorHandler, Injectable, Injector } from '@angular/core';
import { LogService } from '../services/log.service';
import { LogLevel, LogContext, DefaultLogContext } from '../models/log';

@Injectable()
export class GlobalErrorHandler implements ErrorHandler {
  constructor(private injector: Injector) {}

  handleError(error) {
    const logService = this.injector.get(LogService);
    logService.log(LogLevel.WARN, '$$$$  Catch Error : ' + error.message);
    const logContext: LogContext = new DefaultLogContext();
    logContext.source = 'global-error.handler func handleError';
    logContext.stack_trace = error.stack;
    logService.log(LogLevel.ERROR, error.message, logContext);
  }
}
