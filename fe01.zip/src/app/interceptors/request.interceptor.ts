import {
  HttpEvent,
  HttpHandler,
  HttpInterceptor,
  HttpRequest,
  HttpHeaders,
} from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { v4 as uuidv4 } from 'uuid';
import { LogService } from '../services/log.service';
import { LogLevel, LogContext, DefaultLogContext } from '../models/log';
/**
 * Intercepteur pour les requête HTTP
 */
@Injectable()
export class RequestInterceptor implements HttpInterceptor {
  constructor(private logService: LogService) {}

  /**
   * Intercepte la requête et rajoute la gestion des crédentials.
   * Envoi des cookies de session au BFF
   * @param req La requête
   * @param next Le prochain gestionnaire de la requête
   */
  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    const request = req.clone({
      withCredentials: true,
      headers: this.addExtraHeaders(req.headers),
    });

    const logContext: LogContext = new DefaultLogContext();
    logContext.uri = request.urlWithParams;
    logContext.corr_id = request.headers.get('idCorrelation');
    this.logService.log(
      LogLevel.DEBUG,
      'Envoi de la requête au serveur',
      logContext
    );
    return next.handle(request);
  }

  private addExtraHeaders(headers: HttpHeaders): HttpHeaders {
    headers = headers.append('idCorrelation', uuidv4());
    return headers;
  }
}
