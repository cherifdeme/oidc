export interface Caisses {
    numero: string;
	application: string;
	eds: string;
	codeCr: string;
	adabo: string;
	branche: string;
	adherent: string;
	brancheReference: string;
	entite: string;
	poste: string;
}

export interface Branches {
    id: string;
	groupe: string;
	application: string;
	eds: string;
	poste: string;
	cr: string;
	branche: string;
}