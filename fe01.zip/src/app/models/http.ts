export interface HttpOperation {
  operation: string;
  url?: string;
  options?: any;
  body?: any;
}
