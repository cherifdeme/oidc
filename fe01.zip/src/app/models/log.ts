import { v4 as uuidv4 } from 'uuid';

/**
 * Interface décrivant le log config
 */
export interface LogConfig {
  clientLogLevel: string;
  disableConsoleLog: string;
  serverLogLevel: string;
}

/**
 * Interface décrivant une agence
 */
export interface LogContext {
  event_cod: string;
  event_typ: string;
  sec_event_typ: string;
  usr_id: string;
  uom_cod: string;
  app_id: string;
  component_id: string;
  corr_id: string;
  sess_id: string;
  src_client_id: string;
  profil: string;
  instance_name: string;
  uri: string;
  component_type: string;
  terminal: string;
  eds: string;
  operational_post_id: string;
  source: string;
  stack_trace: string;
  src_client: string;
}

export class DefaultLogContext implements LogContext {
  event_cod = 'LOGS_FRONT';
  event_typ = 'LOGS';
  sec_event_typ: '';
  usr_id = '';
  uom_cod = '';
  app_id = 'STANDALONE';
  component_id = 'ANGULAR';
  corr_id = uuidv4();
  sess_id = '';
  src_client_id = 'IHML-DEMO';
  profil = '';
  instance_name = '';
  uri = '';
  component_type = 'FRONT';
  terminal = window.navigator.userAgent;
  eds = '';
  operational_post_id = '';
  source = '';
  stack_trace = '';
  src_client = 'IHML-DEMO';
}

export enum LogLevel {
  TRACE,
  DEBUG,
  INFO,
  LOG,
  WARN,
  ERROR,
  FATAL,
  OFF,
}
