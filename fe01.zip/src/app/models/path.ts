/**
 * Interface décrivant un chemin de requête
 */
export interface Path {
  root: string;
  searchParams: any;
}
