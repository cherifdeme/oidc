/**
 * Interface décrivant un utilisateur
 */
export interface User {
  id: string;
  fpLabel: string;
  state: string;
}
