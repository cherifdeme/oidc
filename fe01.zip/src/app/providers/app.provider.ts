import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { APP_INITIALIZER } from '@angular/core';
import { RequestInterceptor } from '../interceptors/request.interceptor';
import { AppInitService } from '../services/app-init.service';

/**
 * Provider pour le chargement de la configuration de l'application
 * @param appInitService Service d'initialisation de l'application
 */
export function provideAppconfiguration(appInitService: AppInitService) {
  return () => appInitService.initialiseApp();
}

/**
 * Provider pour déclarer le chargement de la configuration de l'application à l'initialisation
 */
export const appConfigurationProvider = {
  provide: APP_INITIALIZER,
  useFactory: provideAppconfiguration,
  deps: [AppInitService],
  multi: true,
};

/**
 * Provider pour déclarer l'intercepteur HTTP
 */
export const requestInterceptorProvider = {
  provide: HTTP_INTERCEPTORS,
  useClass: RequestInterceptor,
  multi: true,
};
