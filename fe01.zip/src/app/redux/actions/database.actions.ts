import { createAction, props } from '@ngrx/store';
import { Branches, Caisses } from '../../models/database';

/**
 * Actions concernant les Caisses
 */
export const getCaisses = createAction('[Database] récupération du routage caisses', props<{application: string}>());
export const setCaisses = createAction('[Database] mise à jour liste des routages caisses', props<{caissesList: Caisses[]}>());

/**
 * Actions concernant les Branches
 */
export const getBranches = createAction('[Database] récupération du routage branches', props<{application: string}>());
export const setBranches = createAction('[Database] mise à jour liste des routages branches', props<{branchesList: Branches[]}>());
