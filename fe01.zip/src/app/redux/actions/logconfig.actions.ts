import { createAction, props } from '@ngrx/store';
import { LogconfigState } from '../state/logconfig.state';

/**
 * Actions concernant la log config
 */
export const setLogConfig = createAction('[Application] mise jour de la config des logs', props<{logConfig: LogconfigState}>());

