import { createAction, props } from '@ngrx/store';
import { Message } from '../../models/postmessage';

/**
 * Actions concernant les post message
 */
export const setMessage = createAction('[PostMessage] ajout d\'un post message', props<{message: Message}>());

