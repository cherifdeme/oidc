import { createAction, props } from '@ngrx/store';
import { User } from '../../models/user';

/**
 * Actions concernant l'utilisateur
 */
export const getUser = createAction('[Security Api] récupération de l\'utilisateur');
export const setUser = createAction('[Security Api] mise à jour de l\'utilisateur', props<{ user: User }>());
