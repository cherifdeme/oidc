import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { exhaustMap, switchMap, catchError } from 'rxjs/operators';
import { ContextService } from '../../services/context.service';
import * as ContextActions from '../actions/context.actions';
import { Context } from '../../models/context';

/**
 * NgRx Effects pour les interactions avec le contexte de l'application
 */
@Injectable()
export class ContextEffects {
    constructor(
        private actions$: Actions,
        private contextService: ContextService
    ) { }

    /**
     * Récupération du context de l'application
     */
    getApplicationContext$ = createEffect(() => this.actions$.pipe(
        ofType(ContextActions.getContext),
        exhaustMap(action => {
            return this.contextService.getContext(action.idCtx).pipe(
                switchMap((context: Context) => {
                    return [
                        ContextActions.setContext({context}),
                    ];
                }),
                catchError(err => {
                    const context: Context = {
                        regional_bank_id: null,
                        zip_code: null
                    }
                    return [
                        ContextActions.setContext({context})
                    ];
                })
            );
        })
    ));
}
