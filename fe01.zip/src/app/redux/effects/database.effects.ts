import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { exhaustMap, switchMap } from 'rxjs/operators';
import { Branches, Caisses } from 'src/app/models/database';
import { DatabaseService } from 'src/app/services/database.service';
import * as DatabaseActions from '../actions/database.actions';

/**
 * NgRx Effects pour les interactions avec l'API Databse
 */
@Injectable()
export class DatabaseEffects {
    constructor(
        private actions$: Actions,
        private databaseService: DatabaseService
    ) { }

    /**
     * Récupération de la liste des routage caisses
     */
    getCaisses$ = createEffect(() => this.actions$.pipe(
        ofType(DatabaseActions.getCaisses),
        exhaustMap((action) => {
            return this.databaseService.getCaisses(action.application).pipe(
                switchMap((caissesList: Caisses[]) => {
                    return [
                        DatabaseActions.setCaisses({ caissesList }),
                    ];
                })
            );
        })
    ));

        /**
     * Récupération de la liste des routage branches
     */
    getBranches$ = createEffect(() => this.actions$.pipe(
        ofType(DatabaseActions.getBranches),
        exhaustMap((action) => {
            return this.databaseService.getBranches(action.application).pipe(
                switchMap((branchesList: Branches[]) => {
                    return [
                        DatabaseActions.setBranches({ branchesList }),
                    ];
                })
            );
        })
    ));
}
