import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { exhaustMap, mergeMap, switchMap } from 'rxjs/operators';
import { CR, DistributionEntity, Entity } from '../../models/places';
import { PlacesService } from '../../services/places.service';
import * as PlacesActions from '../actions/places.actions';

/**
 * NgRx Effects pour les interactions avec l'API Places
 */
@Injectable()
export class PlacesEffects {
    constructor(
        private actions$: Actions,
        private placesService: PlacesService
    ) { }

    /**
     * Récupération de la liste des CR
     */
    getCRList$ = createEffect(() => this.actions$.pipe(
        ofType(PlacesActions.getCRList),
        mergeMap(() => {
            return this.placesService.getCRList().pipe(
                switchMap((crsList: CR[]) => {
                    return [
                        PlacesActions.setCRList({ crsList }),
                    ];
                })
            );
        })
    ));

    /**
     * Récupération de la liste des villes d'une CR
     */
    getCREntities$ = createEffect(() => this.actions$.pipe(
        ofType(PlacesActions.getEntitiesList),
        exhaustMap(action => {
            return this.placesService.getCREntities(action.selectedCrId).pipe(
                switchMap((entiesList: Entity[]) => {
                    return [
                        PlacesActions.setEntitiesList({ entiesList: entiesList }),
                    ];
                })
            );
        })
    ));

    /**
     * Récupération de la liste des agences d'une ville d'une CR
     */
    getCRAgencesList$ = createEffect(() => this.actions$.pipe(
        ofType(PlacesActions.getDistributionEntities),
        exhaustMap(action => {
            return this.placesService.getCRAgencesList(action.selectedCrId, action.selectedEntityZipCode).pipe(
                switchMap((distributionEntities: DistributionEntity[]) => {
                    return [
                        PlacesActions.setDistributionEntities({ distributionEntiesList: distributionEntities }),
                    ];
                })
            );
        })
    ));
}
