import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { mergeMap, switchMap } from 'rxjs/operators';
import { SecurityService } from '../../services/security.service';
import { User } from '../../models/user';
import * as SessionActions from '../actions/session.actions';

/**
 * NgRx Effect pour la gestion de session
 */
@Injectable()
export class SessionEffects {
    constructor(
        private actions$: Actions,
        private securityService: SecurityService
    ) { }

    /**
     * Récupération de l'utilisateur connecté
     */
    getUser$ = createEffect(() => this.actions$.pipe(
        ofType(SessionActions.getUser),
        mergeMap(() => {
            return this.securityService.getUserConnected().pipe(
                switchMap((user: User) => {
                    return [
                        SessionActions.setUser({ user }),
                    ];
                })
            );
        })
    ));
}
