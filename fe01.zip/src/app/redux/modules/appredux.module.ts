import { NgModule } from "@angular/core";
import { StoreModule } from "@ngrx/store";
import { UIModule } from "./ui.module";
import { SessionModule } from "./session.module";
import { PMModule } from "./pm.module";
import { ContextModule } from "./context.module";
import { ManifestModule } from "./manifest.module";
import { LogconfigModule } from "./logconfig.module";

/**
 * Module parent pour la déclaration du store NgRx
 */
@NgModule({
  imports: [
    StoreModule.forRoot({}),
    UIModule,
    SessionModule,
    PMModule,
    ContextModule,
    ManifestModule,
    LogconfigModule,
  ],
})
export class AppReduxModule {}
