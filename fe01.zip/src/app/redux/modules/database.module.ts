import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import { databaseFeatureKey, databaseReducer } from '../reducers/database.reducer';

/**
 * Module pour la déclaration du store liés aux agences
 */
@NgModule({
  imports: [
    StoreModule.forFeature(databaseFeatureKey, databaseReducer)
  ],
})
export class DatabaseModule {}
