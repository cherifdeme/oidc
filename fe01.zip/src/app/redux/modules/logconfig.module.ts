import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import {logconfigReducer, logconfigFeatureKey} from '../reducers/logconfig.reducer';

/**
 * Module déclarant le store lié à la config des log
 */
@NgModule({
  imports: [
    StoreModule.forFeature(logconfigFeatureKey, logconfigReducer)
  ],
})
export class LogconfigModule {}
