import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import {manifestReducer, manifestFeatureKey} from '../reducers/manifest.reducer';

/**
 * Module déclarant le store lié à l'UI
 */
@NgModule({
  imports: [
    StoreModule.forFeature(manifestFeatureKey, manifestReducer)
  ],
})
export class ManifestModule {}
