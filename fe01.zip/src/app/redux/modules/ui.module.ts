import { NgModule } from '@angular/core';
import { StoreModule } from '@ngrx/store';
import {uiReducer, uiFeatureKey} from '../reducers/ui.reducer';

/**
 * Module déclarant le store lié à l'UI
 */
@NgModule({
  imports: [
    StoreModule.forFeature(uiFeatureKey, uiReducer)
  ],
})
export class UIModule {}
