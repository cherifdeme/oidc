import { createReducer, on } from '@ngrx/store';
import * as _ from 'lodash';
import * as ContextActions from '../actions/context.actions';
import { ContextState } from '../state/context.state';

/**
 * Clé du store lié aux places
 */
export const contextFeatureKey = 'context';

/**
 * State initial pour le store places
 */
export const initialState: ContextState = {
    regional_bank_id: null,
    zip_code: null
};

/**
 * Réducer pour la gesion du store context
 */
const _contextReducer = createReducer(
    initialState,
    /**
     * Listener pour la mise à jour du context
     */
    on(ContextActions.setContext, (state, { context }) => {
        return _.assign({}, state, {regional_bank_id: context.regional_bank_id, zip_code: context.zip_code});
    }),
    /**
     * Listener pour le reset de la CR dans le context
     */
    on(ContextActions.resetContextCR, (state) => {
        return _.assign({}, state, {regional_bank_id: null});
    }),
    /**
     * Listener pour le reset du code postal dans le context
     */
    on(ContextActions.resetContextEntity, (state) => {
        return _.assign({}, state, {zip_code: null});
    })
);

/**
 * Exposition du reducer
 * @param state Le state reçue
 * @param action  L'action déclanchée
 */
export function contextReducer(state, action) {
    return _contextReducer(state, action);
}

