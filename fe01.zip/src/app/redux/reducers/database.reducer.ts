import { createReducer, on } from '@ngrx/store';
import * as _ from 'lodash';
import { Branches, Caisses } from 'src/app/models/database';
import * as DatabaseActions from '../actions/database.actions';
import { DatabaseState } from '../state/database.state';

/**
 * Clé du store lié aux places
 */
export const databaseFeatureKey = 'database';

/**
 * State initial pour le store places
 */
export const initialState: DatabaseState = {
    caisses: [],
    branches: [],
};

/**
 * Réducer pour la gesion du store places
 */
const _databaseReducer = createReducer(
    initialState,
    /**
     * Listener pour la mise à jour des routages caisses
     */
    on(DatabaseActions.setCaisses, (state, { caissesList }) => {
        const caisses: Caisses[] = _.concat([], caissesList);
        return _.assign({}, state, {caisses});
    }),
    /**
     * Listener pour la mise à jour des routages branches
     */
    on(DatabaseActions.setBranches, (state, { branchesList }) => {
        const branches: Branches[] = _.concat([], branchesList);
        return _.assign({}, state, {branches});
    }),
);

/**
 * Exposition du reducer
 * @param state Le state reçue
 * @param action  L'action déclanchée
 */
export function databaseReducer(state, action) {
    return _databaseReducer(state, action);
}

