import { createReducer, on } from '@ngrx/store';
import * as _ from 'lodash';
import { setLogConfig} from '../actions/logconfig.actions';
import { LogconfigState } from '../state/logconfig.state';

/**
 * Clé du store lié a l'ui
 */
export const logconfigFeatureKey = 'logconfig';

/**
 * State initial pour le store log config
 */
export const initialState: LogconfigState = {
    clientLogLevel: null,
    disableConsoleLog: null,
    serverLogLevel: null
};

/**
 * Réducer pour la gesion du store log config
 */
const _logconfigReducer = createReducer(
    initialState,
    on(setLogConfig, (state, { logConfig }) => {
        return _.assign({}, state,  logConfig);
    }),
);

/**
 * Exposition du reducer
 * @param state Le state reçue
 * @param action  L'action déclanchée
 */
export function logconfigReducer(state, action) {
    return _logconfigReducer(state, action);
}
