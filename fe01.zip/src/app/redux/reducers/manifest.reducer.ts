import { createReducer, on } from '@ngrx/store';
import * as _ from 'lodash';
import {setBffManifest, setFrontManifest} from '../actions/manifest.actions';
import { ManifestState } from '../state/manifest.state';
import Constants from '../../../const';

/**
 * Clé du store lié a l'ui
 */
export const manifestFeatureKey = 'manifest';

/**
 * State initial pour le store UI
 */
export const initialState: ManifestState = {
    bff: {
        framework: null,
        version: null
    },
    front: {
        version: null
    }
};

/**
 * Réducer pour la gesion du store UI
 */
const _manifestReducer = createReducer(
    initialState,
    on(setBffManifest, (state, { manifest }) => {
        return _.assign({}, state, {bff: manifest});
    }),
    on(setFrontManifest, (state, { manifest }) => {
        return _.assign({}, state, {front: manifest});
    }),
);

/**
 * Exposition du reducer
 * @param state Le state reçue
 * @param action  L'action déclanchée
 */
export function manifestReducer(state, action) {
    return _manifestReducer(state, action);
}
