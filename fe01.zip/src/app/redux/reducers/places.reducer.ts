import { createReducer, on } from '@ngrx/store';
import * as _ from 'lodash';
import * as PlacesActions from '../actions/places.actions';
import { PlacesState } from '../state/places.state';
import { CR, Entity, DistributionEntity } from '../../models/places';

/**
 * Clé du store lié aux places
 */
export const placesFeatureKey = 'places';

/**
 * State initial pour le store places
 */
export const initialState: PlacesState = {
    crs: [],
    entities: [],
    distributionEntities: [],
    selectedCR: null,
    selectedEntity: null,
    selectedDistributionEntity: null
};

/**
 * Réducer pour la gesion du store places
 */
const _placesReducer = createReducer(
    initialState,
    /**
     * Listener pour la mise à jour de la liste des CR
     */
    on(PlacesActions.setCRList, (state, { crsList }) => {
        const crs: CR[] = _.concat([], crsList);
        return _.assign({}, state, {crs});
    }),
    /**
     * Listener pour la mise à jour de la liste des villes d'une CR
     */
    on(PlacesActions.setEntitiesList, (state, { entiesList }) => {
        const entities: Entity[] = _.concat([], entiesList);
        return _.assign({}, state, {entities});
    }),
    /**
     * Listener pour la mise à jour de la liste des agences d'une ville d'une CR
     */
    on(PlacesActions.setDistributionEntities, (state, { distributionEntiesList }) => {
        const distributionEntities: DistributionEntity[] = _.concat([], distributionEntiesList);
        return _.assign({}, state, {distributionEntities});
    }),
    /**
     * Listener pour la selection de la CR choisie par l'utilisateur
     */
    on(PlacesActions.selectCRById, (state, { crId }) => {
        const cr: CR = _.find(state.crs, {regional_bank_id: crId}) || null;
        return _.assign({}, state, {selectedCR: cr});
    }),
    /**
     * Listener pour la selection de la ville choisie par l'utilisateur
     */
    on(PlacesActions.selectEntityByZipCode, (state, { entityZipCode }) => {
        const entity: Entity = _.find(state.entities, {zip_code: entityZipCode}) || null;
        return _.assign({}, state, {selectedEntity: entity});
    }),
    /**
     * Listener pour la selection de l'agence choisie par l'utilisateur
     */
    on(PlacesActions.selectDistributionEntityById, (state, { distributionEntityId }) => {
        const distributionEntity: DistributionEntity = _.find(state.distributionEntities, {id: distributionEntityId}) || null;
        return _.assign({}, state, {selectedDistributionEntity: distributionEntity});
    })
);

/**
 * Exposition du reducer
 * @param state Le state reçue
 * @param action  L'action déclanchée
 */
export function placesReducer(state, action) {
    return _placesReducer(state, action);
}

