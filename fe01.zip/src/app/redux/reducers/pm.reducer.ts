import { createReducer, on } from '@ngrx/store';
import * as _ from 'lodash';
import { Message } from '../../models/postmessage';
import { setMessage } from '../actions/pm.actions';
import { PMState } from '../state/pm.state';

/**
 * Clé du store lié aux post messages
 */
export const pmFeatureKey = 'pm';

/**
 * State initial pour le store post message
 */
export const initialState: PMState = {
    messages: []
};

/**
 * Réducer pour la gesion du store post message
 */
const _pmReducer = createReducer(
    initialState,
    /**
     * Listener pour la mise à jour de la liste des post messages
     */
    on(setMessage, (state, { message }) => {
        const messages: Message[] = _.concat([], state.messages, [message]);
        return _.assign({}, state, { messages });
    }),

);

/**
 * Exposition du reducer
 * @param state Le state reçue
 * @param action  L'action déclanchée
 */
export function pmReducer(state, action) {
    return _pmReducer(state, action);
}
