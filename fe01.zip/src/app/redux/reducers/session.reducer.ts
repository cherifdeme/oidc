import { createReducer, on } from '@ngrx/store';
import * as _ from 'lodash';
import {setUser} from '../actions/session.actions';
import { SessionState } from '../state/session.state';

/**
 * Clé du store lié a la session
 */
export const sessionFeatureKey = 'session';

/**
 * State initial pour le store session
 */
export const initialState: SessionState = {
    user: {id: null, state: null, fpLabel: null}
};

/**
 * Réducer pour la gesion du store places
 */
const _sessionReducer = createReducer(
    initialState,
    /**
     * Listener pour la mise à jour de l'utilisateur de la session
     */
    on(setUser, (state, { user }) => {
        return _.assign({}, state, {user: user});
    })
);

/**
 * Exposition du reducer
 * @param state Le state reçue
 * @param action  L'action déclanchée
 */
export function sessionReducer(state, action) {
    return _sessionReducer(state, action);
}
