import { createSelector, createFeatureSelector } from '@ngrx/store';
import { ContextState } from '../state/context.state';

/**
 * NgRx Selector pour le store context
 */
export const selectContextState = createFeatureSelector<ContextState>('context');

/**
 * NgRx Selector pour le store context.reginonal_bank_id
 */
export const selectContextRegionalBankId = createSelector(
    selectContextState,
    (state: ContextState) => state.regional_bank_id
);

/**
 * NgRx Selector pour le store context.zip_code
 */
export const selectContextZipCode = createSelector(
    selectContextState,
    (state: ContextState) => state.zip_code
);
