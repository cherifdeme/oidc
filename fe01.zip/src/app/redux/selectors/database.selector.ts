import { createFeatureSelector, createSelector } from '@ngrx/store';
import { DatabaseState } from '../state/database.state';

/**
 * NgRx Selector pour le store places
 */
export const selectDatabaseState = createFeatureSelector<DatabaseState>('database');

/**
 * NgRx Selector pour le store places.crs
 */
export const selectCaisses = createSelector(
    selectDatabaseState,
    (state: DatabaseState) => state.caisses
);

/**
 * NgRx Selector pour le store places.distributionEntities
 */
export const selectBranches = createSelector(
    selectDatabaseState,
    (state: DatabaseState) => state.branches
);

