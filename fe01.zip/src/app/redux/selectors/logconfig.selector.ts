import { createSelector } from '@ngrx/store';
import { AppState } from '../state/app.state';


/**
 * NgRx Selector pour le store log config
 */
export const selectLogConfigState  = (state: AppState) => state.logconfig;
