import { createSelector } from '@ngrx/store';
import { AppState } from '../state/app.state';
import { SessionState } from '../state/session.state';

/**
 * NgRx Selector pour le store session
 */
export const selectSessionState = (state: AppState) => state.session;

/**
 * NgRx Selector pour le store session.user
 */
export const selectUser = createSelector(
    selectSessionState,
    (state: SessionState) => state.user
);
