import { SessionState } from './session.state';
import { UIState } from './ui.state';
import { PMState } from './pm.state';
import { ContextState } from './context.state';
import { ManifestState } from './manifest.state';
import { LogconfigState } from './logconfig.state';

/**
 * Interface déclarant le state globale de l'application
 */
export interface AppState {
  pm: PMState;
  ui: UIState;
  session: SessionState;
  context: ContextState;
  manifest: ManifestState;
  logconfig: LogconfigState;
}
