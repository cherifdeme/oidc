import { Context } from '../../models/context';

/**
 * Interface décrivant le state context
 */
export interface ContextState {
    regional_bank_id: string;
    zip_code: string;
}
