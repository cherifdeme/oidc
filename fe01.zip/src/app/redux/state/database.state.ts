import { Branches, Caisses } from 'src/app/models/database';

/**
 * Interface décrivant le state database
 */
export interface DatabaseState {
    caisses: Caisses[];
    branches: Branches[];
}