/**
 * Interface décrivant le state log config
 */

export interface LogconfigState {
    clientLogLevel: string;
    disableConsoleLog: string;
    serverLogLevel: string;
}


