import { CR, Entity, DistributionEntity } from '../../models/places';

/**
 * Interface décrivant le state places
 */
export interface PlacesState {
    crs: CR[];
    entities: Entity[];
    distributionEntities: DistributionEntity[];
    selectedCR: CR;
    selectedEntity: Entity;
    selectedDistributionEntity: DistributionEntity;
}