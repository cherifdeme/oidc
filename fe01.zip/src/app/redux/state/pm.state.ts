import { Message} from '../../models/postmessage';

/**
 * Interface décrivant le state post message
 */
export interface PMState {
    messages: Message[];
}
