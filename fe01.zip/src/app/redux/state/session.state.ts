import { User } from '../../models/user';

/**
 * Interface décrivant le state session
 */
export interface SessionState {
    user: User;
}
