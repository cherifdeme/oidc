import { HttpClient } from '@angular/common/http';
import { PlatformLocation } from '@angular/common';
import { Injectable } from '@angular/core';
import { Store } from '@ngrx/store';
import * as _ from 'lodash';
import { of } from 'rxjs';
import { catchError, map, mergeMap, finalize } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { User } from '../models/user';
import * as SessionActions from '../redux/actions/session.actions';
import * as ManifestActions from '../redux/actions/manifest.actions';
import * as LogconfigActions from '../redux/actions/logconfig.actions';
import { AppState } from '../redux/state/app.state';
import { BffState, FrontState } from '../redux/state/manifest.state';
import { LogconfigState } from '../redux/state/logconfig.state';
import packageJson from '../../../package.json';
import { NGXLogger } from 'ngx-logger';
import { LogConfig, LogLevel } from '../models/log';
import { LogService } from './log.service';
/**
 * Service pour l'initialisation de l'application
 */
@Injectable()
export class AppInitService {
  constructor(
    private http: HttpClient,
    private store: Store<AppState>,
    private logService: LogService,
    private location: PlatformLocation
  ) {}

  /**
   * Permet d'initialisation l'application.
   * Appeler au lancement de l'application
   * Important: It should return a Promise
   */
  public initialiseApp() {
    // Récupération de la configuration de l'applicatio(n
    return this.http
      .get('configuration/app-config.json')
      .pipe(
        map((config) => {
          // Détermination de l'url de redirection en fonction du base ref
          config['redirectUrl'] = `${
            window.location.origin
          }${this.location.getBaseHrefFromDOM()}${config['redirectUrl']}`;

          _.assign(environment, config);
          // Mise à jour de la config des logs
          const logConfig: LogconfigState = {
            clientLogLevel: `${environment.logLevel}`,
            serverLogLevel: `${environment.serverLogLevel}`,
            disableConsoleLog: `${environment.disableConsoleLogging}`,
          };
          this.store.dispatch(LogconfigActions.setLogConfig({ logConfig }));
          return;
        }),
        mergeMap(() => {
          // Récupération du manifest du bff
          return this.http.get(`${environment.apiBasePath}/manifest`);
        }),
        map((manifest: BffState) => {
          // Mise à jour du manifes bff
          this.store.dispatch(ManifestActions.setBffManifest({ manifest }));
          return manifest;
        }),
        map(() => {
          // Mise à jour du manifest front
          const manifest: FrontState = packageJson;
          this.store.dispatch(ManifestActions.setFrontManifest({ manifest }));
          return manifest;
        }),
        mergeMap(() => {
          // Récupération de la config des logs
          return this.http.get(`${environment.apiBasePath}/logs/configuration`);
        }),
        map((logConfig: LogconfigState) => {
          // Mise à jour de la config des logs
          this.store.dispatch(LogconfigActions.setLogConfig({ logConfig }));
          return;
        }),
        mergeMap(() => {
          // Récupération de l'utilisateur lié à la session
          return this.http.get(`${environment.apiBasePath}/security/user`);
        }),
        map((user: User) => {
          // S'il y a un utilisateur connecté on le sauvergarde dans le store
          this.store.dispatch(SessionActions.setUser({ user: user }));
          return user;
        }),
        catchError((err) => {
          if (err.status === 404) {
            // S'il n'y a pas d'utilisateur on le reset
            this.store.dispatch(
              SessionActions.setUser({
                user: { id: null, state: null, fpLabel: null },
              })
            );
          } else {
            this.logService.log(
              LogLevel.ERROR,
              `Erreurlors du chargement initial | ${JSON.stringify(err)}`
            );
          }

          return of(null);
        }),
        finalize(() => {
          this.logService.log(LogLevel.INFO, 'Application IHML demo chargée');
        })
      )
      .toPromise();
  }
}
