import { PlatformLocation } from '@angular/common';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import * as _ from 'lodash';
import { environment } from 'src/environments/environment';
import Constants from '../../const';
import { getPathInfos } from '../../utils';
import { User } from '../models/user';
import * as SessionActions from '../redux/actions/session.actions';
import * as UserSelectors from '../redux/selectors/session.selector';
import { AppState } from '../redux/state/app.state';
import { UIError } from '../redux/state/ui.state';
import { HttpService } from './http.service';
import { SecurityService } from './security.service';

/**
 * Service pour la gestion de l'authentification
 */
@Injectable()
export class AuthService {

    // Internal variable
    private user: User;

    constructor(
        private securityService: SecurityService,
        private httpService: HttpService,
        private router: Router,
        private store: Store<AppState>,
        private location: PlatformLocation
    ) {
        // Ecoute du store pour savoir si un utilisateur a été sauvegardé
        this.store.pipe(select(UserSelectors.selectUser)).subscribe((user: User) => {
            this.user = user;

            if (!_.isEmpty(user.id)) {
                // Si un utilisateur existe on le redirige vers la page initialement demandée.
                const redirectTo = this.getRedirectTo();

                // Suppression du canal si on la positionné
                if (!_.isEmpty(this.getCanal())) {
                    this.removeCanal();
                }

                if (!_.isEmpty(redirectTo)) {
                    const pathInfos = getPathInfos(redirectTo);
                    this.removeRedirectTo();
                    this.router.navigate([pathInfos.root], { queryParams: pathInfos.searchParams });
                }
            }
        });
    }

    /**
     * Permet de savoir si un utilisateur est authentifié
     */
    get authenticated(): boolean {
        return !_.isEmpty(this.user.id);
    }

    /**
     * Gère la cinématique de connexion à la mire X Connect
     * @param redirectTo  Page de redirection une fois l'authentification faite
     */
    login(redirectTo: string) {
        // Sauvegarde dans le sessionStorage la page demandée par l'utilisateur
        this.storeRedirectTo(redirectTo);

        // Génération d'un state pour X Connect et la récupértion du refresh token
        const xcsrfToken: string = this.user.state;
        // Construction URL pour la redirection vers le mire X Connect
        const queryParams = {
            client_Id: environment.clientId,
            redirect_uri: environment.redirectUrl,
            response_type: 'code',
            scope: 'openid',
            state: xcsrfToken
        };

        let queryParamsString = `client_id=${queryParams.client_Id}`;
        queryParamsString = `${queryParamsString}&redirect_uri=${queryParams.redirect_uri}`;
        queryParamsString = `${queryParamsString}&response_type=${queryParams.response_type}`;
        queryParamsString = `${queryParamsString}&scope=${queryParams.scope}`;
        queryParamsString = `${queryParamsString}&state=${queryParams.state}`;

        // Redirection vers la mire X Connect
        location.assign(`${environment.xConnectUrl}${Constants.ROUTES.X_CONNECT.AUTHORIZE}?${queryParamsString}`);
    }

    /**
     * Gère le retour de la mire X Connect après authentification
     */
    handleAuth() {
        // Récupération des paramètres de la requête
        const queryParamsMap = getPathInfos(location.search).searchParams;
        let code = null;
        let state = null;
        if (!_.isEmpty(queryParamsMap)) {
            // Sauvegarde de l'authorization code et du state
            code = queryParamsMap['code'];
            state = queryParamsMap['state'];
        }
        
        // Récupération du canal depuis le sessionStorage
        const canal = this.getCanal();
        if (!_.isEmpty(code) && !_.isEmpty(state)) {
            // Si on un code et un state on demande la création d'un OAuthToken au BFF
            this.securityService.login(code, environment.redirectUrl, state, canal).subscribe(() => {
                // Une fois connecté on demande les informations sur l'utilisateur
                this.store.dispatch(SessionActions.getUser());
            });
        } else {
            const uiError: UIError = {
                operation: Constants.ACTIONS.REDIRECT_FROM_XCONNECT,
                errorMessage: Constants.ERROR_MESSAGES.BAD_XCONNECT_INFORMATION,
                link: getPathInfos(this.router.url)
            };

            this.httpService.handleError(uiError);
        }
    }

    /**
     * Gestion de la déconnexion
     */
    logout(logoutType: string) {

        this.securityService.standAlonelogout().subscribe(
            () => {
                // Une fois connecté on demande les informations sur l'utilisateur
                this.store.dispatch(SessionActions.getUser());

                const goto: string = `${window.location.origin}${this.location.getBaseHrefFromDOM()}home`;
                // Redirection vers la mire X Connect pour la déconnexion
                // Goto --> url de redirection après la déconnexion de la mire
                // La revokation des token sera demandé par mire directement au BFF
                location.assign(`${environment.xConnectUrl}${Constants.ROUTES.X_CONNECT.LOGOUT}?goto=${goto}`);
            },
            () => { }
        );
    }

    /**
     * Permet la sauvegarde de la page demandée par l'utilisateur dans le sessionStorage
     * @param redirectTo La page demandée
     */
    private storeRedirectTo(redirectTo: string) {
        sessionStorage.setItem('redirectTo', redirectTo);
    }

    /**
     * Permet la supression de la page demandée par l'utilisateur dans le sessionStorage
     */
    private removeRedirectTo() {
        sessionStorage.removeItem('redirectTo');
    }

    /**
     * Récupération de la page initialement demandée par l'utilisateur dans le sessionStorage
     */
    private getRedirectTo(): string {
        return _.isNull(sessionStorage.getItem('redirectTo')) ? null : sessionStorage.getItem('redirectTo');
    }

    /**
     * Permet la sauvegarde du canal de connexion dans le sessionStorage
     * @param canal Le canal de communication
     */
    public storeCanal(canal: string) {
        sessionStorage.setItem('canal', canal);
    }

    /**
     * Permet la supression du canal de connexion dans le sessionStorage
     */
    private removeCanal() {
        sessionStorage.removeItem('canal');
    }

    /**
     * Récupération du canal de connexion dans le sessionStorage
     */
    private getCanal(): string {
        return _.isEmpty(sessionStorage.getItem('canal')) ? '' : sessionStorage.getItem('canal');
    }
}
