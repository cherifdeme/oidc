import { Injectable } from '@angular/core';
import { HttpService } from './http.service';
import { Context } from '../models/context';
import { HttpOperation } from '../models/http';
import { environment } from '../../environments/environment';
import Constants from 'src/const';

/**
 * Service pour la gestion des appels aux API places
 */
@Injectable()
export class ContextService {
  constructor(private httpService: HttpService) {}

  /**
   * Retourne le context de l'application
   * @param idCtx L'id du contexte sauvegargé
   */
  getContext(idCtx: string) {
    // Création HttpOperation
    const httpOperation: HttpOperation = {
      url: `${environment.apiBasePath}/context/${idCtx}`,
      operation: `${Constants.ACTIONS.GET_CONTEXT}${idCtx}`,
      options: { accept404: true },
    };

    return this.httpService.get(httpOperation);
  }

  /**
   * Spécifie le context de l'application à sauvegarder
   * @param context Le contexte à sauvegarder
   */
  setContext(context: Context) {
    // Création HttpOperation
    const httpOperation: HttpOperation = {
      url: `${environment.apiBasePath}/context`,
      operation: Constants.ACTIONS.SAVE_CONTEXT,
      body: context,
    };

    return this.httpService.post(httpOperation);
  }
}
