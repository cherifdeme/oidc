import { Injectable } from '@angular/core';
import { HttpService } from './http.service';
import { HttpOperation } from '../models/http';
import { environment } from 'src/environments/environment';
import Constants from 'src/const';

/**
 * Service pour la gestion des appels aux Database
 */
@Injectable()
export class DatabaseService {
    constructor(
        private httpService: HttpService
    ) { }

    /**
     * Retourne la liste des routage caisses via le dao MyBatis
     */
    getCaisses(application: string) {
        // Création HttpOperation
        const httpOperation: HttpOperation = {
            url: `${environment.apiBasePath}/db/daoListCaisses?application=${application}&count=10`,
            operation: Constants.ACTIONS.GET_ROUTE_CAISSES
        };

        return this.httpService.get(httpOperation);
    }

        /**
     * Retourne la liste des routage branches via jpa
     */
    getBranches(application: string) {
        // Création HttpOperation
        const httpOperation: HttpOperation = {
            url: `${environment.apiBasePath}/db/listBranches?application=${application}&count=10`,
            operation: Constants.ACTIONS.GET_ROUTE_BRANCHES
        };

        return this.httpService.get(httpOperation);
    }
}
