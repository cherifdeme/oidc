import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import * as _ from 'lodash';
import { Observable } from 'rxjs';
import { catchError, mergeMap } from 'rxjs/operators';
import Constants from 'src/const';
import { environment } from 'src/environments/environment';
import { getPathInfos } from '../../utils';
import { HttpOperation } from '../models/http';
import { User } from '../models/user';
import * as UIActions from '../redux/actions/ui.actions';
import * as UserSelectors from '../redux/selectors/session.selector';
import { AppState } from '../redux/state/app.state';
import { UIError } from '../redux/state/ui.state';
import * as SessionActions from '../redux/actions/session.actions';

/**
 * Service permettant la gestion des appels HTTP au BFF
 */
@Injectable()
export class HttpService {
  // Internal variable
  private user: User;

  constructor(
    private http: HttpClient,
    private router: Router,
    private store: Store<AppState>
  ) {
    // Ecoute du store pour savoir si un utilisateur a été sauvegardé
    this.store
      .pipe(select(UserSelectors.selectUser))
      .subscribe((user: User) => {
        this.user = user;
      });
  }

  /**
   * Gestion des requêtes de type GET
   * @param url Chemin de l'url
   */
  public get(httpOperation: HttpOperation): Observable<any> {
    return this.http.get<any>(httpOperation.url, httpOperation.options).pipe(
      catchError((error) => {
        throw this.handleApiError<any>(error, httpOperation);
      })
    );
  }

  /**
   * Gestion des requêtes de type POST
   * @param url Chemin de la requête
   * @param body Body de la requête
   */
  public post(httpOperation: HttpOperation): Observable<any> {
    return this.http
      .post<any>(httpOperation.url, httpOperation.body, httpOperation.options)
      .pipe(
        catchError((error) => {
          throw this.handleApiError<any>(error, httpOperation);
        })
      );
  }

  /**
   * Gestion des requêtes de type PATCH
   * @param url Chemin de la requête
   * @param body Body de la requête
   */
  public patch(httpOperation: HttpOperation): Observable<any> {
    return this.http
      .patch<any>(httpOperation.url, httpOperation.body, httpOperation.options)
      .pipe(
        catchError((error) => {
          throw this.handleApiError<any>(error, httpOperation);
        })
      );
  }

  /**
   * Gestion des requêtes de type DELETE
   * @param url Chemin de la requête
   */
  public delete(httpOperation: HttpOperation): Observable<any> {
    return this.http.delete<any>(httpOperation.url, httpOperation.options).pipe(
      catchError((error) => {
        throw this.handleApiError<any>(error, httpOperation);
      })
    );
  }

  handleApiError<T>(
    error: HttpErrorResponse,
    httpOperation: HttpOperation
  ): HttpErrorResponse {
    // Reset de la dernière erreur
    this.store.dispatch(UIActions.setLastError({ lastError: null }));
    let redirectToError = false;
    const errorMsg = !_.isEmpty(error.error)
      ? error.error.message
      : error.message;

    // construction url de redirection
    const redirectUrl = getPathInfos(this.router.url);

    // Création de l'objet d'affichage de l'erreur
    const uiError: UIError = {
      operation: httpOperation.operation,
      errorMessage: `${error.status} - ${errorMsg}`,
      link: {
        root: redirectUrl.root,
        searchParams: redirectUrl.searchParams,
      },
      details: {
        Url: httpOperation.url,
        Body: !_.isEmpty(httpOperation.body)
          ? JSON.stringify(httpOperation.body, null, '\t')
          : null,
      },
    };

    switch (error.status) {
      case 0:
        // Dans le cas d'une erreur CORS (ou serveur absent)
        uiError.errorMessage = Constants.ERROR_MESSAGES.SERVER_NOT_REACHABLE;
        redirectToError = true;
        break;
      case 404:
        redirectToError = !httpOperation.options.accept404;
        break;
      case 401:
        this.handle401(uiError);
        break;
      default:
        redirectToError = true;
    }

    if (redirectToError) {
      this.handleError(uiError);
    }

    return error;
  }

  handleError(uiError: UIError) {
    // Mise à jour de l'erreur dans le store
    this.store.dispatch(UIActions.setLastError({ lastError: uiError }));

    // Rédirection vers la page d'erreur pour l'afficher
    this.router.navigate(['/error']);
  }

  /**
   * Gest du code retour 401.
   * On renvoit sur la mire de connexion
   * @param uiError
   */
  handle401(uiError: UIError) {
    // Appel pour avoir le user connecté --> nouveau state
    // Création HttpOperation
    const httpOperation: HttpOperation = {
      url: `${environment.apiBasePath}/security/user`,
      operation: Constants.ACTIONS.GET_USER_INFORMATION,
    };
    this.get(httpOperation).subscribe((user: User) => {
      // Sauvegarde dans le sessionStorage la page demandée par l'utilisateur
      const searchParamsUrl = uiError.link.searchParams
        ? '?' + uiError.link.searchParams
        : '';
      sessionStorage.setItem(
        'redirectTo',
        `${uiError.link.root}${searchParamsUrl}`
      );

      // Génération d'un state pour X Connect et la récupértion du refresh token
      const xcsrfToken: string = user.state;
      // Construction URL pour la redirection vers le mire X Connect
      const queryParams = {
        client_Id: environment.clientId,
        redirect_uri: environment.redirectUrl,
        response_type: 'code',
        scope: 'openid',
        state: xcsrfToken,
      };

      let queryParamsString = `client_id=${queryParams.client_Id}`;
      queryParamsString = `${queryParamsString}&redirect_uri=${queryParams.redirect_uri}`;
      queryParamsString = `${queryParamsString}&response_type=${queryParams.response_type}`;
      queryParamsString = `${queryParamsString}&scope=${queryParams.scope}`;
      queryParamsString = `${queryParamsString}&state=${queryParams.state}`;

      // Redirection vers la mire X Connect
      location.assign(
        `${environment.xConnectUrl}${Constants.ROUTES.X_CONNECT.AUTHORIZE}?${queryParamsString}`
      );
    });
  }
}
