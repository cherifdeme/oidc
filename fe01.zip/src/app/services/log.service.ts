import { Injectable } from '@angular/core';
import { select, Store } from '@ngrx/store';
import * as _ from 'lodash';
import { NGXLogger } from 'ngx-logger';
import { environment } from 'src/environments/environment';
import {
  LogConfig,
  LogContext,
  LogLevel,
  DefaultLogContext,
} from '../models/log';
import * as LogconfigSelectors from '../redux/selectors/logconfig.selector';
import { AppState } from '../redux/state/app.state';
/**
 * Service pour la gestion des appels aux API places
 */
@Injectable()
export class LogService {
  constructor(private store: Store<AppState>, private logger: NGXLogger) {
    this.logger.setWithCredentialsOptionValue(true);

    // Ecoute du store pour savoir si une config est chargée
    this.store
      .pipe(select(LogconfigSelectors.selectLogConfigState))
      .subscribe((logconfig: LogConfig) => {
        if (!_.isEmpty(logconfig)) {
          // maj de la config
          this.logger.updateConfig({
            serverLoggingUrl: environment.serverLoggingUrl,
            level: Number(logconfig.clientLogLevel),
            serverLogLevel: Number(logconfig.serverLogLevel),
            disableConsoleLogging: Boolean(logconfig.disableConsoleLog),
          });
          // this.log(LogLevel.INFO, `Mise à jour de la configuration de log cliente | ${JSON.stringify(this.logger.getConfigSnapshot())}`);
        }
      });
  }

  log(
    level: LogLevel,
    message: string,
    logContext: LogContext = new DefaultLogContext()
  ) {
    const logContextString = JSON.stringify(logContext);
    switch (level) {
      case LogLevel.DEBUG:
        this.logger.debug(message, logContextString);
        break;
      case LogLevel.ERROR:
        this.logger.error(message, logContextString);
        break;
      case LogLevel.FATAL:
        this.logger.fatal(message, logContextString);
        break;
      case LogLevel.INFO:
        this.logger.info(message, logContextString);
        break;
      case LogLevel.LOG:
        this.logger.log(message, logContextString);
        break;
    }
  }
}
