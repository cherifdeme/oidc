import { Injectable } from '@angular/core';
import { HttpService } from './http.service';
import { HttpOperation } from '../models/http';
import { environment } from 'src/environments/environment';
import Constants from 'src/const';
import { from, Observable } from 'rxjs';

/**
 * Service pour la gestion des appels aux API places
 */
@Injectable()
export class OIDCService {
  constructor(private httpService: HttpService) {}

  getUserInfos() {
    // Création HttpOperation
    const httpOperation: HttpOperation = {
      url: `${environment.apiBasePath}/infos/users`,
      operation: Constants.ACTIONS.GET_USER_INFORMATION
    };
    return this.httpService.get(httpOperation);
  }

  controlToken() {
    // Création HttpOperation
    const httpOperation: HttpOperation = {
      url: `${environment.apiBasePath}/control/token`,
      operation: Constants.ACTIONS.CONTROL_TOKEN,
    };
    return this.httpService.get(httpOperation);
  }

    encryptSecureData(data) {
    // Création HttpOperation
    const httpOperation: HttpOperation = {
      url: `${environment.apiBasePath}/encrypt/message`,
      body: data,
      operation: Constants.ACTIONS.GET_CR_LIST
    };
    return this.httpService.post(httpOperation);
  }
}
