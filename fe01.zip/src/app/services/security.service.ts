import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpOperation } from '../models/http';
import Constants from 'src/const';
import { HttpService } from './http.service';

@Injectable()
export class SecurityService {
  constructor(private httpService: HttpService) {}

  login(code: string, redirect_uri: string, state: string, canal: string) {
    // Création HttpOperation
    const httpOperation: HttpOperation = {
      url: `${environment.apiBasePath}/security/login?code=${code}&redirect_uri=${redirect_uri}&state=${state}&canal=${canal}`,
      operation: Constants.ACTIONS.USER_LOGIN,
      options: { withCredentials: true },
    };

    return this.httpService.get(httpOperation);
  }

  standAlonelogout() {
    // Création HttpOperation
    const httpOperation: HttpOperation = {
      url: `${environment.apiBasePath}/security/standalonelogout`,
      operation: Constants.ACTIONS.USER_LOGOUT,
      options: { accept404: true, withCredentials: true },
    };

    return this.httpService.post(httpOperation);
  }

  getUserConnected() {
    // Création HttpOperation
    const httpOperation: HttpOperation = {
      url: `${environment.apiBasePath}/security/user`,
      operation: Constants.ACTIONS.GET_USER_INFORMATION,
    };

    return this.httpService.get(httpOperation);
  }
}
