const constants = {
    ROUTES: {
        PATHS: {
            AUTHORIZE: '/authorize'
        },
        PARAMS: {
            ID_CONTEXT: 'idCtx',
            CANAL: 'canal'
        },
        X_CONNECT : {
            AUTHORIZE: 'authorize',
            LOGOUT: 'loggedout'
        },
        REMOTE_APP : {
            AGENCES: 'agences'
        }
    },
    AUTH: {
        LOGOUT_STDA: 'LOGOUT_STDA',
        LOGOUT_BCK_CHNL: 'LOGOUT_BCK_CHNL'
    },
    MENUS: {
        HOME: 'home',
        AGENCES: 'agences',
        POSTE_MESSAGE: 'postMessage'
    },
    WEEK_DAYS: [
        {
            day_of_week: '1',
            label: 'Lundi'
        },
        {
            day_of_week: '2',
            label: 'Mardi'
        },
        {
            day_of_week: '3',
            label: 'Mercredi'
        },
        {
            day_of_week: '4',
            label: 'Jeudi'
        },
        {
            day_of_week: '5',
            label: 'Vendredi'
        },
        {
            day_of_week: '6',
            label: 'Samedi'
        },
        {
            day_of_week: '7',
            label: 'Dimanche'
        }
    ],
    ACTIONS: {
        REDIRECT_FROM_XCONNECT: 'Retour de la mire de connexion',
        GET_CONTEXT: 'Récupération du contexte: ',
        SAVE_CONTEXT: 'Sauvegarde du contexte',
        CONTROL_TOKEN: "Verification du token jwt",
        REDIRECTION_TO_XCONNECT: 'Vous allez être redirigé vers la mire de déconnexion',
        GET_CR_LIST: 'Récupération de la liste des CR',
        GET_CR_ENTITIES_LIST: 'Récupération de la liste des villes de la CR:',
        GET_CR_CITY_DISTRIBUTION_ENTITIES: 'Récupération de la liste des agences de la CR et de la ville:',
        USER_LOGIN: 'Connexion de l\'utilisateur',
        USER_LOGOUT: 'Déconnexion de l\'utilisateur',
        GET_USER_INFORMATION: 'Récupération information sur l\'utilisateur connecté',
        GET_ROUTE_CAISSES: 'Récupération routage caisses via My Batis',
        GET_ROUTE_BRANCHES: 'Récupération routage branches via JPA'
    },
    ERROR_MESSAGES: {
        BAD_XCONNECT_INFORMATION: 'Les informations de retour de connexion sont incorrectes',
        BAD_XCONNECT_CRSF: 'Les informations CRSF de retour de connexion sont invalides',
        SERVER_NOT_REACHABLE: '404 - Le serveur ne peut être contacté.'
    },
    LOGS: {
        LEVELS: {
            TRACE: 'TRACE',
            DEBUG: 'DEBUG',
            INFO: 'INFO',
            LOG: 'LOG',
            WARN: 'WARN',
            ERROR: 'ERROR',
            FATAL: 'FATAL',
            OFF: 'OFF'
        }
    }
};
export default constants;