class Environment {

    public production: boolean;
    public title: string;
    public apiBasePath: string;
    public xConnectUrl: string;
    public clientId: string;
    public redirectUrl: string;
    public remoteClientId: string;
    public remoteUrl: string;
    public remoteUrlRegex: string;
    public serverLoggingUrl: string;
    public logLevel: number;
    public serverLogLevel: number;
    public disableConsoleLogging: boolean;
    public backgroundColor: string;
    public swaggerUrl: string;

    constructor() {
        this.production = true;
    }
}

export const environment = new Environment();
