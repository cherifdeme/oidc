import * as _ from 'lodash';
import { Path } from './app/models/path';

export function getPathInfos(path: string): Path {
    const pathSplit = path.split('?');
    const queryString = pathSplit.length === 1 ? '' : pathSplit.pop();
    const queryParamsMap = {};
    if (!_.isEmpty(queryString)) {
        // Parse query string
        const params = queryString.split('&');
        params.forEach((param) => {
            const paramObject = param.split('=');
            queryParamsMap[paramObject[0]] = paramObject[1];
        });
    }

    return {
        root: pathSplit[0],
        searchParams: !_.isEmpty(queryParamsMap) ? queryParamsMap : null
    };
}
