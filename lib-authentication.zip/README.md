# lib-authentication

```
cd existing_repo
git remote add origin https://scm.saas.cagip.group.gca/cats/tribu-socles-architecture/p0042/s0115/libraries/lib-authentication.git
git branch -M master
git push -uf origin master

```

## Description
Librairie qui simplifie la configuration et l'utilisation de spring security.

Spring security est un framework puissant et personnalisable qui offre des fonctions d'authentification, d'autorisation,
de protection contre les attaques et d'intégration avec le Servelet API.

Cette librairie est compatible avec Springboot, Spring MVC, RESTful API.

## Usage

    <dependency>
        <groupId>fr.ca.cats.p0042.s0115</groupId>
        <artifactId>lib-authentication</artifactId>
        <version>1.0.0</version>
    </dependency>

## Releases

### 1.0.3
* gestion des erreurs pour un jeton saml vide
* mise à jour de la liste des chemins ignorés par la sécurité
* remplacement des méthodes de sécurité spring obsolètes
* mise à jour dépendances spring

### 1.0.2
* code en java 17
* mise à jour vers lib-commons(ex sharelib)

### 1.0.1
* ajout readme

### 1.0.0
* Ajout filtre de sécurité et de contexte
* Mise à jour vers Spring security 6.2.0
* Java 17
* socle.fwk 3.0.1
