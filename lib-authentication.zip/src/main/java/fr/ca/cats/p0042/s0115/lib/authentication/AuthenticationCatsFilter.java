package fr.ca.cats.p0042.s0115.lib.authentication;

import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.exception.UnauthorizedException;
import fr.ca.cat.ihm.security.ISecurity;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import java.io.IOException;

public final class AuthenticationCatsFilter extends BasicAuthenticationFilter {

    private ISecurity securityContextService;
    private ISecurityHandler securityHandler;


    public AuthenticationCatsFilter(AuthenticationManager authenticationManager, ISecurity securityContextService, ISecurityHandler securityHandler) {
        super(authenticationManager);
        this.securityContextService = securityContextService;
        this.securityHandler = securityHandler;
    }

    /**
     * intercepte toutes les rquétes et vérifie les habilitations
     *
     * @param request
     * @param response
     * @param chain
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain chain) throws ServletException, IOException {
        try {
            //récupération du Security DTO après check du jeton saml
            final var securityDTO = securityContextService.extractSecurityFromRequest(request);
            //ajout de la sécurité et des rôles autorisés dans le contexte
            securityHandler.addSecurityContext(securityDTO, request);
        } catch (TechnicalException e) {
            throw new RuntimeException(e);
        } catch (UnauthorizedException e) {
            response.setContentType(String.valueOf(MediaType.APPLICATION_JSON));
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("{\"erreur\":" + HttpStatus.UNAUTHORIZED.getReasonPhrase() + ",\"description\":\"le jeton saml est null\"}");
        } finally {
            chain.doFilter(request, response);
        }
    }
}