package fr.ca.cats.p0042.s0115.lib.authentication;

import fr.ca.cat.ihm.logger.LogUtils;
import fr.ca.cat.ihm.utils.Consommateur;
import fr.ca.cat.ihm.utils.ContextHelper;
import fr.ca.cat.ihm.utils.IdCorrelationUtils;
import fr.ca.cat.most.util.log.MDCConstants;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.MDC;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import java.io.IOException;


@Order(Ordered.HIGHEST_PRECEDENCE)
public class ContextFilter extends BasicAuthenticationFilter {

    public ContextFilter(AuthenticationManager authenticationManager) {
        super(authenticationManager);
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {

        final Consommateur imWorkingForThatGuy = ContextHelper.getEmetteur(request);
        //dans un contexte de réutilisation de threads par le moteur de servlet il doit y avoir le pendant ds le finally
        MDC.put(MDCConstants.CorrelationID, IdCorrelationUtils.getIdCorrelation());
        MDC.put(MDCConstants.nomOperation, request.getRequestURI());

        //tout pareil
        LogUtils.setEmetteur(imWorkingForThatGuy);

        ContextHelper.getContextExecution(request);
        final var ctxApp = ContextHelper.getContextApp(request);

        LogUtils.setConsommateur(ctxApp.getApplication());
        LogUtils.setConsommateurOrigine(ctxApp.getApplicationOrigine());

        MDC.put(MDCConstants.IdInstanceUA, ctxApp.getAppUid());
        filterChain.doFilter(request, response);
    }
}