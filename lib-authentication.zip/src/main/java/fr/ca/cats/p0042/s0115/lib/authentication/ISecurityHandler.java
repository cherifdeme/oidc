package fr.ca.cats.p0042.s0115.lib.authentication;

import fr.ca.cat.ihm.security.dto.SecurityDTO;
import jakarta.servlet.http.HttpServletRequest;

public sealed interface ISecurityHandler permits SecurityHandlerImpl {
    void addSecurityContext(SecurityDTO securityDTO, HttpServletRequest request);
}
