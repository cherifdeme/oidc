package fr.ca.cats.p0042.s0115.lib.authentication;

import fr.ca.cat.ihm.security.ISecurity;
import fr.ca.cat.ihm.security.domain.WebCatsPrincipalImpl;
import fr.ca.cat.ihm.security.dto.SecurityDTO;
import fr.ca.cat.ihm.security.dto.UserDTO;
import fr.ca.cat.ihm.security.dto.UserInfos;
import fr.ca.cat.ihm.utils.ContextHelper;
import fr.ca.cat.ihm.utils.RequestUtils;
import fr.ca.cats.p0042.s0115.lib.authentication.utils.WebAuthenticationUtils;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collection;

import static fr.ca.cat.ihm.security.impl.SecurityImpl.AULN_SESSION_ID;

@Component
public non-sealed class SecurityHandlerImpl implements ISecurityHandler {
    /**
     * récupération des rôles et création des rôles autorisés
     *
     * @param userDTO
     * @return
     */
    private static Collection<SimpleGrantedAuthority> buildSimpleGrantedAuthorities(final UserDTO userDTO) {
        Collection<SimpleGrantedAuthority> authorities = new ArrayList<>();
        final var resources = userDTO.getResources();
        resources.stream().forEach(e -> authorities.add(new SimpleGrantedAuthority(e)));
        return authorities;
    }

    @Override
    public void addSecurityContext(final SecurityDTO securityDTO, final HttpServletRequest request) {

        if (securityDTO != null) {

            final var correlationId = request.getHeader("CorrelationID");
            final var requestId = request.getHeader("x-request-id");
            final var requestContextPath = request.getContextPath();

            final var requestHeaders = WebAuthenticationUtils.extractRequestHttpHeaders(request);
            final var requestQueryParams = WebAuthenticationUtils.extractRequestQueryParams(request);
            final var auldCookieValue = RequestUtils.getCookie(AULN_SESSION_ID, request);

            securityDTO.setAulnSessionId(auldCookieValue);
            request.setAttribute(ISecurity.SECURITY_DTO_ATTRIBUTE_NAME, securityDTO);

            // build web principal
            final var userDTO = securityDTO.getUserDTO();
            final var contextExecution = ContextHelper.getContextExecution(request);
            final var infos = new UserInfos(userDTO, contextExecution);
            final var principal = new WebCatsPrincipalImpl(infos, correlationId, requestId);

            principal.setRequestContextPath(requestContextPath);
            principal.setRequestHeaders(requestHeaders);
            principal.setRequestQueryParams(requestQueryParams);

            SecurityContextHolder.getContext().setAuthentication(new UsernamePasswordAuthenticationToken(principal, securityDTO.getUserDTO().getSamlToken(),
                    buildSimpleGrantedAuthorities(userDTO)));
        }
    }
}
