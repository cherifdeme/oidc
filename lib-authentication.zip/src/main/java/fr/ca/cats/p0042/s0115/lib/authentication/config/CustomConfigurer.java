package fr.ca.cats.p0042.s0115.lib.authentication.config;

import fr.ca.cat.ihm.security.ISecurity;
import fr.ca.cat.ihm.security.impl.SecurityFullRedis;
import fr.ca.cats.p0042.s0115.lib.authentication.AuthenticationCatsFilter;
import fr.ca.cats.p0042.s0115.lib.authentication.ContextFilter;
import fr.ca.cats.p0042.s0115.lib.authentication.ISecurityHandler;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

public class CustomConfigurer extends AbstractHttpConfigurer<CustomConfigurer, HttpSecurity> {

    private ISecurity securityContextService;
    private ISecurityHandler securityHandler;

    public CustomConfigurer(ISecurity securityContextService, ISecurityHandler securityHandler) {
        this.securityContextService = securityContextService;
        this.securityHandler = securityHandler;
    }

    /**
     * ajoute un filtre qui intercepte toutes les requétes et verifie le token saml
     *
     * @param http
     */
    @Override
    public void configure(HttpSecurity http) {
        var authenticationManager = http.getSharedObject(AuthenticationManager.class);
        http.addFilterBefore(new ContextFilter(authenticationManager), BasicAuthenticationFilter.class);
        http.addFilter(new AuthenticationCatsFilter(authenticationManager, securityContextService, securityHandler));
    }
}
