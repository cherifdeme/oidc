package fr.ca.cats.p0042.s0115.lib.authentication.config;

import fr.ca.cat.ihm.security.ISecurity;
import fr.ca.cat.ihm.security.impl.SecurityFullRedis;
import fr.ca.cats.p0042.s0115.lib.authentication.ISecurityHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;

/*
 * class de configuration de la sécurité spring
 * active le pré ou post authentification niveau contrôleur ou niveau end point
 */

@Configuration
@EnableMethodSecurity(securedEnabled = true, jsr250Enabled = true)
public class SecurityConfig {

    private ISecurity securityContextService;

    private ISecurityHandler securityHandler;

    @Autowired
    public SecurityConfig(ISecurity securityContextService, ISecurityHandler securityHandler) {
        this.securityContextService = securityContextService;
        this.securityHandler = securityHandler;
    }

    /**
     * on instancie la class de configuration SecurityFilterChain
     * permet l'accès au doc
     * permet de Surveiller notre application et collecter des métriques
     * Garantie que toute demande adressée à notre application nécessite que l'utilisateur soit authentifié
     * désactive le formulaire de login par défaut de spring
     * désactive la protection csrf, nous avons un mécanisme d'authentification different
     *
     * @param http
     * @return
     * @throws Exception
     */
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
                .authorizeHttpRequests(auth -> auth
                        .anyRequest().authenticated())
                .csrf(AbstractHttpConfigurer::disable)
                .formLogin((AbstractHttpConfigurer::disable))
                .with(customConfigurer(), Customizer.withDefaults());

        http.headers(headers -> headers.xssProtection(HeadersConfigurer.XXssConfig::disable)
                .frameOptions(HeadersConfigurer.FrameOptionsConfig::disable));

        return http.build();
    }

    private CustomConfigurer customConfigurer() {
        return new CustomConfigurer(securityContextService, securityHandler);
    }

    @Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        return web -> web.ignoring().requestMatchers("/error", "images/**", "/v3/api-docs/**", "/v2/api-docs/**", "/swagger-ui/**", "/actuator/**", "/js/**", "/css/**", "/index.html","/view/**");
    }
}