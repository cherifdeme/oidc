package fr.ca.cats.p0042.s0115.lib.authentication.utils;

import jakarta.servlet.http.HttpServletRequest;

import java.util.*;
import java.util.stream.Collectors;

public final class WebAuthenticationUtils {

    public static Map<String, List<String>> extractRequestHttpHeaders(HttpServletRequest request) {
        Map<String, List<String>> lowerCaseHeaders = new HashMap<>();

        Enumeration<String> headerNames = request.getHeaderNames();
        if (headerNames != null) {
            String tmpHeaderName;
            while (headerNames.hasMoreElements()) {
                tmpHeaderName = headerNames.nextElement();
                addOrCreateList(lowerCaseHeaders, tmpHeaderName.toLowerCase(), request.getHeader(tmpHeaderName));
            }
        }
        return lowerCaseHeaders;
    }

    private static void addOrCreateList(Map<String, List<String>> map, String key, String value) {
        if (map.containsKey(key)) {
            map.get(key).add(value);
            return;
        }
        List<String> headerValues = new LinkedList<>();
        headerValues.add(value);
        map.put(key, headerValues);
    }

    public static Map<String, List<String>> extractRequestQueryParams(HttpServletRequest request) {
        return request.getParameterMap().entrySet()
                .stream()
                .collect(Collectors.toMap(
                                Map.Entry::getKey, list -> Arrays
                                        .stream(list.getValue())
                                        .filter(value -> value != null && value.length() > 0)
                                        .collect(Collectors.toList())
                        )
                );
    }

    public static String getFirstRequestHeader(final Map<String, List<String>> requestHeaders, String headerName) {
        if (headerName == null) {
            return null;
        }
        return Optional.ofNullable(requestHeaders)
                .map(h -> h.get(headerName.toLowerCase()))
                .map(l -> l.get(0))
                .orElse(null);
    }
}
