package fr.ca.cats.p0042.s0115.lib.authentication.filter;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.ca.cat.ihm.security.dto.SecurityDTO;
import fr.ca.cat.ihm.security.dto.UserDTO;
import fr.ca.cat.ihm.security.impl.SecurityFullRedis;
import fr.ca.cats.p0042.s0115.lib.authentication.AuthenticationCatsFilter;
import fr.ca.cats.p0042.s0115.lib.authentication.ContextFilter;
import fr.ca.cats.p0042.s0115.lib.authentication.ISecurityHandler;
import fr.ca.cats.p0042.s0115.lib.authentication.SecurityHandlerImpl;
import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletResponse;
import okhttp3.mockwebserver.MockResponse;
import okhttp3.mockwebserver.MockWebServer;
import org.junit.jupiter.api.*;
import org.mockito.Mockito;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.context.SecurityContextHolder;

import java.io.IOException;
import java.util.UUID;

import static org.mockito.Mockito.mock;

class AuthenticationFilterTest {

    public static MockWebServer mockWebServer;
    private AuthenticationCatsFilter authenticationCatsFilter;
    private ContextFilter contextFilter;
    private SecurityFullRedis securityContextService;

    @BeforeAll
    static void setUp() throws IOException {
        mockWebServer = new MockWebServer();
        mockWebServer.start();
    }

    @AfterAll
    static void tearDown() throws IOException {
        mockWebServer.shutdown();
    }

    @BeforeEach
    void init() throws JsonProcessingException {

        ObjectMapper objectMapper = new ObjectMapper();
        mockWebServer.enqueue(new MockResponse()
                .addHeader("Cookie", "AULN_SESSION_ID=bf4cd5f7-c784-45cf-b693-6ba526ca5b06"));

        AuthenticationManager authenticationManager = mock(AuthenticationManager.class);
        contextFilter = new ContextFilter(authenticationManager);
        securityContextService = mock(SecurityFullRedis.class);
        ISecurityHandler securityHandler = new SecurityHandlerImpl();
        authenticationCatsFilter = new AuthenticationCatsFilter(authenticationManager, securityContextService, securityHandler);
        SecurityContextHolder.getContext().setAuthentication(null);
    }

    @Test
    void doFilterInternalNoHeader() throws Exception {
        SecurityDTO sec = new SecurityDTO();
        UserDTO user = new UserDTO();
        user.setId("test");
        sec.setUserDTO(user);
        MockHttpServletRequest request = new MockHttpServletRequest();
        Mockito.when(securityContextService.extractSecurityFromRequest(request)).thenReturn(sec);
        authenticationCatsFilter.doFilter(request, mock(HttpServletResponse.class), mock(FilterChain.class));
        contextFilter.doFilter(request, mock(HttpServletResponse.class), mock(FilterChain.class));
        Assertions.assertNotNull(SecurityContextHolder.getContext().getAuthentication());
    }

    @Test
    void doFilterInternalInvalidToken() throws Exception {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("Authorization", "Bearer " + UUID.randomUUID());
        authenticationCatsFilter.doFilter(request, mock(HttpServletResponse.class), mock(FilterChain.class));
        Assertions.assertNull(SecurityContextHolder.getContext().getAuthentication());
    }
}
