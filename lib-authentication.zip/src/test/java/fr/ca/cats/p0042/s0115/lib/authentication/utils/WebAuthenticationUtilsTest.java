package fr.ca.cats.p0042.s0115.lib.authentication.utils;

import org.junit.Assert;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpHeaders;
import org.springframework.mock.web.MockHttpServletRequest;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

class WebAuthenticationUtilsTest {
    private static final String BEAR = "Bearer";
    private static final String CONSO_ORIGINE = "C_ORI";
    private static final String CATS_CONSOMMATEUR_ORIGINE_HEADER = "cats_consommateurorigine";
    private static final String AUTH = BEAR + " testAUC9";

    @Test
    void testExtractRequestHttpHeaders() {

        MockHttpServletRequest request = new MockHttpServletRequest();
        request.addHeader("Bearer", AUTH);
        Map<String, List<String>> headers = WebAuthenticationUtils.extractRequestHttpHeaders(request);
        List<String> bearer = headers.get("bearer");
        Assert.assertFalse(bearer.isEmpty());
        Assert.assertEquals(AUTH, bearer.get(0));
    }

    @Test
    void testGetFirstRequestHeader() {
        Map<String, List<String>> requestHeaders = Map.of(HttpHeaders.AUTHORIZATION.toLowerCase(), List.of(AUTH),
                CATS_CONSOMMATEUR_ORIGINE_HEADER.toLowerCase(), List.of(CONSO_ORIGINE));

        String authorization = WebAuthenticationUtils.getFirstRequestHeader(requestHeaders, "cats_consommateurorigine");
        assertEquals(CONSO_ORIGINE, authorization);
    }
}