# Sharelib

```
cd existing_repo
git remote add origin https://scm.saas.cagip.group.gca/cats/tribu-socles-architecture/p0042/s0115/libraries/lib-commons.git
git branch -M master
git push -uf origin master
```

## Description

La sharelib du socle IHM est une librairie utiliaire qui expose tous les jar necessaires pour les solutions qui
l'importent.

## Usage

    <dependency>
        <groupId>fr.ca.cats.p0042.s0115</groupId>
        <artifactId>lib-commons</artifactId>
        <version>3.0.7</version>
    </dependency>

## Releases

### 3.0.7

* Mise en oeuvre interopérabilité Host <=> Open (Zos connect)
* Simplification RsConf
* Ménage adsu et RPA
* Ménage Bundle

### 3.0.6

* fichier socle.beans.properties remplacé par @Value

### 3.0.5

* ajout du perf message lors des appels API
* ajout paramétrage de l'implémention de sécurité utilisée
* bonne gestion des erreurs quand le token saml est null
* ajout nouveau test pour la couverture sonar
* ajout du rs-proxy avec client http asynchrone
* ajout du ws-proxy (comme avant)
* mise à jour des dépendances
* mise à jour du StateDTO

### 3.0.4

* mise à jour du StateDTO

### 3.0.3

* sharelib devient lib-commons

### 3.0.2

* code en java 17
* correction CVE

### 3.0.1

* Java 17
* Spring 6
* Suppression des package nni, oidc, ihmf, catalog, ws, rs, orchestrator
* clean code

### 3.0.0

* java 17
* spring 6
* ajout spring security (lib-authentication)
* suppression instanciation des beans par xml
