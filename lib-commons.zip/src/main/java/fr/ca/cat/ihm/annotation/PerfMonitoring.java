package fr.ca.cat.ihm.annotation;

import fr.ca.cat.ihm.utils.Generated;
import org.springframework.stereotype.Component;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation permettant d'indiquer que l'on souhaite monitorer l'exécution d'une méthode
 *
 * @author ETP2473
 */
@Component
@Target(value = {ElementType.METHOD, ElementType.TYPE})
@Retention(value = RetentionPolicy.RUNTIME)
@Generated
public @interface PerfMonitoring {

    String prefix() default "";

    /**
     * Indique une description
     *
     * @return la description associée à l'annotation
     */
    String description() default "";

    /**
     * Counter utilisé dans les logs
     *
     * @return le counter
     */
    String counter() default "001";

    /**
     * identifiant unique de la trace
     *
     * @return
     */
    String mostCode() default "";

}