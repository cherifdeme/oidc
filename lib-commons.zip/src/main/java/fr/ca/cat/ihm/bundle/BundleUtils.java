package fr.ca.cat.ihm.bundle;

import fr.ca.cat.ihm.utils.Generated;
import org.apache.commons.text.StringSubstitutor;

import java.util.*;

/**
 * Utilitaire de formattage des messages bundle
 *
 * @author Pascal Rivière
 */
@Generated
public final class BundleUtils {

    /**
     * Permet de formatter un message avec paramètres
     * PI : MessageFormat n'est pas utilisé ici pour la problématique liée à l'utilisation de quote
     *
     * @param message le message
     * @param params  les paramètres
     * @return le message formatté
     */
    public static String formatMessage(final String message, final Object... params) {
        if (params == null) {
            return message;
        }
        Map<String, Object> map = new HashMap<>();
        for (int i = 0; i < params.length; i++) {
            map.put(String.valueOf(i), params[i]);
        }

        return StringSubstitutor.replace(message, map, "{", "}");
    }

    public static Enumeration<String> getKeys(String rbName, String local) {

        return ResourceBundle.getBundle(rbName, Locale.forLanguageTag(local)).getKeys();
    }

    public static boolean searchInEnum(Iterator<String> it, String key) {

        while (it.hasNext()) {
            if (key.equalsIgnoreCase(it.next())) {
                return true;
            }
        }
        return false;
    }

}
