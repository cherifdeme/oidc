package fr.ca.cat.ihm.bundle;

import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.logger.TypeLogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Service;

import java.util.Locale;

/**
 * Point d'entree pour l'acces au ResourceBundle permettant de parser des
 * fichiers de properties ou la base de donnée afin de gérer la localisation.
 * <p>
 * Par ex : localisation du catalogue des applications.
 *
 * @author E902425
 */
@Service
public final class ResourceBundleFactory {

    private static final Logger LOGGER = LogFactory.getLog(ResourceBundleFactory.class, TypeLogger.LOGGER_SOCLE);

    public ResourceBundleMessageSource messageSource;

    /**
     * Constructeur privé pour bloquer l'instanciation
     */
    @Autowired
    public ResourceBundleFactory(@Qualifier("bundleBean") ResourceBundleMessageSource messageSource) {
        this.messageSource = messageSource;
    }

    /**
     * Récupère le bundle de message selon la locale fourni.
     *
     * @param baseName
     * @param locale
     * @return un bundle
     */
    public ResourceBundleMessageSource getBundle(final String baseName, final Locale locale) {
        if (!messageSource.getBasenameSet().contains(baseName)) {
            LOGGER.debug("Ajout du bundle " + baseName, null);
            messageSource.addBasenames(baseName);
        }
        messageSource.setDefaultLocale(locale);
        return messageSource;
    }

    /**
     * Récupère les bundle de message selon la locale fourni.
     *
     * @param baseName
     * @param locale
     * @return un messageSource
     */
    public ResourceBundleMessageSource getBundle(final String baseName, final String baseNameVal, final Locale locale) {
        if (!messageSource.getBasenameSet().contains(baseName)) {
            LOGGER.debug("Ajout du bundle " + baseName + ", " + baseNameVal, null);
            messageSource.addBasenames(baseName);
        }
        messageSource.setDefaultLocale(locale);
        return messageSource;
    }
}
