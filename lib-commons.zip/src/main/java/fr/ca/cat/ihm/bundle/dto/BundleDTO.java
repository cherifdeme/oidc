package fr.ca.cat.ihm.bundle.dto;

import fr.ca.cat.ihm.utils.Generated;

import java.util.Locale;

/**
 * DTO permettant d'identifier le bundle à utiliser
 *
 * @author ETP2473
 */
@Generated
public class BundleDTO {

    /**
     * Le baseName du fichier properties
     */
    private final String baseName;

    /**
     * La locale à utiliser
     */
    private final Locale locale;


    /**
     * Full constructeur
     *
     * @param baseName Le baseName du fichier properties
     * @param locale   La locale à utiliser
     */
    public BundleDTO(final String baseName, final Locale locale) {
        super();
        this.baseName = baseName;
        this.locale = locale;
    }


    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {

        final var result = 31 + ((baseName == null) ? 0 : baseName.hashCode());
        return 31 * result + ((locale == null) ? 0 : locale.hashCode());
    }


    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        final var other = (BundleDTO) obj;
        if (baseName == null || !other.baseName.equals(baseName)) {
            return false;
        }
        if (locale == null && other.locale != null) {
            return false;
        } else if (locale != null) {
            return locale.equals(other.locale);
        }
        return false;
    }
}
