/**
 *
 */
package fr.ca.cat.ihm.config;


import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.TypeLogger;
import fr.ca.cat.ihm.utils.Generated;

/**
 * Classe utilitaire permettant d'initialiser la config + monitoring. Son interet est la mesure du temps d'initialisation.
 *
 * @author ETP1484
 */
@Generated
public final class FwkSocle {
    private static final ThreadLocal<Boolean> initHolder = new ThreadLocal<>();

    private FwkSocle() {

    }

    /**
     * Initialisation de la config avec prise de perf.
     */
    public static void init() {
        if (initHolder.get() == null) {
            synchronized (initHolder) {
                // perf init Spring
                final var start = System.currentTimeMillis();
                final var end = System.currentTimeMillis();

                LogFactory.getLog(TypeLogger.LOGGER_SOCLE).perf((int) (end - start), "Initialisation Spring", null);
                initHolder.set(Boolean.TRUE);
            }
        }

    }

    public static void unload() {
        initHolder.remove();
    }

}
