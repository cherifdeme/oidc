package fr.ca.cat.ihm.controller;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.utils.Generated;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

@Generated
public class APIView extends MappingJackson2JsonView {


    public final static String MODEL_KEY = "responseDTO";

    public APIView(Context ctx) {
        super();

        setModelKey(MODEL_KEY);
        setExtractValueFromSingleKeyModel(true);
    }


}
