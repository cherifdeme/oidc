/**
 *
 */
package fr.ca.cat.ihm.controller;

import fr.ca.cat.ihm.bundle.BundleUtils;
import fr.ca.cat.ihm.bundle.ResourceBundleFactory;
import fr.ca.cat.ihm.controller.bean.Browser;
import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.controller.dto.*;
import fr.ca.cat.ihm.error.ErrorManagerFactory;
import fr.ca.cat.ihm.error.dto.ErrorDTO;
import fr.ca.cat.ihm.error.dto.ErrorGravityType;
import fr.ca.cat.ihm.error.dto.ErrorRequestDTO;
import fr.ca.cat.ihm.exception.SocleException;
import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.helper.ISocleJavaHelper;
import fr.ca.cat.ihm.helper.SocleJavaHelper;
import fr.ca.cat.ihm.logger.*;
import fr.ca.cat.ihm.messages.dto.MessagesDTO;
import fr.ca.cat.ihm.performance.dto.PerformanceDTO;
import fr.ca.cat.ihm.security.dto.SecurityAPIBean;
import fr.ca.cat.ihm.security.dto.SecurityDTO;
import fr.ca.cat.ihm.security.dto.UserDTO;
import fr.ca.cat.ihm.utils.Generated;
import fr.ca.cat.ihm.utils.IdCorrelationUtils;
import fr.ca.cat.ihm.utils.RequestUtils;
import fr.ca.cat.ihm.utils.Version;
import fr.ca.cat.ihm.validation.IValidationProcessor;
import fr.ca.cat.ihm.validation.ValidationProcessorFactory;
import fr.ca.cat.ihm.web.client.IRsProxy;
import fr.ca.cat.ihm.web.client.RsConf;
import fr.ca.cat.ihm.web.client.WebClientFactory;
import fr.ca.cat.ihm.ws.WsConf;
import fr.ca.cat.ihm.ws.WsProxyFactory;
import fr.ca.cat.most.util.log.MostCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import java.security.Principal;
import java.util.*;

/**
 * "Controleur" ajoutant la couche d'interruptabilite. Ce controleur remplace le
 * AbstractController
 *
 * @author ETP1484
 */
@Generated
public abstract class AbstractBreakableController {

    private static final Logger LOGGER = LogFactory.getLog(AbstractBreakableController.class, TypeLogger.LOGGER_SOCLE);

    private static final MostCode MC_KO_FIND_ERROR_CODE = new MostCode("IHME_1472459348075");
    private static final MostCode MC_WARN_GET_MESSAGES = new MostCode("IHME_1427210476077");
    private static final MostCode MC_WARN_FILET_ERREUR = new MostCode("IHME_1499089312781");

    private final ISocleJavaHelper sjHelper = new SocleJavaHelper();

    @Autowired
    private WebClientFactory webClientFactory;

    @Autowired
    private ResourceBundleFactory resourceBundleFactory;

    /**
     * Methode a surcharger qui sera appelée pour repositionner l'UA dans un
     * etat qui a ete interrompu.<br>
     * Cette methode est facultative (toutes les UA ne sont pas interruptible)
     *
     * @param taskId identifiant de la tache
     * @return
     * @throws SocleException
     */
    @PostMapping(value = "/jump")
    @ResponseBody
    protected ResponseDTO jump(@RequestBody String taskId) throws SocleException {

        throw new TechnicalException(getContext(), "FWK032", new String[]{"jump"});
    }

    /**
     * Méthode renvoyant le message d'erreur demandé. Le client récupère donc un
     * objet contenant le message localisé.
     *
     * @return ErrorDTO
     * @throws SocleException
     */
    @PostMapping(value = "/getError")
    public @ResponseBody ResponseDTO getError(@RequestBody ErrorRequestDTO errorRequestDTO) throws SocleException {

        final String errorCode = errorRequestDTO.getCode();
        final String[] errorArgs = errorRequestDTO.getArgs();
        final ErrorDTO error = ErrorManagerFactory.getErrorManager().getErrorUA(getUaID(), errorCode, errorArgs,
                getContext());

        return createSuccessfulResponse(error);
    }

    /**
     * Méthode renvoyant sous forme de HashMap le bundle de l'UA représentant
     * l'ensemble des messages dynamiques de l'UA à destination du client. Le
     * client récupère donc les messages localisés en fonction de son
     * paramétrage navigateur sous forme de tableau avec clef=valeur.
     *
     * @return HashMap de messages de l'UA localisés
     * @throws SocleException
     */
    @PostMapping(value = "/getMessages", produces = "application/json; charset=UTF-8")
    @ResponseBody
    protected ResponseDTO getMessages() throws SocleException {
        // On récupère le bundle de message du socle
        ResourceBundleMessageSource rb = null;
        final String rbName = "bundle/" + this.getUaID() + "_message";

        try {
            rb = resourceBundleFactory.getBundle(rbName, getUserLocale());
        } catch (Exception e) {
            final String logMsg = "echec recuperation bundle " + rbName;
            LOGGER.info(MC_WARN_GET_MESSAGES, logMsg, getContext());
        }

        final MessagesDTO messages = new MessagesDTO();
        if (rb != null) {
            final Map<String, String> bundle = new HashMap<>();
            String currentKey;
            Enumeration<String> keys = BundleUtils.getKeys(rbName, getUserLocale().getLanguage());
            // On boucle sur l'ensemble des clefs des messages du bundle
            while (keys.hasMoreElements()) {
                currentKey = keys.nextElement();
                // On insère le couple clef / valeur du bundle dans la HashMap
                bundle.put(currentKey, rb.getMessage(currentKey, null, getUserLocale()));
            }
            // On renvoie au client la HashMap via un DTO spécifique pour les
            // messages localisés.
            messages.setValues(bundle);
        }

        return createSuccessfulResponse(messages);
    }

    /**
     * Envoie une mesure effectué dans la session.
     *
     * @param timeInMs     temps écoulé en ms entre le début et la fin de la mesure.
     * @param functionName identifiant de la fonction utilisé permettant de donner un
     *                     sens à la mesure.
     */
    protected final void top(int timeInMs, String functionName) {

        final PerfMessage msg = new PerfMessage(timeInMs, functionName);
        msg.setFunctionName(functionName);

        LogFactory.getLog(this.getClass()).perf(msg.getTimeInMs(), msg, null);
    }

    /**
     * Envoie une mesure effectué dans la session.
     *
     * @param code         permettant une recherche directe du message dans les traces.
     * @param timeInMs     temps écoulé en ms entre le début et la fin de la mesure.
     * @param functionName identifiant de la fonction utilisé permettant de donner un
     *                     sens à la mesure.
     */
    protected final void top(MostCode code, int timeInMs, String functionName) {

        final PerfMessage msg = new PerfMessage(timeInMs, functionName);
        msg.setFunctionName(functionName);

        LogFactory.getLog(this.getClass()).perf(code, msg.getTimeInMs(), msg, null);
    }

    /**
     * Retourne l'utilisateur.
     *
     * @return L'utilisateur.
     */
    protected UserDTO getUser() {
        return getSecurity().getUserDTO();
    }

    /**
     * Retourne l'objet sécurité contenant le User et d'autres informations.
     *
     * @return L'objet sécurité.
     */
    protected SecurityDTO getSecurity() {
        return sjHelper.getSecurity();
    }

    protected final <T> T getWsProxy(WsConf wsConf) throws TechnicalException {
        return WsProxyFactory.getWsProxy(wsConf, getContext(), getUaID(), getUaVersion());
    }

    /**
     * /** Retourne le context de l'application.
     *
     * @return Le servletContext de la WebApp.
     */
    protected final WebApplicationContext geWebApplicationContext() {
        return sjHelper.geWebApplicationContext();
    }

    /**
     * Retourne le bean du servletContext de la WebApp en fonction de son
     * identifiant.
     *
     * @return Le bean.
     */
    protected final Object getBean(String beanId) {
        return geWebApplicationContext().getBean(beanId);
    }

    /**
     * Renvoi le "context path" de la requète.
     *
     * @return Le "context path".
     */
    protected final String getContextPath() {
        return sjHelper.getContextPath();
    }

    /**
     * Retourne le bean du servletContext de la WebApp en fonction d'une
     * interface.
     *
     * @param <T>           Type de classe.
     * @param beanInterface
     * @return Le bean.
     */

    protected final <T> T getBean(Class<T> beanInterface) {
        return geWebApplicationContext().getBean(beanInterface);
    }

    /**
     * @return La locale du browser récuperer depuis la requete.
     */
    protected Locale getUserLocale() {
        return sjHelper.getUserLocale();
    }

    /**
     * @return Le "Principal" de la personne authentifié ou null si non
     * authentifié.
     */
    public Principal getUserPrincipal() {
        return sjHelper.getUserPrincipal();
    }

    /**
     * @return Le user agent utilisé.
     */
    protected String getUserAgent() {
        return sjHelper.getUserAgent();
    }

    /**
     * @return Renvoi l'objet Browser contenant des informations sur le Browser.
     */
    protected Browser getBrowser() {
        return sjHelper.getBrowser();
    }

    /**
     * @return Renvoie l'objet Context contenant des informations sur le
     * Browser, le user, l'UA en cours, etc
     * @throws TechnicalException
     */
    public Context getContext() {
        final String idPerf = LogUtils.getIdPerformance(RequestUtils.getRequest());
        return new Context(sjHelper.getBrowser(), new PerformanceDTO(idPerf), sjHelper.getSecurity(), getUaID(),
                getUaVersion(), sjHelper.getContextExecution());
    }

    /**
     * Création d'une instance de ResponseDTO à partir de données "data" Appel
     * au ValidationProcessor qui introspecte la classe DTO afin de parser les
     * annotations de chaque variable.
     *
     * @param data les données à retourner au client
     * @return Instance de ResponseDTO qui va être retournée côté client
     */
    protected final ResponseDTO createSuccessfulResponse(final DataDTO data) throws TechnicalException {
        return createSuccessfulResponse(data, null);
    }

    /**
     * Création d'une instance de ResponseDTO à partir de données "data" et de
     * l'état logique "state" Appel au ValidationProcessor qui introspecte la
     * classe DTO afin de parser les annotations de chaque variable.
     *
     * @param data  les données à retourner au client
     * @param state l'état logique à retourner au client
     * @return Instance de ResponseDTO qui va être retournée côté client
     */
    protected final ResponseDTO createSuccessfulResponse(DataDTO data, StateDTO state) throws TechnicalException {

        final ResponseDTO responseDTO = new ResponseDTO();

        responseDTO.setFullVersion(getUaFullVersion());
        responseDTO.setData(data);

        if (data != null) {
            IValidationProcessor vp = ValidationProcessorFactory.getProcessor();
            Map<String, List<Validator>> validators = vp.processValidation(data.getClass(), getContext(), getUaID());
            if (null != validators && validators.size() > 0 && null != data.getDynamicValidator()
                    && null != data.getDynamicValidator().getDynamicValidators()) {
                validators = vp.processDynamicValidator(validators, data);
            }
            responseDTO.setValidators(validators);
        }
        responseDTO.setState(state);
        MessageResponseDTO message = new MessageResponseDTO();
        message.setCorrelationId(IdCorrelationUtils.getIdCorrelation());
        message.setType(MessageResponseType.SUCCESS);
        responseDTO.setMessage(message);
        return responseDTO;

    }

    /**
     * la suppression du cookie API rend cette méthode dépréciée
     *
     * @deprecated
     */
    @Deprecated
    protected final ModelAndView createMAV(DataDTO data, StateDTO state) throws TechnicalException {

        return createMAV(createSuccessfulResponse(data, state));
    }

    /**
     * la suppression du cookie API rend cette méthode dépréciée
     *
     * @deprecated
     */
    @Deprecated
    protected final ModelAndView createMAV(ResponseDTO respData) {
        ModelAndView result = new ModelAndView();

        Context ctx = null;
        try {
            ctx = getContext();
        } catch (Exception e) {
            // pff on est mort
        }

        result.setView(new APIView(ctx));
        result.addObject(APIView.MODEL_KEY, respData);

        return result;
    }

    /**
     * Interception d'une exception de type SocleException par la dispatcher
     * servlet
     * ACHTUNG : Tant qu'il y a des controller avec des methodes qui retournent des ModelAndView, la gestion des erreurs doit garder ce prototypage !! (JIRA SD-59103)
     * Sinon Spring part en sucette en HTTP 404
     *
     * @param sEx exception interceptée par la dispatcher servlet
     * @return Instance de ResponseDTO qui va être retournée côté client
     */
    @ExceptionHandler(SocleException.class)
    protected ModelAndView handleSocleException(SocleException sEx) {
        return createMAV(createResponse(sEx));
    }

    /**
     * Interception d'une Exception non typée par la dispatcher servlet
     * ACHTUNG : Tant qu'il y a des controller avec des methodes qui retournent des ModelAndView, la gestion des erreurs doit garder ce prototypage !! (JIRA SD-59103)
     * Sinon Spring part en sucette en HTTP 404
     *
     * @param e exception interceptée par la dispatcher servlet
     * @return Instance de ResponseDTO qui va être retournée côté client
     */
    @ExceptionHandler(Exception.class)
    protected ModelAndView handleException(Exception e) {
        final String[] args = {this.getClass().getName()};
        final String code;

        if (e instanceof SocleException socleException) {
            code = socleException.getCode();
        } else {
            code = "FWK007";
        }

        TechnicalException tex = new TechnicalException(getContext(), e, code, args);
        LOGGER.warn(MC_WARN_FILET_ERREUR, e.getMessage(), e, getContext());
        return createMAV(createResponse(tex));
    }

    /**
     * Création d'une instance de ResponseDTO à partir d'une SocleException
     *
     * @param sEx exception qui a été lancée côté serveur
     * @return Instance de ResponseDTO qui va être retournée côté client
     */
    private ResponseDTO createResponse(SocleException sEx) {
        final ResponseDTO responseDto = new ResponseDTO();

        responseDto.setFullVersion(getUaFullVersion());

        final MessageResponseDTO message = new MessageResponseDTO();
        message.setType(sEx.getType());
        message.setCode(sEx.getCode());

        message.setCorrelationId(IdCorrelationUtils.getIdCorrelation());
        message.setInfosSupport(getInfoSupport());

        ErrorDTO errorDTO = null;
        try {
            errorDTO = ErrorManagerFactory.getErrorManager().getError(getUaID(), sEx, getContext());
        } catch (Exception e) {
            Context ctx = getContext();
            final String logMsg = "code erreur inexistant dans les ressources de l'UA " + sEx.getCode();
            LOGGER.error(MC_KO_FIND_ERROR_CODE, logMsg, e, ctx);
        }
        if (errorDTO != null) {
            message.setLabel(errorDTO.getMessage());
            message.setGravity(errorDTO.getGravity());
            message.setAction(errorDTO.getAction());
        } else {
            message.setLabel("Message d'erreur non défini");
            message.setGravity(ErrorGravityType.UNDEFINED);
            message.setAction("Action non définie");
        }
        responseDto.setMessage(message);
        return responseDto;
    }

    /**
     * Valide que le user dispose de la ressource d'habilitation demandée
     *
     * @param resourceID identifiant de la ressource d'habilitation demandée
     */
    protected final Boolean hasResource(String resourceID) {
        var result = false;

        result = getSecurity().getUserDTO().hasResource(resourceID);
        return result;
    }

    /**
     * Fournit l'ID technique de l'UA. A la mise en place du projet, les
     * archétypes mettent en place la méthode. qui renvoie une donnée "immuable"
     * issue de la conception : l'identifiant d'UA
     */
    protected abstract String getUaID();

    /**
     * Fournit la version technique de l'UA.
     */
    protected abstract Version getUaVersion();

    /**
     * pas de méthode abstraite pour ne pas avoir d'impact sur les UAs
     * existantes. A surcharger par les UAs. (réalisé par l'archétype pour les
     * UAs créées après cette évolution)
     *
     * @return la version "complète" (x.y.z)
     */
    protected String getUaFullVersion() {
        return null;
    }


    /**
     * Les infos qui seront insérées par le socle dans une réponse d'un
     * traitement en exception
     *
     * @return infos qui permettent au CDS d'améliorier la qualification
     * l'incident
     */
    protected InfosSupport<?> getInfoSupport() {
        return null;
    }

    /**
     * Récupération de l'ID Token
     *
     * @return l'ID Token lié au jeton de session
     */
    protected String getIdToken(RsConf rsConf) throws TechnicalException {
        Context context = getContext();
        SecurityAPIBean uaSecurityAPIBean = webClientFactory.getUaSecurityApiBean(rsConf, context, getUaID(),
                getUaVersion());
        return uaSecurityAPIBean.getId_token();
    }

    /**
     * Récupération de l'Access Token
     *
     * @return l'Access Token lié au jeton de session
     */
    protected String getAccessToken(RsConf rsConf) throws TechnicalException {
        Context context = getContext();

        return webClientFactory.getUaSecurityApiBean(rsConf, context, getUaID(), getUaVersion()).getAccess_token();

    }

    /**
     * Retourne le proxy permettant d'injecter les headers de sécurité dans la
     * requête REST.
     *
     * @return Le proxy
     * @throws TechnicalException
     */
    protected final IRsProxy getRsProxy(RsConf rsConf) throws TechnicalException {
        Context context = getContext();
        return webClientFactory.getRsProxy(rsConf, context, getUaID(), getUaVersion());
    }
}
