package fr.ca.cat.ihm.controller.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import fr.ca.cat.ihm.utils.Generated;

/**
 * L'annotation ci-dessous est utilisée pour ne pas rendre bloquant (pas d'exception remontée)
 * le fait qu'une propriété reçue ne soit pas définie dans le bean
 *
 * @author ETP2473
 */
@Generated
@JsonIgnoreProperties(ignoreUnknown = true)
public class BaseObject {

    private String id = "";

    private String uid = "";

    public String getUid() {
        return uid;
    }

    public void setUid(final String uid) {
        this.uid = uid;
    }

    public String getId() {
        return id;
    }

    public void setId(final String id) {
        this.id = id;
    }

}
