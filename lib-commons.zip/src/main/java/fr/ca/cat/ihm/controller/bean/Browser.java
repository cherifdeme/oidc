/**
 *
 */
package fr.ca.cat.ihm.controller.bean;

import fr.ca.cat.ihm.utils.ContextHelper;
import fr.ca.cat.ihm.utils.Generated;

import java.util.Locale;

/**
 * Contient des informations sur le browser client.
 *
 * @author ETP1484
 */
@Generated
public class Browser {

    private final Locale locale;
    private String userAgent = "";

    /**
     * @param userAgent Information du Browser  (si transmise dans la requête).
     * @param locale    Localisation du Browser (si transmise dans la requête).
     */
    public Browser(final String userAgent, final Locale locale) {
        super();
        this.userAgent = userAgent;
        this.locale = locale;
    }

    /**
     * @return userAgent Information du Browser (si transmise dans la requête).
     */
    public String getUserAgent() {
        if (null == userAgent) {
            return ContextHelper.DEFAULT_VALUE;
        }
        return userAgent;
    }

    /**
     * @return locale Localisation du Browser (si transmise dans la requête)
     */
    public Locale getLocale() {
        return locale;
    }


}
