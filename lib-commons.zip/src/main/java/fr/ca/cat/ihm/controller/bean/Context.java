package fr.ca.cat.ihm.controller.bean;

import fr.ca.cat.ihm.performance.dto.PerformanceDTO;
import fr.ca.cat.ihm.security.dto.SecurityDTO;
import fr.ca.cat.ihm.utils.Generated;
import fr.ca.cat.ihm.utils.IdCorrelationUtils;
import fr.ca.cat.ihm.utils.RequestUtils;
import fr.ca.cat.ihm.utils.Version;

/**
 * Regroupe des informations de contexte issue de la requete et de la securite.
 *
 * @author ETP1484
 */
@Generated
public class Context {

    private final Browser browser;
    private final PerformanceDTO performanceDTO;
    private final SecurityDTO securityDTO;
    private final String uaId;
    private final Version uaVersion;
    private final ContextExecution contextExecution;
    private final String correlationId;
    private final String vpucK8s;

    /**
     * Constructeur
     *
     * @param browser
     * @param performanceDTO
     * @param securityDTO
     * @param uaId
     * @param uaVersion
     */
    public Context(final Browser browser, final PerformanceDTO performanceDTO,
                   final SecurityDTO securityDTO, final String uaId, final Version uaVersion) {
        super();
        this.browser = browser;
        this.performanceDTO = null == performanceDTO ? new PerformanceDTO("uuid") : performanceDTO;
        this.securityDTO = securityDTO;
        this.uaId = uaId;
        this.uaVersion = uaVersion;
        this.contextExecution = new ContextExecution();
        this.correlationId = IdCorrelationUtils.getIdCorrelation();
        this.vpucK8s = RequestUtils.getCookie(RequestUtils.COOKIE_VPUC_K8S);

    }

    /**
     * Full constructeur
     *
     * @param browser
     * @param performanceDTO
     * @param securityDTO
     * @param uaId
     * @param uaVersion
     * @param contextExecution
     */
    public Context(final Browser browser, final PerformanceDTO performanceDTO, final SecurityDTO securityDTO,
                   final String uaId, final Version uaVersion, final ContextExecution contextExecution) {
        super();
        this.browser = browser;
        this.performanceDTO = null == performanceDTO ? new PerformanceDTO("uuid") : performanceDTO;
        this.securityDTO = securityDTO;
        this.uaId = uaId;
        this.uaVersion = uaVersion;
        this.contextExecution = contextExecution;

        this.correlationId = IdCorrelationUtils.getIdCorrelation();
        this.vpucK8s = RequestUtils.getCookie(RequestUtils.COOKIE_VPUC_K8S);
    }

    /**
     * @param browser
     * @param performanceDTO
     * @param securityDTO
     * @param uaId
     * @param uaVersion
     * @param contextExecution
     * @param correlationId    à récupérer dans les headers de la requete
     */
    public Context(final Browser browser, final PerformanceDTO performanceDTO, final SecurityDTO securityDTO,
                   final String uaId, final Version uaVersion, final ContextExecution contextExecution, final String correlationId) {
        super();
        this.browser = browser;
        this.performanceDTO = null == performanceDTO ? new PerformanceDTO("uuid") : performanceDTO;
        this.securityDTO = securityDTO;
        this.uaId = uaId;
        this.uaVersion = uaVersion;
        this.contextExecution = contextExecution;
        this.correlationId = null != correlationId && !correlationId.isEmpty() ? correlationId : IdCorrelationUtils.getIdCorrelation();
        this.vpucK8s = RequestUtils.getCookie(RequestUtils.COOKIE_VPUC_K8S);
    }

    /**
     * @return browser
     */
    public Browser getBrowser() {
        return browser;
    }

    /**
     * @return performanceDTO
     */
    public PerformanceDTO getPerformanceDTO() {
        return performanceDTO;
    }

    /**
     * @return securityDTO
     */
    public SecurityDTO getSecurityDTO() {
        return securityDTO;
    }

    /**
     * @return L'identifiant de l'UA.
     */
    public String getUaId() {
        return uaId;
    }

    /**
     * @return La version de l'UA.
     */
    public Version getUaVersion() {
        return uaVersion;
    }

    /**
     * Renvoie le contexte d'exécution
     *
     * @return ContextExecution (null si non renseigné)
     */
    public ContextExecution getContextExecution() {
        return contextExecution;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public String getVpucK8s() {
        return vpucK8s;
    }
}
