package fr.ca.cat.ihm.controller.bean;

import fr.ca.cat.ihm.utils.Consommateur;
import fr.ca.cat.ihm.utils.Generated;
import fr.ca.cat.ihm.utils.Version;

/**
 * Les infos envoyées par le PU_C sur les applications en cours pour le contexte de traces.
 *
 * @author ET00437
 */
@Generated
public class ContextApp {

    private String appId = Consommateur.UNKNOWN.getId();
    private String appUid = "";
    private Version versionApp = Consommateur.UNKNOWN.getVersion();
    private String origineId = Consommateur.UNKNOWN.getId();
    private String origineUid = "";
    private Version origineVersion = Consommateur.UNKNOWN.getVersion();


    /**
     * @return identifiant de l'application en cours (id au sens catalogue des UAs)
     */
    public String getAppId() {
        return appId;
    }

    public void setAppId(final String appId) {
        this.appId = appId;
    }

    /**
     * @return identifant d'instance de l'application en cours (uuid)
     */
    public String getAppUid() {
        return appUid;
    }

    public void setAppUid(final String appUid) {
        this.appUid = appUid;
    }

    /**
     * @return version de l'application au sens catalogue
     */
    public Version getVersionApp() {
        return versionApp;
    }

    public void setVersionApp(final Version versionApp) {
        this.versionApp = versionApp;
    }

    /**
     * Application origine = portail, ou application mère (ou mère de la mère, etc..)
     *
     * @return identifiant de l'application origine (id au sens catalogue des UAs)
     */
    public String getOrigineId() {
        return origineId;
    }

    public void setOrigineId(final String origineId) {
        this.origineId = origineId;
    }

    /**
     * Application origine = portail, ou application mère (ou mère de la mère, etc..)
     *
     * @return identifant d'instance de l'application origine (uuid)
     */
    public String getOrigineUid() {
        return origineUid;
    }

    public void setOrigineUid(final String origineUid) {
        this.origineUid = origineUid;
    }

    /**
     * @return version de l'application origine au sens catalogue
     */
    public Version getOrigineVersion() {
        return origineVersion;
    }

    public void setOrigineVersion(final Version origineVersion) {
        this.origineVersion = origineVersion;
    }

    public Consommateur getApplication() {
        return new Consommateur(appId, versionApp);
    }

    public Consommateur getApplicationOrigine() {
        return new Consommateur(appId, versionApp);
    }

}
