package fr.ca.cat.ihm.controller.bean;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import fr.ca.cat.ihm.utils.Generated;

/**
 * L'annotation ci-dessous est utilisée pour ne pas rendre bloquant (pas d'exception remontée)
 * le fait qu'une propriété reçue ne soit pas définie dans le bean
 *
 * @author ETP2473
 */
@Generated
@JsonIgnoreProperties(ignoreUnknown = true)
public class ContextExecution {
    private Profile profile;
    private SystemInfo systemInfo;
    private SessionMode sessionMode;

    /**
     * Constructeur
     */
    public ContextExecution() {
        super();
    }

    public ContextExecution(final Profile profile, final SystemInfo systemInfo, final SessionMode sessionMode) {
        super();
        this.profile = profile;
        this.systemInfo = systemInfo;
        this.sessionMode = sessionMode;
    }

    public Profile getProfile() {
        if (this.profile == null) {
            this.profile = new Profile();
        }
        return this.profile;
    }

    public void setProfile(final Profile profile) {
        this.profile = profile;
    }

    public SystemInfo getSystemInfo() {
        if (this.systemInfo == null) {
            this.systemInfo = new SystemInfo();
        }
        return this.systemInfo;
    }

    public void setSystemInfo(final SystemInfo systemInfo) {
        this.systemInfo = systemInfo;
    }

    public SessionMode getSessionMode() {
        if (this.sessionMode == null) {
            this.sessionMode = new SessionMode();
        }
        return this.sessionMode;
    }

    public void setSessionMode(final SessionMode sessionMode) {
        this.sessionMode = sessionMode;
    }


    /**
     * Avec les tablettes le mode de transport n'est pas fiable, en attendant la régularisation, on utilise la règle donnée par le projet nomadisme
     *
     * @return
     */

    public String getTansportReel() {
        return ("INTER".equals(getSessionMode().getTransport()) ||
                "2".equals(getSystemInfo().getOperationalPost().getType()) ? "INTER" : "INTRA");
    }

    @Override
    public String toString() {
        return new StringBuilder("ContextExecution [profile=").append(profile).append(", systemInfo=")
                .append(systemInfo).append(", sessionMode=").append(sessionMode).append("]").toString();
    }
}
