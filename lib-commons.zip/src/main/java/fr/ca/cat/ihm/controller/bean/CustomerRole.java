package fr.ca.cat.ihm.controller.bean;

import fr.ca.cat.ihm.utils.Generated;

import java.util.Arrays;

@Generated
public class CustomerRole extends BaseObject {
    private String[] markets = new String[]{};
    private String[] segments;

    /**
     * Retourne la liste des marchés de l'utilisateur connecté
     *
     * @return tableau de String
     */
    public String[] getMarkets() {
        if (null == markets) {
            markets = new String[]{};
        }
        return markets;
    }

    public void setMarkets(final String[] markets) {
        this.markets = markets.clone();
    }

    /**
     * Retourne la liste des segments de l'utilisateur connecté
     *
     * @return tableau de String
     */
    public String[] getSegments() {
        if (null == segments) {
            segments = new String[]{};
        }
        return segments;
    }

    public void setSegments(final String[] segments) {
        this.segments = segments.clone();
    }

    @Override
    public String toString() {
        return new StringBuilder("CustomerRole [markets=").append(Arrays.toString(markets)).append(", segments=")
                .append(Arrays.toString(segments)).append("]").toString();
    }

}
