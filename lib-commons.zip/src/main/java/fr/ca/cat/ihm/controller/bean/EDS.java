package fr.ca.cat.ihm.controller.bean;

import fr.ca.cat.ihm.utils.ContextHelper;
import fr.ca.cat.ihm.utils.Generated;

@Generated
public class EDS extends BaseObject {

    private String label;
    private String idexelst;

    /**
     * Retourne le libellé de l'élément de structure (ou agence).
     *
     * @return libellé de l'agence
     */
    public String getLabel() {
        if (null == label) {
            label = ContextHelper.DEFAULT_VALUE;
        }
        return label;
    }

    public void setLabel(final String label) {
        this.label = label;
    }

    @Override
    public String toString() {
        return new StringBuilder("EDS [id=").append(getId()).append(", label=").append(label).append("]").toString();
    }

    /**
     * Retourne l'identifiant de l'EDS, correspond au numéro de l'agence
     *
     * @return String id
     */
    @Override
    public String getId() {
        // sert uniquement à exposer la javadoc
        return super.getId();
    }

    /**
     * identifiant externe element de structure.
     *
     * @return idexelst
     */
    public String getIdexelst() {
        return idexelst;
    }

    /**
     * identifiant externe element de structure.
     * Aucune vérification de format n'est mise en oeuvre
     *
     * @param idexelst doit être fourni au format groupe (5 caractères zéros à gauche)
     */
    public void setIdexelst(String idexelst) {
        this.idexelst = idexelst;
    }

}
