package fr.ca.cat.ihm.controller.bean;

import fr.ca.cat.ihm.utils.ContextHelper;
import fr.ca.cat.ihm.utils.Generated;

@Generated
public class FunctionalPost extends BaseObject {
    private String label;
    private String functionId;
    private String edsId;
    private String functionLabel;

    /**
     * Retourne le libellé de poste fonctionnel (LPOSTF/32 alpha/EDS)
     *
     * @return String label
     */
    public String getLabel() {
        if (null == label) {
            label = ContextHelper.DEFAULT_VALUE;
        }
        return label;
    }

    public void setLabel(final String label) {
        this.label = label;
    }

    /**
     * Retourne l'identifiant de fonction (IDFONC/4 numériques/EDS)
     *
     * @return String id
     */
    public String getFunctionId() {
        if (null == functionId) {
            functionId = ContextHelper.DEFAULT_VALUE;
        }
        return functionId;
    }

    public void setFunctionId(final String functionId) {
        this.functionId = functionId;
    }

    /**
     * Retourne l'identifiant de l'agence de rattachement (IDELSTDE/12 alphanumériques/EDS)
     *
     * @return String id de l'agence
     */
    public String getEdsId() {
        if (null == edsId) {
            edsId = ContextHelper.DEFAULT_VALUE;
        }
        return edsId;
    }

    public void setEdsId(final String edsId) {
        this.edsId = edsId;
    }

    /**
     * Retourne la libellé de la fonction
     *
     * @return String Libellé de la fonction
     */
    public String getFunctionLabel() {
        if (null == functionLabel) {
            functionLabel = ContextHelper.DEFAULT_VALUE;
        }
        return functionLabel;
    }

    public void setFunctionLabel(final String functionLabel) {
        this.functionLabel = functionLabel;
    }

    @Override
    public String toString() {
        return new StringBuilder("FunctionalPost [id=").append(getId()).append(", label=").append(label).append(", functionId=")
                .append(functionId).append(", edsId=").append(edsId).append("]").toString();
    }

    /**
     * Retourne l'identifiant du poste fonctionnel (IDPOFO/9 alphanumériques/EDS)
     *
     * @return String id
     */
    @Override
    public String getId() {
        // sert uniquement à exposer la javadoc
        return super.getId();
    }
}
