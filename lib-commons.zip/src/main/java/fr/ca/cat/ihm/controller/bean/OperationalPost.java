package fr.ca.cat.ihm.controller.bean;

import fr.ca.cat.ihm.utils.ContextHelper;
import fr.ca.cat.ihm.utils.Generated;

import java.util.Arrays;

@Generated
public class OperationalPost extends BaseObject {
    private String label;
    private String type;
    private String mediaType;
    private String deviceType;
    private PrinterPeripheral[] printerPeripherals;
    private String ip;
    private String hostname;

    /**
     * Retourne le libellé du poste opérationel
     *
     * @return String Label support
     */
    public String getLabel() {
        if (null == label) {
            label = ContextHelper.DEFAULT_VALUE;
        }
        return label;
    }

    public void setLabel(final String label) {
        this.label = label;
    }

    /**
     * Retourne le type du poste opérationel
     *
     * @return String Type support
     */
    public String getType() {
        if (null == type) {
            type = ContextHelper.DEFAULT_VALUE;
        }
        return type;
    }

    public void setType(final String type) {
        this.type = type;
    }

    /**
     * Retourne le type du média (CDTME)
     *
     * @return String
     */
    public String getMediaType() {
        if (null == mediaType) {
            mediaType = ContextHelper.DEFAULT_VALUE;
        }
        return mediaType;
    }

    public void setMediaType(final String mediaType) {
        this.mediaType = mediaType;
    }

    /**
     * Retourne le type de l'appareil (CTIMRP)
     *
     * @return String
     */
    public String getDeviceType() {
        if (null == deviceType) {
            deviceType = ContextHelper.DEFAULT_VALUE;
        }
        return deviceType;
    }

    public void setDeviceType(final String deviceType) {
        this.deviceType = deviceType;
    }

    /**
     * Retourne la liste des imprimantes associées au device
     *
     * @return tableau de PrinterPeripheral
     */
    public PrinterPeripheral[] getPrinterPeripherals() {
        if (null == printerPeripherals) {
            printerPeripherals = new PrinterPeripheral[]{};
        }
        return printerPeripherals;
    }

    public void setPrinterPeripherals(final PrinterPeripheral[] printerPeripherals) {
        this.printerPeripherals = printerPeripherals.clone();
    }

    @Override
    public String toString() {
        return new StringBuilder("OperationalPost [id=").append(getId()).append(", label=").append(label).append(", type=")
                .append(type).append(", mediaType=").append(mediaType).append(", deviceType=").append(deviceType)
                .append(", printerPeripherals=").append(Arrays.toString(printerPeripherals)).append("]").toString();
    }

    /**
     * Retourne l'adresse IP du poste
     *
     * @return String IP
     */
    public String getIp() {
        if (null == ip) {
            ip = ContextHelper.DEFAULT_VALUE;
        }
        return ip;
    }

    public void setIp(final String iP) {
        this.ip = iP;
    }

    /**
     * Retourne le nom du poste physique
     *
     * @return String hostname
     */
    public String getHostname() {
        if (null == hostname) {
            hostname = ContextHelper.DEFAULT_VALUE;
        }
        return hostname;
    }

    public void setHostname(final String hostname) {
        this.hostname = hostname;
    }

    /**
     * Retourne l'identifiant du poste opérationel (IDPTVE)
     *
     * @return String id
     */
    @Override
    public String getId() {
        // sert uniquement à exposer la javadoc
        return super.getId();
    }
}
