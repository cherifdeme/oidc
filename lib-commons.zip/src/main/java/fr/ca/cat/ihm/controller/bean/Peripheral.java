package fr.ca.cat.ihm.controller.bean;

import fr.ca.cat.ihm.utils.ContextHelper;
import fr.ca.cat.ihm.utils.Generated;

@Generated
public class Peripheral extends BaseObject {

    private String type;
    private String label;
    private Integer isDefault;

    /**
     * Retourne le type du périphérique (CDTYPER)
     *
     * @return String type
     */
    public String getType() {
        if (type == null) {
            return ContextHelper.DEFAULT_VALUE;
        }
        return type;
    }

    public void setType(final String type) {
        this.type = type;
    }

    /**
     * Retourne le libellé du périphérique (LIPER)
     *
     * @return String label
     */
    public String getLabel() {
        if (null == label) {
            return ContextHelper.DEFAULT_VALUE;
        }
        return label;
    }

    public void setLabel(final String label) {
        this.label = label;
    }

    /**
     * Retourne LPTDEF
     * Valeurs possibles :
     * 1 : si le périphérique est celui par défaut,
     * 0 : sinon
     *
     * @return Integer
     */
    public Integer getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(final Integer isDefault) {
        this.isDefault = isDefault;
    }

    @Override
    public String toString() {
        return new StringBuilder("Peripheral [id=").append(getId()).append(", type=").append(type).append(", label=")
                .append(label).append(", isDefault=").append(isDefault).append("]").toString();
    }

    /**
     * Retourne l'identifiant du périphérique (IDCDPER)
     *
     * @return String id
     */
    @Override
    public String getId() {
        // sert uniquement à exposer la javadoc
        return super.getId();
    }
}
