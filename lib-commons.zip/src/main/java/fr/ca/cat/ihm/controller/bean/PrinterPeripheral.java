package fr.ca.cat.ihm.controller.bean;

import fr.ca.cat.ihm.utils.Generated;

/**
 * Un périphérique de type "imprimante"
 *
 * @author ETP2473
 */
@Generated
public class PrinterPeripheral extends Peripheral {

    private static final Integer DEFAULT_PRINTER_TYPE = 3;

    private static final Integer DEFAULT_COLOR_SUPPORT = 0;

    private static final Integer DEFAULT_PRINTER_TRAY_NUMBER = 1;

    private static final Integer DEFAULT_VERSO_SUPPORT = 0;


    /**
     * Le type d'imprimante
     */
    private Integer printerType;

    /**
     * Couleur supportée ou pas
     */
    private Integer colorSupport;

    /**
     * Le numéro du bac
     */
    private Integer printerTrayNumber;

    /**
     * Impression recto ou recto/verso
     */
    private Integer versoSupport;

    /**
     * Retourne le type de l'imprimante (CDTIMP)
     * Valeurs possibles :
     * 0 : Laser
     * 1 : Matricielle
     * 2 : jet d'encre
     * 3 : autre
     *
     * @return Integer printerType
     */
    public Integer getPrinterType() {
        if (printerType == null) {
            printerType = DEFAULT_PRINTER_TYPE;
        }
        return printerType;
    }

    /**
     * @param printerType printerType à définir
     */
    public void setPrinterType(final Integer printerType) {
        this.printerType = printerType;
    }

    /**
     * Retourne le type de couleur géré par l'imprimante (CDSUCO)
     * Valeurs possibles :
     * 0 : noir et blanc
     * 1 : couleur
     *
     * @return Integer colorSupport
     */
    public Integer getColorSupport() {
        if (colorSupport == null) {
            colorSupport = DEFAULT_COLOR_SUPPORT;
        }
        return colorSupport;
    }

    /**
     * @param colorSupport colorSupport à définir
     */
    public void setColorSupport(final Integer colorSupport) {
        this.colorSupport = colorSupport;
    }

    /**
     * Retourne le nombre de bacs de l'imprimante (NBBACS)
     *
     * @return Integer printerTrayNumber
     */
    public Integer getPrinterTrayNumber() {
        if (printerTrayNumber == null) {
            printerTrayNumber = DEFAULT_PRINTER_TRAY_NUMBER;
        }
        return printerTrayNumber;
    }

    /**
     * @param printerTrayNumber printerTrayNumber à définir
     */
    public void setPrinterTrayNumber(final Integer printerTrayNumber) {
        this.printerTrayNumber = printerTrayNumber;
    }

    /**
     * Retourne le type d'impression géré par l'imprimante (IVERSO)
     * Valeurs possibles :
     * 0 : recto seul
     * 1 : recto / verso
     *
     * @return Integer versoSupport
     */
    public Integer getVersoSupport() {
        if (versoSupport == null) {
            versoSupport = DEFAULT_VERSO_SUPPORT;
        }
        return versoSupport;
    }

    /**
     * @param versoSupport versoSupport à définir
     */
    public void setVersoSupport(final Integer versoSupport) {
        this.versoSupport = versoSupport;
    }

    /**
     * {@inheritDoc}
     *
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return new StringBuilder("PrinterPeripheral [printerType=").append(getPrinterType()).append(", colorSupport=")
                .append(getColorSupport()).append(", printerTrayNumber=").append(getPrinterTrayNumber())
                .append(", versoSupport=").append(getVersoSupport()).append(", type=").append(getType())
                .append(", label=").append(getLabel()).append(", isDefault=").append(getIsDefault())
                .append(", uid=").append(getUid()).append(", id=").append(getId()).append("]").toString();
    }

}
