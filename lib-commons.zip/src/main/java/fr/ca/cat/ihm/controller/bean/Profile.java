package fr.ca.cat.ihm.controller.bean;

import fr.ca.cat.ihm.utils.ContextHelper;
import fr.ca.cat.ihm.utils.Generated;

@Generated
public class Profile extends BaseObject {

    private FunctionalPost functionalPost;
    private User user;
    private CustomerRole customerRole;
    private String structureId;
    private String camEntity;
    private String inversedCAMEntity;

    /**
     * --> ZIDRSB
     * Réseau bancaire X(2) .
     * Valeurs possibles :
     * BD : PLATEFORME TELEPHONIQUE
     * BE : BANQUE ENTREPRISE
     * BP : BANQUE DE PROXIMITE
     * BS : BANQUE SPECIALISEE
     * FV : FIL VERT
     * IN : INTERNET
     * SI : SIEGE
     */
    private String bankNetwork;

    /**
     * Retourne le descriptif du poste fonctionnel courant
     *
     * @return FunctionaPost
     */
    public FunctionalPost getFunctionalPost() {
        if (null == functionalPost) {
            functionalPost = new FunctionalPost();
        }
        return functionalPost;
    }

    public void setFunctionalPost(final FunctionalPost functionalPost) {
        this.functionalPost = functionalPost;
    }

    /**
     * Retourne l'utilisateur
     *
     * @return User
     */
    public User getUser() {
        if (null == user) {
            user = new User();
        }
        return user;
    }

    public void setUser(final User user) {
        this.user = user;
    }

    /**
     * @return CustomerRole
     */
    public CustomerRole getCustomerRole() {
        if (null == customerRole) {
            customerRole = new CustomerRole();
        }
        return customerRole;
    }

    public void setCustomerRole(final CustomerRole customerRole) {
        this.customerRole = customerRole;
    }

    /**
     * Retourne le structureID de la CR de connexion.
     *
     * @return String
     */
    public String getStructureId() {
        if (null == structureId) {
            structureId = ContextHelper.DEFAULT_VALUE;
        }
        return structureId;
    }

    public void setStructureId(final String structureId) {
        this.structureId = structureId;
    }

    /**
     * Retourne le réseau bancaire X(2) ou ZIDRSB
     * Valeurs possibles :
     * BD : PLATEFORME TELEPHONIQUE
     * BE : BANQUE ENTREPRISE
     * BP : BANQUE DE PROXIMITE
     * BS : BANQUE SPECIALISEE
     * FV : FIL VERT
     * IN : INTERNET
     * SI : SIEGE
     *
     * @return String bankNetwork
     */
    public String getBankNetwork() {
        if (null == bankNetwork) {
            bankNetwork = ContextHelper.DEFAULT_VALUE;
        }
        return bankNetwork;
    }

    public void setBankNetwork(final String bankNetwork) {
        this.bankNetwork = bankNetwork;
    }


    /**
     * Retourne l'entité CAM de connexion
     *
     * @return String
     */
    public String getCamEntity() {
        if (null == camEntity) {
            camEntity = ContextHelper.DEFAULT_VALUE;
        }
        return camEntity;
    }

    public void setCamEntity(final String camEntity) {
        this.camEntity = camEntity;
    }

    /**
     * Retourne l'entité Inversé de connexion
     *
     * @return String
     */
    public String getInversedCAMEntity() {
        if (null == inversedCAMEntity) {
            inversedCAMEntity = ContextHelper.DEFAULT_VALUE;
        }
        return inversedCAMEntity;
    }

    public void setInversedCAMEntity(final String inversedCAMEntity) {
        this.inversedCAMEntity = inversedCAMEntity;
    }

    @Override
    public String toString() {
        return new StringBuilder("Profile [functionalPost=").append(functionalPost).append(", user=").append(user)
                .append(", customerRole=").append(customerRole).append(", structureId=").append(structureId)
                .append(", bankNetwork=").append(bankNetwork).append("]").toString();
    }

}
