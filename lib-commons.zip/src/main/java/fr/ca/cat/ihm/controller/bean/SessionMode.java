package fr.ca.cat.ihm.controller.bean;

import com.fasterxml.jackson.annotation.JsonProperty;
import fr.ca.cat.ihm.utils.ContextHelper;
import fr.ca.cat.ihm.utils.Generated;

@Generated
public class SessionMode extends BaseObject {


    public final static String USAGE_CLI = "CLI";
    public final static String USAGE_COL = "COL";


    private String idSessionPortail;
    private String canal;
    private String distribCanal;
    private String transport;
    private boolean ccmActive;
    private String usage;

    /**
     * Retourne l'identifiant de la session du portail
     *
     * @return String
     */
    public String getIdSessionPortail() {
        if (null == idSessionPortail) {
            idSessionPortail = ContextHelper.DEFAULT_VALUE;
        }
        return idSessionPortail;
    }

    public void setIdSessionPortail(final String idSessionPortail) {
        this.idSessionPortail = idSessionPortail;
    }

    /**
     * Retourne le code du canal utilisé (IDCANA)
     * Valeurs possibles :
     * 12 : agence
     * 3 : internet
     * 7 : centre de contact multimédia
     *
     * @return String
     */
    public String getCanal() {
        if (null == canal) {
            canal = ContextHelper.DEFAULT_VALUE;
        }
        return canal;
    }

    public void setCanal(final String canal) {
        this.canal = canal;
    }

    /**
     * Retourne le code cu canal de distribution (IDCNL)
     *
     * @return String
     */
    public String getDistribCanal() {
        if (null == distribCanal) {
            distribCanal = ContextHelper.DEFAULT_VALUE;
        }
        return distribCanal;
    }

    public void setDistribCanal(final String distribCanal) {
        this.distribCanal = distribCanal;
    }

    /**
     * Retourne le transport (valeur présente dans l'AD sous CDMOTR)
     * Valeurs possibles : INTER, INTRA
     *
     * @return String
     */
    public String getTransport() {
        if (null == transport) {
            transport = ContextHelper.DEFAULT_VALUE;
        }
        return transport;
    }

    public void setTransport(final String transport) {
        this.transport = transport;
    }

    /**
     * Indique si l'icône côte à côte doit être visible
     *
     * @return boolean
     */
    @JsonProperty("CCMActive")
    public boolean isCcmActive() {
        return ccmActive;
    }

    public void setCcmActive(final boolean ccmActive) {
        this.ccmActive = ccmActive;
    }

    @Override
    public String toString() {
        return new StringBuilder("SessionMode [canal=").append(canal).append(", distribCanal=").append(distribCanal)
                .append(", transport=").append(transport).append(", CcmActive=").append(ccmActive)
                .append(", usage=").append(usage).append("]").toString();
    }

    /**
     * Attendu CLI/COL
     * Distingue une session client d'une session agent sans attendre l'ident/authent.
     */
    public String getUsage() {
        return usage;
    }

    /**
     * Attendu CLI/COL
     * Distingue une session client d'une session agent sans attendre l'ident/authent.
     *
     * @param usage
     */
    public void setUsage(final String usage) {
        this.usage = usage;
    }

    /**
     * @return true si et seulement si usage="COL"
     */
    public Boolean isUsageCollaborateur() {
        return USAGE_COL.equals(usage);
    }

}
