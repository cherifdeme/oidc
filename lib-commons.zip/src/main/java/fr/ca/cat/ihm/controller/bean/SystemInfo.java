package fr.ca.cat.ihm.controller.bean;

import fr.ca.cat.ihm.utils.Generated;

import javax.xml.datatype.XMLGregorianCalendar;

@Generated
public class SystemInfo extends BaseObject {
    private OperationalPost operationalPost;
    private EDS eds;
    private XMLGregorianCalendar financialTransactionDate;

    /**
     * Retourne le descriptif du poste opérationnel
     *
     * @return OperationalPost
     */
    public OperationalPost getOperationalPost() {
        if (null == operationalPost) {
            operationalPost = new OperationalPost();
        }
        return operationalPost;
    }

    public void setOperationalPost(final OperationalPost operationalPost) {
        this.operationalPost = operationalPost;
    }

    /**
     * Retourne le descriptif de l'élément de structure (ou agence) de rattachement
     *
     * @return EDS
     */
    public EDS getEds() {
        if (null == eds) {
            eds = new EDS();
        }
        return eds;
    }

    public void setEds(final EDS eds) {
        this.eds = eds;
    }

    /**
     * Retourne la date de référence des opérations financières
     *
     * @return {XMLGregorianCalendar} financialTransactionDate
     */
    public XMLGregorianCalendar getFinancialTransactionDate() {
        return financialTransactionDate;
    }

    public void setFinancialTransactionDate(final XMLGregorianCalendar financialTransactionDate) {
        this.financialTransactionDate = financialTransactionDate;
    }

}
