package fr.ca.cat.ihm.controller.bean;

import fr.ca.cat.ihm.utils.ContextHelper;
import fr.ca.cat.ihm.utils.Generated;

@Generated
public class User extends BaseObject {
    private String code;
    private String type;
    private String lastName;
    private String firstName;

    /**
     * Retourne le code de l'utilisateur (IDUSER)
     *
     * @return String
     */
    public String getCode() {
        if (null == code) {
            code = ContextHelper.DEFAULT_VALUE;
        }
        return code;
    }

    public void setCode(final String code) {
        this.code = code;
    }

    /**
     * Retourne le type de l'utilisateur (TYACTR)
     * Valeurs possibles 9(2), norme CASA :
     * 01 : Agent
     * 02 : Personne physique connue du SI
     * 03 : Personne Physique non connue du SI
     * 04 : Prospect
     * 05 : Traitement info non déclanché par un humain
     *
     * @return String
     */
    public String getType() {
        if (null == type) {
            type = ContextHelper.DEFAULT_VALUE;
        }
        return type;
    }

    public void setType(final String type) {
        this.type = type;
    }

    /**
     * Retourne le nom de famille
     * Si Agent : (LNAGEN/32 char/EDS)
     *
     * @return String
     */
    public String getLastName() {
        if (null == lastName) {
            lastName = ContextHelper.DEFAULT_VALUE;
        }
        return lastName;
    }

    public void setLastName(final String lastName) {
        this.lastName = lastName;
    }

    /**
     * Retourne le prénom
     * Si Agent : (LNPREN/32 char/EDS)
     *
     * @return String
     */
    public String getFirstName() {
        if (null == firstName) {
            firstName = ContextHelper.DEFAULT_VALUE;
        }
        return firstName;
    }

    public void setFirstName(final String firstName) {
        this.firstName = firstName;
    }

    @Override
    public String toString() {
        return new StringBuilder("User [id=").append(getId()).append(", code=").append(code).append(", type=").append(type)
                .append(", lastName=").append(lastName).append(", firstName=").append(firstName).append("]").toString();
    }

    /**
     * Retourne l'identifiant de l'utilisateur (IAGENT)
     * Si Agent : (IDAGEN/12 char/EDS)
     *
     * @return String id
     */
    @Override
    public String getId() {
        // sert uniquement à exposer la javadoc
        return super.getId();
    }
}
