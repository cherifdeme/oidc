package fr.ca.cat.ihm.controller.dto;

import fr.ca.cat.ihm.utils.Generated;

@Generated
public class BooleanDTO extends DataDTO {

    private Boolean result;

    public BooleanDTO() {
        super();
    }

    /**
     * @return the result
     */
    public Boolean getResult() {
        return result;
    }

    /**
     * @param result the result to set
     */
    public void setResult(Boolean result) {
        this.result = result;
    }
}
