package fr.ca.cat.ihm.controller.dto;

import fr.ca.cat.ihm.utils.Generated;

@Generated
public class BusinessControlDTO extends DataDTO {
    private Boolean businessControlOk;
    private String errorTitle;
    private String errorMessage;


    public Boolean isBusinessControlOk() {
        return businessControlOk;
    }

    public void setBusinessControlOk(Boolean controleMetierOk) {
        this.businessControlOk = controleMetierOk;
    }

    public String getErrorTitle() {
        return errorTitle;
    }

    public void setErrorTitle(final String errorTitle) {
        this.errorTitle = errorTitle;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(final String errorMessage) {
        this.errorMessage = errorMessage;
    }


}
