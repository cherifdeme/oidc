package fr.ca.cat.ihm.controller.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import fr.ca.cat.ihm.utils.Generated;
import fr.ca.cat.ihm.validation.IDynamicValidator;
import org.apache.commons.lang3.StringUtils;

@Generated
public class DataDTO {

    private String className;

    @JsonIgnore
    private IDynamicValidator dynamicValidator = null;

    public String getClassName() {
        if (this.className == null) {
            this.className = getClass().getName();
        }
        return this.className;
    }

    public void setClassName(final String pClassName) {
        if (StringUtils.isBlank(pClassName)) {
            this.className = getClass().getName();
        } else {
            this.className = pClassName;
        }
    }

    @JsonIgnore
    public IDynamicValidator getDynamicValidator() {
        return dynamicValidator;
    }

    @JsonIgnore
    public void setDynamicValidator(IDynamicValidator dynamicValidator) {
        this.dynamicValidator = dynamicValidator;
    }
}