package fr.ca.cat.ihm.controller.dto;

import fr.ca.cat.ihm.utils.Generated;

/**
 * Objet inséré dans les réponses du controller d'UA en cas d'erreur (exception)
 * Permet de remonter au Centre de Services des infos sur l'UA.
 */
@Generated
public sealed interface InfosSupport<T> permits InfosSupportData {

    /**
     * @return identifiant UA
     */
    String getUaId();

    /**
     * @return la version du composant UA.
     */
    String getUaVersion();

    /**
     * @return le groupe support propriétaire de l'UA que le CDS pourra contacter
     */
    String getGroupeSupport();

    /**
     * Libre ! Permet à la squad d'ajouter des infos pertinentes à ses yeux qui seront transmises au CDS
     *
     * @return
     */
    T getMoreInfos();

}