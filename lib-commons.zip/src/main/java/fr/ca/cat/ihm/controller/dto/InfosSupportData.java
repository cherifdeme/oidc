package fr.ca.cat.ihm.controller.dto;

import fr.ca.cat.ihm.utils.Generated;

@Generated
public non-sealed class InfosSupportData<T> implements InfosSupport<T> {

    private String uaId;
    private String uaVersion;
    private String groupeSupport;

    private T moreInfos;

    @Override
    public String getUaId() {
        return uaId;
    }

    public void setUaId(String uaId) {
        this.uaId = uaId;
    }

    @Override
    public String getUaVersion() {
        return uaVersion;
    }

    public void setUaVersion(String version) {
        this.uaVersion = version;
    }

    @Override
    public String getGroupeSupport() {
        return groupeSupport;
    }

    public void setGroupeSupport(String supportMetis) {
        this.groupeSupport = supportMetis;
    }

    @Override
    public T getMoreInfos() {
        return moreInfos;
    }

    public void setMoreInfos(T moreInfos) {
        this.moreInfos = moreInfos;
    }


}
