package fr.ca.cat.ihm.controller.dto;

import fr.ca.cat.ihm.error.dto.ErrorGravityType;
import fr.ca.cat.ihm.utils.Generated;

@Generated
public class MessageResponseDTO {

    private String label;

    private MessageResponseType type = MessageResponseType.SUCCESS;

    private String code;

    private String action;

    private ErrorGravityType gravity;

    private String correlationId;

    private InfosSupport<?> infosSupport;

    public MessageResponseDTO() {
        super();
    }

    public MessageResponseType getType() {
        return type;
    }

    public void setType(MessageResponseType messageType) {
        this.type = messageType;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(final String label) {
        this.label = label;
    }

    public String getCode() {
        return code;
    }

    public void setCode(final String code) {
        this.code = code;
    }

    public String getAction() {
        return action;
    }

    public void setAction(final String action) {
        this.action = action;
    }

    public ErrorGravityType getGravity() {
        return gravity;
    }

    public void setGravity(ErrorGravityType gravity) {
        this.gravity = gravity;
    }

    public InfosSupport<?> getInfosSupport() {
        return infosSupport;
    }

    public void setInfosSupport(InfosSupport<?> infosSupport) {
        this.infosSupport = infosSupport;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }
}
