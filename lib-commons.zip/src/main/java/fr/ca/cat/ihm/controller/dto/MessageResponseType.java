package fr.ca.cat.ihm.controller.dto;

import fr.ca.cat.ihm.utils.Generated;

@Generated
public enum MessageResponseType {

    SUCCESS,

    TECHNICAL,

    BUSINESS

}