package fr.ca.cat.ihm.controller.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import fr.ca.cat.ihm.utils.Generated;

import java.util.List;
import java.util.Map;


/**
 * Objet échangé dans le sens contrôleur -> client
 */
@Generated
public class ResponseDTO {

    private MessageResponseDTO message;

    private DataDTO data;

    private Map<String, List<Validator>> validators;

    private StateDTO state;


    @JsonInclude(JsonInclude.Include.NON_NULL)
    private String fullVersion;

    public ResponseDTO() {
        super();
    }

    public MessageResponseDTO getMessage() {
        return message;
    }

    public void setMessage(MessageResponseDTO message) {
        this.message = message;
    }

    public DataDTO getData() {
        return data;
    }

    public void setData(DataDTO data) {
        this.data = data;
    }

    public Map<String, List<Validator>> getValidators() {
        return validators;
    }

    public void setValidators(Map<String, List<Validator>> validators) {
        this.validators = validators;
    }

    public StateDTO getState() {
        return state;
    }

    public void setState(StateDTO state) {
        this.state = state;
    }

    public String getFullVersion() {
        return fullVersion;
    }

    public void setFullVersion(String currentVersion) {
        this.fullVersion = currentVersion;
    }
}

