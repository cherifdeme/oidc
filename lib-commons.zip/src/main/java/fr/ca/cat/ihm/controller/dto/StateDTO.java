package fr.ca.cat.ihm.controller.dto;

/**
 * Représente l'état logique de l'UA, au sens de l'orchestrateur
 *
 * @author ET01343
 */
public class StateDTO {

    private String label;
    private PageType pageType = PageType.JSP;


    public String getLabel() {
        return label;
    }

    public void setLabel(final String label) {
        this.label = label;
    }

    public PageType getPageType() {
        return pageType;
    }

    public void setPageType(PageType pageType) {
        this.pageType = pageType;
    }

    public enum PageType {

        JSP,
        HTML
    }

}
