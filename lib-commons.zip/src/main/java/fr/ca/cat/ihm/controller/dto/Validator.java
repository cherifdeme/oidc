package fr.ca.cat.ihm.controller.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import fr.ca.cat.ihm.utils.Generated;
import fr.ca.cat.ihm.validation.IValidationProcessor;

import java.util.HashMap;
import java.util.Map;

/**
 * Classe représentant un validateur de champ visuel pour le client. {@link  IValidationProcessor}
 * <p>
 * Elle contient :
 * <p>
 * - la propriété de la classe introspectée qui possède une annotation.
 * - la classe de traitement cliente associée à l'annotation
 * - les arguments spécifiés dans l'annotation.
 *
 * @author ETP0979
 * @see IValidationProcessor
 */
@Generated
public class Validator {
    /**
     * Nom de l'attribut sur lesquel la regle de validation s'applique.
     */
    private String property;
    /**
     * Nom de la classe javascript de validation.
     */
    private String className;
    /**
     * Arguments utilisées par le validateur.
     */
    private Map<String, String> args;
    /**
     * Spécifie si le validateur est actif ou non
     * dans le cadre de la surcharge pour un validateur
     * dynamique
     * <p>
     * Par défaut, il est actif.
     * La propriété n'est pas sérialisée lors de la construction du DTO renvoyé
     */
    @JsonIgnore
    private boolean isActive = true;

    /**
     * Constructeur du validator.
     *
     * @param property  Nom de l'attribut sur lesquel la regle de validation s'applique.
     * @param className Nom de la classe javascript validation.
     * @param args      Arguments utilisées par le validateur.
     */
    public Validator(final String property, final String className, final Map<String, String> args) {
        this.property = property;
        this.className = className;
        this.args = args;
    }

    /**
     * Constructeur du validator utilisé dans le cadre des contrôles de surface dynamique.
     *
     * @param property  Nom de l'attribut sur lesquel la regle de validation s'applique.
     * @param className Nom de la classe javascript validation.
     * @param args      Arguments utilisées par le validateur.
     * @param isActive  True si le validateur est actif.
     */
    public Validator(final String property, final String className, final Map<String, String> args, boolean isActive) {
        this.property = property;
        this.className = className;
        this.args = args;
        this.isActive = isActive;
    }

    /**
     * Constructeur par recopie du validator utilisé dans le cadre des contrôles de surface dynamique.
     *
     * @param dv Validateur à copier
     */
    public Validator(final Validator dv) {
        this.property = dv.getProperty();
        this.className = dv.getClassName();
        this.args = new HashMap<>(dv.getArgs());
        this.isActive = dv.isActive();
    }

    /**
     * Méthode de clonage de l'objet
     *
     * @return Le validateur cloné
     */
    protected Object clone() throws CloneNotSupportedException {
        return new Validator(this);
    }

    /**
     * @return Nom de l'attribut sur lesquels la regle de validation s'applique.
     */
    public String getProperty() {
        return property;
    }

    /**
     * @param property Nom de l'attribut sur lesquel la regle de validation s'applique.
     */
    public void setProperty(final String property) {
        this.property = property;
    }

    /**
     * @return Nom de la classe validation.
     */
    public String getClassName() {
        return className;
    }

    /**
     * @param className Nom de la classe javascript validation.
     */
    public void setClassName(final String className) {
        this.className = className;
    }

    /**
     * @return Arguments utilisées par le validateur.
     */
    public Map<String, String> getArgs() {
        return args;
    }

    /**
     * @param args Arguments utilisées par le validateur.
     */
    public void setArgs(final Map<String, String> args) {
        this.args = args;
    }

    /**
     * @return isActive True si le validateur est actif.
     */
    @JsonIgnore
    public boolean isActive() {
        return isActive;
    }

    /**
     * @param isActive True si le validateur est actif.
     */
    @JsonIgnore
    public void setActive(boolean isActive) {
        this.isActive = isActive;
    }
}
