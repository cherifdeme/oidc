package fr.ca.cat.ihm.crypto;

import fr.ca.cat.ihm.utils.Generated;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@Generated
public class CryptoSHA256 {

    public static String cryptoHash(String text) throws NoSuchAlgorithmException {
        var md = MessageDigest.getInstance("SHA-256");

        // Change this to UTF-16 if needed
        md.update(text.getBytes(StandardCharsets.UTF_8));
        var digest = md.digest();

        return String.format("%064x", new BigInteger(1, digest));
    }

}
