package fr.ca.cat.ihm.dispatcher;

import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.logger.TypeLogger;
import fr.ca.cat.ihm.utils.Generated;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;

@Generated
public class SimpleCORSFilter implements Filter {

    private static final Logger LOGGER = LogFactory.getLog(SimpleCORSFilter.class, TypeLogger.LOGGER_SOCLE);

    @Override
    public void init(FilterConfig arg0) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse resp,
                         FilterChain chain) throws IOException, ServletException {

        final var response = (HttpServletResponse) resp;
        final var request = (HttpServletRequest) req;
        response.setHeader("Access-Control-Allow-Origin", request.getHeader("origin"));
        response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE");
        response.setHeader("Access-Control-Max-Age", "3600");
        response.setHeader("Access-Control-Allow-Credentials", "true");
        response.setHeader("Access-Control-Allow-Headers", "origin, x-requested-with, content-type, accept,contextapp, contextApp,contextExecution, contextexecution,idCorrelation, idcorrelation");
        if (LOGGER.isDebugEnabled()) {
            LOGGER.debug("SimpleCORSFilter : mise en place allow-Origin " + request.getHeader("origin"), null);
        }

        chain.doFilter(req, resp);
    }

    @Override
    public void destroy() {
    }

}