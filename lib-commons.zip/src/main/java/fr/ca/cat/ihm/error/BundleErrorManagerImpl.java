package fr.ca.cat.ihm.error;

import fr.ca.cat.ihm.bundle.ResourceBundleFactory;
import fr.ca.cat.ihm.bundle.BundleUtils;
import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.error.dto.ErrorDTO;
import fr.ca.cat.ihm.error.dto.ErrorGravityType;
import fr.ca.cat.ihm.exception.SocleException;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.logger.TypeLogger;
import fr.ca.cat.ihm.utils.StackTraceUtils;
import fr.ca.cat.most.util.log.MostCode;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Locale;
import java.util.MissingResourceException;

/**
 * Gestionnaire des erreurs (version avec accès à un ResourceBundle)
 *
 * @author ET01343
 */
@Service
public non-sealed class BundleErrorManagerImpl implements IErrorManager {

    private static final Logger LOGGER = LogFactory.getLog(BundleErrorManagerImpl.class, TypeLogger.LOGGER_SOCLE);

    private static final MostCode MC_KO_NO_BUNDLE = new MostCode("IHME_1472471676001");
    private static final MostCode MC_KO_IO_BUNDLE = new MostCode("IHME_1472471676003");
    private static final MostCode MC_KO_FORMAT_CODE_ERREUR = new MostCode("IHME_1472474543051");
    private static final String DEFAULT_LANGUAGE = "fr";
    private static final String SOCLE_CODE = "FWK";

    private ResourceBundleFactory resourceBundleFactory;

    /**
     * Constructeur
     */
    @Autowired
    public BundleErrorManagerImpl(ResourceBundleFactory resourceBundleFactory) {
        this.resourceBundleFactory = resourceBundleFactory;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ErrorDTO getError(final String idUA, final SocleException exception, final Context ctx) {
        return getErrorException(idUA, exception, ctx);
    }

    /**
     * Récupération de l'erreur à partir d'une exception
     *
     * @param idUA      idUA
     * @param exception
     * @param ctx
     * @return
     */
    private ErrorDTO getErrorException(final String idUA, final SocleException exception, final Context ctx) {
        ErrorDTO error;

        if (isExceptionOfFWK(exception)) {
            error = getErrorFWK(exception.getCode(), exception.getArgs(), ctx);
            // robustesse supplémentaire :
            // si on ne trouve pas le message d'erreur dans le fichier du socle,
            // alors on essaye dans le fichier de l'UA
            if ((error == null) || error.getCode().contains("ERR")) {
                error = getErrorUA(idUA, exception.getCode(), exception.getArgs(), ctx);
            }
        } else {
            error = getErrorUA(idUA, exception.getCode(), exception.getArgs(), ctx);
            // robustesse supplémentaire :
            // si on ne trouve pas le message d'erreur dans le fichier de l'UA,
            // alors on essaye dans le fichier du socle
            if ((error == null) || error.getCode().contains("ERR")) {
                error = getErrorFWK(exception.getCode(), exception.getArgs(), ctx);
            }
        }

        error.setStackTrace(StackTraceUtils.getStackTrace(exception));
        return error;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ErrorDTO getErrorFWK(final String code, final String[] args, final Context ctx) {
        return getError(code, args, ctx, SOCLE_CODE.toLowerCase());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public ErrorDTO getErrorUA(final String idUA, final String code, final String[] args, final Context ctx) {
        return getError(code, args, ctx, idUA);
    }

    /**
     * Récupération de la locale
     *
     * @param ctx le contexte utilisateur
     * @return la locale
     */
    private Locale getLocale(final Context ctx) {
        Locale locale;
        if (ctx == null || ctx.getBrowser() == null || ctx.getBrowser().getLocale() == null || StringUtils.isEmpty(ctx.getBrowser().getLocale().getLanguage())) {
            locale = new Locale(DEFAULT_LANGUAGE);
        } else {
            locale = ctx.getBrowser().getLocale();
        }
        return locale;
    }

    /**
     * {@inheritDoc}
     */
    private ErrorDTO getError(final String code, final String[] args, final Context ctx, final String idUA) {

        ResourceBundleMessageSource refErrors;
        ErrorDTO error = null;
        // contrôle du code erreur : 6c
        if (code.length() != 6) {
            error = new ErrorDTO(
                    "ERR000",
                    "Le code erreur doit être sur 6 caractères, code = " + code,
                    "", ErrorGravityType.ERROR);
            LOGGER.error(MC_KO_FORMAT_CODE_ERREUR, error.getMessage(), ctx);
        } else {
            // récupération du référentiel des erreurs
            try {
                final var locale = getLocale(ctx);
                refErrors = getBundle(idUA, locale);

                // récupération des caractéristiques de l'erreur
                ErrorGravityType errorGravityType = ErrorGravityType.UNDEFINED;

                final var messageKey = code + ".MSG";
                String errorMessage = refErrors.getMessage(messageKey, null, locale);
                final var actionKey = code + ".ACT";
                String errorAction = refErrors.getMessage(actionKey, null, locale);
                final var gravityKey = code + ".GRA";
                final var errorGravity = refErrors.getMessage(gravityKey, null, locale);
                // remplacement des libellés variabilisés
                if (null != args && args.length > 0) {
                    errorMessage = BundleUtils.formatMessage(errorMessage, (Object[]) args);
                    errorAction = BundleUtils.formatMessage(errorAction, (Object[]) args);
                }
                // mise à jour de la gravité
                if (!StringUtils.isBlank(errorGravity)) {
                    for (ErrorGravityType errorGravityItem : ErrorGravityType.values()) {
                        if (errorGravity.compareTo(errorGravityItem.getDbValue()) == 0) {
                            errorGravityType = errorGravityItem;
                            break;
                        }
                    }
                }
                // construction de l'erreur
                error = new ErrorDTO(code, errorMessage, errorAction, errorGravityType);

            } catch (MissingResourceException e) {
                error = new ErrorDTO("ERR001",
                        "Problème accès référentiel des erreurs, "
                                + e.getMessage(), "", ErrorGravityType.ERROR);
                LOGGER.error(MC_KO_NO_BUNDLE, error.getMessage(), e, ctx);
            } catch (IOException ioe) {
                error = new ErrorDTO("ERR003", "", "", ErrorGravityType.ERROR);
                LOGGER.error(MC_KO_IO_BUNDLE, error.getMessage(), ioe, ctx);
            }
        }
        return error;
    }


    /**
     * @param idUA   identifiant ua ou "fwk"
     * @param locale la locale pour laquelle on recherche le bundle
     * @return Le bundle qui contient les messages d'erreur personnalisés selon la locale
     * @throws IOException
     */
    private ResourceBundleMessageSource getBundle(final String idUA, final Locale locale) throws IOException {

        final var baseName = "bundle/" + idUA + "_errorbundle";
        return resourceBundleFactory.getBundle(baseName, locale);
    }

    /**
     * Permet de savoir si l'exception provient du socle.
     *
     * @param ex exception à tester
     * @return true si le code contient FWK
     */
    private boolean isExceptionOfFWK(final SocleException ex) {
        return ex.getCode().contains(SOCLE_CODE);
    }
}