/**
 *
 */
package fr.ca.cat.ihm.error;

import fr.ca.cat.ihm.utils.Generated;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Point d'entree pour l'acces au gestionnaire des erreurs
 *
 * @author ET01343
 */
@Component
@Generated
public final class ErrorManagerFactory {


    public static IErrorManager errorManager;

    /**
     * Constructeur privé pour bloquer l'instanciation
     */
    @Autowired
    private ErrorManagerFactory(IErrorManager errorManager) {
        this.errorManager = errorManager;
    }

    /**
     * Recupere l'instance du gestionnaire des erreurs
     *
     * @return
     */
    public static IErrorManager getErrorManager() {
        return errorManager;
    }
}
