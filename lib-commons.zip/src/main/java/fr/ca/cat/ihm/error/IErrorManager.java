package fr.ca.cat.ihm.error;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.error.dto.ErrorDTO;
import fr.ca.cat.ihm.exception.SocleException;
import fr.ca.cat.ihm.utils.Generated;

/**
 * Interface d'accès à la gestion des erreurs
 *
 * @author ET01343
 */
@Generated
public sealed interface IErrorManager permits BundleErrorManagerImpl {

    /**
     * Renvoie l'erreur correspondant au code donné,
     * pour la locale fournie dans le contexte d'exécution
     *
     * @param code le code de l'erreur (chaîne 6c)
     * @param args les chaînes variables à inclure dans le message
     * @param ctx  Contexte d'exécution, à récupérer via l'orchestrateur ou le controleur
     */
    ErrorDTO getErrorFWK(String code, String[] args, Context ctx);

    /**
     * Renvoie l'erreur correspondant au code donné,
     * pour la locale fournie dans le contexte d'exécution
     *
     * @param idUA l'identifiant de l'UA
     * @param code le code de l'erreur (chaîne 6c)
     * @param args les chaînes variables à inclure dans le message
     * @param ctx  Contexte d'exécution, à récupérer via l'orchestrateur ou le controleur
     */
    ErrorDTO getErrorUA(String idUA, String code, String[] args, Context ctx);

    /**
     * Renvoie l'erreur pour une exception héritant de SocleException et pour la
     * locale fournie dans le contexte d'exécution
     *
     * @param idUA      identifiant de l'UA
     * @param exception une exception héritant de SocleException
     * @param ctx       Contexte d'exécution, à récupérer via l'orchestrateur ou le controleur
     */
    ErrorDTO getError(String idUA, SocleException exception, Context ctx);

}
