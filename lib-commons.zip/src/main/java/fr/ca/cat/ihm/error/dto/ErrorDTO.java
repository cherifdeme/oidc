package fr.ca.cat.ihm.error.dto;

import fr.ca.cat.ihm.controller.dto.DataDTO;
import fr.ca.cat.ihm.utils.Generated;

@Generated
public class ErrorDTO extends DataDTO {
    private final String code;
    private final String message;
    private final String action;
    private final ErrorGravityType gravity;
    private String stackTrace; // si l'erreur est construite à partir d'une
    // exception

    /**
     * Constructeur
     *
     * @param code    code de l'erreur
     * @param message message d'erreur
     * @param action  action associee a l'erreur
     * @param gravity type gravite (0:info, 1:warn, 2:error)
     */
    public ErrorDTO(final String code, final String message, final String action, final ErrorGravityType gravity) {
        this.code = code;
        this.message = message;
        this.action = action;
        this.gravity = gravity;
        this.stackTrace = "";
    }

    public String getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    public String getAction() {
        return action;
    }

    public ErrorGravityType getGravity() {
        return gravity;
    }

    public String getStackTrace() {
        return stackTrace;
    }

    public void setStackTrace(final String stackTrace) {
        this.stackTrace = stackTrace;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        String builder = "ErrorDTO [code=" +
                code +
                ", message=" +
                message +
                ", action=" +
                action +
                ", gravity=" +
                gravity.toString() +
                "]";
        return builder;
    }
}
