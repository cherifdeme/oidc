package fr.ca.cat.ihm.error.dto;

import fr.ca.cat.ihm.utils.Generated;

@Generated
public enum ErrorGravityType {

    INFO("0"),

    WARN("1"),

    ERROR("2"),

    UNDEFINED(" ");

    private final String dbValue;

    ErrorGravityType(final String dbValue) {
        this.dbValue = dbValue;
    }

    public String getDbValue() {
        return dbValue;
    }

}