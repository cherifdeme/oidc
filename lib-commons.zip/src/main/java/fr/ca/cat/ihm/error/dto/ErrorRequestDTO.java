package fr.ca.cat.ihm.error.dto;

import fr.ca.cat.ihm.utils.Generated;

/**
 * Objet erreur en provenance du client
 *
 * @author ET01343
 */
@Generated
public class ErrorRequestDTO {

    private String code;
    private String[] args;

    /**
     * Retourne le code de l'erreur
     *
     * @return
     */
    public String getCode() {
        return code;
    }

    /**
     * Positionne le code de l'erreur
     */
    public void setCode(final String code) {
        this.code = code;
    }

    /**
     * Retourne les arguments à insérer dans le message d'erreur
     *
     * @return
     */
    public String[] getArgs() {
        return args;
    }
}
