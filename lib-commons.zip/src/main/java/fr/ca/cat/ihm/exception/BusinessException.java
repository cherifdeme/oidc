/**
 *
 */
package fr.ca.cat.ihm.exception;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.controller.dto.MessageResponseType;

/**
 * Exception de type métier.
 *
 * @author ETP1484
 */
public class BusinessException extends SocleException {

    /**
     *
     */
    private static final long serialVersionUID = 8243003594722371504L;

    /**
     * Création d’une exception avec le code de l’erreur et les arguments
     * nécessaires au message d’erreur.
     *
     * @param ctx  (permet de renseigner des données de log)
     * @param code
     * @param args
     */
    public BusinessException(final Context ctx, final String code, final String[] args) {
        super(ctx, code, args, MessageResponseType.BUSINESS);
    }

    /**
     * Création d’une exception avec le code de l’erreur.
     *
     * @param ctx  (permet de renseigner des données de log)
     * @param code
     */
    public BusinessException(final Context ctx, final String code) {
        this(ctx, code, null);

    }

    /**
     * Création d’une exception à partir d’une autre exception, avec le code de
     * l’erreur et les arguments nécessaires au message d’erreur
     *
     * @param ctx       (permet de renseigner des données de log)
     * @param throwable
     * @param code
     * @param args
     */
    public BusinessException(final Context ctx, final Throwable throwable,
                             final String code, final String[] args) {
        super(ctx, throwable, code, args, MessageResponseType.BUSINESS);
    }

    /**
     * Création d’une exception à partir d’une autre exception, avec le code de
     * l’erreur
     *
     * @param ctx       (permet de renseigner des données de log)
     * @param throwable
     * @param code
     */
    public BusinessException(final Context ctx, final Throwable throwable, final String code) {
        this(ctx, throwable, code, null);
    }

}
