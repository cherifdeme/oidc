package fr.ca.cat.ihm.exception;

import fr.ca.cat.ihm.utils.Generated;

/**
 * @author ET01528
 * Exception spécifique utilisée pour la Résilience
 * Contient l'exception d'origine masquée par le pattern pour traitement éventuel par l'appelant
 */
@Generated
public class CATResilientException extends RuntimeException {

    private static final long serialVersionUID = 3243825991090166892L;

    public CATResilientException() {
        super();
    }

    public CATResilientException(String message, Throwable cause) {
        super(message, cause);
    }

    public CATResilientException(String message) {
        super(message);
    }

    /**
     * Exception spécifique utilisée pour la Résilience
     *
     * @param cause : Exception d'origine
     */
    public CATResilientException(Throwable cause) {
        super(cause);
    }


}
