/**
 *
 */
package fr.ca.cat.ihm.exception;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.controller.dto.MessageResponseType;
import fr.ca.cat.ihm.error.IErrorManager;
import fr.ca.cat.ihm.utils.Generated;
import jakarta.annotation.PostConstruct;
import org.apache.commons.lang3.StringUtils;

import java.io.Serial;
import java.util.Arrays;

/**
 * Classe communes des exceptions non typées.
 *
 * @author ETP1484
 */
@Generated
public abstract class SocleException extends Exception {

    @Serial
    private static final long serialVersionUID = 7476631049296715729L;
    public IErrorManager errorManager;
    private final String code;
    private int statusCode;
    private String[] args;
    private String messageException;
    private final MessageResponseType type;
    private StackTraceElement[] stack;
    private final Context ctx;
    private String id = "";


    /**
     * Constructeur
     *
     * @param ctx     (permet de renseigner des données de log)
     * @param code    Code du message sur 6 caractères
     * @param args    Arguments du message (facultatif)
     * @param msgType
     */
    public SocleException(final Context ctx, final String code, final String[] args,
                          final MessageResponseType msgType) {
        super("SocleException");

        if (code == null || code.equals("")) {
            this.code = "FWK009";
        } else {
            this.code = code;
        }
        if (args != null) {
            this.args = Arrays.copyOf(args, args.length);
        }
        this.ctx = ctx;

        if (null != ctx) {
            id = ctx.getUaId();
        }
        if (StringUtils.isBlank(id)) {
            id = "fwk";
        }
        this.type = msgType;
    }

    /**
     * Constructeur
     *
     * @param ctx     (permet de renseigner des données de log)
     * @param code    Code du message sur 6 caractères
     * @param args    Arguments du message (facultatif)
     * @param msgType
     */
    public SocleException(final Context ctx, final Throwable throwable, final String code,
                          final String[] args, final MessageResponseType msgType) {
        this(ctx, code, args, msgType);
        this.stack = throwable.getStackTrace();
    }

    @PostConstruct
    public void afterConstructor(IErrorManager errorManager) {
        this.messageException = errorManager.getError(id, this, ctx).getMessage();

    }

    public StackTraceElement[] getStack() {
        return stack;
    }

    public String getCode() {
        return code;
    }

    public String[] getArgs() {
        return args;
    }

    public MessageResponseType getType() {
        return type;
    }

    public String getMessageException() {
        return messageException;
    }

    public void setMessageException(final String message) {
        this.messageException = message;
    }

    /**
     * Renvoie la stack trace d'erreur dans une chaine de texte concaténée.
     *
     * @return
     */
    public String getStackTraceAsString() {
        final StringBuilder sb = new StringBuilder();
        if (null != stack && stack.length > 0) {
            for (int i = 0; i < stack.length - 1; i++) {
                sb.append(stack[i]).append("\n");
            }
            sb.append(stack[stack.length - 1]);
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        final var name = getClass().getName();
        final Throwable cause = getCause();
        if (null != cause) {
            final var msg = cause.getMessage();
            if (!StringUtils.isBlank(msg)) {
                final int length = name.length() + 2 + msg.length();
                final StringBuilder buffer = new StringBuilder(length);
                return buffer.append(name).append(": ").append(msg).toString(); //$NON-NLS-1$
            } else {
                return name;
            }
        } else {
            final String msg = getLocalizedMessage();
            final int length = name.length() + 2 + msg.length();
            final StringBuilder buffer = new StringBuilder(length);
            return buffer.append(name).append(": ").append(msg).toString(); //$NON-NLS-1$
        }
    }

    public int getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }
}
