/**
 *
 */
package fr.ca.cat.ihm.exception;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.controller.dto.MessageResponseType;

/**
 * Exception de type technique.
 *
 * @author ETP0981
 */
public class TechnicalException extends SocleException {

    private static final long serialVersionUID = 5218893998614948178L;


    /**
     * Création d’une exception avec le code de l’erreur et les arguments
     * nécessaires au message d’erreur.
     *
     * @param ctx  (permet de renseigner des données de log)
     * @param code
     * @param args
     */
    public TechnicalException(final Context ctx, final String code, final String[] args) {
        super(ctx, code, args, MessageResponseType.TECHNICAL);
    }

    /**
     * Création d’une exception avec le code de l’erreur.
     *
     * @param ctx  (permet de renseigner des données de log)
     * @param code
     */
    public TechnicalException(final Context ctx, final String code) {
        this(ctx, code, null);
    }

    /**
     * Création d’une exception à partir d’une autre exception, avec le code de
     * l’erreur et les arguments nécessaires au message d’erreur
     *
     * @param ctx       (permet de renseigner des données de log)
     * @param throwable
     * @param code
     * @param args
     */
    public TechnicalException(final Context ctx, final Throwable throwable,
                              final String code, final String[] args) {
        super(ctx, throwable, code, args, MessageResponseType.TECHNICAL);
    }

    /**
     * Création d’une exception à partir d’une autre exception, avec le code de
     * l’erreur
     *
     * @param ctx       (permet de renseigner des données de log)
     * @param throwable
     * @param code
     */
    public TechnicalException(final Context ctx, final Throwable throwable, final String code) {
        this(ctx, throwable, code, null);

    }

    /**
     * Affiche l'erreur de manière plus détaillée
     */
    @Override
    public String toString() {
        return "TechnicalException [Message:" + this.getMessage() +
                ",Parameters:" + this.showArgs() +
                ",Code:" + this.getCode() +
                ",\nStackTrace:" + this.getStackTraceAsString() + "]\n";
    }

    /**
     * Retourne l'ensemble des paramètres
     *
     * @return l'ensemble des paramètres
     */
    private String showArgs() {
        var args = new StringBuilder();
        if (this.getArgs() != null) {
            for (String arg : this.getArgs()) {
                args.append(arg).append(",");
            }
            // on supprime le dernier , si nécessaire
            if (args.toString().endsWith(",")) {
                args = new StringBuilder(args.substring(0, args.length() - 1));
            }
        }
        return args.toString();
    }

}