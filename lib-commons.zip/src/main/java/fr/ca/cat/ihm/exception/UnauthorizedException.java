package fr.ca.cat.ihm.exception;

import fr.ca.cat.ihm.utils.Generated;
import org.joda.time.LocalDateTime;

@Generated
public class UnauthorizedException extends Exception {
    private String errorMessage;
    private int statusCode;


    public UnauthorizedException(final int scUnauthorized, final String reasonPhrase, final LocalDateTime now) {
        super(reasonPhrase);
        this.errorMessage = reasonPhrase;
        this.statusCode = scUnauthorized;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public int getErrorCode() {
        return statusCode;
    }

    public void setErrorCode(int statusCode) {
        this.statusCode = statusCode;
    }
}
