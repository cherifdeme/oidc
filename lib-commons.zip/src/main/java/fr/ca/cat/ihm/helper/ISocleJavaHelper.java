package fr.ca.cat.ihm.helper;

import fr.ca.cat.ihm.controller.bean.Browser;
import fr.ca.cat.ihm.controller.bean.ContextExecution;
import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.security.dto.SecurityDTO;
import org.springframework.web.context.WebApplicationContext;

import java.security.Principal;
import java.util.Locale;

public sealed interface ISocleJavaHelper permits SocleJavaHelper {

    /**
     * @return Objet Browser contenant des informations sur le Browser.
     * @see #getUserAgent()
     * @see #getUserLocale()
     */
    Browser getBrowser();

    /**
     * Retourne l'objet sécurité contenant le User et d'autres informations.
     *
     * @return L'objet sécurité
     * @throws TechnicalException
     */
    SecurityDTO getSecurity();

    /**
     * @return La locale du browser, recuperee depuis la requete.
     */
    Locale getUserLocale();

    /**
     * @return Le "Principal" de la personne authentifié ou null si non authentifié.
     */
    Principal getUserPrincipal();

    /**
     * @return Le browser utilisé.
     */
    String getUserAgent();

    /**
     * /** Retourne le context de l'application.
     *
     * @return Le servletContext de la WebApp.
     */
    WebApplicationContext geWebApplicationContext();

    /**
     * Renvoi le "context path" de la requète.
     *
     * @return Le "context path".
     */
    String getContextPath();

    ContextExecution getContextExecution();

}