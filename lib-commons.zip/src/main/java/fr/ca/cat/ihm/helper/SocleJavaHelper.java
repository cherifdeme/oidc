/**
 *
 */
package fr.ca.cat.ihm.helper;

import fr.ca.cat.ihm.controller.bean.Browser;
import fr.ca.cat.ihm.controller.bean.ContextExecution;
import fr.ca.cat.ihm.security.dto.SecurityDTO;
import fr.ca.cat.ihm.utils.ContextHelper;
import fr.ca.cat.ihm.utils.Generated;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.support.WebApplicationContextUtils;

import java.security.Principal;
import java.util.Locale;

/**
 * Permet de stoker des méthodes utilisées par plusieurs classes de socle.fwk.java
 */
public non-sealed class SocleJavaHelper implements ISocleJavaHelper {

    /**
     * Clef de configuration de la sécurité
     * informant le socle s'il est en mode bouchon pour la gestion du jeton SAML.
     */
    private static final String MSG_REQUEST_NULL = "Erreur, la requete ne peut etre nulle";

    /**
     * Constructeur
     */
    public SocleJavaHelper() {
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Browser getBrowser() {
        return new Browser(getUserAgent(), getUserLocale());
    }


    /**
     * Retourne l'objet sécurité contenant le User et d'autres informations.
     *
     * @param request request
     * @return L'objet sécurité.
     */
    @Generated
    public SecurityDTO getSecurity(HttpServletRequest request) {

        assert null != request : MSG_REQUEST_NULL;
        return (SecurityDTO) request.getAttribute("securityDTO");
    }


    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.helper.ISocleJavaHelper#getSecurity()
     */
    @Override
    public SecurityDTO getSecurity() {
        return this.getSecurity(getRequest());
    }


    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.helper.ISocleJavaHelper#getUserLocale()
     */
    @Override
    @Generated
    public Locale getUserLocale() {
        var request = getRequest();
        assert null != request : MSG_REQUEST_NULL;

        return request.getLocale();
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.helper.ISocleJavaHelper#getUserPrincipal()
     */
    @Override
    @Generated
    public Principal getUserPrincipal() {
        var request = getRequest();
        assert null != request : MSG_REQUEST_NULL;

        return request.getUserPrincipal();
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.helper.ISocleJavaHelper#getUserAgent()
     */
    @Override
    @Generated
    public String getUserAgent() {
        var request = getRequest();
        assert null != request : MSG_REQUEST_NULL;
        return request.getHeader("User-Agent");
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.helper.ISocleJavaHelper#geWebApplicationContext()
     */
    @Override
    public final WebApplicationContext geWebApplicationContext() {
        return WebApplicationContextUtils.getWebApplicationContext(getRequest().getSession().getServletContext());
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.helper.ISocleJavaHelper#getContextPath()
     */
    @Override
    @Generated
    public final String getContextPath() {
        return getRequest().getContextPath();
    }

    /**
     * Retourne la requête.
     *
     * @return La requête.
     */
    @Generated
    private final HttpServletRequest getRequest() {
        var t = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        return t.getRequest();

    }

    /**
     * (non-Javadoc)
     *
     * @see fr.ca.cat.ihm.helper.ISocleJavaHelper#getContextExecution()
     */
    @Override
    public ContextExecution getContextExecution() {
        // On utilise l'utilitaire pour récupérer le contexte d'exéxcution
        return ContextHelper.getContextExecution(getRequest());
    }

}
