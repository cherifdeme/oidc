/**
 *
 */
package fr.ca.cat.ihm.helper;

import fr.ca.cat.ihm.utils.Version;

/**
 * @author ETP1484
 * Permet d'extraire la version depuis la chaine de texte.
 */
public final class VersionHelper {


    /**
     * Constructeur privé car classe utilitaire
     * cela permet de masquer le constructeur par défaut
     */
    VersionHelper() {
        super();
    }

    /**
     * Renvoi la version de l'UA sans SNAPSHOT.
     *
     * @param fullVersion la version complete (avec SNAPSHOT...) de l'UA.
     * @return La version de l'UA sans SNAPSHOT.
     */
    public static Version getLongVersion(final String fullVersion) {
        return new Version(getLongStrVersion(fullVersion));
    }


    /**
     * Renvoi la version courte de l'UA (x.y).
     *
     * @param fullVersion la version complete (avec SNAPSHOT...) de l'UA.
     * @return La version courte de l'UA (x.y).
     */
    public static Version getVersion(final String fullVersion) {
        final var longVersion = getLongStrVersion(fullVersion);
        String[] split = longVersion.split("\\.");

        return new Version(split.length > 1 ? split[0].concat(".").concat(split[1]) : longVersion);
    }

    /**
     * Renvoi la version de l'UA sans SNAPSHOT.
     *
     * @param fullVersion la version complete (avec SNAPSHOT...) de l'UA.
     * @return La version de l'UA sans SNAPSHOT.
     */
    private static String getLongStrVersion(final String fullVersion) {
        final var index = fullVersion.indexOf("-SNAPSHOT");

        return index > 0 ? fullVersion.substring(0, index) : fullVersion;
    }

}
