package fr.ca.cat.ihm.jsp;

import fr.ca.cat.ihm.bundle.BundleUtils;
import fr.ca.cat.ihm.bundle.ResourceBundleFactory;
import fr.ca.cat.ihm.utils.Generated;
import fr.ca.cat.ihm.utils.Version;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Locale;


/**
 * Composant qui masque la "complexité" d'accès aux bundles de messages
 *
 * @author et00437
 * @deprecated
 */
@Generated
public class BundleJspFwk {
    @Autowired
    private ResourceBundleFactory resourceBundleFactory;
    private String uaId = null;

    private Locale locale = Locale.FRENCH;

    /**
     * Avant de virer cette méthode, il faut refaire fwk.jsp dans les archetypes et que toutes les UAs l'aient mis en oeuvre cette nouvelle version.
     *
     * @param uaId
     * @param version
     * @param request
     */
    public BundleJspFwk(final String uaId, final Version version, final HttpServletRequest request) {
        this.uaId = uaId;
        this.locale = request.getLocale();
    }

    /**
     * Récup du message associé à la clé dans la locale par défaut
     *
     * @param key
     * @return le message, si pas trouvé, on restitue la clé fournie en entrée
     */
    public String getString(final String key) throws IOException {

        final var uaRbMessage = resourceBundleFactory.getBundle("bundle/" + uaId + "_message", this.locale);
        Enumeration<String> keys = BundleUtils.getKeys("bundle/" + uaId + "_message", this.locale.getLanguage());
        if (BundleUtils.searchInEnum(keys.asIterator(), key)) {
            return uaRbMessage.getMessage(key, null, this.locale);
        }

        final var uaRbMessageValidation = resourceBundleFactory.getBundle("bundle/" + uaId + "_messagevalidation", this.locale);
        Enumeration<String> keyss = BundleUtils.getKeys("bundle/" + uaId + "_messagevalidation", this.locale.getLanguage());
        if (BundleUtils.searchInEnum(keyss.asIterator(), key)) {
            return uaRbMessageValidation.getMessage(key, null, this.locale);
        }
        // par défaut
        return key;
    }
}
