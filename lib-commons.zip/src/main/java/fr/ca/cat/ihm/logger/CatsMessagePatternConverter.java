package fr.ca.cat.ihm.logger;

import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.pattern.ConverterKeys;
import org.apache.logging.log4j.core.pattern.LogEventPatternConverter;
import org.apache.logging.log4j.core.pattern.MessagePatternConverter;
import org.apache.logging.log4j.core.pattern.PatternConverter;

import java.util.Map;

@Plugin(name = "CatsMessagePatternConverter", category = PatternConverter.CATEGORY)
@ConverterKeys({"mcats"})
public class CatsMessagePatternConverter extends LogEventPatternConverter {


    private MessagePatternConverter core;

    private CatsMessagePatternConverter(Configuration config, String[] options) {
        super(null, null);
        core = MessagePatternConverter.newInstance(config, options);
    }

    public static CatsMessagePatternConverter newInstance(Configuration config, final String[] options) {
        return new CatsMessagePatternConverter(config, options);
    }


    @Override
    public void format(LogEvent event, StringBuilder toAppendTo) {

        Map<String, String> mdc = event.getContextData().toMap();

        if (mdc.containsKey(LogUtils.MDC_RPA_SESSION_APPLICATIVE)) {
            toAppendTo.append(String.format("[sessionApplicative=%s]", mdc.get(LogUtils.MDC_RPA_SESSION_APPLICATIVE)));
        }
        if (mdc.containsKey(LogUtils.MDC_RPA_SERVEUR_CIBLE)) {
            toAppendTo.append(String.format("[serveurCible=%s]", mdc.get(LogUtils.MDC_RPA_SERVEUR_CIBLE)));
        }
        core.format(event, toAppendTo);

    }

}
