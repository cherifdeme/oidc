package fr.ca.cat.ihm.logger;


/**
 * Helper au log masquant l'implémentation.
 *
 * @author Pierre DURET
 */
public final class LogFactory {

    /**
     * Constructeur privé pour bloquer l'instanciation
     */
    private LogFactory() {
    }

    /**
     * Permet de récupérer le logger pour le type de composant passé en paramètre
     *
     * @return Logger
     */
    public static Logger getLog(TypeLogger typeLogger) {
        return new LoggerImpl(typeLogger);
    }

    /**
     * Permet de récupérer le logger pour les UA
     *
     * @return Logger
     */
    public static Logger getLog() {
        return new LoggerImpl(TypeLogger.LOGGER_UA);
    }


    public static Logger getLog(Class<?> emetteur) {
        return new LoggerImpl(TypeLogger.LOGGER_UA, emetteur);
    }


    public static Logger getLog(Class<?> emetteur, TypeLogger type) {
        return new LoggerImpl(type, emetteur);
    }


    public static Logger getLog(String emetteur, TypeLogger type) {
        return new LoggerImpl(type, emetteur);
    }


}
