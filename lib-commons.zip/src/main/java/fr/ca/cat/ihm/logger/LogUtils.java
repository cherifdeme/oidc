package fr.ca.cat.ihm.logger;

import fr.ca.cat.ihm.controller.bean.ContextExecution;
import fr.ca.cat.ihm.utils.Consommateur;
import fr.ca.cat.ihm.utils.Generated;
import fr.ca.cat.most.util.log.MDCConstants;
import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.MDC;

import java.util.UUID;

public class LogUtils {

    public final static String MDC_idSessionApplicative = "IHME.idSessionApplicative";
    public final static String MDC_RPA_SESSION_APPLICATIVE = "sessionApplicative";
    public final static String MDC_RPA_SERVEUR_CIBLE = "serveurCible";

    /**
     * Contructeur privé car c'est une classe utilitaire,
     * cela permet de masquer le contructeur par défaut
     */
    public LogUtils() {
        super();
    }

    /**
     * Suppression du MDC de toutes les données spécifiques CAT
     */

    @Generated
    public static void removeMDC() {

        MDC.remove(MDCConstants.CorrelationID);
        MDC.remove(MDCConstants.nomOperation);
        MDC.remove(MDCConstants.nomEmetteur);
        MDC.remove(MDCConstants.versionEmetteur);
        MDC.remove(MDCConstants.idConsommateurOrigine);
        MDC.remove(MDCConstants.versionConsommateurOrigine);
        MDC.remove(MDCConstants.idConsommateur);
        MDC.remove(MDCConstants.versionConsommateur);
        MDC.remove(MDCConstants.idSessionPortail);
        MDC.remove(MDCConstants.subject);
        MDC.remove(MDCConstants.caisseRegionale);
        MDC.remove(MDCConstants.operationalPostID);
        MDC.remove(MDCConstants.connectionEDSID);
        MDC.remove(MDCConstants.functionalPostEDSID);
        MDC.remove(MDCConstants.userTypeCASA);
        MDC.remove(MDCConstants.bankNetwork);
        MDC.remove(MDCConstants.canalID);
        MDC.remove(MDCConstants.distribCanalID);
        MDC.remove(MDCConstants.typeEmetteur);
        MDC.remove(MDCConstants.idMachine);
        MDC.remove(MDCConstants.IdInstanceUA);

        MDC.remove(MDC_idSessionApplicative);
        MDC.remove(MDC_RPA_SERVEUR_CIBLE);
        MDC.remove(MDC_RPA_SESSION_APPLICATIVE);

    }


    public static void setContext(final ContextExecution ctxExe) {

        MDC.put(MDCConstants.idSessionPortail, ctxExe.getSessionMode().getIdSessionPortail().trim());
        MDC.put(MDCConstants.subject, ctxExe.getProfile().getUser().getCode().trim());
        MDC.put(MDCConstants.caisseRegionale, ctxExe.getProfile().getStructureId().trim());
        MDC.put(MDCConstants.operationalPostID, ctxExe.getSystemInfo().getOperationalPost().getId().trim());
        MDC.put(MDCConstants.connectionEDSID, ctxExe.getSystemInfo().getEds().getId().trim());
        MDC.put(MDCConstants.functionalPostEDSID, ctxExe.getProfile().getFunctionalPost().getEdsId().trim());
        MDC.put(MDCConstants.userTypeCASA, ctxExe.getProfile().getUser().getType().trim());
        MDC.put(MDCConstants.bankNetwork, ctxExe.getProfile().getBankNetwork().trim());
        MDC.put(MDCConstants.canalID, ctxExe.getSessionMode().getCanal().trim());
        MDC.put(MDCConstants.distribCanalID, ctxExe.getSessionMode().getDistribCanal().trim());

        MDC.put(LogUtils.MDC_idSessionApplicative, ctxExe.getSessionMode().getId().trim());

    }

    @Generated
    public static void setEmetteur(final Consommateur consumer) {
        MDC.put(MDCConstants.nomEmetteur, consumer.getId());
        MDC.put(MDCConstants.versionEmetteur, consumer.getVersion().getCurrent());
    }

    @Generated
    public static void setConsommateur(final Consommateur consumer) {
        MDC.put(MDCConstants.idConsommateur, consumer.getId());
        MDC.put(MDCConstants.versionConsommateur, consumer.getVersion().getCurrent());

    }

    @Generated
    public static void setConsommateurOrigine(final Consommateur consumer) {
        MDC.put(MDCConstants.idConsommateurOrigine, consumer.getId());
        MDC.put(MDCConstants.versionConsommateurOrigine, consumer.getVersion().getCurrent());
    }


    public static final String counterForChildProcess(final String counter) {
        String aCounter = null;
        if (null != counter) {
            aCounter = counter.concat("-001");
        } else {
            aCounter = "001";
        }
        return aCounter;
    }


    public static final String counterForNextProcess(final String counter) {
        String aCounter = null;
        if (null != counter) {
            final int index = counter.indexOf('-');

            final int next = Integer.parseInt(index > 0 ? counter.substring(index + 1) : counter) + 1;
            final StringBuilder sb = new StringBuilder(3).append(next);
            while (sb.length() < 3) {
                sb.insert(0, "0");
            }
            if (index > 0) {
                sb.insert(0, counter.substring(0, index + 1));
            }
            aCounter = sb.toString();

        } else {
            aCounter = "001";
        }

        return aCounter;
    }

    /**
     * En mode "REST", l'id performance est un header http
     * Sur le RPA, pas de REST, mais potentiellement en tant qu'attribut
     *
     * @return
     */
    @Generated
    public static final String getIdPerformance(final HttpServletRequest request) {

        // sur l'init de certains composants on a pas de request.
        if (null == request) {
            return UUID.randomUUID().toString();
        }

        String sResu = request.getHeader("idPerformance");

        //spécial proxy en fait
        if (null == sResu) {
            sResu = (String) request.getAttribute("idPerformance");
        }

        return sResu;
    }

    public static String obfuscateUUIDString(String uuidString) {
        return uuidString.replaceAll(".{20}$", "XXXXX");
    }

}
