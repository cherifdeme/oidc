package fr.ca.cat.ihm.logger;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.most.util.log.MostCode;

/**
 * Interface d'accès aux méthodes de logs.
 * La définition des méthodes se base sur le document :
 * [CAT] Logger - ISI PROD.doc
 *
 * @author Pierre DURET
 */
public sealed interface Logger permits LoggerImpl {

    /**
     * Vérifie l'activation d'une trace de niveau DEBUG
     *
     * @return boolean, vrai si le niveau DEBUG est activé
     */
    boolean isDebugEnabled();

    /**
     * Vérifie l'activation d'une trace de niveau INFO.
     *
     * @return boolean, vrai si le niveau INFO est activé
     */
    boolean isInfoEnabled();


    // -------------------------------------------------------- Méthodes de Logging

    /**
     * Réaliser une trace de secu
     */
    void secu(String message, Context contexte);

    /**
     * Réaliser une trace de secu
     */
    void secu(MostCode code, String message, Context contexte);

    /**
     * Réaliser une trace de secu, mais avec une exception :)
     */
    void secu(String message, Throwable cause, Context contexte);

    /**
     * Réaliser une trace de secu, mais avec une exception :)
     */
    void secu(MostCode code, String message, Throwable cause, Context contexte);

    /**
     * Une trace de perf. On ne trace pas des "top" mais des durées.
     *
     * @param mesurePerf un delta de temps en millisecondes
     * @param message    infos complémentaires
     * @param contexte   donnée de contexte permettant de valoriser les entêtes
     */
    void perf(int mesurePerf, String message, Context contexte);


    /**
     * Une trace de perf. On ne trace pas des "top" mais des durées.
     *
     * @param mesurePerf un delta de temps en millisecondes
     * @param message    infos complémentaires
     * @param contexte   donnée de contexte permettant de valoriser les entêtes
     */
    void perf(int mesurePerf, Object message, Context contexte);


    /**
     * Une trace de perf. On ne trace pas des "top" mais des durées.
     *
     * @param code       identifiant unique de traces
     * @param mesurePerf un delta de temps en millisecondes
     * @param message    infos complémentaires
     * @param contexte   donnée de contexte permettant de valoriser les entêtes
     */
    void perf(MostCode code, int mesurePerf, String message, Context contexte);


    /**
     * Une trace de perf. On ne trace pas des "top" mais des durées.
     *
     * @param code       identifiant unique de traces
     * @param mesurePerf un delta de temps en millisecondes
     * @param message    infos complémentaires
     * @param contexte   donnée de contexte permettant de valoriser les entêtes
     */
    void perf(MostCode code, int mesurePerf, Object message, Context contexte);


    /**
     * Trace un message de niveau DEBUG.
     *
     * @param message  à tracer
     * @param contexte d'exécution
     */
    void debug(String message, Context contexte);

    /**
     * Trace un message de niveau DEBUG.
     *
     * @param code     identifiant unique de traces
     * @param message  à tracer
     * @param contexte d'exécution
     */
    void debug(MostCode code, String message, Context contexte);

    /**
     * Trace un message de niveau DEBUG.
     *
     * @param message  à tracer
     * @param cause    de la trace
     * @param contexte d'exécution
     */
    void debug(String message, Throwable cause, Context contexte);

    /**
     * Trace un message de niveau DEBUG.
     *
     * @param code     identifiant unique de traces
     * @param message  à tracer
     * @param cause    de la trace
     * @param contexte d'exécution
     */
    void debug(MostCode code, String message, Throwable cause, Context contexte);

    /**
     * Trace un message de niveau INFO.
     *
     * @param message  à tracer
     * @param contexte d'exécution
     */
    void info(String message, Context contexte);

    /**
     * Trace un message de niveau INFO.
     *
     * @param code     identifiant unique de traces
     * @param message  à tracer
     * @param contexte d'exécution
     */
    void info(MostCode code, String message, Context contexte);

    /**
     * Trace un message de niveau INFO.
     *
     * @param message  à tracer
     * @param cause    de la log
     * @param contexte d'exécution
     */
    void info(String message, Throwable cause, Context contexte);

    /**
     * Trace un message de niveau INFO.
     *
     * @param code     identifiant unique de traces
     * @param message  à tracer
     * @param cause    de la log
     * @param contexte d'exécution
     */
    void info(MostCode code, String message, Throwable cause, Context contexte);

    /**
     * Trace un message de niveau WARN.
     *
     * @param message  à tracer
     * @param contexte d'exécution
     */
    void warn(String message, Context contexte);

    /**
     * Trace un message de niveau WARN.
     *
     * @param code     identifiant unique de traces
     * @param message  à tracer
     * @param contexte d'exécution
     */
    void warn(MostCode code, String message, Context contexte);

    /**
     * Trace un message de niveau WARN.
     *
     * @param message  à tracer
     * @param cause    de l'erreur
     * @param contexte d'exécution
     */
    void warn(String message, Throwable cause, Context contexte);

    /**
     * Trace un message de niveau WARN.
     *
     * @param code     identifiant unique de traces
     * @param message  à tracer
     * @param cause    de l'erreur
     * @param contexte d'exécution
     */
    void warn(MostCode code, String message, Throwable cause, Context contexte);

    /**
     * Trace un message de niveau ERROR.
     *
     * @param message  à tracer
     * @param contexte d'exécution
     */
    void error(String message, Context contexte);

    /**
     * Trace un message de niveau ERROR.
     *
     * @param code     identifiant unique de traces
     * @param message  à tracer
     * @param contexte d'exécution
     */
    void error(MostCode code, String message, Context contexte);

    /**
     * Trace un message de niveau ERROR.
     *
     * @param message  à tracer
     * @param cause    de l'erreur
     * @param contexte d'exécution
     */
    void error(String message, Throwable cause, Context contexte);

    /**
     * Trace une erreur en prenant plusieurs objets en paramètres
     *
     * @param code      identifiant la trace dans les sources
     * @param message   la chaîne représentant le format de message
     * @param arguments les arguments qui seront éventuellement valorisés dans le message
     */
    void error(final MostCode code, final String message, Object... arguments);

    /**
     * Trace un message de niveau ERROR.
     *
     * @param message  à tracer
     * @param cause    de l'erreur
     * @param contexte d'exécution
     */
    void error(MostCode code, String message, Throwable cause, Context contexte);


    /**
     * Trace un message de niveau FATAL.
     *
     * @param message  à tracer
     * @param contexte d'exécution
     */
    void fatal(String message, Context contexte);


    /**
     * Trace un message de niveau FATAL avec plusieurs objets en arguments
     *
     * @param code      identifiant la trace dans les sources
     * @param message   la chaîne représentant le format de message
     * @param arguments les arguments qui seront éventuellement valorisés dans le message
     */
    void fatal(final MostCode code, final String message, Object... arguments);

    /**
     * Trace un message de niveau FATAL.
     *
     * @param code     identifiant unique de traces
     * @param message  à tracer
     * @param contexte d'exécution
     */
    void fatal(MostCode code, String message, Context contexte);

    /**
     * Trace un message de niveau FATAL.
     *
     * @param message  à tracer
     * @param cause    de l'erreur
     * @param contexte d'exécution
     */
    void fatal(String message, Throwable cause, Context contexte);

    /**
     * Trace un message de niveau FATAL.
     *
     * @param code     identifiant unique de traces
     * @param message  à tracer
     * @param cause    de l'erreur
     * @param contexte d'exécution
     */
    void fatal(MostCode code, String message, Throwable cause, Context contexte);

}
