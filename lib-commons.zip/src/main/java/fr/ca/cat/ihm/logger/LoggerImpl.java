package fr.ca.cat.ihm.logger;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.utils.Generated;
import fr.ca.cat.most.util.log.MDCConstants;
import fr.ca.cat.most.util.log.MostCode;
import fr.ca.cat.most.util.log.MostLogger;
import org.slf4j.MDC;

import java.net.InetAddress;
import java.net.UnknownHostException;

/**
 * Implémentation du logger basée sur CATLogger et sur log4j.
 */
public final class LoggerImpl implements Logger {

    // profondeur maximale de recherche dans la stack trace pour récupérer la méthode appelante
    private static final int MAX = 10;
    private MostLogger catLogger = null;
    private String codeLogger = "";
    private String ipMachine = "";

    public LoggerImpl(TypeLogger typeLogger, Class<?> emetteur) {

        super();
        this.catLogger = MostLogger.getLogger(emetteur);
        this.codeLogger = typeLogger.getCode();
        prepareIpMachine();

    }

    @Generated
    public LoggerImpl(TypeLogger typeLogger, String name) {

        super();
        this.catLogger = MostLogger.getLogger(name);
        this.codeLogger = typeLogger.getCode();
        prepareIpMachine();

    }


    public LoggerImpl(TypeLogger typeLogger) {
        super();

        this.catLogger = MostLogger.getLogger(getClassAppelante());
        this.codeLogger = typeLogger.getCode();
        prepareIpMachine();

    }

    /**
     * Retourne la classe qui a appelé le logger
     *
     * @return un nom de classe
     */
    private Class<?> getClassAppelante() {
        // initialisation de la chaîne de caractères à retourner
        String codeAppelant = this.getClass().getName();

        // stacktrace :
        final StackTraceElement[] stack = Thread.currentThread().getStackTrace();

        // élément de stacktrace
        StackTraceElement elt;

        // numéro d'élément dans la stacktrace
        int i = 0;

        // etape utilisée pour l'inspection de la stacktrace :
        // etape = 0 pour le début de l'inspection
        // passe à 1 quand on arrive sur la classe LoggerImpl (classe courante)
        // passe à 2 quand on arrive sur la classe LoggerFactory
        // passe à 3 quand on arrive sur la classe appelante sauf pour les perf
        int etape = 0;

        if (stack != null) {
            while (etape < 3 && i < MAX && stack[i] != null) {
                elt = stack[i];
                if (etape == 0 && elt.getClassName().equals(this.getClass().getName())) {
                    etape = 1;
                }
                if (etape == 1 && !elt.getClassName().equals(this.getClass().getName())) {
                    etape = 2;
                }
                if (etape == 2 && !elt.getClassName().equals(LogFactory.class.getName())) {
                    if (!elt.getClassName().equals(LoggerImpl.class.getName()) &&
                            !elt.getClassName().contains("java.lang.")) {
                        etape = 3;
                        codeAppelant = elt.getClassName();
                    }
                }
                i++;
            }
        }
        try {
            return Class.forName(codeAppelant);
        } catch (ClassNotFoundException e) {
            return this.getClass();
        }
    }


    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#isDebugEnabled()
     */
    @Override
    public boolean isDebugEnabled() {
        return this.catLogger.isDebugEnabled();
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#isInfoEnabled()
     */
    @Override
    public boolean isInfoEnabled() {
        return this.catLogger.isSuiviEnabled();
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#perf(int, java.lang.String, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void perf(final int mesurePerf, final String message, final Context contexte) {
        putMDC();

        this.catLogger.perf(new MostCode("PERF"), message, mesurePerf);

    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#perf(int, java.lang.Object, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void perf(final int mesurePerf, Object message, final Context contexte) {

        putMDC();
        this.catLogger.perf(new MostCode("PERF"), message, mesurePerf);

    }


    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#perf(fr.ca.cat.most.util.log.MostCode, int, java.lang.String, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void perf(final MostCode code, final int mesurePerf, final String message, final Context contexte) {

        putMDC();
        this.catLogger.perf(code, message, mesurePerf);

    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#perf(fr.ca.cat.most.util.log.MostCode, int, java.lang.Object, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void perf(MostCode code, int mesurePerf, Object message, Context contexte) {
        putMDC();
        this.catLogger.perf(code, message, mesurePerf);

    }


    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#secu(java.lang.String, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void secu(final String message, final Context contexte) {
        this.secu(new MostCode("SECU"), message, contexte);
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#secu(fr.ca.cat.most.util.log.MostCode, java.lang.String, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void secu(final MostCode code, final String message, final Context contexte) {
        putMDC();
        this.catLogger.secu(code, message);
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#secu(java.lang.String, java.lang.Throwable, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void secu(final String message, final Throwable cause, final Context contexte) {
        this.secu(new MostCode("SECU"), message, cause, contexte);
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#secu(fr.ca.cat.most.util.log.MostCode, java.lang.String, java.lang.Throwable, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void secu(final MostCode code, final String message, final Throwable cause, final Context contexte) {
        putMDC();
        this.catLogger.secu(code, message, cause);
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#debug(java.lang.String, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void debug(final String message, final Context contexte) {
        this.debug(new MostCode(codeLogger), message, contexte);
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#debug(fr.ca.cat.most.util.log.MostCode, java.lang.String, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void debug(final MostCode code, final String message, final Context contexte) {
        putMDC();
        this.catLogger.debug(code, message);
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#debug(java.lang.String, java.lang.Throwable, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void debug(final String message, final Throwable cause, final Context contexte) {
        this.debug(new MostCode(codeLogger), message, cause, contexte);
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#debug(fr.ca.cat.most.util.log.MostCode, java.lang.String, java.lang.Throwable, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void debug(MostCode code, final String message, Throwable cause, Context contexte) {
        putMDC();
        this.catLogger.debug(code, message, cause);
    }


    public void debug(MostCode code, Context contexte, String format, Object... arguments) {
        putMDC();
        this.catLogger.debug(code, format, arguments);

    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#info(java.lang.String, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void info(final String message, final Context contexte) {
        this.info(new MostCode(codeLogger), message, contexte);
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#info(fr.ca.cat.most.util.log.MostCode, java.lang.String, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void info(MostCode code, final String message, Context contexte) {
        putMDC();
        this.catLogger.suivi(code, message);
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#info(java.lang.String, java.lang.Throwable, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void info(final String message, final Throwable cause, final Context contexte) {
        this.info(new MostCode(codeLogger), message, cause, contexte);
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#info(fr.ca.cat.most.util.log.MostCode, java.lang.String, java.lang.Throwable, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void info(MostCode code, final String message, Throwable cause, Context contexte) {
        putMDC();
        this.catLogger.suivi(code, message, cause);
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#warn(java.lang.String, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void warn(final String message, final Context contexte) {
        this.warn(new MostCode(codeLogger), message, contexte);
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#warn(fr.ca.cat.most.util.log.MostCode, java.lang.String, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void warn(MostCode code, final String message, Context contexte) {
        putMDC();
        this.catLogger.warn(code, message);
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#warn(java.lang.String, java.lang.Throwable, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void warn(final String message, final Throwable cause, final Context contexte) {
        this.catLogger.warn(new MostCode(codeLogger), message, cause);
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#warn(fr.ca.cat.most.util.log.MostCode, java.lang.String, java.lang.Throwable, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    @Generated
    public void warn(MostCode code, final String message, Throwable cause, Context contexte) {
        putMDC();
        this.catLogger.warn(code, message, cause);
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#error(java.lang.String, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void error(final String message, final Context contexte) {
        this.error(new MostCode(codeLogger), message, contexte);
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#error(fr.ca.cat.most.util.log.MostCode, java.lang.String, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Generated
    @Override
    public void error(MostCode code, final String message, Context contexte) {
        putMDC();
        this.catLogger.erreur(code, message);
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#error(java.lang.String, java.lang.Throwable, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void error(final String message, final Throwable cause, final Context contexte) {
        this.error(new MostCode(codeLogger), message, cause, contexte);
    }

    @Generated
    public void error(final MostCode code, final String message, Object... arguments) {
        putMDC();
        this.catLogger.erreur(code, message, arguments);

    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#error(fr.ca.cat.most.util.log.MostCode, java.lang.String, java.lang.Throwable, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void error(MostCode code, final String message, Throwable cause, Context contexte) {
        putMDC();
        this.catLogger.erreur(code, message, cause);
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#fatal(java.lang.String, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void fatal(final String message, final Context contexte) {
        this.fatal(new MostCode(codeLogger), message, contexte);
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#fatal(fr.ca.cat.most.util.log.MostCode, java.lang.String, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    public void fatal(MostCode code, final String message, Context contexte) {
        putMDC();
        this.catLogger.erreur(code, message);
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#fatal(java.lang.String, java.lang.Throwable, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Generated
    @Override
    public void fatal(final String message, final Throwable cause, final Context contexte) {
        this.fatal(new MostCode(codeLogger), message, cause, contexte);
    }

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.logger.Logger#fatal(fr.ca.cat.most.util.log.MostCode, java.lang.String, java.lang.Throwable, fr.ca.cat.ihm.controller.bean.Context)
     */
    @Override
    @Generated
    public void fatal(MostCode code, final String message, Throwable cause, Context contexte) {
        putMDC();
        this.catLogger.erreur(code, message, cause);
    }

    /**
     * Valorise les données du contexte d'exécution dans le MDC de log4j pour constitution des logs
     */
    private void putMDC() {

        MDC.put(MDCConstants.typeEmetteur, codeLogger);
        MDC.put(MDCConstants.idMachine, this.ipMachine);

    }

    @Generated
    private void prepareIpMachine() {
        final StringBuilder sb = new StringBuilder();
        try {
            final InetAddress addr = InetAddress.getLocalHost();
            sb.append(addr.getHostName()).append('/').append(addr.getHostAddress());
        } catch (UnknownHostException t) {
            sb.append("Inconnu");
            this.catLogger.warn("Erreur lors l'obtention de l'adresse IP", t);
        }
        this.ipMachine = sb.toString();
    }


    @Generated
    @Override
    public void fatal(MostCode code, String message, Object... arguments) {
        putMDC();
        this.catLogger.erreur(code, message, arguments);

    }

}