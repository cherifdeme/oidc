package fr.ca.cat.ihm.logger;


import fr.ca.cat.ihm.utils.Generated;
import org.apache.commons.lang3.StringUtils;

/**
 * Pour compatibilité avec le monitoring "historique"
 *
 * @author et00437
 */
@Generated
public class PerfMessage {

    private int timeInMs;
    private String functionName;
    private String counter;
    private String className;
    private String uri;
    private String description;

    public PerfMessage() {
        super();
    }

    public PerfMessage(final int elapse, final String body) {
        super();
        this.timeInMs = elapse;
        this.description = body;
    }

    public int getTimeInMs() {
        return timeInMs;
    }

    public void setTimeInMs(final int timeInMs) {
        this.timeInMs = timeInMs;
    }

    public String getFunctionName() {
        return functionName;
    }

    public void setFunctionName(final String functionName) {
        this.functionName = functionName;
    }

    public String getCounter() {
        return counter;
    }

    public void setCounter(final String counter) {
        this.counter = counter;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(final String className) {
        this.className = className;
    }

    public String getUri() {
        return uri;
    }

    public void setUri(final String uri) {
        this.uri = uri;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(final String description) {
        this.description = description;
    }

    @Override
    public String toString() {

        final var msg = new StringBuilder();
        if (!StringUtils.isBlank(functionName)) {
            msg.append("[fonction:").append(functionName).append("]");
        }
        if (!StringUtils.isBlank(className)) {
            msg.append("[className:").append(className).append("]");
        }

        if (!StringUtils.isBlank(uri)) {
            msg.append("[uri:").append(uri).append("]");
        }
        if (!StringUtils.isBlank(description)) {
            msg.append("[description:").append(description).append("]");
        }
        return msg.toString();
    }
}
