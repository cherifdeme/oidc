/**
 *
 */
package fr.ca.cat.ihm.logger;

/**
 * Enumération permettant de lister les différents types de logger et leurs propriétés
 *
 * @author ETP1485
 */
public enum TypeLogger {

    LOGGER_SOCLE("SocleLogger", "IHME"),

    LOGGER_UA("UALogger", "UA"),

    LOGGER_PUCC("PUCCLogger", "PUC"),

    LOGGER_EM("EMLogger", "EM"),

    LOGGER_PERF("PerfLogger", "PERF"),

    LOGGER_IC04("IC04Logger", "IC04");

    // nom du logger dans log4j.properties
    private final String nom;
    // code affiché dans les traces de sortie
    private final String code;

    /**
     * @param nom
     * @param code
     */
    TypeLogger(final String nom, final String code) {
        this.nom = nom;
        this.code = code;
    }

    /**
     * @return le nom du logger dans log4j.properties
     */
    public String getNom() {
        return nom;
    }

    /**
     * @return le code affiché dans les traces de sortie
     */
    public String getCode() {
        return code;
    }
}