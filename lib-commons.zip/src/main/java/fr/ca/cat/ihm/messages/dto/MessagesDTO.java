package fr.ca.cat.ihm.messages.dto;

import fr.ca.cat.ihm.controller.dto.DataDTO;
import fr.ca.cat.ihm.utils.Generated;

import java.util.HashMap;
import java.util.Map;

@Generated
public class MessagesDTO extends DataDTO {

    private Map<String, String> values;

    public MessagesDTO() {
        super();
    }

    public void addValue(final String key, final String value) {
        if (values == null) {
            values = new HashMap<String, String>();
        }
        values.put(key, value);
    }

    public Map<String, String> getValues() {
        return values;
    }

    public void setValues(final Map<String, String> values) {
        this.values = values;
    }
}
