package fr.ca.cat.ihm.performance;

import fr.ca.cat.ihm.annotation.PerfMonitoring;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.PerfMessage;
import fr.ca.cat.ihm.logger.TypeLogger;
import fr.ca.cat.ihm.utils.Generated;
import fr.ca.cat.most.util.log.MostCode;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

/**
 * Permet d'effectuer des relevés de performances de manière non intrusive
 *
 * @author Pascal Rivière
 */
@Aspect
@Generated
public class MonitorAspect {

    /**
     * Toutes les méthodes des classes des packages et sous-packages
     * fr.ca.cat.ihm
     */
    @Pointcut("execution(* fr.ca.cat.ihm..*.*(..))")
    public void allMethod() {
    }

    /**
     * Méthode utilisée pour le calcul du temps d'exécution
     *
     * @param joinPoint les informations sur la méthode à exécuter
     * @throws Throwable l'exection remontée par la méthode
     */
    @Around("allMethod() && @annotation(perfMonitoring)")
    public Object logPerfAround(final ProceedingJoinPoint joinPoint, final PerfMonitoring perfMonitoring) throws Throwable {

        // Début de la mesure du temps d'exécution
        final var start = System.currentTimeMillis();

        final var emetteur = getClassEmetteur(joinPoint);
        final var logger = LogFactory.getLog(emetteur, TypeLogger.LOGGER_SOCLE);

        try {
            // on effectue le traitement de la méthode !
            return joinPoint.proceed();
        } finally {
            // Fin de la mesure du temps d'exécution
            final var msg = new PerfMessage((int) (System.currentTimeMillis() - start), perfMonitoring.description());
            msg.setFunctionName(joinPoint.getSignature().getName());
            msg.setDescription(perfMonitoring.description());

            logger.perf(new MostCode(perfMonitoring.mostCode()), msg.getTimeInMs(), msg.toString(), null);
        }
    }

    private Class<?> getClassEmetteur(final ProceedingJoinPoint joinPoint) {
        return (null != joinPoint.getTarget() ? joinPoint.getTarget().getClass() : this.getClass());
    }
}