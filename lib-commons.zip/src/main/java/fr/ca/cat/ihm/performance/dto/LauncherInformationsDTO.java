package fr.ca.cat.ihm.performance.dto;

import fr.ca.cat.ihm.controller.dto.DataDTO;
import fr.ca.cat.ihm.utils.Generated;

/**
 * Pojo qui porte les informations permettant d'identifier une session de prise de perfs.
 *
 * @author ETP1484
 */
@Generated
public class LauncherInformationsDTO extends DataDTO {
    /**
     * Identifiant de performance de l'action.
     */
    private final String idPerfAction;
    /**
     * Identifiant de l'action.
     */
    private final String action;
    /**
     * Identification de l'utilisateur.
     */
    private final String userId;

    /**
     * Role de l'utilisateur.
     */
    private final String role;

    /**
     * Réponds à la question : l'utilisateur est il un collaborateur ?
     */
    private final boolean collaborator;

    /**
     * @param action       identifiant fonctionnel de l'action.
     * @param userId       identifiant de l'utilisateur.
     * @param role         type de rôle.
     * @param collaborator mettre vrais si l'utilisateur est un collaborateur.
     */
    public LauncherInformationsDTO(final String idPerfAction, final String action, final String userId, final String role,
                                   final boolean collaborator) {
        this.idPerfAction = idPerfAction;
        this.action = action;
        this.userId = userId;
        this.role = role;
        this.collaborator = collaborator;
    }

    /**
     * @return identifiant fonctionnel de l'action.
     */
    public String getAction() {
        return action;
    }

    /**
     * @return identifiant de l'utilisateur.
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @return type de rôle.
     */
    public String getRole() {
        return role;
    }

    /**
     * @return vrais si l'utilisateur est un collaborateur.
     */
    public boolean isCollaborator() {
        return collaborator;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder() //
                .append("LauncherInformations [action=").append(action) //
                .append(", userId=").append(userId) //
                .append(", role=").append(role) //
                .append(", collaborator=").append(collaborator) //
                .append(", perfAction=").append(idPerfAction)
                .append("]");
        return builder.toString();
    }

}
