package fr.ca.cat.ihm.performance.dto;

import fr.ca.cat.ihm.controller.dto.DataDTO;
import fr.ca.cat.ihm.utils.Generated;
import jakarta.validation.constraints.Null;

import java.util.Date;
import java.util.List;
import java.util.Map;

@Generated
public class PerfMonitor extends DataDTO {

    private String uid;
    private String id;

    private Map<String, String> data;

    private String phase;

    @Null
    private String timestart;
    @Null
    private String timeend;
    @Null
    private String memorystart;
    @Null
    private String memoryend;

    private List<PerfMonitorTick> ticks;

    private Date date;

    public Map<String, String> getData() {
        return data;
    }

    public void setData(final Map<String, String> data) {
        this.data = data;
    }

    public String getMemorystart() {
        return memorystart;
    }

    public void setMemorystart(final String memorystart) {
        this.memorystart = memorystart;
    }

    public String getMemoryend() {
        return memoryend;
    }

    public void setMemoryend(final String memoryend) {
        this.memoryend = memoryend;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(final Date date) {
        this.date = date;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(final String id) {
        this.uid = id;
    }

    public String getPhase() {
        return phase;
    }

    public void setPhase(final String newPhase) {
        this.phase = newPhase;
    }

    public String getTimestart() {
        return timestart;
    }

    public void setTimestart(final String timestart) {
        this.timestart = timestart;
    }

    public String getTimeend() {
        return timeend;
    }

    public void setTimeend(final String timeend) {
        this.timeend = timeend;
    }

    public List<PerfMonitorTick> getTicks() {
        return ticks;
    }

    public void setTicks(final List<PerfMonitorTick> ticks) {
        this.ticks = ticks;
    }

    @Override
    public String toString() {
        final var buffer = new StringBuilder(" uid:");
        buffer.append(getUid()).append(" phase:").append(getPhase());
        if (null != getTicks()) {
            buffer.append(" ticks:").append(getTicks().size());
        }
        return buffer.toString();
    }

    public String getId() {
        return id;
    }

    public void setId(final String id) {
        this.id = id;
    }

}
