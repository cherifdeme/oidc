package fr.ca.cat.ihm.performance.dto;

import fr.ca.cat.ihm.controller.dto.DataDTO;
import fr.ca.cat.ihm.utils.Generated;
import jakarta.validation.constraints.Null;

import java.util.Date;

@Generated
public class PerfMonitorTick extends DataDTO {

    private String id;

    private String uid;

    private String monitorname = null;

    private String stepname = null;

    private long timestart = 0;

    private long timeend = 0;

    private String userid = null;

    @Null
    private String memorystart;
    @Null
    private String memoryend;

    private Date date;

    public String getMemorystart() {
        return memorystart;
    }

    public void setMemorystart(final String memorystart) {
        this.memorystart = memorystart;
    }

    public String getMemoryend() {
        return memoryend;
    }

    public void setMemoryend(final String memoryend) {
        this.memoryend = memoryend;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(final Date date) {
        this.date = date;
    }

    public String getId() {
        return id;
    }

    public void setId(final String id) {
        this.id = id;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(final String uid) {
        this.uid = uid;
    }

    public String getMonitorname() {
        return monitorname;
    }

    public void setMonitorname(final String monitorname) {
        this.monitorname = monitorname;
    }

    public String getStepname() {
        return stepname;
    }

    public void setStepname(final String stepname) {
        this.stepname = stepname;
    }

    public long getTimestart() {
        return timestart;
    }

    public void setTimestart(final long timestart) {
        this.timestart = timestart;
    }

    public long getTimeend() {
        return timeend;
    }

    public void setTimeend(final long timeend) {
        this.timeend = timeend;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(final String userid) {
        this.userid = userid;
    }

    @Override
    public String toString() {
        return new StringBuilder(" monitorname:").append(getMonitorname()).append(" stepName:").append(getStepname()).toString();
    }
}
