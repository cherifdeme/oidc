package fr.ca.cat.ihm.performance.dto;

import fr.ca.cat.ihm.controller.dto.DataDTO;
import fr.ca.cat.ihm.utils.Generated;

/**
 * DTO contenant les informations d'une prise de perf
 *
 * @author ETP1484
 */
@Generated
public class PerformanceDTO extends DataDTO {

    private final String uuid;

    private String counter = "002"; // DEFAUT

    /**
     * @param uuid indentifiant de la prise de perf
     */
    public PerformanceDTO(final String uuid) {
        super();
        this.uuid = uuid;
    }

    /**
     * @return uuid indentifiant de la prise de perf
     */
    public String getUuid() {
        return uuid;
    }

    /**
     * @return counter
     */
    public String getCounter() {
        return counter;
    }

    /**
     * @param counter counter à définir
     */
    public void setCounter(final String counter) {
        this.counter = counter;
    }
}
