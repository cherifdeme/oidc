package fr.ca.cat.ihm.redis;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.crypto.CryptoSHA256;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.LogUtils;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.logger.TypeLogger;
import fr.ca.cat.ihm.security.dto.SecurityAPIBean;
import fr.ca.cat.ihm.utils.Generated;
import fr.ca.cat.ihm.web.client.WebClientFactory;
import fr.ca.cat.most.util.log.MostCode;
import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.beans.factory.annotation.Value;
import redis.clients.jedis.Connection;
import redis.clients.jedis.HostAndPort;
import redis.clients.jedis.JedisCluster;
import redis.clients.jedis.exceptions.JedisException;

import java.security.NoSuchAlgorithmException;
import java.time.Duration;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@Generated
public class RedisCacheService {

    private static final String API2M_SESSION_PREFIX = "api2m:session";
    private static final String API2M_REFRESH_PREFIX = "api2m:refresh";
    private static final String AULN_SAML_PREFIX = "auln:saml";

    private static final MostCode MC_IHME_API_GET_REDIS_KEY = new MostCode("IHME-API_GET_REDIS_KEY");

    private static final Logger LOGGER = LogFactory.getLog(WebClientFactory.class, TypeLogger.LOGGER_SOCLE);
    @Value("${socle.api.atknTtlMinus:180000}")
    private String atknTtlMinus;

    @Value("${socle.api.rtknTtlMinus:43200}")
    private String rtknTtlMinus;
    private JedisCluster jedis;

    public RedisCacheService(boolean cluster, String hostsName, String ports) {
        new RedisCacheService(cluster, hostsName, ports, 8, 8, 0, 30);
    }

    public RedisCacheService(boolean cluster, String hostsName, String ports, int poolMaxTotal, int poolMaxIdle, int poolMinIdle, long maxWaitInSeconds) {
        if (cluster) {
            String[] hostList = hostsName.split(",");
            String[] portList = ports.split(",");
            // Redis cluster
            Set<HostAndPort> clusterNodes = new HashSet<>();
            for (String host : hostList) {
                for (String port : portList) {
                    clusterNodes.add(new HostAndPort(host, Integer.parseInt(port)));
                }
            }
            GenericObjectPoolConfig<Connection> config = new GenericObjectPoolConfig<>();
            config.setMaxTotal(poolMaxTotal);
            config.setMaxIdle(poolMaxIdle);
            config.setMinIdle(poolMinIdle);
            Duration maxWaitDuration = Duration.ofSeconds(maxWaitInSeconds);
            config.setMaxWait(maxWaitDuration);
            jedis = new JedisCluster(clusterNodes, config);
        }

    }


    public void saveToken(Context context, SecurityAPIBean uaApiBean) {
        // Sauvegarde information de la session
        String sessionKey = getRedisKey(API2M_SESSION_PREFIX, context);
        this.jedis.hset(sessionKey, "access_token", uaApiBean.getAccess_token());
        this.jedis.hset(sessionKey, "id_token", uaApiBean.getId_token());
        // On set l'expiration de la cle selon le champ expires in avec une
        // marge de 30 secondes
        long tokenThreshold = Long.parseLong(atknTtlMinus);
        this.jedis.expire(sessionKey, uaApiBean.getExpires_in() - tokenThreshold / 1000L);
    }

    public SecurityAPIBean getTokens(Context context) {
        SecurityAPIBean apiBean = null;
        // Test si les informations pour la session sont toujours là.
        String sessionKey = getRedisKey(API2M_SESSION_PREFIX, context);
        Map<String, String> sessionInformation = this.jedis.hgetAll(sessionKey);
        if (sessionInformation != null && !sessionInformation.isEmpty()) {
            apiBean = new SecurityAPIBean();
            apiBean.setAccess_token(sessionInformation.get("access_token"));
            apiBean.setId_token(sessionInformation.get("id_token"));
        }
        return apiBean;
    }

    public void saveRefreshToken(Context context, SecurityAPIBean uaApiBean) {
        // Sauvegarde du refresh token de la session
        String refreshTokenKey = getRedisKey(API2M_REFRESH_PREFIX, context);
        this.jedis.set(refreshTokenKey, uaApiBean.getRefresh_token());
        long ttlRefreshToken = Long.parseLong(rtknTtlMinus);
        this.jedis.expire(refreshTokenKey, ttlRefreshToken);
    }

    public SecurityAPIBean getRefreshToken(Context context) {
        SecurityAPIBean apiBean = null;
        // Test pour recuperer le refresh token
        String refreshTokenKey = getRedisKey(API2M_REFRESH_PREFIX, context);
        String refreshToken = this.jedis.get(refreshTokenKey);
        if (refreshToken != null && !refreshToken.isEmpty()) {
            apiBean = new SecurityAPIBean();
            apiBean.setRefresh_token(refreshToken);
        }
        return apiBean;
    }


    /**
     * récup directe de jeton SAML dans le cache REDIS
     *
     * @param key
     * @return
     */
    public String getSAMLRedis(String key) {
        String s = null;
        String hash = null;

        String partialKeyValue = LogUtils.obfuscateUUIDString(key);
        try {
            hash = AULN_SAML_PREFIX + ":" + CryptoSHA256.cryptoHash(key);
            s = jedis.hget(hash, "saml_token");

            if (null == s || s.isEmpty()) {
                LOGGER.info("pas de SAML trouve dans REDIS pour la session : " + partialKeyValue, null);
            } else {
                return s;
            }
        } catch (NoSuchAlgorithmException e) {
            LOGGER.error("Erreur lors de la creation du hash de session : {}" + partialKeyValue, e, null);
        } catch (JedisException e) {
            LOGGER.error("Exception levee lors de l'acces pour la session : {}" + partialKeyValue, e, null);
        }
        return null;
    }


    /**
     * constitution d'une clé de cache REDIS pour chercher le JETON d'API de l'UA.
     *
     * @param prefix
     * @param context
     * @return
     */
    private String getRedisKey(String prefix, Context context) {
        String hashKey;
        try {
            hashKey = CryptoSHA256.cryptoHash(context.getSecurityDTO().getAulnSessionId());
            String redisKey = String.format("%s:%s:%s", prefix, hashKey, context.getUaId());
            LOGGER.debug(MC_IHME_API_GET_REDIS_KEY, "Recuperation cle redis: " + redisKey.replaceAll("^.{40}", "XXXX"), context);
            return redisKey;
        } catch (NoSuchAlgorithmException e) {
            LOGGER.warn("Erreur lors de la recuperation du token", context);
            return context.getContextExecution().getSessionMode().getIdSessionPortail();
        }
    }
}