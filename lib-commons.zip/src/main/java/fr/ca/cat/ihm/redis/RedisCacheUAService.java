package fr.ca.cat.ihm.redis;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.utils.Constants;
import fr.ca.cat.ihm.utils.RedisCacheUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.CacheManager;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class RedisCacheUAService {

    /**
     * Injection de l'objet CacheManager pour gérer l'accès au caches Redis
     */
    protected CacheManager cacheManager;

    @Autowired
    public RedisCacheUAService(@Qualifier("redis_cache_ua") CacheManager cacheManager) {
        this.cacheManager = cacheManager;
    }


    public void saveToken(final Context context, final Object uaApiBean) {
        final var sessionKey = RedisCacheUtils.getRedisKey(Constants.API2M_SESSION_PREFIX, context);
        if (Objects.nonNull(this.cacheManager.getCache(Constants.TOKEN_CACHE))) {
            this.cacheManager.getCache(Constants.TOKEN_CACHE).put(sessionKey, uaApiBean);
        } else {
            throw new IllegalArgumentException(Constants.CACHE_TOKEN_NULL);
        }
    }

    public Object getTokens(final Context context) {
        final var sessionKey = RedisCacheUtils.getRedisKey(Constants.API2M_SESSION_PREFIX, context);
        if (Objects.nonNull(this.cacheManager.getCache(Constants.TOKEN_CACHE))) {
            return this.cacheManager.getCache(Constants.TOKEN_CACHE).get(sessionKey, Object.class);
        } else {
            throw new IllegalArgumentException(Constants.CACHE_TOKEN_NULL);
        }
    }

    /**
     * Sauvegarde d'un refresh token dans le cache TOKEN REDIS
     *
     * @param context      La clé de sauvegarde
     * @param refreshToken Le refresh token à sauvegarder
     */
    public void saveRefreshToken(final Context context, String refreshToken) {

        final var sessionKey = RedisCacheUtils.getRedisKey(Constants.API2M_REFRESH_PREFIX, context);
        if (Objects.nonNull(this.cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE))) {
            this.cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE).put(sessionKey, refreshToken);
        } else {
            throw new IllegalArgumentException(Constants.CACHE_REFRESH_TOKEN_NULL);
        }
    }

    /**
     * Retourne la valeur du refresh token
     *
     * @param context La clé souhaitée
     * @return La valeur dans le cache REDIS
     */
    public String getRefreshToken(final Context context) {
        final var sessionKey = RedisCacheUtils.getRedisKey(Constants.API2M_REFRESH_PREFIX, context);
        if (Objects.nonNull(this.cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE))) {
            return this.cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE).get(sessionKey, String.class);
        } else {
            throw new IllegalArgumentException(Constants.CACHE_REFRESH_TOKEN_NULL);
        }
    }

}
