package fr.ca.cat.ihm.resilience;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;


/**
 * Représente l'état des compteurs d'Event d'un circuit breaker à un instant t
 */
public class BufferStateCircuitBreaker {

    private static final int NB_MAX_IT_LOG = 3;
    private static final String ISO_8601_DATE_PATTERN = "yyyy-MM-dd'T'HH:mm:ss'Z'";

    private long lastSuccess = 0;
    private long lastFailure = 0;
    private long lastShortCircuited = 0;
    private long lasttimeout = 0;
    private long success = 0;
    private long failure = 0;
    private long shortCircuited = 0;
    private long timeout = 0;
    private int cptlogs = 0;


    private long timestamp = 0;


    /**
     * Constructeur
     */
    public BufferStateCircuitBreaker() {

        timestamp = System.currentTimeMillis();

    }


    /**
     * Enregistre l'état courant des compteurs du circuit + compteur de logs
     */
    public void setCircuit(String cbname) {

        success = ConfigurationResilience4jModules.getEventCircuitBreakerConsumer().getBufferedSuccessEvents().stream()
                .filter(event -> event.getCircuitBreakerName().equals(cbname))
                .count();

        failure = ConfigurationResilience4jModules.getEventCircuitBreakerConsumer().getBufferedErrorEvents().stream()
                .filter(event -> event.getCircuitBreakerName().equals(cbname))
                .count();
        shortCircuited = ConfigurationResilience4jModules.getEventCircuitBreakerConsumer().getBufferedNotPermittedEvents().stream()
                .filter(event -> event.getCircuitBreakerName().equals(cbname))
                .count();
        // Time limiter
        timeout =
                ConfigurationResilience4jModules.getEventTimeLimiterConsumer().getBufferedTimeoutEvents().
                        stream().filter(event -> event.getTimeLimiterName().equals(cbname))
                        .count();

        cptlogs++;
    }


    /**
     * Sauvegarde l'état des compteurs tracés + raz compteur de logs
     */
    public void logged() {
        lastSuccess = success;
        lastFailure = failure;
        lastShortCircuited = shortCircuited;
        lasttimeout = timeout;
        timestamp = System.currentTimeMillis();
        cptlogs = 0;
    }

    /**
     * On doit tracer quand :
     * <br> - il y a une erreur
     * <br> - Il y a un cb ouvert
     * <br> - la 3ième itération de mesure prise
     */
    public boolean isTracable() {
        return ((getFailure()) > 0 || (getShortCircuited()) > 0 || cptlogs >= NB_MAX_IT_LOG);
    }

    public long getSuccess() {
        return success - lastSuccess;
    }

    public long getFailure() {
        return failure - lastFailure;
    }

    public long getShortCircuited() {
        return shortCircuited - lastShortCircuited;
    }

    public long getTimeout() {
        return timeout - lasttimeout;
    }

    public String getDate() {
        Date date = new Date(timestamp);
        DateFormat form = new SimpleDateFormat(ISO_8601_DATE_PATTERN);
        // on trace en GMT
        form.setTimeZone(TimeZone.getTimeZone("GMT"));
        return form.format(date);
    }
}
