package fr.ca.cat.ihm.resilience;

import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.logger.TypeLogger;
import fr.ca.cat.ihm.utils.Generated;
import jakarta.annotation.PostConstruct;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Classe de monitoring de l'état des circuits breaker
 */
public class CircuitBreakerSupervision {

    private static final Logger LOGGER = LogFactory.getLog(TypeLogger.LOGGER_SOCLE);

    // périodicité des logs du circuit
    private Long period;

    @Generated
    public void setPeriod(Long period) {
        this.period = period;
    }

    /**
     * Initialisation du Scheduler pour log des métriques Resilience4J
     */
    @PostConstruct
    @Generated
    public void initSupervision() {

        ScheduledExecutorService scheduler4j;

        try {
            scheduler4j = Executors.newSingleThreadScheduledExecutor();

            /**
             * Scheduler des logs de métriques Resilience4J
             *
             */
            scheduler4j.scheduleAtFixedRate(new LogMetricsResilience4j(), 1, period.longValue(), TimeUnit.SECONDS);

            LOGGER.debug("Initialisation Monitoring CircuitBreaker Resilience4J, fréquence de log (en seconde) : "
                    + period.toString(), null);
        } catch (Exception ex) {
            LOGGER.error(
                    "Initialisation Monitoring CircuitBreaker Resilience4J, erreur sur initialisation du scheduler de logs : le monitoring sera indisponible",
                    ex, null);
        }
    }

}
