package fr.ca.cat.ihm.resilience;

import fr.ca.cat.ihm.utils.Generated;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.circuitbreaker.event.CircuitBreakerEvent;
import io.github.resilience4j.timelimiter.TimeLimiter;
import io.github.resilience4j.timelimiter.TimeLimiterRegistry;
import io.github.resilience4j.timelimiter.event.TimeLimiterEvent;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Iterator;

/**
 * Service permettant d'obtenir la configuration des modules Resilience4j de types :
 * <li> CircuitBreaker
 * <li> TimeLimiter
 *
 * @author ET01528
 */
@Service
@Generated
public class ConfigurationResilience4jModules {

    private static CircuitBreakerRegistry registryCircuit;
    private static TimeLimiterRegistry registryTimeout;

    private static EventCircuitBreakerConsumer<CircuitBreakerEvent> logeventCircuit = new EventCircuitBreakerConsumer<>();

    private static EventTimeLimiterConsumer<TimeLimiterEvent> logeventTimeout = new EventTimeLimiterConsumer<>();

    public static CircuitBreakerRegistry getCircuitbreakerRegistry() {
        return registryCircuit;
    }

    public static EventCircuitBreakerConsumer<CircuitBreakerEvent> getEventCircuitBreakerConsumer() {
        return logeventCircuit;
    }

    public static TimeLimiterRegistry getTimelimiterRegistry() {
        return registryTimeout;
    }

    public static EventTimeLimiterConsumer<TimeLimiterEvent> getEventTimeLimiterConsumer() {
        return logeventTimeout;
    }

    @Autowired
    private CircuitBreakerRegistry getCbRegistry(CircuitBreakerRegistry registry) {
        if (!registry.getAllCircuitBreakers().isEmpty()) {
            Iterator<CircuitBreaker> it = registry.getAllCircuitBreakers().iterator();
            while (it.hasNext()) {
                CircuitBreaker circuitbreaker = it.next();
                // Enregistrement d'un comsumer d'event par Circuitbreaker
                circuitbreaker.getEventPublisher().onEvent(logeventCircuit);
            }
        }
        return ConfigurationResilience4jModules.registryCircuit = registry;
    }

    @Autowired
    private TimeLimiterRegistry getTlRegistry(TimeLimiterRegistry registry) {
        if (!registry.getAllTimeLimiters().isEmpty()) {
            Iterator<TimeLimiter> it = registry.getAllTimeLimiters().iterator();
            while (it.hasNext()) {
                TimeLimiter timelimiter = it.next();
                // Enregistrement d'un comsumer d'event par Timelimiter
                timelimiter.getEventPublisher().onEvent(logeventTimeout);
            }
        }
        return ConfigurationResilience4jModules.registryTimeout = registry;
    }
}
