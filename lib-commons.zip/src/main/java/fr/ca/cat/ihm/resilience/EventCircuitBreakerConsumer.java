/**
 *
 */
package fr.ca.cat.ihm.resilience;

import fr.ca.cat.ihm.utils.Generated;
import io.github.resilience4j.circuitbreaker.event.CircuitBreakerEvent;
import io.github.resilience4j.core.EventConsumer;

import java.util.ArrayList;
import java.util.List;


/**
 * Consumer des Events émis par le circuit breaker
 * <br>Permet d'alimenter des compteurs par type d'Event {@link CircuitBreakerEvent}
 *
 * @param <T>
 * @author ET01528
 */
@Generated
public class EventCircuitBreakerConsumer<T> implements EventConsumer<T> {

    // Liste d'Events
    final List<T> listSuccessEvents = new ArrayList<>();
    final List<T> listErrorEvents = new ArrayList<>();
    final List<T> listNotPermittedEvents = new ArrayList<>();

    public EventCircuitBreakerConsumer() {
        super();
    }

    @Override
    public void consumeEvent(T event) {
        String classeEvent = event.getClass().getSimpleName();
        switch (classeEvent) {
            case "CircuitBreakerOnSuccessEvent":
                listSuccessEvents.add(event);
                break;
            case "CircuitBreakerOnErrorEvent":
                listErrorEvents.add(event);
                break;
            case "CircuitBreakerOnCallNotPermittedEvent":
                listNotPermittedEvents.add(event);
                break;
            default:
                break;
        }
    }


    /**
     * @return Liste cumulative des Events de type SUCCESS
     */
    public List<T> getBufferedSuccessEvents() {
        return listSuccessEvents;
    }

    /**
     * @return Liste cumulative des Events de type ERROR
     */
    public List<T> getBufferedErrorEvents() {
        return listErrorEvents;
    }

    /**
     * @return Liste cumulative des Events de type NOT_PERMITTED
     */
    public List<T> getBufferedNotPermittedEvents() {
        return listNotPermittedEvents;
    }
}
