/**
 *
 */
package fr.ca.cat.ihm.resilience;

import fr.ca.cat.ihm.utils.Generated;
import io.github.resilience4j.core.EventConsumer;
import io.github.resilience4j.timelimiter.event.TimeLimiterEvent;

import java.util.ArrayList;
import java.util.List;

/**
 * Consumer des Events émis par le Time Limiter
 * <br>Permet d'alimenter des compteurs par type d'Event {@link TimeLimiterEvent}
 *
 * @param <T>
 * @author ET01528
 */
@Generated
public class EventTimeLimiterConsumer<T> implements EventConsumer<T> {

    // Liste d'Events
    final List<T> listSuccessEvents = new ArrayList<>();
    final List<T> listErrorEvents = new ArrayList<>();
    final List<T> listTimeoutEvents = new ArrayList<>();

    public EventTimeLimiterConsumer() {
        super();
    }

    @Override
    public void consumeEvent(T event) {
        String classeEvent = event.getClass().getSimpleName();
        switch (classeEvent) {
            case "TimeLimiterOnSuccessEvent":
                listSuccessEvents.add(event);
                break;
            case "TimeLimiterOnErrorEvent":
                listErrorEvents.add(event);
                break;
            case "TimeLimiterOnTimeoutEvent":
                listTimeoutEvents.add(event);
                break;
            default:
                break;
        }
    }


    /**
     * @return Liste cumulative des Events de type SUCCESS
     */
    public List<T> getBufferedSuccessEvents() {
        return listSuccessEvents;
    }

    /**
     * @return Liste cumulative des Events de type ERROR
     */
    public List<T> getBufferedErrorEvents() {
        return listErrorEvents;
    }

    /**
     * @return Liste cumulative des Events de type TIMEOUT
     */
    public List<T> getBufferedTimeoutEvents() {
        return listTimeoutEvents;
    }
}
