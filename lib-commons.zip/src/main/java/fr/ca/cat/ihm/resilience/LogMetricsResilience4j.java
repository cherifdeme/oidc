package fr.ca.cat.ihm.resilience;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonGenerator;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.logger.TypeLogger;
import fr.ca.cat.most.util.log.MostCode;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;

import java.io.IOException;
import java.io.StringWriter;
import java.util.HashMap;
import java.util.Iterator;

/**
 * Classe de génération des métriques Resilience4j sous forme de logs
 *
 * <br>Mostcode : IHME-CIRCUIT_BREAKER_METRICS
 *
 * @author ET01528
 */
public class LogMetricsResilience4j implements Runnable {

    private static final Logger LOGGER = LogFactory.getLog(LogMetricsResilience4j.class, TypeLogger.LOGGER_SOCLE);
    private static final MostCode MC_IHME_CIRCUIT_BREAKER_METRICS = new MostCode("IHME-CIRCUIT_BREAKER_METRICS");
    private static JsonFactory jsonfactory = new JsonFactory();
    // Map de l'état des compteurs des circuits breakers
    private static HashMap<String, BufferStateCircuitBreaker> circuits = new HashMap<>();
    private CircuitBreakerRegistry registry = ConfigurationResilience4jModules.getCircuitbreakerRegistry();

    @Override
    public void run() {

        // on ne trace une log que s'il y a au moins un circuitbreaker
        if (!registry.getAllCircuitBreakers().isEmpty()) {
            Iterator<CircuitBreaker> it = registry.getAllCircuitBreakers().iterator();

            while (it.hasNext()) {

                CircuitBreaker circuitbreaker = it.next();

                try (JsonGenerator json = jsonfactory.createGenerator(new StringWriter())) {
                    BufferStateCircuitBreaker circuit = circuits.get(circuitbreaker.getName());

                    if (circuit == null) {
                        circuit = new BufferStateCircuitBreaker();
                        circuits.put(circuitbreaker.getName(), circuit);
                    }

                    // Pour enregistrer l'état courant du circuit
                    circuit.setCircuit(circuitbreaker.getName());

                    if (circuit.isTracable()) {
                        json.writeStartObject();

                        // Old : Groupe pour avoir le même format qu'Hystrix utilisé par le SOA
                        json.writeStringField("Group", "Appels-Services");

                        // circuit breaker
                        json.writeStringField("Key", circuitbreaker.getName());
                        // Compteurs cumulatifs sur la période
                        json.writeNumberField("SUCCESS", circuit.getSuccess());
                        json.writeNumberField("FAILURE", circuit.getFailure());
                        json.writeNumberField("SHORT_CIRCUITED", circuit.getShortCircuited());
                        // valorisé si utilisation Time limiter
                        json.writeNumberField("TIMEOUT", circuit.getTimeout());
                        //
                        json.writeStringField("SINCE", circuit.getDate());

                        json.writeEndObject();

                        json.flush();

                        LOGGER.perf(MC_IHME_CIRCUIT_BREAKER_METRICS, 0, json.getOutputTarget().toString(), null);

                        // Pour historiser l'état de la commande
                        circuit.logged();
                    }

                } catch (IOException ex) {
                    LOGGER.info("Scheduler des logs de métriques Resilience4j, erreur sur écriture des logs : "
                            + ex.getMessage(), null);
                }

            }
        }

    }

}
