package fr.ca.cat.ihm.security;

import fr.ca.cat.ihm.utils.Generated;

import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.Arrays;

public final class Encryptor {


    private static final String ALGORITHM = "AES/GCM/NoPadding";

    private static final String DEFAULT_SECRET_KEY = "TotoFaitDuVelo";
    private static final byte[] DEFAULT_IV = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    private Key secretKeySpec;

    private GCMParameterSpec gcmParameterSpec;

    public Encryptor() throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException,
            UnsupportedEncodingException {
        this(null, DEFAULT_IV);
    }

    public Encryptor(String secretKey, byte[] iv) throws NoSuchAlgorithmException {
        this.secretKeySpec = generateKey(secretKey);

        gcmParameterSpec = new GCMParameterSpec(16 * 8, iv);
    }

    @Generated
    public String encrypt(String plainText) throws InvalidKeyException, NoSuchAlgorithmException,
            NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, gcmParameterSpec);
        plainText = plainText.concat(randomString(16));
        byte[] encrypted = cipher.doFinal(plainText.getBytes(StandardCharsets.UTF_8));
        return asHexString(encrypted);
    }

    @Generated
    public String decrypt(String encryptedString) throws InvalidKeyException, IllegalBlockSizeException,
            BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidAlgorithmParameterException {
        Cipher cipher = Cipher.getInstance(ALGORITHM);
        cipher.init(Cipher.DECRYPT_MODE, secretKeySpec, gcmParameterSpec);
        byte[] original = cipher.doFinal(toByteArray(encryptedString));
        String decrypt = new String(original);
        return decrypt.substring(0, original.length - 16);
    }

    @Generated
    private Key generateKey(String secretKey) throws NoSuchAlgorithmException {
        if (secretKey == null) {
            secretKey = DEFAULT_SECRET_KEY;
        }
        byte[] key = (secretKey).getBytes(StandardCharsets.UTF_8);
        MessageDigest sha = MessageDigest.getInstance("SHA-256");
        key = sha.digest(key);
        key = Arrays.copyOf(key, 16); // use only the first 128 bit

        KeyGenerator kgen = KeyGenerator.getInstance("AES");
        kgen.init(128); // 192 and 256 bits may not be available

        return new SecretKeySpec(key, "AES");
    }

    private final String asHexString(byte buf[]) {
        StringBuilder strbuf = new StringBuilder(buf.length * 2);
        int i;
        for (i = 0; i < buf.length; i++) {
            if (((int) buf[i] & 0xff) < 0x10) {
                strbuf.append("0");
            }
            strbuf.append(Long.toString((int) buf[i] & 0xff, 16));
        }
        return strbuf.toString();
    }

    private final byte[] toByteArray(String hexString) {
        int arrLength = hexString.length() >> 1;
        byte buf[] = new byte[arrLength];
        for (int ii = 0; ii < arrLength; ii++) {
            int index = ii << 1;
            String lDigit = hexString.substring(index, index + 2);
            buf[ii] = (byte) Integer.parseInt(lDigit, 16);
        }
        return buf;
    }

    private String randomString(int length) {
        char[] chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789".toCharArray();
        StringBuilder sb = new StringBuilder();
        SecureRandom random = new SecureRandom();
        for (int i = 0; i < length; i++) {
            char c = chars[random.nextInt(chars.length)];
            sb.append(c);
        }
        return sb.toString();
    }
}
