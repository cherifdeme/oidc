package fr.ca.cat.ihm.security;

import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.exception.UnauthorizedException;
import fr.ca.cat.ihm.security.dto.SecurityDTO;
import jakarta.servlet.http.HttpServletRequest;

/**
 * Interface permettant de gérer la sécurité applicative<br>
 * On récupère le UserDTO grâce au jeton SAML contenu dans la requête.
 *
 * @author ETP0981
 */
public interface ISecurity {

    /**
     * Nom de la propriété dans le header qui contient le jeton SAML
     */
    String SAML_HEADER_NAME = "authorization";

    /**
     * Le nom de l'attribut du securitDTO dans la request
     */
    String SECURITY_DTO_ATTRIBUTE_NAME = "securityDTO";

    /**
     * Retourne l'objet sécurité contenant le User et d'autres informations<br>
     * <p>
     * Vérifie l'intégrité, la signature et les dates d'expiration du jeton SAML
     * <p>
     * Le User est récupéré grâce au jeton SAML contenu dans la requête.
     *
     * @param req La requête arrivant au serveur.
     * @return L'objet sécurité.
     */
    SecurityDTO extractSecurityFromRequest(HttpServletRequest req) throws TechnicalException, UnauthorizedException;
}
