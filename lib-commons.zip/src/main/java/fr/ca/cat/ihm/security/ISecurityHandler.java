package fr.ca.cat.ihm.security;

import fr.ca.cat.ihm.security.dto.SecurityDTO;
import jakarta.servlet.http.HttpServletRequest;

public interface ISecurityHandler {
    void addSecurityContext(SecurityDTO securityDTO, HttpServletRequest request);
}
