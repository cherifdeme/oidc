package fr.ca.cat.ihm.security;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.regex.Pattern;

public final class IhmeEncryptor {

    public static final Pattern CIPHERED_PATTERN = Pattern.compile("Ciphered\\{([a-zA-Z0-9]+)\\}");

    public String encrypt(final String plainText) throws InvalidKeyException, NoSuchAlgorithmException,
            NoSuchPaddingException, IllegalBlockSizeException, BadPaddingException, UnsupportedEncodingException, InvalidAlgorithmParameterException {

        final var encryptor = new Encryptor();
        return String.format("Ciphered{%s}", encryptor.encrypt(plainText));
    }


    /**
     * Dechiffre la valeur XX si Ciphered{XX}, sinon retourne XX (i.e XX non chiffree)
     *
     * @param encryptedString
     * @return
     * @throws InvalidKeyException
     * @throws IllegalBlockSizeException
     * @throws BadPaddingException
     * @throws NoSuchAlgorithmException
     * @throws NoSuchPaddingException
     * @throws InvalidAlgorithmParameterException
     */

    public String decrypt(String encryptedString) throws InvalidKeyException, IllegalBlockSizeException,
            BadPaddingException, NoSuchAlgorithmException, NoSuchPaddingException, UnsupportedEncodingException, InvalidAlgorithmParameterException {

        final var matcher = CIPHERED_PATTERN.matcher(encryptedString);
        if (matcher.find()) {
            encryptedString = matcher.group(1);
            final var encryptor = new Encryptor();
            return encryptor.decrypt(encryptedString);
        }
        return encryptedString;
    }
}
