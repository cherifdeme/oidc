/**
 *
 */
package fr.ca.cat.ihm.security;


import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.logger.TypeLogger;
import fr.ca.cat.ihm.utils.Generated;
import jakarta.servlet.http.HttpServletRequest;

/**
 * Fournit l'implementation de la classe de securité
 *
 * @author ETP0981
 */
@Generated
public final class SecurityFactory {

    /**
     * Logger de la classe SecurityFactory
     */
    private static final Logger LOGGER = LogFactory.getLog(TypeLogger.LOGGER_SOCLE);
    public static ISecurity security;

    /**
     * Constructeur privé pour bloquer l'instanciation
     */
    private SecurityFactory() {
    }


    public static ISecurity getSecurity(HttpServletRequest request) {

        return security;
    }
}
