package fr.ca.cat.ihm.security.auc9;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.security.dto.SecurityAPIBean;
import fr.ca.cat.ihm.utils.Generated;
import fr.ca.cat.ihm.web.client.RsConf;

@Generated
public interface WebClientAuc9Service {
    SecurityAPIBean getOpenidToken() throws TechnicalException;

    SecurityAPIBean getToken() throws TechnicalException;

    void revokeToken(SecurityAPIBean secuBean);

    SecurityAPIBean getUATokensFromJWT() throws TechnicalException;

    SecurityAPIBean refreshToken(String refreshToken) throws TechnicalException;

    void setContext(Context context);

    void setRsConf(RsConf rsConf);
}
