package fr.ca.cat.ihm.security.auc9;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.logger.TypeLogger;
import fr.ca.cat.ihm.security.dto.SecurityAPIBean;
import fr.ca.cat.ihm.utils.Constants;
import fr.ca.cat.ihm.utils.Generated;
import fr.ca.cat.ihm.web.client.RsConf;
import fr.ca.cat.ihm.web.client.impl.WebClient;
import fr.ca.cat.most.util.log.MostCode;
import org.apache.http.HttpHeaders;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;
import reactor.core.publisher.Mono;

import java.util.Objects;
import java.util.UUID;

/**
 * implementation de la securité à travers le webclient, appel AUC9,
 * utilise la librairie spring webflux pour effectuer les appels.
 *
 * @author cherif DEME
 */
@Service
public class WebClientAuc9ServiceImpl extends WebClient implements WebClientAuc9Service {
    private static final Logger LOGGER = LogFactory.getLog(WebClientAuc9ServiceImpl.class, TypeLogger.LOGGER_SOCLE);

    public WebClientAuc9ServiceImpl(@Autowired @Qualifier("authentificationCollaborateurV2") RsConf rsConf,
                                    @Autowired(required = false) Context context) {
        super(rsConf, context);
    }

    @Override
    public SecurityAPIBean getOpenidToken() throws TechnicalException {
        LOGGER.debug("On entre dans la methode getOpenIdToken pour obtenir un jeton JWT", context);

        final var uri = getUriComponents(rsConf.getUrl(), "/openid/token");
        MultiValueMap<String, String> bodyParameters = new LinkedMultiValueMap<>();
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();

        this.provideClientHeader(headers);
        headers.add(HttpHeaders.CONTENT_TYPE, Constants.APPLICATION_X_WWW_FORM_URLENCODED);
        headers.add(Constants.HDR_CORRELATION_ID, UUID.randomUUID().toString());//Le service authen collab v2 demande un UUID
        setAuthorization(headers);

        bodyParameters.add(Constants.GRANT_TYPE, "client_credentials");
        bodyParameters.add(Constants.SCOPE, "openid");
        bodyParameters.add(Constants.AUTHENTICATION_LEVEL, "2");

        final Mono<?> mono = this.executePostRequest(headers, bodyParameters, rsConf, uri, SecurityAPIBean.class,
                HttpMethod.POST, Constants.APPLICATION_X_WWW_FORM_URLENCODED);

        if (mono.block() instanceof WebClientResponseException e) {
            throw processAuc9Exception(e);
        } else {
            return (SecurityAPIBean) mono.block();
        }
    }


    @Override
    /**
     * Methode pour demander un nouvel access token � partir d'un refresh token
     */
    public SecurityAPIBean refreshToken(final String refreshToken) throws TechnicalException {
        LOGGER.debug("On entre dans la methode refreshToken pour obtenir un jeton authorization code", context);
        final var uri = getUriComponents(rsConf.getUrl(), Constants.URI_TOKEN);

        MultiValueMap<String, String> bodyParameters = new LinkedMultiValueMap<>();
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        this.setAuthorization(headers);
        this.buildBody(bodyParameters);
        final Mono<?> mono = this.executePostRequest(headers, bodyParameters, rsConf, uri, SecurityAPIBean.class,
                HttpMethod.POST, Constants.APPLICATION_X_WWW_FORM_URLENCODED);

        if (mono.block() instanceof WebClientResponseException e) {
            throw processAuc9Exception(e);
        } else {
            return (SecurityAPIBean) mono.block();
        }
    }

    @Override
    public void revokeToken(final SecurityAPIBean secuBean) {
        final var uri = getUriComponents(rsConf.getUrl(), "/revoke");
        MultiValueMap<String, String> bodyParameters = new LinkedMultiValueMap<>();
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();

        try {

            this.provideClientHeader(headers);
            headers.add(HttpHeaders.CONTENT_TYPE, Constants.APPLICATION_X_WWW_FORM_URLENCODED);
            headers.add(Constants.HDR_CORRELATION_ID, UUID.randomUUID().toString());//Le service authen collab v2 demande un UUID
            bodyParameters.add("token", secuBean.getRefresh_token());

            final Mono<?> mono = this.executePostRequest(headers, bodyParameters, rsConf, uri, SecurityAPIBean.class,
                    HttpMethod.POST, Constants.APPLICATION_X_WWW_FORM_URLENCODED);

            if (mono.block() instanceof WebClientResponseException e) {
                LOGGER.warn(new MostCode("IHME-API_1513096645419"),
                        e.getMessage(), context);
                throw processAuc9Exception(e);
            }

        } catch (Exception e) {
            LOGGER.warn(new MostCode("IHME-API_1513096645417"), e.getMessage(), e, context);
        }
    }

    @Generated
    @Override
    public SecurityAPIBean getToken() throws TechnicalException {
        final var uri = getUriComponents(rsConf.getUrl(), Constants.URI_TOKEN);
        MultiValueMap<String, String> bodyParameters = new LinkedMultiValueMap<>();
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        this.provideClientHeader(headers);
        this.setAuthorization(headers);
        this.buildBody(bodyParameters);
        headers.add(HttpHeaders.CONTENT_TYPE, Constants.APPLICATION_X_WWW_FORM_URLENCODED);
        headers.add(Constants.HDR_CORRELATION_ID, UUID.randomUUID().toString());//Le service authen collab v2 demande un UUID
        final Mono<?> mono = this.executePostRequest(headers, bodyParameters, rsConf, uri, SecurityAPIBean.class,
                HttpMethod.POST, Constants.APPLICATION_X_WWW_FORM_URLENCODED);

        if (mono.block() instanceof WebClientResponseException e) {
            throw processAuc9Exception(e);
        } else {
            return (SecurityAPIBean) mono.block();
        }
    }

    @Generated
    @Override
    public SecurityAPIBean getUATokensFromJWT() throws TechnicalException {
        final var uri = getUriComponents(rsConf.getUrl(), Constants.URI_TOKEN);
        MultiValueMap<String, String> bodyParameters = new LinkedMultiValueMap<>();
        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        this.provideClientHeader(headers);
        this.setAuthorization(headers);
        this.buildBody(bodyParameters);
        headers.add(HttpHeaders.CONTENT_TYPE, Constants.APPLICATION_X_WWW_FORM_URLENCODED);
        headers.add(Constants.HDR_CORRELATION_ID, UUID.randomUUID().toString());
        bodyParameters.add(Constants.GRANT_TYPE, "urn:ietf:params:oauth:grant-type:jwt-bearer");
        bodyParameters.add("assertion", context.getSecurityDTO().getApiSecurity().getId_token());

        final Mono<?> mono = this.executePostRequest(headers, bodyParameters, rsConf, uri, SecurityAPIBean.class,
                HttpMethod.POST, Constants.APPLICATION_X_WWW_FORM_URLENCODED);

        if (mono.block() instanceof WebClientResponseException e) {
            throw processAuc9Exception(e);
        } else {
            return (SecurityAPIBean) mono.block();
        }
    }

    @Generated
    private TechnicalException processAuc9Exception(final WebClientResponseException entity) {
        final HttpStatus resolve = HttpStatus.resolve(entity.getStatusCode().value());
        final UriComponents uri = UriComponentsBuilder.fromUri(Objects.requireNonNull(entity.getRequest()).getURI()).build();
        doPerf(entity.getStatusCode().value(), Objects.requireNonNull(entity.getRequest()).getMethod().name(), uri);
        switch (Objects.requireNonNull(resolve)) {
            case UNAUTHORIZED -> {
                LOGGER.error(Constants.MC_IHME_API_AUC9_KO_4XX, entity.getResponseBodyAsString(), context);
                final var technicalException = new TechnicalException(context, Constants.TEX_FWK633,
                        new String[]{entity.getStatusText(), context.getCorrelationId(), String.valueOf(HttpStatus.UNAUTHORIZED)});
                technicalException.setStatusCode(resolve.value());
                return technicalException;
            }
            case BAD_REQUEST -> {
                LOGGER.error(Constants.MC_IHME_API_AUC9_KO_4XX, entity.getResponseBodyAsString(), context);
                final var technicalException = new TechnicalException(context, Constants.TEX_FWK632,
                        new String[]{entity.getStatusText(), context.getCorrelationId(), String.valueOf(HttpStatus.BAD_REQUEST)});
                technicalException.setStatusCode(resolve.value());
                return technicalException;
            }
            default -> {
                LOGGER.error(Constants.MC_IHME_API_AUC9_KO, entity.getResponseBodyAsString(), context);
                final var technicalException = new TechnicalException(context, Constants.TEX_FWK630, new String[]{
                        entity.getStatusCode() + " " + entity.getStatusText(), context.getCorrelationId()});
                technicalException.setStatusCode(resolve.value());
                return technicalException;
            }
        }
    }

    @Override
    public void setRsConf(final RsConf rsConf) {
        this.rsConf = rsConf;
    }

    @Override
    public void setContext(final Context context) {
        this.context = context;
    }

}
