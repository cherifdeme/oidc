package fr.ca.cat.ihm.security.domain;

import fr.ca.cat.ihm.utils.Generated;

@Generated
public enum AuthenticationSchemeEnum {

    Bearer, Basic
}
