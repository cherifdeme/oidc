package fr.ca.cat.ihm.security.domain;

import fr.ca.cat.ihm.security.dto.UserInfos;
import fr.ca.cat.ihm.utils.Generated;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Generated
public interface CatsPrincipal {

//    String AUTHENTICATION_SCHEME_BEARER = "Bearer";
//    String AUTHENTICATION_SCHEME_BASIC = "Basic";

    /**
     * L'identifiant unique d'une requête (web) ou d'un événement (kafka) reçu ou généré si non provisionné
     *
     * @return requestId
     */
    String getRequestId();

    /**
     * L'identifiant de correlation reçu ou généré si non provisionné
     * <p>
     * <b>Obligatoire</b>
     * </p>
     *
     * @return correlationId
     */
    String getCorrelationId();

    /**
     * L'identifiant de caisse régionale <b>retenu</b>
     * <p>
     * <b>Obligatoire</b>
     * </p>
     *
     * @return idCr
     */
    String getIdCR();

    /**
     * L'identifiant de l'application consommatrice issu du jeton si bearer ou du basic
     *
     * @return clientId
     */
    String getClientId();

    /**
     * Le type d'authentification (bearer, basic, etc.)
     * <p>
     * <b>Optionnel</b>
     * </p>
     *
     * @return le type d'authentification
     */
    AuthenticationSchemeEnum getAuthenticationScheme();

    /**
     * Les infos parsés du token JWS
     * <p>
     * <b>Optionnel</b>
     * </p>
     *
     * @return JwtInfos
     */
    Optional<UserInfos> getUserInfos();

    /**
     * Map des headers de la requête (web) ou de l'événement (asynchrone)
     *
     * @return headers
     */
    Map<String, List<String>> getHeaders();
}