package fr.ca.cat.ihm.security.domain;

import fr.ca.cat.ihm.utils.Generated;

import java.util.List;
import java.util.Map;

@Generated
public interface InternalWebCatsPrincipal extends WebCatsPrincipal {

    /**
     * Permet de positionner le contexte path de la requête
     *
     * @param requestContextPath est la valeur à positionner
     */
    void setRequestContextPath(String requestContextPath);

    /**
     * Permet de positionner la map des headers de la requête
     *
     * @param requestHeaders est la valeur à positionner
     */
    void setRequestHeaders(Map<String, List<String>> requestHeaders);

    /**
     * Permet de positionner la map des paramètres de la query de la requête
     *
     * @param requestQueryParams est la valeur à positionner
     */
    void setRequestQueryParams(Map<String, List<String>> requestQueryParams);
}
