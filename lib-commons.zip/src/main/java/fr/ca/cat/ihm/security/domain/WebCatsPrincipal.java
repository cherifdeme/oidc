package fr.ca.cat.ihm.security.domain;

import fr.ca.cat.ihm.utils.Generated;

import java.util.List;
import java.util.Map;

@Generated
public interface WebCatsPrincipal extends CatsPrincipal {

    /**
     * Le contexte path de la requête
     *
     * @return requestContextPath
     */
    String getRequestContextPath();

    /**
     * Map des paramètres de la query de la requête
     *
     * @return requestQueryParams
     */
    Map<String, List<String>> getRequestQueryParams();
}
