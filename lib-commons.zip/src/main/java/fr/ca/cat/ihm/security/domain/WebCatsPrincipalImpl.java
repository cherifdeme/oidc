package fr.ca.cat.ihm.security.domain;

import fr.ca.cat.ihm.security.dto.UserInfos;
import fr.ca.cat.ihm.utils.Generated;

import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

@Generated
public final class WebCatsPrincipalImpl implements InternalWebCatsPrincipal {

    private final UserInfos userInfos;

    private final String idCR;

    private final String correlationId;

    private final String requestId;

    private final String clientId;

    private final AuthenticationSchemeEnum authenticationScheme;

    private Map<String, List<String>> headers;
    private String requestContextPath;
    private Map<String, List<String>> requestQueryParams;

    public WebCatsPrincipalImpl(final UserInfos userInfos, final String correlationId, final String requestId) {
        super();
        this.userInfos = Objects.requireNonNull(userInfos);
        this.correlationId = correlationId;
        this.requestId = requestId;
        this.clientId = userInfos.getUserDTO().getUserID();
        this.authenticationScheme = AuthenticationSchemeEnum.Bearer;
        this.idCR = this.userInfos.getUserDTO().getConnectionStructureID();

    }

    @Override
    public void setRequestHeaders(Map<String, List<String>> requestHeaders) {
        this.headers = requestHeaders;
    }

    @Override
    public String getRequestId() {
        return this.requestId;
    }

    @Override
    public String getCorrelationId() {
        return this.correlationId;
    }

    @Override
    public String getIdCR() {
        return this.idCR;
    }

    @Override
    public String getClientId() {
        return this.clientId;
    }

    @Override
    public AuthenticationSchemeEnum getAuthenticationScheme() {
        return this.authenticationScheme;
    }

    @Override
    public Optional<UserInfos> getUserInfos() {
        return Optional.of(this.userInfos);
    }

    @Override
    public Map<String, List<String>> getHeaders() {
        return this.headers;
    }

    @Override
    public String getRequestContextPath() {
        return this.requestContextPath;
    }

    @Override
    public void setRequestContextPath(String requestContextPath) {
        this.requestContextPath = requestContextPath;
    }

    @Override
    public Map<String, List<String>> getRequestQueryParams() {
        return this.requestQueryParams;
    }

    @Override
    public void setRequestQueryParams(Map<String, List<String>> requestQueryParams) {
        this.requestQueryParams = requestQueryParams;
    }
}
