package fr.ca.cat.ihm.security.dto;

import fr.ca.cat.ihm.utils.Generated;

@Generated
public interface SecurityAPI {

    String getToken_type();

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.security.dto.SecurityAPI#getExpires_in()
     */
    int getExpires_in();

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.security.dto.SecurityAPI#getAccess_token()
     */
    String getAccess_token();

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.security.dto.SecurityAPI#getId_token()
     */
    String getId_token();

    /* (non-Javadoc)
     * @see fr.ca.cat.ihm.security.dto.SecurityAPI#getRefresh_token()
     */
    String getRefresh_token();
}