package fr.ca.cat.ihm.security.dto;

import fr.ca.cat.ihm.utils.Generated;

@Generated
public class SecurityCodeAPIBean {

    public String code;

    public String redirect_uri;

    public String state;

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getRedirect_uri() {
        return redirect_uri;
    }

    public void setRedirect_uri(String redirect_uri) {
        this.redirect_uri = redirect_uri;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}

