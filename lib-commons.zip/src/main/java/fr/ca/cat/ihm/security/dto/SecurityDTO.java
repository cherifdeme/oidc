/**
 *
 */
package fr.ca.cat.ihm.security.dto;

import fr.ca.cat.ihm.utils.Generated;
import org.opensaml.saml.saml2.core.Assertion;

/**
 * @author ETP0981
 */
@Generated
public class SecurityDTO {

    private UserDTO userDTO;

    /**
     * Resultat du parsing du jeton.
     * PERFS : on le stocke ici pour injecter l'element XML dans les headers SOAP
     */
    private Assertion samlAssertion;

    private SecurityAPIBean apiSecurity;

    private String aulnSessionId;

    /**
     * @return userDTO
     */
    public final UserDTO getUserDTO() {
        return userDTO;
    }

    /**
     * @param userDTO
     */
    public final void setUserDTO(final UserDTO userDTO) {
        this.userDTO = userDTO;
    }

    public Assertion getSamlAssertion() {
        return samlAssertion;
    }

    public void setSamlAssertion(final Assertion samlAssertion) {
        this.samlAssertion = samlAssertion;
    }

    public SecurityAPIBean getApiSecurity() {
        return apiSecurity;
    }

    public void setApiSecurity(SecurityAPIBean apiSecurity) {
        this.apiSecurity = apiSecurity;
    }


    public String getAulnSessionId() {
        return aulnSessionId;
    }

    public void setAulnSessionId(String aulnSessionId) {
        this.aulnSessionId = aulnSessionId;
    }
}
