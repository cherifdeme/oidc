package fr.ca.cat.ihm.security.dto;

import fr.ca.cat.ihm.utils.Generated;

import java.io.Serializable;
import java.security.Principal;
import java.util.HashSet;
import java.util.Set;

/**
 * Utilisateur
 *
 * @author ETP0981
 */
@Generated
public class UserDTO implements Principal, Serializable {
    public static final String SESSION_ATTRIBUTE = "most.security.userPrincipal";
    public static final String USER_UNAUTHENTICATED = "most_unauthenticated";
    private static final long serialVersionUID = -4385781996267724237L;
    private String id;
    private String firstName;
    private String lastName;
    private String profile;
    private String funcScopeBOUID;
    private String connectionStructureID;
    private String userID;
    private String functionalPostID;
    private String role;
    private Set<String> crs = new HashSet<String>();
    private boolean vip;
    private String samlToken;
    private String browser;
    private String ip;
    private String hostName;
    private Set<String> resources = new HashSet<String>();

    /**
     * Constructeur avec paramètres
     *
     * @param firstName Nom de l'utilisateur
     * @param profile   Profil de l'utilisateur (agent, client, etc...)
     * @param role      Rôle de l'utilisateur (superviseur, etc...)
     * @param crs       Caisses régionales de l'utilisateur (Annecy, Paris, etc...)
     */
    public UserDTO(final String firstName, final String profile, final String role, final Set<String> crs) {
        super();
        this.firstName = firstName;
        this.profile = profile;
        this.role = role;
        this.crs = crs;
    }

    /**
     * Constructeur par défaut
     */
    public UserDTO() {
        super();
    }

    public String getBrowser() {
        return browser;
    }

    public void setBrowser(final String browser) {
        this.browser = browser;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(final String ip) {
        this.ip = ip;
    }

    public String getHostName() {
        return hostName;
    }

    public void setHostName(final String hostName) {
        this.hostName = hostName;
    }

    /**
     * Renvoie id
     *
     * @return id
     */
    public String getId() {
        return id;
    }

    /**
     * Définit id
     *
     * @param id
     */
    public void setId(final String id) {
        this.id = id;
    }

    /**
     * Renvoie firstName
     *
     * @return firstName
     */
    public final String getFirstName() {
        return firstName;
    }

    /**
     * Définit firstName
     *
     * @param firstName le prénom de l'utilisateur
     */
    public final void setFirstName(final String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(final String lastName) {
        this.lastName = lastName;
    }

    /**
     * Renvoie profile
     *
     * @return profile
     */
    public final String getProfile() {
        return profile;
    }

    /**
     * Définit profile
     *
     * @param profile de l'utilisateur
     */
    public final void setProfile(final String profile) {
        this.profile = profile;
    }

    /**
     * Renvoie role
     *
     * @return role
     */
    public final String getRole() {
        return role;
    }

    /**
     * Définit role
     *
     * @param role
     */
    public final void setRole(final String role) {
        this.role = role;
    }

    /**
     * Renvoie crs
     *
     * @return crs
     */
    public Set<String> getCrs() {
        return crs;
    }

    /**
     * @param crs liste de caisses régionales
     */
    public void setCrs(final Set<String> crs) {
        this.crs = crs;
    }

    /**
     * @param pCrs la caisse régionale
     */
    public void addCrs(final String pCrs) {
        this.crs.add(pCrs);
    }

    /**
     * Renvoie crs
     *
     * @return crs
     */
    public Set<String> getResources() {
        return resources;
    }

    /**
     * @param resources resources à définir
     */
    public void setResources(final Set<String> resources) {
        this.resources = resources;
    }

    public void addResource(final String currentResource) {
        this.resources.add(currentResource);
    }

    public String getFuncScopeBOUID() {
        return this.funcScopeBOUID;
    }

    public void setFuncScopeBOUID(final String funcScopeBOUID) {
        this.funcScopeBOUID = funcScopeBOUID;
    }

    public String getConnectionStructureID() {
        return this.connectionStructureID;
    }

    public void setConnectionStructureID(final String connectionStructureID) {
        this.connectionStructureID = connectionStructureID;
    }

    public String getUserID() {
        return this.userID;
    }

    public void setUserID(final String userID) {
        this.userID = userID;
    }

    public String getFunctionalPostID() {
        return this.functionalPostID;
    }

    public void setFunctionalPostID(final String functionalPostID) {
        this.functionalPostID = functionalPostID;
    }

    public boolean isVip() {
        return vip;
    }

    public void setVip(final boolean vip) {
        this.vip = vip;
    }

    /**
     * @return samlToken
     */
    public String getSamlToken() {
        return samlToken;
    }

    /**
     * @param samlToken jeton SAML
     */
    public void setSamlToken(final String samlToken) {
        this.samlToken = samlToken;
    }

    @Override
    public String getName() {
        return id;
    }

    /**
     * Méthode vérifiant la présence de l'habilitation
     * spécifiée en paramètre dans la liste des
     * habilitations de l'utilisateur connecté.
     *
     * @param resourceName, l'habilitation à vérifier
     * @return true si l'utilisateur possède l'habilitation spécifiée
     */
    public Boolean hasResource(final String resourceName) {
        boolean hasResource = false;

        if (null != this && null != this.getResources() && !this.getResources().isEmpty()) {
            hasResource = this.getResources().contains(resourceName);
        }
        return hasResource;
    }

    /**
     * C'est de la daube mais ça devrait suffire dans le cadre du PU_C.
     * Fait le mapping entre le user type "CAT" (pas de doc)et le user type "CASA" (pas trouvé la nomenclature officielle)
     * Règle de mapping : <br>
     * <ul>
     * <li>"Agent" = > "01" </li>
     * <li>autreValeur => autreValeur</li>
     * </ul>
     *
     * @return
     */
    public String getTypeActeurCASA() {
        if ("Agent".equals(this.profile)) {
            return "01";
        }
        return this.profile;
    }
}
