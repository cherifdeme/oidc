package fr.ca.cat.ihm.security.dto;

import fr.ca.cat.ihm.controller.bean.ContextExecution;
import fr.ca.cat.ihm.utils.Generated;

@Generated
public class UserInfos {

    private UserDTO userDTO;
    private ContextExecution ctx;

    public UserInfos(UserDTO userDTO, ContextExecution ctx) {
        this.userDTO = userDTO;
        this.ctx = ctx;
    }

    public UserInfos() {

    }

    public UserDTO getUserDTO() {
        return userDTO;
    }

    public void setUserDTO(UserDTO userDTO) {
        this.userDTO = userDTO;
    }

    public ContextExecution getCtx() {
        return ctx;
    }

    public void setCtx(ContextExecution ctx) {
        this.ctx = ctx;
    }
}
