package fr.ca.cat.ihm.security.impl;

import fr.ca.cat.ihm.controller.bean.Browser;
import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.logger.TypeLogger;
import fr.ca.cat.ihm.performance.dto.PerformanceDTO;
import fr.ca.cat.ihm.security.ISecurity;
import fr.ca.cat.ihm.security.dto.SecurityDTO;
import fr.ca.cat.ihm.security.dto.UserDTO;
import fr.ca.cat.ihm.utils.ContextHelper;
import fr.ca.cat.most.util.log.MostCode;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.io.IOUtils;
import org.opensaml.saml.saml2.core.Assertion;
import org.springframework.beans.factory.annotation.Value;

import java.io.IOException;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * Classe d'implémentation de l'interface ISecurity permettant de gérer la sécurité<br>
 * <p>
 * Implémentation bouchonnée de la sécurité applicative du socle.<br>
 * <p>
 * Récupère le jeton SAML depuis un fichier XML bouchon, ensuite vérifie la signature du jeton SAML ainsi que le
 * fait qu'il ne soit pas expiré.<br>
 * <p>
 * On récupère le UserDTO grâce au jeton SAML bouchonné en fichier XML<br>
 * <p>
 * On génère le SecurityDTO associé.<br>
 *
 * @author Guillaume Marchal.
 */
public class MockFileSecurityImpl extends SecurityImpl {

    private static final Logger LOGGER = LogFactory.getLog(MockFileSecurityImpl.class, TypeLogger.LOGGER_SOCLE);

    private static final MostCode MC_KO_MOCK = new MostCode("IHME_1472471972927");

    //Récupération du jeton SAML bouchon depuis le fichier XML
    @Value("${socle.security.auln.sessionId.filename}")
    public String sessionIdFile;

    //Récupération du jeton SAML bouchon depuis le fichier XML
    @Value("${socle.security.tai.samlTokenStubUrl}")
    public String samlTokenStub;

    /**
     * {@inheritDoc}
     **/
    @Override
    public SecurityDTO extractSecurityFromRequest(final HttpServletRequest request) throws TechnicalException {

        var securityDTO = (SecurityDTO) request.getAttribute(ISecurity.SECURITY_DTO_ATTRIBUTE_NAME);

        if (securityDTO != null) {
            return securityDTO;
        }

        // attention, ne pas essayer d'appeler HELPER.getSecurity() à la place
        // de new SecurityDTO()
        // pour obtenir une instance de SecurityDTO, car ça va boucler !!
        final var contextExecution = ContextHelper.getContextExecution(request);
        final var imWorkingForThatGuy = ContextHelper.getEmetteur(request);

        final var ctx = new Context(
                new Browser("", new Locale("")),
                new PerformanceDTO(""),
                new SecurityDTO(),
                imWorkingForThatGuy.getId(),
                imWorkingForThatGuy.getVersion(),
                contextExecution
        );


        final var samlToken = getSamlToken(request);

        //Récupération du SecurityDTO depuis la classe parente (fonctionnement nominal)
        securityDTO = buildSecurity(samlToken, ctx);

        // Lecture du fichier AULN_SESSION_ID
        securityDTO.setAulnSessionId(getAulnSessionID());

        request.setAttribute(ISecurity.SECURITY_DTO_ATTRIBUTE_NAME, securityDTO);

        return securityDTO;
    }


    /**
     * Désactive la vérification de la signature du jeton
     *
     * @param assertion l'assertion à vérifier
     * @param ctx       le contexte utilisateur
     */
    @Override
    protected void verifySignature(final Assertion assertion, final Context ctx) {
        LOGGER.secu("mock on fait rien", ctx);
    }

    /**
     * Désactive la vérification de la date de validité du jeton
     *
     * @param samlA le jeton SAML
     * @param ctx   le contexte utilisateur
     */
    @Override
    protected boolean isSAMLTokenDateValid(final Assertion samlA, final Context ctx) {

        LOGGER.secu("mock on fait rien", ctx);
        return true;
    }


    @Override
    protected boolean isContextExeValid(final Context ctx, final UserDTO user) throws TechnicalException {
        return super.isContextExeValid(ctx, user);
    }

    protected String getAulnSessionID() {

        String aulnSessionID = null;
        final var writer = new StringWriter();
        try {
            IOUtils.copy(Thread.currentThread().getContextClassLoader().getResourceAsStream(sessionIdFile), writer, StandardCharsets.UTF_8);
            aulnSessionID = writer.toString();
        } catch (IOException e) {
            LOGGER.error(MC_KO_MOCK, "Le chargement du fichier session bouchon : " +
                    sessionIdFile + "a echoue", e, null);
        }

        return aulnSessionID;

    }

    @Override
    protected String getSamlToken(final HttpServletRequest request) {

        String samlMockToken = null;
        final var writer = new StringWriter();
        try {
            IOUtils.copy(Thread.currentThread().getContextClassLoader().getResourceAsStream(samlTokenStub), writer, StandardCharsets.UTF_8);
            samlMockToken = writer.toString();
        } catch (IOException e) {
            LOGGER.error(MC_KO_MOCK, "Le chargement du fichier XML bouchon : " +
                    samlTokenStub + " du jeton SAML a echoue", e, null);
        }
        return samlMockToken;
    }
}
