package fr.ca.cat.ihm.security.impl;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.exception.UnauthorizedException;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.LogUtils;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.logger.TypeLogger;
import fr.ca.cat.ihm.redis.RedisCacheService;
import fr.ca.cat.ihm.security.dto.UserDTO;
import fr.ca.cat.ihm.utils.RequestUtils;
import fr.ca.cat.most.util.log.MostCode;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.joda.time.LocalDateTime;
import org.springframework.http.HttpStatus;

public class SecurityFullRedis extends SecurityImpl {

    private static final MostCode MC_AULN_SESSION = new MostCode("IHME_AULN_SESSION");

    private static final Logger LOGGER = LogFactory.getLog(SecurityFullRedis.class, TypeLogger.LOGGER_SOCLE);

    public static RedisCacheService redisCacheService;

    public SecurityFullRedis(RedisCacheService redisCacheService) {
        this.redisCacheService = redisCacheService;
    }

    @Override
    protected boolean isContextExeValid(final Context ctx, final UserDTO user) {
        return true;
    }

    /**
     * A l'instar du RPSA, travailler le cookie de session ident/authent pour
     * aller chercher le jeton SAML dans le cache REDIS
     */
    @Override
    public String getSamlToken(final HttpServletRequest request) throws UnauthorizedException {

        final var aulnCookieValue = RequestUtils.getCookie(AULN_SESSION_ID, request);
        LOGGER.info(MC_AULN_SESSION, LogUtils.obfuscateUUIDString(aulnCookieValue), null);
        final String samlToken = redisCacheService.getSAMLRedis(aulnCookieValue);

        if (samlToken == null) {
            LOGGER.error("Le jeton saml est null", null);

            throw new UnauthorizedException(HttpServletResponse.SC_UNAUTHORIZED,
                    HttpStatus.UNAUTHORIZED.getReasonPhrase(), LocalDateTime.now());
        }
        return samlToken;
    }
}
