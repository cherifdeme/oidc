package fr.ca.cat.ihm.security.impl;


import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.controller.bean.ContextExecution;
import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.exception.UnauthorizedException;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.LogUtils;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.logger.TypeLogger;
import fr.ca.cat.ihm.performance.dto.PerformanceDTO;
import fr.ca.cat.ihm.security.ISecurity;
import fr.ca.cat.ihm.security.dto.SecurityDTO;
import fr.ca.cat.ihm.security.dto.UserDTO;
import fr.ca.cat.ihm.utils.Consommateur;
import fr.ca.cat.ihm.utils.ContextHelper;
import fr.ca.cat.ihm.utils.Generated;
import fr.ca.cat.ihm.utils.RequestUtils;
import fr.ca.cat.most.util.log.MostCode;
import fr.ca.cat.securite.saml.IUserCAT;
import fr.ca.cat.securite.saml.UserCatFactory;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.commons.lang3.StringUtils;
import org.joda.time.LocalDateTime;
import org.opensaml.saml.saml2.core.Assertion;
import org.springframework.http.HttpStatus;

/**
 * Classe d'implémentation de l'interface ISecurity permettant de gérer la sécurité<br>
 * <p>
 * Implémentation nominale de la sécurité applicative du socle.<br>
 * <p>
 * Récupère le jeton SAML dans le header de la requête, vérifie sa signature ainsi que le
 * fait qu'il ne soit pas expiré.<br>
 * <p>
 * On récupère le UserDTO grâce au jeton SAML contenu dans la requête.<br>
 * <p>
 * On génère le SecurityDTO associé.<br>
 *
 * @author Guillaume Marchal.
 */
public class SecurityImpl implements ISecurity {
    /**
     * Cookie de session AULN
     */
    public static final String AULN_SESSION_ID = "AULN_SESSION_ID";
    /**
     * Suffixe du user du jeton SAML anonyme
     */
    private final static String SUFFIXE_USER_ANONYME_SAML = "AUINUNAUTH";
    /**
     * Logger de la classe SecurityImpl
     */
    private static final Logger LOGGER = LogFactory.getLog(SecurityImpl.class, TypeLogger.LOGGER_SOCLE);
    private static final String DEFAULT_VALUE = "Inconnu";
    private static final MostCode MC_FWK065 = new MostCode("FWK065");
    private static final MostCode MC_FWK066 = new MostCode("FWK066");
    private static final MostCode MC_IHME_API_GET_AULN_SESSION_ID = new MostCode("IHME-API_GET_AULN_SESSION_ID");
    private String samlToken;
    private int atknTtlMinus = 180000;

    private SecurityDTO SecurityDTO;

    private static Context getContext(HttpServletRequest request, ContextExecution contextExecution, Consommateur imWorkingForThatGuy) {
        var ctx = new Context(
                ContextHelper.getBrowser(request),
                new PerformanceDTO(LogUtils.getIdPerformance(request)),
                new SecurityDTO(),
                imWorkingForThatGuy.getId(),
                imWorkingForThatGuy.getVersion(),
                contextExecution
        );
        return ctx;
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public SecurityDTO extractSecurityFromRequest(final HttpServletRequest request) throws TechnicalException, UnauthorizedException {

        // Récupération du bean à partir de la request
        var securityDTO = (SecurityDTO) request.getAttribute(ISecurity.SECURITY_DTO_ATTRIBUTE_NAME);
        if (securityDTO != null) {
            return securityDTO;
        }

        // attention, ne pas essayer d'appeler HELPER.getSecurity() à la place
        // de new SecurityDTO()
        // pour obtenir une instance de SecurityDTO, car ça va boucler !!
        final var contextExecution = ContextHelper.getContextExecution(request);
        final var imWorkingForThatGuy = ContextHelper.getEmetteur(request);

        Context ctx = getContext(request, contextExecution, imWorkingForThatGuy);

        samlToken = getSamlToken(request);

        securityDTO = this.buildSecurity(samlToken, ctx);

        // mise à jour du contexte
        ctx = new Context(
                ContextHelper.getBrowser(request),
                new PerformanceDTO(LogUtils.getIdPerformance(request)),
                securityDTO,
                imWorkingForThatGuy.getId(),
                imWorkingForThatGuy.getVersion(),
                contextExecution
        );

        // Lecture cookie de session AULN_SESSION_ID
        final var aulnCookieValue = RequestUtils.getCookie(AULN_SESSION_ID, request);
        LOGGER.debug(MC_IHME_API_GET_AULN_SESSION_ID, "Lecture du cookie AULN_SESSION_ID: " + LogUtils.obfuscateUUIDString(aulnCookieValue), ctx);
        if (securityDTO != null) {
            securityDTO.setAulnSessionId(aulnCookieValue);
        }

        request.setAttribute(ISecurity.SECURITY_DTO_ATTRIBUTE_NAME, securityDTO);

        return securityDTO;
    }

    /**
     * Retourne l'objet sécurité contenant le User et d'autres informations<br>
     * <p>
     * Vérifie la signature et la date d'expiration du jeton SAML de la requête
     * <p>
     * Le User est récupéré grâce au jeton SAML contenu dans la requête.<br>
     *
     * @param samlToken, le jeton SAML
     * @param ctx        Contexte IHM
     * @return L'objet sécurité.
     */
    protected SecurityDTO buildSecurity(final String samlToken, final Context ctx) throws TechnicalException {

        if (StringUtils.isBlank(samlToken)) {
            return null;
        }

        SecurityDTO securityDTO = null;
        UserDTO user = null;

        //Initialisation de la librairie OpenSAML
        try {
            final var assertion = UserCatFactory.getSamlAssertion(samlToken);
            final var userCAT = UserCatFactory.getUser(assertion, samlToken);

            // Vérification de la signature du jeton
            this.verifySignature(assertion, ctx);

            //La signature du jeton SAML est valide, on vérifie s'il n'est pas expiré
            if (!isSAMLTokenDateValid(assertion, ctx)) {
                throw new TechnicalException(ctx, "FWK058");
            }

            //Création du UserDTO depuis le jeton SAML
            user = buildUserFromUserCAT(userCAT);

            // si le user du jeton SAML contient le suffixe, alors il s'agit d'un jeton anonyme et on ne valide pas le contenu du contexte d'exe
            if (!user.getId().contains(SUFFIXE_USER_ANONYME_SAML)) {
                // vérification des infos utilisateur : le contexe exe doit contenir les mêmes valeurs que le jeton SAML
                isContextExeValid(ctx, user);
            } else {
                // jeton anonyme : on vérifie si un user est présent dans le contexte d'exécution
                final var codeUser = ctx.getContextExecution().getProfile().getUser().getCode();
                if (null != codeUser && !codeUser.trim().isEmpty()) {
                    // on a un user dans le contexte d'exécution, donc c'est une perte de session
                    LOGGER.secu(MC_FWK066, "perte de session  : contexte execution valorise et jeton SAML anonyme", ctx);
                    throw new TechnicalException(ctx, "FWK066", new String[]{codeUser});
                }
            }

            //Création du SecurityDTO
            securityDTO = new SecurityDTO();
            securityDTO.setUserDTO(user);
            securityDTO.setSamlAssertion(assertion);

        } catch (TechnicalException e) {
            throw e;
        } catch (Exception e) {
            throw new TechnicalException(ctx, e, "FWK059");
        }
        this.setSecurityDTO(securityDTO);
        return securityDTO;
    }

    /**
     * E27 on met des warning et pas d'exception => retourne toujours vrai.
     * Retourne vrai si les données du contexte d'exécution sont les mêmes
     * que celles présentes dans userDTO, alimenté à partir du jeton SAML
     *
     * @param ctx  contient le contexte d'exécution
     * @param user contient les données extraites du jeton SAML
     * @return boolean
     */
    @Generated
    protected boolean isContextExeValid(final Context ctx, final UserDTO user) throws TechnicalException {

        final var ctxExe = ctx.getContextExecution();
        final var ctxUser = ctxExe.getProfile().getUser();

        if (!isContextCheckable(ctx)) {
            return true;
        }

        if (!ctxUser.getCode().trim().equalsIgnoreCase((user.getId().trim()))) {
            LOGGER.secu(MC_FWK065, new TechnicalException(ctx, "FWK065",
                    new String[]{"code du user", ctxUser.getCode(), user.getId()}).getMessageException(), ctx);
        }
        if (!ctxUser.getId().trim().equalsIgnoreCase((user.getUserID().trim()))) {
            LOGGER.secu(MC_FWK065, new TechnicalException(ctx, "FWK065",
                    new String[]{"id user", ctxUser.getId(), user.getUserID()}).getMessageException(), ctx);
        }

        if (!ctxUser.getType().trim().equals(user.getTypeActeurCASA())) {
            LOGGER.secu(MC_FWK065, new TechnicalException(ctx, "FWK065",
                    new String[]{"type du user", ctxUser.getType(), user.getProfile()}).getMessageException(), ctx);
        }

        if (!ctxUser.getFirstName().trim().equalsIgnoreCase(user.getFirstName().trim())) {
            LOGGER.secu(MC_FWK065, new TechnicalException(ctx, "FWK065",
                    new String[]{"prénom", ctxUser.getFirstName(), user.getFirstName()}).getMessageException(), ctx);
        }
        if (!ctxUser.getLastName().trim().equalsIgnoreCase((user.getLastName().trim()))) {
            LOGGER.secu(MC_FWK065, new TechnicalException(ctx, "FWK065",
                    new String[]{"nom", ctxUser.getLastName(), user.getLastName()}).getMessageException(), ctx);
        }
        if (!ctxExe.getProfile().getStructureId().equals(user.getConnectionStructureID())) {
            LOGGER.secu(MC_FWK065, new TechnicalException(ctx, "FWK065",
                    new String[]{"structureId", ctxExe.getProfile().getStructureId(), user.getConnectionStructureID()}).getMessageException(), ctx);
        }
        if (!ctxExe.getProfile().getFunctionalPost().getId().equals(user.getFunctionalPostID())) {
            LOGGER.secu(MC_FWK065, new TechnicalException(ctx, "FWK065",
                    new String[]{"poste fonctionnel", ctxExe.getProfile().getFunctionalPost().getId(), user.getFunctionalPostID()}).getMessageException(), ctx);
        }
        if (!DEFAULT_VALUE.equals(user.getBrowser()) && !ctx.getBrowser().getUserAgent().equals(user.getBrowser())) {
            LOGGER.secu(MC_FWK065, new TechnicalException(ctx, "FWK065",
                    new String[]{"navigateur", ctx.getBrowser().getUserAgent(), user.getBrowser()}).getMessageException(), ctx);
        }
        if (!DEFAULT_VALUE.equals(user.getIp()) && !ctxExe.getSystemInfo().getOperationalPost().getIp().equals(user.getIp())) {
            LOGGER.secu(MC_FWK065, new TechnicalException(ctx, "FWK065",
                    new String[]{"IP", ctxExe.getSystemInfo().getOperationalPost().getIp(), user.getIp()}).getMessageException(), ctx);
        }
        return true;
    }


    /**
     * Vérifie la signature du jeton SAML
     *
     * @param assertion l'assertion à vérifier
     * @param ctx       le contexte utilisateur
     * @throws TechnicalException si erreur de validation
     */
    @Generated
    protected void verifySignature(final Assertion assertion, final Context ctx) throws TechnicalException {

        if (!UserCatFactory.verifySignature(assertion)) {
            throw new TechnicalException(ctx, "FWK064");
        }
    }

    /**
     * Méthode interne de la sécurité applicative qui vérifie si le jeton SAML passé
     * en paramètre est expiré ou non.
     *
     * @param samlA, le jeton SAML
     * @param ctx,   le contexte de la requête
     * @return true si le jeton SAML est valide. (non expiré)
     */
    protected boolean isSAMLTokenDateValid(final Assertion samlA, final Context ctx) {

        return UserCatFactory.isSAMLTokenDateValid(samlA);
    }


    private UserDTO buildUserFromUserCAT(final IUserCAT userCat) {

        // Alimentation du User à partir des informations contenues dans le jeton SAML
        final var user = new UserDTO();
        user.setSamlToken(userCat.getSamlToken());

        user.setId(userCat.getId());
        user.setProfile(userCat.getProfile());
        user.setFirstName(userCat.getFirstName());
        user.setLastName(userCat.getLastName());
        user.setFuncScopeBOUID(userCat.getFuncScopeBOUID());
        user.setConnectionStructureID(userCat.getConnectionStructureID());
        user.setUserID(userCat.getUserID());
        user.setFunctionalPostID(userCat.getFunctionalPostID());

        user.setBrowser(userCat.getBrowser());
        if (null == user.getBrowser()) {
            user.setBrowser(DEFAULT_VALUE);
        }

        user.setIp(userCat.getIp());
        if (null == user.getIp()) {
            user.setIp(DEFAULT_VALUE);
        }

        user.getResources().addAll(userCat.getResources());

        return user;
    }

    /**
     * Indique si le contexte est effectivement à vérifier contre le jeton SAML
     * On checke les données ajoutées dans le contexte suite à l'ident/authent
     * càd les données qui caractérisent un contexte exe d'un utilisateur authentifié
     * On ne checke pas les données qui sont dans le contexte anonyme
     *
     * @param ctx
     * @return vraie dès qu'une donnée checkable est renseignée
     */
    protected boolean isContextCheckable(final Context ctx) {

        final var ctxExe = ctx.getContextExecution();
        final var ctxUser = ctxExe.getProfile().getUser();

        String toCheck = ctxExe.getSystemInfo().getOperationalPost().getId() +
                ctxExe.getSystemInfo().getEds().getId() +
                //on ne checke pas @ip car toujours présent
                //on ne checke pas le hostname car toujours present

                ctxExe.getProfile().getFunctionalPost().getId() +
                ctxExe.getProfile().getFunctionalPost().getFunctionId() + //pas ds le jeton
                ctxExe.getProfile().getFunctionalPost().getEdsId() + //pas dans le jeton

                ctxUser.getCode() +
                ctxUser.getId() +
                ctxUser.getType() +
                ctxUser.getFirstName() +
                ctxUser.getLastName() +

                //on ne  checke par le structure id du profile car toujours présent, même dans contexte anonyme
                ctxExe.getProfile().getCamEntity() + //pas dans le jeton
                ctxExe.getProfile().getInversedCAMEntity(); //pas dans le jeton

        return (!toCheck.trim().isEmpty());
    }

    protected String getSamlToken(final HttpServletRequest request) throws UnauthorizedException {
        final String samlToken = request.getHeader(ISecurity.SAML_HEADER_NAME);
        if (samlToken == null) {
            LOGGER.error("Le jeton saml est null", null);

            throw new UnauthorizedException(HttpServletResponse.SC_UNAUTHORIZED,
                    HttpStatus.UNAUTHORIZED.getReasonPhrase(), LocalDateTime.now());
        }
        return samlToken;
    }

    @Generated
    public int getAtknTtlMinus() {
        return atknTtlMinus;
    }

    public void setAtknTtlMinus(int atknTtlMinus) {
        this.atknTtlMinus = atknTtlMinus;
    }

    @Generated
    public String getSamlToken() {
        return samlToken;
    }

    @Generated
    public void setSamlToken(String samlToken) {
        this.samlToken = samlToken;
    }

    @Generated
    public fr.ca.cat.ihm.security.dto.SecurityDTO getSecurityDTO() {
        return SecurityDTO;
    }

    public void setSecurityDTO(fr.ca.cat.ihm.security.dto.SecurityDTO securityDTO) {
        SecurityDTO = securityDTO;
    }
}
