package fr.ca.cat.ihm.security.tools;

import fr.ca.cat.ihm.utils.Generated;

/**
 * Classe de constantes utilisées dans les echanges Soap avec le DataPower. Ces
 * constantes sont enrichies et utilisées par la brique Sécurité.
 *
 * @see fr.ca.cat.ihm.security.ISecurity
 */
@Generated
public final class SecuritySoapConstants {

    /**
     * Nom du header SOAP : HeaderApplicationContext
     */
    public static final String HEADER_TECH = "HeaderTech";

    /** Les constantes pour le header SOAP HeaderTech, transmis lors d'un appel à un service SOA */
    /**
     * Caractéristiques de HeaderApplicationContext
     */
    public static final String PREFIX_HEADER_TECH = "ca-tech";
    public static final String NAMESPACE_HEADER_TECH = "http://fr.ca.ca-technologies/soapheader";
    /**
     * Numéro de la version
     */
    public static final String NUM_VERSION = "numeroVersion";
    public static final String DATA_CONTEXT = "DataContext";
    /**
     * Identifiant du consommateur.
     */
    public static final String ID_CONSOMMATEUR = "idConsommateur";
    /**
     * "ID" de l'user.
     */
    public static final String SUBJECT = "subject";
    /**
     * Nom de l'emetteur.
     */
    public static final String CONSUMER = "Consumer";
    /**
     * Version de l'"emetteur".
     */
    public static final String CONSUMER_VERSION = "versionEmetteur";
    /**
     * Type de l'"emetteur".
     */
    public static final String TYPE_EMETTEUR = "typeEmetteur";
    /**
     * Caisse Regionale.
     */
    public static final String CAISSE_REGIONALE = "caisseRegionale";
    public static final String CR_ID = "idCR";
    /**
     * Identifant de la machine.
     */
    public static final String ID_MACHINE = "idMachine";
    /**
     * IP du client.
     */
    public static final String IP_CLIENT = "IPClient";
    /**
     * Type de poste client.
     */
    public static final String TYPE_TERMINAL = "typeTerminal";
    /**
     * Media.
     */
    public static final String MEDIA = "media";
    /**
     * Broswer.
     */
    public static final String NAVIGATEUR = "navigateur";
    /**
     * Poste fonctionnel de l'utilisateur
     */
    public static final String POSTE_FONCTIONNEL = "IDPOFO";
    /**
     * Poste opérationnel de l'utilisateur
     */
    public static final String POSTE_OPERATIONNEL = "IDPTVE";
    /**
     * Elément de structure de connexion de l'utilisateur
     */
    public static final String ELT_STRUCTURE_CONNEXION = "IDELSTCO";
    /**
     * Nom du header SOAP : HeaderApplicationContext
     */
    public static final String HEADER_APPLI_CONTEXT = "HeaderApplicationContext";


/** Les constantes pour le header SOAP HeaderApplicationContext, transmis lors d'un appel à un service SOA */
    /**
     * Caractéristiques de HeaderApplicationContext
     */
    public static final String PREFIX_HEADER_APPLI_CONTEXT = "caapplicationcontext";
    public static final String NAMESPACE_HEADER_APPLI_CONTEXT = "http://fr.ca.application.context/soapheader";
    /**
     * Version du header
     */
    public static final String VERSION = "version";
    /**
     * Identifiant du poste opérationnel
     */
    public static final String OPERATIONAL_POST = "operationalPostID";
    /**
     * Identifiant de l'élément de structure de connexion
     */
    public static final String CONNECTION_EDS = "connectionEDSID";
    /**
     * Identifiant du poste fonctionnel de l'élément de structure
     */
    public static final String FUNCTIONAL_POST_EDS = "functionalPostEDSID";
    /**
     * Identifiant du canal de connexion (en français ?)
     */
    public static final String CHANNEL = "canalID";
    /**
     * Identifiant du canal de distribution (en français ?)
     */
    public static final String DISTRIB_CHANNEL = "distribCanalID";
    /**
     * Identifiant de la session du portail (en français ?)
     */
    public static final String SESSION_PORTAL = "idSessionPortail";
    /**
     * Identifiant de corrélation
     */
    public static final String ID_CORRELATION = "idCorrelation";
    /**
     * Type de l'utilisateur au sens CASA
     */
    public static final String USER_TYPE_CASA = "userTypeCASA";
    /**
     * Réseau bancaire
     */
    public static final String BANK_NETWORK = "bankNetwork";
    /**
     * En cas de pile d'appels d'UA, on veut l'UA tout bas de la pile.
     */
    public static final String ID_CONSOMMATEUR_ORIGINE = "idConsommateurOrigine";
    /**
     * En cas de pile d'appels d'UA, on veut l'UA tout bas de la pile.
     */
    public static final String VERSION_CONSOMMATEUR_ORIGINE = "versionConsommateurOrigine";


    private SecuritySoapConstants() {
    }

}
