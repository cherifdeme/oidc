package fr.ca.cat.ihm.spring;

import fr.ca.cat.cache.proxy.CacheBeanNameAutoProxyCreator;
import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.redis.RedisCacheService;
import fr.ca.cat.ihm.resilience.CircuitBreakerSupervision;
import fr.ca.cat.ihm.security.ISecurity;
import fr.ca.cat.ihm.security.impl.MockFileSecurityImpl;
import fr.ca.cat.ihm.security.impl.SecurityFullRedis;
import fr.ca.cat.ihm.security.impl.SecurityImpl;
import fr.ca.cat.ihm.url.IUrlService;
import fr.ca.cat.ihm.url.PropertiesUrlServiceImpl;
import fr.ca.cat.ihm.utils.Generated;
import fr.ca.cat.ihm.web.client.RsConf;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.Primary;
import org.springframework.context.support.ResourceBundleMessageSource;

import java.util.HashMap;
import java.util.Objects;

@Configuration
@EnableAspectJAutoProxy
@Generated
public class BeanConfiguration {
    @Value("${socle.beans.auc9.api2m.authorization:Ciphered{4df0ce0384f60c4b0adae6d6698e58da8cb942c372bbae14d07c7655aea89970402ca50ea7849cef95679013d66f76940843feee8a6a8d488753d2fa24827ea28f1f853e75a85335f03f8572578d44929378632e15185cd25678a07afa1a6b1396e37eae3277516d9394896bdb5cfcf19b5e1b8d2851531a2b7089e780f0f7e2e12ac07ae694f1e880b1b647edc87d657b6f}}")
    private String authorization;
    @Value("${socle.beans.auc9.url:https://dev1-private.api.credit-agricole.fr/authentification_collaborateur/v2}")
    private String auc9url;
    @Value("${socle.api.timeout:47000}")
    private String timeout;
    @Value("${socle.api.atknTtlMinus:300000}")
    private String atknTtlMinus;
    @Value("${socle.beans.redis.cluster:true}")
    private String redisCluster;
    @Value("${socle.beans.redis.hostsName:10.77.187.60}")
    private String hostsname;
    @Value("${socle.beans.redis.ports:7001,7002,7003,7004,7005,7006}")
    private String port;
    @Value("${socle.resilience.monitoring.period:40}")
    private Long period;
    @Value("${socle.logicalhost.properties:socle.logicalhost.properties}")
    private String logicalHost;
    @Value("${socle.beans.security.impl:SecurityFullRedis}")
    private String securityImp;
    @Value("${socle.beans.redis.poolMax:8}")
    private String poolMaxTotal;
    @Value("${socle.beans.redis.poolMaxIdle:8}")
    private String poolMaxIdle;
    @Value("${socle.beans.redis.poolMinIdle:0}")
    private String poolMinIdle;
    @Value("${socle.beans.redis.maxWaitInSeconds:30}")
    private String maxWaitInSeconds;

    @Bean("bundleBean")
    public ResourceBundleMessageSource messageSource() {
        ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
        String[] baseNames = new String[]{"bundle/defaultmessagevalidation", "bundle/fwkmessage"};
        messageSource.setBasenames(baseNames);
        messageSource.setDefaultEncoding("UTF-8");
        return messageSource;
    }

    @Bean
    @Qualifier("authentificationCollaborateurV2")
    public RsConf getConf() {
        RsConf conf = new RsConf();
        conf.setAuthorization(authorization);
        conf.setUrl(auc9url);
        return conf;
    }

    @Bean
    @Autowired
    public ISecurity security(RedisCacheService redisCacheService) {
        final int atknTtlMinus1 = Integer.parseInt(atknTtlMinus);
        switch (Objects.requireNonNull(securityImp)) {
            case "SecurityFullRedis" -> {
                final SecurityFullRedis securityFullRedis = new SecurityFullRedis(redisCacheService);
                securityFullRedis.setAtknTtlMinus(atknTtlMinus1);
                return securityFullRedis;
            }
            case "SecurityImpl" -> {
                final SecurityImpl security = new SecurityImpl();
                security.setAtknTtlMinus(atknTtlMinus1);
                return security;
            }
            case "MockFileSecurityImpl" -> {
                final MockFileSecurityImpl mockFileSecurity = new MockFileSecurityImpl();
                mockFileSecurity.setAtknTtlMinus(atknTtlMinus1);
                return mockFileSecurity;
            }
            default ->
                    throw new RuntimeException("classe d'implementation de securité inexistante, verifier la classe de configuration des beans");
        }
    }

    @Bean
    @Primary
    public RsConf authentificationCollaborateurV2() {
        RsConf rsConf = new RsConf();
        rsConf.setAuthorization(authorization);
        rsConf.setUrl(auc9url);
        return rsConf;
    }

    @Bean
    public RedisCacheService redisCacheService() {
        return new RedisCacheService(Boolean.parseBoolean(redisCluster), hostsname, port, Integer.parseInt(poolMaxTotal),
                Integer.parseInt(poolMaxIdle), Integer.parseInt(poolMinIdle), Integer.parseInt(maxWaitInSeconds));
    }

    @Bean("LogicalHost")
    public IUrlService getLogicalHost() throws TechnicalException {
        return new PropertiesUrlServiceImpl(logicalHost);
    }

    @Bean
    public CacheBeanNameAutoProxyCreator cacheAdvisor() {
        final CacheBeanNameAutoProxyCreator cacheBeanNameAutoProxyCreator = new CacheBeanNameAutoProxyCreator();
        cacheBeanNameAutoProxyCreator.setCachedBeans(new HashMap<>());
        return cacheBeanNameAutoProxyCreator;
    }

    @Bean
    public CircuitBreakerSupervision circuitbreakersupervision() {
        CircuitBreakerSupervision circuitbreakersupervision = new CircuitBreakerSupervision();
        circuitbreakersupervision.setPeriod(period);
        return circuitbreakersupervision;
    }
}
