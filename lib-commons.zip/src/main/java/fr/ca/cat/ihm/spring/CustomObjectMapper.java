package fr.ca.cat.ihm.spring;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.databind.util.ISO8601DateFormat;
import fr.ca.cat.ihm.utils.Generated;

@Generated
public class CustomObjectMapper extends ObjectMapper {

    private static final long serialVersionUID = 2853693512906718618L;

    public CustomObjectMapper() {
        configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);
        setDateFormat(new ISO8601DateFormat());
    }
}
