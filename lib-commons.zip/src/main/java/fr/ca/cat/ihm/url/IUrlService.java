package fr.ca.cat.ihm.url;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.exception.TechnicalException;

/**
 * Ce service nous permet de récupérer une URL à partir d'un hote logique donné, du type d'utilisateur et d'une zone
 *
 * @author ETP2473
 */
public sealed interface IUrlService permits PropertiesUrlServiceImpl {

    /**
     * méthode permettant de calculer une URL à partir d'un hote logique donné, du type d'utilisateur et d'une zone
     *
     * @param hoteLogique l'hôte logique
     * @param ctx         le contexte utilisateur
     * @param zone        la zone
     * @return l'URL correspondant à l'hote logique donné, du type d'utilisateur et d'une zone
     * @throws TechnicalException si erreur technique (hote logique non trouvé, impossibilité de calculer l'URL)
     */
    String getURL4LogicalHost(String hoteLogique, Context ctx, ZoneEnum zone) throws TechnicalException;

    /**
     * Restitue le premier LogicalHost trouvé dans la matrice qui matche avec le domaine fourni
     *
     * @param domain
     * @param ctx
     * @return null ou un logicalHost
     */
    String findLogicalHost(String domain, Context ctx);


    /**
     * L'énuméré correspondant à la liste des zones possibles
     * - END_USER
     * - BACK_END
     * - FRONT_END
     *
     * @author ETP2473
     */
    enum ZoneEnum {END_USER, BACK_END, FRONT_END}
}
