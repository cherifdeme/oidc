package fr.ca.cat.ihm.url;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.exception.TechnicalException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.Properties;

/**
 * Implémentation par défaut de l'interface IUrlService
 *
 * @author ETP2473
 */
public non-sealed class PropertiesUrlServiceImpl implements IUrlService {

    public static final String FWK051 = "FWK051";
    public static final String FWK052 = "FWK052";
    /**
     * Le séparateur ; utilisé dans le fichier properties
     */
    protected static final String SEPARATEUR = ";";
    private static final String FWK050 = "FWK050";
    /**
     * Représente le fichier properties chargé
     */
    protected Properties prop;

    /**
     * Constructeur
     *
     * @param fileNameProperty le nom du fichier properties à charger
     * @throws TechnicalException
     */
    public PropertiesUrlServiceImpl(final String fileNameProperty) throws TechnicalException {
        try {
            this.prop = new Properties();
            this.prop.load(Thread.currentThread().getContextClassLoader().getResourceAsStream(fileNameProperty));
        } catch (NullPointerException | IOException e) {
            throw new TechnicalException(null, e, FWK052);
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getURL4LogicalHost(final String hoteLogique, final Context ctx, final ZoneEnum zone)
            throws TechnicalException {
        if (hoteLogique == null) {
            throw new TechnicalException(ctx, FWK051, new String[]{"hoteLogique"});
        }
        if (ctx == null) {
            throw new TechnicalException(null, FWK051, new String[]{"ctx"});
        }
        if (zone == null) {
            throw new TechnicalException(ctx, FWK051, new String[]{"zone"});
        }

        return getUrlByZone(getProperty(hoteLogique, ctx), zone);
    }

    /**
     * Retourne l'url en fonction de la zone
     *
     * @param property la propriété
     * @param zone     la zone
     * @return l'url correspondante
     * @throws TechnicalException si erreur technique (fichier "mal formatté")
     */
    protected String getUrlByZone(final String property, final ZoneEnum zone) throws TechnicalException {
        String url = "";
        final String[] propByZone = property.split(SEPARATEUR);
        // On vérifie que le fichier est correctement formaté
        // (on a à minima 4 données par ligne séparées par des ;)
        if (propByZone.length < 4) {
            Context ctx = null;
            throw new TechnicalException(ctx, FWK051, new String[]{"Mauvais formatage : " + property});
        }
        switch (zone) {
            case END_USER:
                url = propByZone[1];
                break;
            case FRONT_END:
                url = propByZone[2];
                break;
            case BACK_END:
                url = propByZone[3];
                break;
            default:
                break;
        }
        return url;
    }

    /**
     * Retourne une collection de recherche dans la matrice d'hôte logique
     * données triée de la plus restrictive à la moins restrictive
     *
     * @param cleFonctionnelle la clé fonctionnelle
     * @param ctx              le contexte utilisateur
     * @return la collection de recherche dans la matrice d'hôte logique
     */
    protected Collection<String> getClesDeRecherche(final String cleFonctionnelle, final Context ctx) {

        final Collection<String> clesDeRechercheList = new ArrayList<>();

        if (null == cleFonctionnelle || cleFonctionnelle.isEmpty()) {
            return clesDeRechercheList;
        }

        final String usage = ctx.getContextExecution().getSessionMode().getUsage();
        final String cr = ctx.getContextExecution().getProfile().getStructureId();
        final String eds = ctx.getContextExecution().getSystemInfo().getEds().getId();

        // avec cr
        if ((cr != null)) {

            if (eds != null) {
                clesDeRechercheList.add(new StringBuilder(cleFonctionnelle).append(SEPARATEUR).append(usage)
                        .append(SEPARATEUR).append(cr).append(SEPARATEUR).append(eds).append(SEPARATEUR).toString());
            }

            clesDeRechercheList.add(new StringBuilder(cleFonctionnelle).append(SEPARATEUR).append(usage)
                    .append(SEPARATEUR).append(cr).append(SEPARATEUR).append(SEPARATEUR).toString());
        }

        // avec usage
        clesDeRechercheList.add(new StringBuilder(cleFonctionnelle).append(SEPARATEUR).append(usage).append(SEPARATEUR)
                .append(SEPARATEUR).append(SEPARATEUR).toString());
        // hoteLogique nu
        clesDeRechercheList.add(new StringBuilder(cleFonctionnelle).append(SEPARATEUR).append(SEPARATEUR)
                .append(SEPARATEUR).append(SEPARATEUR).toString());

        return clesDeRechercheList;

    }

    /**
     * Retourne la valeur trouvée dans la map passée en paramètre correspondant
     * à la clé fonctionnelle
     *
     * @param cleFonctionnelle la clé fonctionnelle
     * @param referentiel      le référentiel
     * @param ctx              le contexte utilisateur
     * @return la valeur trouvée dans la map passée en paramètre correspondant à
     * la clé fonctionnelle
     */
    protected Object getValue(final String cleFonctionnelle, final Map<Object, Object> referentiel, final Context ctx) {
        final Collection<String> clesDeRechercheList = this.getClesDeRecherche(cleFonctionnelle, ctx);
        for (String sCle : clesDeRechercheList) {
            if (referentiel.containsKey(sCle)) {
                return referentiel.get(sCle);
            }
        }
        return null;
    }

    /**
     * Retourne la valeur de la propriété correspondant à l'hôte logique et à
     * l'utilisateur
     *
     * @param hoteLogique l'hôte logique
     * @param ctx         le contexte
     * @return la valeur de la propriété correspondant à l'hôte logique et à
     * l'utilisateur
     * @throws TechnicalException si erreur technique
     */
    private String getProperty(final String hoteLogique, final Context ctx) throws TechnicalException {
        final String resu = (String) getValue(hoteLogique, prop, ctx);
        if (resu == null) {
            throw new TechnicalException(ctx, FWK050, new String[]{hoteLogique});
        }
        return resu;
    }

    /**
     * Restitue le premier LogicalHost trouvé dans la matrice qui matche avec le
     * domain fourni
     *
     * @param domain
     * @return null ou un logicalHost
     */
    public String findLogicalHost(final String domain, final Context ctx) {
        for (Map.Entry<Object, Object> oEntry : prop.entrySet()) {
            final String sValue = oEntry.getValue().toString();
            if (sValue.contains(domain)) {
                return oEntry.getKey().toString().split(SEPARATEUR)[0];
            }
        }
        return null;
    }

    public Properties getMapHoteLogique() {
        return this.prop;
    }
}
