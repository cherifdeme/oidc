package fr.ca.cat.ihm.url.utils;

import fr.ca.cat.ihm.url.IUrlService;
import fr.ca.cat.ihm.utils.Generated;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

/**
 * Point d'entree pour l'acces à l'ensemble de la configuration relative aux URLs
 * Permet l'accès à la classe IUrlService qui expose la méthode getURL4LogicalHost
 *
 * @author ETP2473
 */
@Generated
@Component
public final class UrlServiceFactory {
    private IUrlService urlService;

    @Autowired
    public UrlServiceFactory(@Qualifier("LogicalHost") final IUrlService urlService) {
        this.urlService = urlService;
    }

    /**
     * Récupère l'instance du service de gestion des URL
     *
     * @return l'instance du service de gestion des URL
     */
    public final IUrlService getUrlService() {
        return urlService;
    }
}

