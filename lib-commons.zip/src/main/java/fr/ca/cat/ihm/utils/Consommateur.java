package fr.ca.cat.ihm.utils;

import java.util.ResourceBundle;

public class Consommateur {
    public static final Consommateur UNKNOWN = new Consommateur("unknown", new Version("0.0"));
    public static final Consommateur IHME = new Consommateur("IHME", new Version(ResourceBundle.getBundle("fwk_java_version").getString("fwkJava.version")));
    private final String id;
    private final Version version;

    public Consommateur(final String sId, final Version release) {
        super();
        this.id = sId;
        this.version = release;
    }

    public String getId() {
        return id;
    }

    public Version getVersion() {
        return version;
    }
}
