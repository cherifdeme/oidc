package fr.ca.cat.ihm.utils;

import fr.ca.cat.most.util.log.MostCode;

@Generated
public class Constants {
    // Redis Cache
    public static final String REFRESH_TOKEN_CACHE = "REFRESH_TOKEN_CACHE";
    public static final String TOKEN_CACHE = "TOKEN_CACHE";
    public static final String REFRESH_TOKEN = "refresh_token";
    public static final String API2M_SESSION_PREFIX = "api2m:session";
    public static final String API2M_REFRESH_PREFIX = "api2m:refresh";
    public static final String AULN_SAML_PREFIX = "auln:saml";
    public static final String FWK533 = "FWK533";
    public static final String URI_TOKEN = "/token";
    public static final String HDR_CORRELATION_ID = "correlationid";
    public static final String HDR_AUTHORIZATION = "Authorization";
    public static final String TEX_FWK630 = "FWK630";
    public static final String TEX_FWK632 = "FWK632";
    public static final String TEX_FWK633 = "FWK633";
    public static final String SCOPE_VALUE = "openid functional_posts";
    public static final String GRANT_TYPE = "grant_type";
    public static final String AUTHENTICATION_LEVEL = "authentication_level";
    public static final String SCOPE = "scope";
    public static final MostCode MC_IHME_API_AUC9_GRANT_TYPE = new MostCode("IHME-API_AUC9_GRANT_TYPE");
    public static final MostCode MC_IHME_API_AUC9_SCOPE = new MostCode("IHME-API_AUC9_SCOPE");
    public static final MostCode MC_IHME_API_AUC9_REFRESH_TOKEN = new MostCode("IHME-API_AUC9_REFRESH_TOKEN");
    public static final MostCode MC_IHME_API_AUC9_KO = new MostCode("IHME-API_AUC9_KO");
    public static final MostCode MC_IHME_API_AUC9_KO_4XX = new MostCode("IHME-API_AUC9_KO_4XX");
    public static final MostCode MC_IHME_API_CIPHERED_KO = new MostCode("IHME-API_CIPEHERED_KO");
    public static final String APPLICATION_X_WWW_FORM_URLENCODED = "application/x-www-form-urlencoded";
    public static String CACHE_TOKEN_NULL = "Erreur récupération cache TOKEN";
    public static String CACHE_REFRESH_TOKEN_NULL = "Erreur récupération cache REFRESH TOKEN";
}
