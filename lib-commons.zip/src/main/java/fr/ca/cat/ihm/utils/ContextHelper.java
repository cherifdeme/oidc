package fr.ca.cat.ihm.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.ca.cat.ihm.controller.bean.Browser;
import fr.ca.cat.ihm.controller.bean.ContextApp;
import fr.ca.cat.ihm.controller.bean.ContextExecution;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.LogUtils;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.logger.TypeLogger;
import fr.ca.cat.most.util.log.MostCode;
import jakarta.servlet.http.HttpServletRequest;
import org.apache.commons.lang3.StringUtils;

import java.util.Locale;

/**
 * Classe utilitaire de construction de Contexte technique pour les logs.
 */
public final class ContextHelper {

    /**
     * Constante utilisé pour stocker/transporter le "contexte Applicatif"
     *
     * @see ContextApp
     */
    public static final String CONTEXT_APP = "contextApp";

    /**
     * Nom du header dans le quel est transmis le contexte d'exécution au format JSON
     */
    public static final String CONTEXT_EXECUTION_HEADER_NAME = "contextExecution";

    /**
     * Nom de l'attribut utilisé dans la requête pour l'objet contextExecution
     */
    public static final String CONTEXT_EXECUTION_REQUEST_ATTRIBUTE = "contextExecutionDTO";

    /**
     * Version du contexte d'exécution transmis
     */
    public static final String VERSION_CONTEXT_EXE = "1.0";

    /**
     * Valeur par défaut des données du contexte d'exécution
     * (valeur par défaut de tous les attributs de type String).
     */
    public static final String DEFAULT_VALUE = "";
    /**
     * CAT Logger (l'objet Context n'est pas dispo ici car en cours de construction)
     */
    public static final Logger LOG = LogFactory.getLog(ContextHelper.class, TypeLogger.LOGGER_SOCLE);
    public static final MostCode MC_IHME_HEADER_CTX_EXE = new MostCode("IHME_HEADER_CTX_EXE");
    private static final String EMETTEUR = "IHME.Emetteur";

    /**
     * Constructeur privé car classe utilitaire
     */
    private ContextHelper() {
        super();
    }

    /**
     * Récupération du contexte d'exécution passé au format JSON stringifié dans le paramètre "contextExecution"
     * Positionne le contexte d'exécution dans le MDC du logger.
     *
     * @param request la requête http
     * @return le contexte d'exécution du portail.
     * ATTENTION ne pas positionner de prise de perf par annotation sur cette méthode (sinon ça boucle)
     */
    @Generated
    public static ContextExecution getContextExecution(final HttpServletRequest request) {
        // Début de la mesure du temps d'exécution

        // Récupération du bean à partir de la request
        var ctxExe = (ContextExecution) request.getAttribute(CONTEXT_EXECUTION_REQUEST_ATTRIBUTE);
        if (ctxExe == null) {
            // récupération du contexte d'exécution transmis par le PUCC
            try {
                final var header = request.getHeader(CONTEXT_EXECUTION_HEADER_NAME);
                if (!StringUtils.isBlank(header)) {
                    //on logue directement le contexte exe json
                    LOG.info(MC_IHME_HEADER_CTX_EXE, header, null);
                    ctxExe = new ObjectMapper().readValue(header, ContextExecution.class);
                }
            } catch (JsonProcessingException jpe) {
                LOG.warn("Erreur JSON lors la récupération du contexte d'execution", jpe, null);
            }
            if (null == ctxExe) {
                ctxExe = new ContextExecution();
            }

            // Ajout du bean à la request
            request.setAttribute(CONTEXT_EXECUTION_REQUEST_ATTRIBUTE, ctxExe);
            LogUtils.setContext(ctxExe);
        }
        return ctxExe;
    }

    /**
     * retourne Le browser utilisé
     *
     * @param request request
     * @return Le browser utilisé.
     */
    private static String getUserAgent(final HttpServletRequest request) {
        return request.getHeader("User-Agent");
    }

    /**
     * Renvoi l'objet Browser contenant des informations sur le Browser.
     *
     * @param request request
     * @return Renvoi l'objet Browser contenant des informations sur le Browser.
     */
    public static Browser getBrowser(final HttpServletRequest request) {
        return new Browser(getUserAgent(request), getUserLocale(request));
    }

    /**
     * La locale du browser récupere depuis la requete.
     *
     * @param request request
     * @return La locale du browser récuperer depuis la requete.
     */
    public static Locale getUserLocale(final HttpServletRequest request) {
        return request.getLocale();
    }

    /**
     * La notion de consommateur est liée au contrat de médiation SOA.
     * Ici on déduit "l'UA en cours" qui va émettre des traces
     * On le déduit à partir de l'URL : (produit|ua)/ua/version
     * Evidemment pour les composants socle c'est plus compliqué puisqu'on a pas respecté cette règle !
     *
     * @param request
     * @return
     */
    private static Consommateur guessEmetteur(final HttpServletRequest request) {

        final var uri = request.getRequestURI();

        if (uri.startsWith("/services/")) {
            return Consommateur.IHME;
        }

        int idx = uri.indexOf("/rest/");
        if (idx == -1) {
            idx = uri.indexOf("/jsp/");
        }

        if (idx == -1) {
            return Consommateur.UNKNOWN;
        }

        final var tabPath = uri.substring(1, idx).split("/");
        if (tabPath.length == 3) {
            //en 0 le le code PRODUIT (ou GRPE) si jamais il est mis en place
            //en 1 l'identifiant UA
            //en 2 la version
            return new Consommateur(tabPath[1], new Version(tabPath[2]));
        }

        if (tabPath.length >= 1) {
            return new Consommateur(tabPath[0], new Version(""));
        }

        return Consommateur.UNKNOWN;
    }

    public static Consommateur getEmetteur(final HttpServletRequest request) {

        var resu = (Consommateur) request.getAttribute(EMETTEUR);

        if (null == resu) {
            resu = guessEmetteur(request);
            request.setAttribute(EMETTEUR, resu);
        }

        return resu;
    }

    /**
     * récup et parsing du contexte d'application.
     * Après le premier parsing, on pousse l'objet en attribut de requête
     *
     * @param request
     * @return
     */
    @Generated
    public static ContextApp getContextApp(final HttpServletRequest request) {

        var ctxApp = (ContextApp) request.getAttribute(CONTEXT_APP);

        if (null == ctxApp) {
            ctxApp = getContextApp(request.getHeader(CONTEXT_APP));
            request.setAttribute(CONTEXT_APP, ctxApp);
        }
        return ctxApp;
    }


    /**
     * récup et parsing du contexte d'application.
     * Après le premier parsing, on pousse l'objet en attribut de requête
     *
     * @param json représentaiton json de l'objet
     * @return l'objet ou null
     */
    @Generated
    public static ContextApp getContextApp(final String json) {

        var ctxApp = new ContextApp();
        try {
            if (!StringUtils.isBlank(json)) {
                ctxApp = new ObjectMapper().readValue(json, ContextApp.class);
            }
        } catch (JsonProcessingException jpe) {
            LOG.warn("Erreur JSON lors la recuperation du contexte d'application", jpe, null);
        }

        //consommateur origine uniquement à fin de traçabilité.
        //on garantit son format pour ne pas péter sur les appels API.
        if (StringUtils.isBlank(ctxApp.getOrigineId())) {
            ctxApp.setOrigineId(Consommateur.UNKNOWN.getId());
        }
        if (ctxApp.getOrigineVersion() == null || ctxApp.getOrigineVersion().getCurrent().isEmpty()) {
            ctxApp.setOrigineVersion(Consommateur.UNKNOWN.getVersion());
        }

        return ctxApp;
    }
}
