package fr.ca.cat.ihm.utils;

import fr.ca.cat.correlationid.CorrelationID;
import fr.ca.cat.ihm.security.tools.SecuritySoapConstants;

/**
 * Utilitaire permettant de récupérer l'identifiant de corrélation
 *
 * @author Pascal Rivière
 */
public final class IdCorrelationUtils {

    /**
     * Constructeur
     */
    private IdCorrelationUtils() {
        super();
    }

    /**
     * Permet de récupérer l'identifiant de correlation de la requête
     *
     * @return l'identifiant de corrélation
     */
    public static String getIdCorrelation() {

        // Récupération de la requête
        final var request = RequestUtils.getRequest();

        // Données à extraire de la requête
        String idCorrelation = null;

        if (request != null) {
            idCorrelation = request.getHeader(SecuritySoapConstants.ID_CORRELATION);
        }

        // Pas d'identifiant de corrélation trouvé : on en génère un !
        if (idCorrelation == null) {
            idCorrelation = CorrelationID.generateCorrelationID("00000"); // CR par défaut 00000
        }
        return idCorrelation;
    }
}
