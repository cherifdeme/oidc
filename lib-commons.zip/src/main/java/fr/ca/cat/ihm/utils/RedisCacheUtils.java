package fr.ca.cat.ihm.utils;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.crypto.CryptoSHA256;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.logger.TypeLogger;
import fr.ca.cat.most.util.log.MostCode;

import java.security.NoSuchAlgorithmException;

public class RedisCacheUtils {
    private static final MostCode MC_IHME_API_GET_REDIS_KEY = new MostCode("IHME-API_GET_REDIS_KEY");

    private static final Logger LOGGER = LogFactory.getLog(RedisCacheUtils.class, TypeLogger.LOGGER_SOCLE);

    /**
     * constitution d'une clé de cache REDIS pour chercher le JETON d'API de l'UA.
     *
     * @param prefix
     * @param context
     * @return
     */
    public static String getRedisKey(final String prefix, final Context context) {
        String hashKey;
        try {
            hashKey = CryptoSHA256.cryptoHash(context.getSecurityDTO().getAulnSessionId());
            final var redisKey = String.format("%s:%s:%s", prefix, hashKey, context.getUaId());
            LOGGER.debug(MC_IHME_API_GET_REDIS_KEY, "Recuperation cle redis: " + redisKey.replaceAll("^.{40}", "XXXX"), context);
            return redisKey;
        } catch (NoSuchAlgorithmException e) {
            LOGGER.warn("Erreur lors de la recuperation du token", context);
            return context.getContextExecution().getSessionMode().getIdSessionPortail();
        }
    }
}
