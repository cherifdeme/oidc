package fr.ca.cat.ihm.utils;

import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/**
 * Permet de récupérer la requête courrante
 *
 * @author Pascal Rivière
 */
@Generated
public final class RequestUtils {

    public static final String COOKIE_VPUC_K8S = "VPUC_K8S";
    public static final String HEADER_VPUC_K8S = "VPUCK8S";
    public static final String AULN_SESSION_ID = "AULN_SESSION_ID";
    public static final String LOGIN = "LOGIN";


    /**
     * Constructeur
     */
    private RequestUtils() {
        super();
    }

    /**
     * Retourne la requête courante et null si elle n'a pas été trouvée
     *
     * @return La requête courante
     */
    public static HttpServletRequest getRequest() {
        try {
            final var t = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
            return t.getRequest();
        } catch (Exception e) {
            return null;
        }
    }


    public static String getCookie(String name) {

        final var request = getRequest();
        if (null != request) {
            return getCookie(name, request);
        }

        return "";
    }

    public static String getCookie(String name, HttpServletRequest request) {

        String res = "";
        if (null != request.getCookies()) {
            for (var james : request.getCookies()) {
                if (name.equals(james.getName())) {
                    res = james.getValue();
                }
            }
        }
        return res;
    }
}
