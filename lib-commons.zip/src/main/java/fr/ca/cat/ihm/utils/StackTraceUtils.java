package fr.ca.cat.ihm.utils;


/**
 * Renvoie la pile complète d'une exception
 *
 * @author ETP2473
 */
public final class StackTraceUtils {

    /**
     * Constructeur privé car classe utilitaire
     * cela permet de masquer le constructeur par défaut
     */
    private StackTraceUtils() {
        super();
    }

    /**
     * Renvoie la pile d'erreur sous forme de string
     *
     * @param exception l'exception que l'on souhaite afficher
     * @return la pile d'erreur sous forme de string
     */
    public static String getStackTrace(final Exception exception) {
        if ((exception == null) || (exception.getStackTrace() == null)) {
            return null;
        }
        final var tabST = exception.getStackTrace();
        final var stacktrace = new StringBuilder();
        for (StackTraceElement st : tabST) {
            stacktrace.append(st.toString());
        }
        return stacktrace.toString();
    }
}
