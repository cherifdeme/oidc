package fr.ca.cat.ihm.utils;

/**
 * Classe modèle pour les n° de version des applications. Permet de gérer des n°
 * de version au format X.Y.Z, et d'effectuer des comparaisons dessus.
 *
 * @author E902425
 */
@Generated
public class Version implements Comparable<Version> {
    /**
     * Chaine de caractères contenant le n° de version
     **/
    private final String current;

    /**
     * tableau de décomposition de la chaine en tokens numériques pour les
     * comparaisons
     **/
    private final String[] tokens;

    /**
     * Constructeur de la classe Version
     *
     * @param current version
     */
    public Version(final String current) {
        this.current = current;
        this.tokens = current.split("\\.");
    }

    /**
     * Compare cette version par rapport à une autre.
     *
     * @param other Version à comparer
     * @return -1 si la version à comparer est inférieure, 0 si identique et 1
     * sisupérieure.
     **/
    @Override
    public int compareTo(final Version other) {
        int i = 0;
        int compare = 0;
        while (i < tokens.length && i < other.tokens.length && 0 == compare) {
            compare = tokens[i].compareTo(other.tokens[i]);
            i++;
        }
        if (0 != compare) {
            if (tokens.length < other.tokens.length) {
                compare = 1;
            } else if (tokens.length > other.tokens.length) {
                compare = -1;
            }
        }
        return compare;
    }

    /**
     * @return current version
     */
    public String getCurrent() {
        return current;
    }
}
