package fr.ca.cat.ihm.utils.zos;

import com.google.gson.Gson;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.utils.zos.dto.Data;
import fr.ca.cat.ihm.utils.zos.dto.Zos;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
@PropertySource("classpath*:zos.properties")
public class ZosConnectUtils {
    private static final Logger LOGGER = LogFactory.getLog();
    @Value("#{systemProperties[adabo] ?: null}")
    private String property;

    @Value("#{{${zos.map:}}}")
    private Map<String, ?> zosMap;

    private static Map<String, Zos> result = new HashMap<>();

    @PostConstruct
    public void afterInit() {
        if (property != null && zosMap != null) {
            final var gson = new Gson();
            final var gsonString = gson.toJson(this.zosMap.get(this.property));
            final Data model = gson.fromJson(gsonString, Data.class);
            result.putAll(model.getMapping());
        }
    }

    public Zos getCodeCaisse(final String codeCaisse) {
        final Zos zos = result.get(codeCaisse);
        if (zos == null) {
            LOGGER.warn("ZosUtils - codeCaisse inexistant", null);
        }
        return zos;
    }
}
