package fr.ca.cat.ihm.utils.zos.dto;

import fr.ca.cat.ihm.utils.Generated;

import java.util.Map;
@Generated
public final class Data {
    private String libelle;
    private Map<String, Zos> mapping;

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public Map<String, Zos> getMapping() {
        return mapping;
    }

    public void setMapping(Map<String, Zos> mapping) {
        this.mapping = mapping;
    }
}