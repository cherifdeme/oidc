package fr.ca.cat.ihm.utils.zos.dto;

import fr.ca.cat.ihm.utils.Generated;

@Generated
public final class Zos {
    private String CaisseRegionale;
    private String Domaine;

    public String getCaisseRegionale() {
        return CaisseRegionale;
    }

    public void setCaisseRegionale(String caisseRegionale) {
        CaisseRegionale = caisseRegionale;
    }

    public String getDomaine() {
        return Domaine;
    }

    public void setDomaine(String domaine) {
        Domaine = domaine;
    }
}
