package fr.ca.cat.ihm.validation;

import fr.ca.cat.ihm.utils.Generated;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Generated
@Component
public final class DynamicValidatorFactory {
    private IDynamicValidator dynamicValidator;

    /**
     * Constructeur privé pour bloquer l'instanciation
     */
    @Autowired
    public DynamicValidatorFactory(IDynamicValidator dynamicValidator) {
        this.dynamicValidator = dynamicValidator;
    }

    /**
     * Recupere l'instance de la factory permettant de
     * mettre à jour les contrôles de surfaces.
     *
     * @return IDynamicValidator
     */
    public IDynamicValidator getDynamicValidatorService() {
        return dynamicValidator;
    }
}

