package fr.ca.cat.ihm.validation;

import fr.ca.cat.ihm.controller.dto.Validator;

import java.util.List;
import java.util.Map;

/**
 * Interface définissant l'ensemble des méthodes permettant de surcharger un validateur statique
 * pour les contrôles de surface client.
 * <p>
 * Définit une méthode de mise à jour des paramètres du validateur par type de contrôle de surface.
 * <p>
 * Permet de modifier les valeurs du validateur et / ou le désactiver.
 * <p>
 * Cette action est à la charge du développeur applicatif qui doit impérativement passer par cette API
 * pour surcharger ses validateurs statiques de DTO.
 *
 * @author Guillaume Marchal.
 */
public interface IDynamicValidator {
    /**
     * Permet de surcharger un validateur statique de type Maximum. @Max
     *
     * @param property, la propriété du DTO qui possède le validateur.
     * @param args,     les arguments du validateur
     * @param isActive, True si le validateur est actif côté client. False pour le désactiver.
     */
    void updateMaxValidator(final String property, final Map<String, String> args, final boolean isActive);

    /**
     * Permet de surcharger un validateur statique de type Minimum. @Min
     *
     * @param property, la propriété du DTO qui possède le validateur.
     * @param args,     les arguments du validateur
     * @param isActive, True si le validateur est actif côté client. False pour le désactiver.
     */
    void updateMinValidator(final String property, final Map<String, String> args, final boolean isActive);

    /**
     * Permet de surcharger un validateur statique de type NotNull. @NotNull
     *
     * @param property, la propriété du DTO qui possède le validateur.
     * @param args,     les arguments du validateur
     * @param isActive, True si le validateur est actif côté client. False pour le désactiver.
     */
    void updateNotNullValidator(final String property, final Map<String, String> args, final boolean isActive);

    /**
     * Permet de surcharger un validateur statique de type Pattern. @Pattern
     *
     * @param property, la propriété du DTO qui possède le validateur.
     * @param args,     les arguments du validateur
     * @param isActive, True si le validateur est actif côté client. False pour le désactiver.
     */
    void updatePatternValidator(final String property, final Map<String, String> args, final boolean isActive);

    /**
     * Permet de récupérer la liste finale de validateur créée afin de l'affecter au DTO concerné.
     *
     * @return List<Validator>, la liste de validateurs surchargés.
     */
    List<Validator> getDynamicValidators();
}
