package fr.ca.cat.ihm.validation;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.controller.dto.DataDTO;
import fr.ca.cat.ihm.controller.dto.Validator;
import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.utils.Generated;

import java.util.List;
import java.util.Map;

/**
 * Interface de la classe Processeur d'annotation : ValidationProcessorImpl.
 * Permet d'introspecter une classe Java définie en paramètre (package +
 * className). Est utilisée pour introspecter les classes de DTO à la recherche
 * d'annotation sur les propriétés de la classe (javax.annotation)
 * <p>
 * Méthode récursive qui gère l'inclusion et l'héritage de DTO.
 * <p>
 * Renvoie une MAP contenant une collection de Validators explicitant le
 * traitement à effectué côté client.
 *
 * @author Guillaume Marchal.
 **/
@Generated
public sealed interface IValidationProcessor permits ValidationProcessorImpl {
    /**
     * Méthode récursive d'introspection qui gère l'inclusion et l'héritage de
     * DTO.
     * <p>
     * Renvoie une MAP contenant une collection de Validators explicitant le
     * traitement à effectué côté client.
     * <p>
     * Parcours chaque variable déclarée dans une classe, vérifie si celle ci
     * est une classe de DTO. Si c'est le cas, on appelle la même méthode pour
     * effectuer un traitement récursif. Sinon, on regarde si des annotations
     * sont définis sur la variable afin de générer un objet Validator.
     *
     * @param clazz classe à introspecter
     * @param ctx   contexte d'exécution
     * @param uaId  indentifiant de l'ua (celle du catalogue)
     * @return une MAP contenant la liste des classes introspectée avec une
     * collection de Validator associé.
     * throws TechnicalException erreur technique
     **/
    Map<String, List<Validator>> processValidation(final Class<?> clazz,
                                                   final Context ctx, final String uaId) throws TechnicalException;

    /**
     * Méthode assurant la mise à jour de la liste des contrôles de surface
     * statique d'un DTO en fonction des valeurs surchargées par le développeur
     * applicatif.
     * <p>
     * Se base sur la liste des validateurs dynamiques créés par le développeur
     * applicatif sur son DTO.
     *
     * @param staticValidators
     * @param data
     * @return dynamicValidators
     */
    Map<String, List<Validator>> processDynamicValidator(final Map<String, List<Validator>> staticValidators, final DataDTO data);

}
