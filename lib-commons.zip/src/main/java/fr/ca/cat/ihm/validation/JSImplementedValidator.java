package fr.ca.cat.ihm.validation;

/**
 * Java Enumération permettant de référencer à un endroit unique
 * la liste des différents validateurs de contrôle de surface connus
 * et gérés par le socle IHM.
 * <p>
 * Si un validateur change ou un nouveau est créer, il faut le référencer ici.
 *
 * @author Guillaume Marchal.
 */
public enum JSImplementedValidator {
    /**
     * Constructeur pour le validateur Maximum
     */
    MAX_VALIDATOR("fr.ca.cat.ihm.fwk.core.validation.validators.constraints.MaxValidator"),
    /**
     * Constructeur pour le validateur Minimum
     */
    MIN_VALIDATOR("fr.ca.cat.ihm.fwk.core.validation.validators.constraints.MinValidator"),
    /**
     * Constructeur pour le validateur NotNull
     */
    NOT_NULL_VALIDATOR("fr.ca.cat.ihm.fwk.core.validation.validators.constraints.NotNullValidator"),
    /**
     * Constructeur pour le validateur Pattern
     */
    REGXP_VALIDATOR("fr.ca.cat.ihm.fwk.core.validation.validators.constraints.PatternValidator");

    /**
     * Le nom de la classe de validation Javascript du validateur courrant.
     */
    private final String className;

    /**
     * Constructeur générique d'énumération pour les différents validateurs.
     *
     * @param className, le nom de la classe Javascript du validateur
     */
    JSImplementedValidator(final String className) {
        this.className = className;
    }

    /**
     * Getter générique qui renvoie la classe Javascript du validateur.
     *
     * @return className, le nom de la classe Javascript du validateur.
     */
    public String getJSValidatorImplementedClassName() {
        return className;
    }
}
