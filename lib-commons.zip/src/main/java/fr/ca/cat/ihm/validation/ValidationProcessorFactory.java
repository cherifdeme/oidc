package fr.ca.cat.ihm.validation;

import fr.ca.cat.ihm.utils.Generated;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Factory permettant d'instancier un Validation processor afin de parser les
 * DTO et leurs annotations et de générer un objet de validations compréhensible
 * par le client.
 *
 * @author Guillaume Marchal.
 */
@Component
@Generated
public final class ValidationProcessorFactory {

    public static IValidationProcessor validationProcessor;

    /**
     * Constructeur privé pour bloquer l'instanciation
     */
    @Autowired
    private ValidationProcessorFactory(IValidationProcessor validationProcessor) {
        this.validationProcessor = validationProcessor;
    }

    /**
     * Recupere l'instance du processeur d'annotations
     *
     * @return IValidationProcessor
     */
    public static IValidationProcessor getProcessor() {
        return validationProcessor;
    }
}
