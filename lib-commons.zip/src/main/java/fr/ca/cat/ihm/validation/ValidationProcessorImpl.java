package fr.ca.cat.ihm.validation;

import fr.ca.cat.ihm.bundle.BundleUtils;
import fr.ca.cat.ihm.bundle.ResourceBundleFactory;
import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.controller.dto.DataDTO;
import fr.ca.cat.ihm.controller.dto.Validator;
import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.utils.Generated;
import jakarta.annotation.PostConstruct;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.*;
import java.util.*;

/**
 * Classe Processeur d'annotation. Permet d'introspecter une classe Java définie
 * en paramètre (package + className). Est utilisée pour introspecter les
 * classes de DTO à la recherche d'annotation sur les propriétés de la classe
 * (javax.annotation)
 * <p>
 * Méthode récursive qui gère l'inclusion et l'héritage de DTO.
 * <p>
 * Renvoie une MAP contenant une collection de Validators explicitant le
 * traitement à effectué côté client.
 *
 * @author E902425
 **/
@Service
@Generated
public non-sealed class ValidationProcessorImpl implements IValidationProcessor {
    /**
     * Langage par défaut
     */
    private static final String DEFAULT_LANGUAGE = "fr";

    private ResourceBundleFactory beanService;

    private static ResourceBundleFactory resourceBundleFactory;

    /**
     * Table synchronisée gérant l'accès concurentiel servant de cache afin de
     * ne pas introspecter plusieurs fois une même classe.
     */
    private static final Map<String, Map<String, List<Validator>>> CACHE = new HashMap<>();

    @Autowired
    public ValidationProcessorImpl(ResourceBundleFactory beanService) {
        this.beanService = beanService;
    }

    @PostConstruct
    public void afterInit() {
        this.resourceBundleFactory = beanService;
    }

    /**
     * MAP contenant l'ensemble des validation gérée par le socle
     */
    private static final Map<String, String> TRANSLATOR = new HashMap<>();
    /**
     * Liste des propriété des validateurs java à remonter coté client.
     */
    private static final String[] VALID_ARGS = new String[]{"value", "message", "regexp"};

    static {
        TRANSLATOR.put("javax.validation.constraints.AssertFalse", null);
        TRANSLATOR.put("javax.validation.constraints.AssertTrue", null);
        TRANSLATOR.put("javax.validation.constraints.DecimalMax", null);
        TRANSLATOR.put("javax.validation.constraints.DecimalMin", null);
        TRANSLATOR.put("javax.validation.constraints.Digits", null);
        TRANSLATOR.put("javax.validation.constraints.Future", null);
        TRANSLATOR.put("javax.validation.constraints.Max", JSImplementedValidator.MAX_VALIDATOR.getJSValidatorImplementedClassName());
        TRANSLATOR.put("javax.validation.constraints.Min", JSImplementedValidator.MIN_VALIDATOR.getJSValidatorImplementedClassName());
        TRANSLATOR.put("javax.validation.constraints.NotNull", JSImplementedValidator.NOT_NULL_VALIDATOR.getJSValidatorImplementedClassName());
        TRANSLATOR.put("javax.validation.constraints.Null", null);
        TRANSLATOR.put("javax.validation.constraints.Past", null);
        TRANSLATOR.put("javax.validation.constraints.Pattern", JSImplementedValidator.REGXP_VALIDATOR.getJSValidatorImplementedClassName());
        TRANSLATOR.put("javax.validation.constraints.Size", null);
    }

    /**
     * Méthode interne du processeur permettant de parser les arguments d'une
     * annotations afin d'en récupérer les valeurs et les trier dans une MAP.
     *
     * @param a    flux d'annotation contenant des arguments.
     * @param ctx  ctx contexte d'exécution, à récupérer au niveau du controleur ou de l'orchestrateur
     * @param uaId
     * @return une MAP avec les arguments de l'annotation sous forme clef /
     * valeur.
     * @throws InvocationTargetException
     * @throws IllegalAccessException
     * @throws IllegalArgumentException
     **/
    private static Map<String, String> getArgs(final Annotation a, final Context ctx, final String uaId)
            throws IllegalAccessException, InvocationTargetException, IOException {
        Map<String, String> args = null;

        if (a != null) {
            final ResourceBundleMessageSource defaultRB = resourceBundleFactory
                    .getBundle("bundle/defaultmessagevalidation", ctx.getBrowser().getLocale());
            final ResourceBundleMessageSource rb = resourceBundleFactory
                    .getBundle("bundle/" + uaId + "_messagevalidation", ctx.getBrowser().getLocale());

            args = new HashMap<>();
            final Class<?> at = a.annotationType();
            for (Method af : at.getDeclaredMethods()) {
                //si il s'agit d'un argument que l'on souhaite récupérer uniquement
                if (Arrays.asList(VALID_ARGS).contains(af.getName())) {
                    String currentMessage = af.invoke(a, (Object[]) null).toString();
                    if (!StringUtils.isBlank(currentMessage) && "message".equals(af.getName())) {
                        final String currentKey = currentMessage.substring(1, currentMessage.length() - 1);
                        Enumeration<String> rbKeys = BundleUtils
                                .getKeys("bundle/" + uaId + "_messagevalidation", ctx.getBrowser().getLocale().getLanguage());
                        Enumeration<String> defaultKeys = BundleUtils
                                .getKeys("bundle/defaultmessagevalidation", ctx.getBrowser().getLocale().getLanguage());
                        if (BundleUtils.searchInEnum(rbKeys.asIterator(), currentKey)) {
                            currentMessage = rb.getMessage(currentKey, null, ctx.getBrowser().getLocale());
                        } else if (BundleUtils.searchInEnum(defaultKeys.asIterator(), currentKey)) {
                            currentMessage = defaultRB.getMessage(currentKey, null, ctx.getBrowser().getLocale());
                        }
                    }
                    args.put(af.getName(), currentMessage);
                }
            }
        }
        return args;
    }

    /**
     * Méthode interne du processeur permettant d'introspecter un type paramétré
     * passé en paramètre Par exemple dans le cas d'une collection de type
     * java.util.list<fr.ca.cat.ihm.dto> permet de vérifier que le type List est
     * paramétré par un type de DTO.
     *
     * @param type type paramétré à introspecter
     * @return null si le type paramétré n'est pas un DTO, sinon le type du DTO.
     **/
    private static Class<?> getCollectionParameterizedType(final Type type) {
        if (type instanceof ParameterizedType parameterized) {
            for (Type parameterizedType : parameterized.getActualTypeArguments()) {
                if (parameterizedType != null) {
                    try {
                        if (DataDTO.class.isAssignableFrom((Class<?>) parameterizedType)) {
                            return (Class<?>) parameterizedType;
                        }
                    } catch (ClassCastException e) {
                        //On ne devrait pas arriver ici.
                        //Mais si c'est le cas, on ne fait rien,
                        //le type paramétré n'est pas un DTO dans tous les cas
                        //on renvoie donc null avec la sortie de la méthode.
                    }
                }
            }
        }
        return null;
    }

    /**
     * Méthode interne du processeur permettant de récupérer la liste des
     * annotations pour un champ spécifié.
     *
     * @param clazz
     * @param f
     * @param ctx
     * @param uaId
     * @return
     * @throws TechnicalException
     */
    private List<Validator> getAnnotationsForType(final Class<?> clazz, final Field f, final Context ctx,
                                                  final String uaId) throws TechnicalException {
        final List<Validator> v = new ArrayList<>();
        final Annotation[] annotations = f.getDeclaredAnnotations();
        for (Annotation a : annotations) {
            final String currentJSClass = TRANSLATOR.get(a.annotationType().getCanonicalName());
            if (!StringUtils.isBlank(currentJSClass)) {
                try {
                    v.add(new Validator(f.getName(), currentJSClass, getArgs(a, ctx, uaId), true));
                } catch (IllegalAccessException | InvocationTargetException | IllegalArgumentException |
                         IOException iae) {
                    throw new TechnicalException(ctx, iae, "FWK010", new String[]{clazz.getName()});
                }
            }
        }
        return v;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Map<String, List<Validator>> processValidation(final Class<?> clazz, final Context ctx, final String uaId)
            throws TechnicalException {
        Locale locale;

        if (ctx == null || ctx.getBrowser() == null || ctx.getBrowser().getLocale() == null) {
            locale = new Locale(DEFAULT_LANGUAGE);
        } else {
            locale = ctx.getBrowser().getLocale();
        }

        if (!CACHE.containsKey(clazz.getName() + locale.getLanguage())) {
            final ArrayList<Validator> v = new ArrayList<>();
            final HashMap<String, List<Validator>> validators = new HashMap<>();

            for (Field f : clazz.getDeclaredFields()) {
                boolean isDTO = false;
                Class<?> currentType = f.getType();
                if (!currentType.isPrimitive()) {
                    if (Collection.class.isAssignableFrom(currentType)) {
                        currentType = getCollectionParameterizedType(f.getGenericType());
                        currentType = (currentType != null ? currentType : f.getType());
                    }
                    isDTO = DataDTO.class.isAssignableFrom(currentType);
                    if (isDTO && !validators.containsKey(currentType.getName())) {
                        if (f.getAnnotations().length > 0) {
                            v.addAll(getAnnotationsForType(clazz, f, ctx, uaId));
                        }
                        validators.putAll(processValidation(currentType, ctx, uaId));
                    }
                }
                if (!isDTO && f.getAnnotations().length > 0) {
                    v.addAll(getAnnotationsForType(clazz, f, ctx, uaId));
                }
                if (v.size() > 0 && !validators.containsKey(clazz.getName())) {
                    validators.put(clazz.getName(), v);
                }
            }
            if (validators.size() > 0 && !CACHE.containsKey(clazz.getName())) {
                CACHE.put(clazz.getName() + locale.getLanguage(), validators);
            }
            return validators;
        }
        return CACHE.get(clazz.getName() + locale.getLanguage());
    }


    /**
     * Permet le clone de la Map<String, List<Validator>> de manière optimisée (on ne clone que les validateurs
     * qui peuvent être surchargés)
     *
     * @param validators Map de validateur à cloner
     * @param className  Type de validateur à cloner spécifiquement (les autres validateurs ne sont pas clonés)
     * @return La map clonée
     */
    private Map<String, List<Validator>> fastDeepCloneValidators(final Map<String, List<Validator>> validators,
                                                                 final String className) {
        Map<String, List<Validator>> clone = null;
        if (validators != null) {
            clone = new HashMap<>(validators);

            if (null != clone.get(className)) {
                clone.put(className, new ArrayList<Validator>());
                for (Validator v : validators.get(className)) {
                    clone.get(className).add(v);
                }
            }
        }
        return clone;
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public Map<String, List<Validator>> processDynamicValidator(final Map<String, List<Validator>> staticValidators,
                                                                final DataDTO data) {
        final String className = data.getClass().getName();
        final List<Validator> dynamicValidators = data.getDynamicValidator().getDynamicValidators();
        return processDynamicValidator(staticValidators, className, dynamicValidators);
    }


    /**
     * Méthode assurant la mise à jour de la liste des contrôles de surface statique d'un DTO
     * en fonction des valeurs surchargées par le développeur applicatif. Se base sur la liste
     * des validateurs dynamiques créés par le développeur applicatif sur son DTO.
     * <br />
     *
     * @param staticValidators
     * @param className         Classname du DTO pour ne surcharger que les validateurs de ce type
     * @param dynamicValidators Liste des validateurs dynamiques rattachés au DTO
     * @return Liste des validateurs une fois surchargés
     */
    private Map<String, List<Validator>> processDynamicValidator(final Map<String, List<Validator>> staticValidators,
                                                                 final String className,
                                                                 final List<Validator> dynamicValidators) {
        final Map<String, List<Validator>> finalValidators = fastDeepCloneValidators(staticValidators, className);

        if (null != dynamicValidators && null != finalValidators && null != finalValidators.get(className)) {
            final List<Validator> toRemove = new ArrayList<Validator>();
            //pour chaque validateur static
            for (Validator v : finalValidators.get(className)) {
                //on parcour les validateurs dynamiques
                for (Validator dv : dynamicValidators) {
                    //si le validateur dynamique est sur la même propriété et est du même type de validateur
                    if (dv.getProperty().equals(v.getProperty()) && dv.getClassName().equals(v.getClassName())) {
                        // on surcharge le validateur static
                        //TODO attention modification du validateur en cache A MODIFIER
                        v.setArgs(new HashMap<String, String>(dv.getArgs()));
                        v.setActive(dv.isActive());
                    }
                }
                //si le validateur une fois modifié n'est pas actif
                if (!v.isActive()) {
                    //on le supprime
                    toRemove.add(v);
                }
            }
            finalValidators.get(className).removeAll(toRemove);
        }
        return finalValidators;
    }


}