package fr.ca.cat.ihm.validation.impl;

import fr.ca.cat.ihm.controller.dto.Validator;
import fr.ca.cat.ihm.validation.IDynamicValidator;
import fr.ca.cat.ihm.validation.JSImplementedValidator;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Classe d'implémentation de l'interface IDynamicValidator.
 * <p>
 * Expose une API permettant d'assister le développeur applicatif
 * dans sa création d'une liste de validateur avec des propriétés
 * permettant de surcharger les validateurs statiques de son DTO.
 * <p>
 * Définit une méthode de mise à jour des paramètres du validateur par type de contrôle de surface.
 * <p>
 * Permet de modifier les valeurs du validateur et / ou le désactiver.
 * <p>
 * Cette action est à la charge du développeur applicatif qui doit impérativement passer par cette API
 * pour surcharger ses validateurs statiques de DTO.
 *
 * @author Guillaume Marchal.
 */
@Service
public class DynamicValidatorImpl implements IDynamicValidator {

    /**
     * Déclaration du validateur Maximum via l'énumération contenant l'ensemble des validateurs disponibles sur le socle IHM.
     */
    private static final String MAX_VALIDATOR = JSImplementedValidator.MAX_VALIDATOR.getJSValidatorImplementedClassName();

    /**
     * Déclaration du validateur Minimum via l'énumération contenant l'ensemble des validateurs disponibles sur le socle IHM.
     */
    private static final String MIN_VALIDATOR = JSImplementedValidator.MIN_VALIDATOR.getJSValidatorImplementedClassName();

    /**
     * Déclaration du validateur NotNull via l'énumération contenant l'ensemble des validateurs disponibles sur le socle IHM.
     */
    private static final String NOT_NULL_VALIDATOR = JSImplementedValidator.NOT_NULL_VALIDATOR.getJSValidatorImplementedClassName();

    /**
     * Déclaration du validateur Pattern via l'énumération contenant l'ensemble des validateurs disponibles sur le socle IHM.
     */
    private static final String REGXP_VALIDATOR = JSImplementedValidator.REGXP_VALIDATOR.getJSValidatorImplementedClassName();

    /**
     * Déclaration de la liste de validateur qui contiendra les nouvelles valeurs afin de surcharger les validateurs statiques de son DTO.
     */
    private final List<Validator> validators = new ArrayList<>();

    /**
     * Méthode générique, privée et interne à l'implémentation des validateurs dynamiques.
     * <p>
     * Appellée par l'ensemble des méthodes d'ajout d'un validateur.
     * <p>
     * Assure l'ajout d'un nouveau validateur dans la liste des validateurs qui
     * surchargeront les validateurs statiques avec les valeurs spécifiées par le
     * développeur applicatif.
     *
     * @param validatorType
     * @param property
     * @param args
     * @param isActive
     */
    private void addValidator(final String validatorType, final String property, final Map<String, String> args, final boolean isActive) {
        if (!StringUtils.isBlank(property)) {
            validators.add(new Validator(property, validatorType, args, isActive));
        }
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public void updateMaxValidator(final String property, final Map<String, String> args, final boolean isActive) {
        addValidator(MAX_VALIDATOR, property, args, isActive);
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public void updateMinValidator(final String property, final Map<String, String> args, final boolean isActive) {
        addValidator(MIN_VALIDATOR, property, args, isActive);
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public void updateNotNullValidator(final String property, final Map<String, String> args, final boolean isActive) {
        addValidator(NOT_NULL_VALIDATOR, property, args, isActive);
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public void updatePatternValidator(final String property, final Map<String, String> args, final boolean isActive) {
        addValidator(REGXP_VALIDATOR, property, args, isActive);
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public List<Validator> getDynamicValidators() {
        return validators;
    }

}