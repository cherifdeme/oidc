/**
 *
 */
package fr.ca.cat.ihm.validator;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import jakarta.validation.ConstraintValidatorFactory;

import java.lang.annotation.Annotation;

/**
 * Validator qui ne fait rien côtès java (permet de limiter le volumes des jar à embarqué car Spring quand il detecte les annonations de validation et essaye d'instancier un Validator).
 *
 * @author ETP1484
 */
public class NopConstraintValidatorFactory implements
        ConstraintValidatorFactory {

    /**
     * {@inheritDoc}
     **/
    @SuppressWarnings("unchecked")
    @Override
    public <T extends ConstraintValidator<?, ?>> T getInstance(Class<T> key) {
        return (T) new ConstraintValidator<>() {

            @Override
            public boolean isValid(final Object value, final ConstraintValidatorContext context) {
                return true;
            }

            @Override
            public void initialize(final Annotation constraintAnnotation) {
                // VOID
            }
        };
    }

    @Override
    public void releaseInstance(ConstraintValidator<?, ?> arg0) {
        // TODO Stub de la méthode généré automatiquement
    }
}
