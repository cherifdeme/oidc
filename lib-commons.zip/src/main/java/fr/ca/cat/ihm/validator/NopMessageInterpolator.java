package fr.ca.cat.ihm.validator;

import fr.ca.cat.ihm.utils.Generated;
import jakarta.validation.MessageInterpolator;

import java.util.Locale;

/**
 * Validator qui ne fait rien côtès java (permet de limiter le volumes des jar à embarqué car Spring quand il detecte les annonations de validation et essaye d'instancier un Validator).
 *
 * @author ETP1484
 */
@Generated
public class NopMessageInterpolator implements MessageInterpolator {

    /**
     * {@inheritDoc}
     **/
    @Override
    public String interpolate(final String messageTemplate, final Context context) {
        return messageTemplate;
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public String interpolate(final String messageTemplate, final Context context, final Locale locale) {
        return messageTemplate;
    }
}
