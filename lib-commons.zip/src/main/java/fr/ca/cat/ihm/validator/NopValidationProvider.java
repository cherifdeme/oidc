/**
 *
 */
package fr.ca.cat.ihm.validator;

import fr.ca.cat.ihm.utils.Generated;
import jakarta.validation.Configuration;
import jakarta.validation.ValidatorFactory;
import jakarta.validation.spi.BootstrapState;
import jakarta.validation.spi.ConfigurationState;
import jakarta.validation.spi.ValidationProvider;

/**
 * Validator qui ne fait rien côtès java (permet de limiter le volumes des jar à embarqué car Spring quand il detecte les annonations de validation et essaye d'instancier un Validator).
 *
 * @author ETP1484
 */
@Generated
public class NopValidationProvider implements
        ValidationProvider<NopValidatorConfiguration> {

    /**
     * {@inheritDoc}
     **/
    @Override
    public NopValidatorConfiguration createSpecializedConfiguration(final BootstrapState state) {
        return new ValidatorConfiguration();
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public Configuration<?> createGenericConfiguration(final BootstrapState state) {
        return new ValidatorConfiguration();
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public ValidatorFactory buildValidatorFactory(final ConfigurationState configurationState) {
        return new NopValidatorFactory();
    }
}
