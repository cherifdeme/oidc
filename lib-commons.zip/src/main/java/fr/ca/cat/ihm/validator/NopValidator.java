/**
 *
 */
package fr.ca.cat.ihm.validator;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import jakarta.validation.executable.ExecutableValidator;
import jakarta.validation.metadata.*;

import java.util.HashSet;
import java.util.Set;


/**
 * Validator qui ne fait rien côtès java (permet de limiter le volumes des jar à embarqué car Spring quand il detecte les annonations de validation et essaye d'instancier un Validator).
 *
 * @author ETP1484
 */

public class NopValidator implements Validator {

    /**
     * {@inheritDoc}
     **/
    @Override
    public <T> Set<ConstraintViolation<T>> validate(T object,
                                                    Class<?>... groups) {
        return new HashSet<>();
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public <T> Set<ConstraintViolation<T>> validateProperty(T object,
                                                            final String propertyName, Class<?>... groups) {
        return new HashSet<>();
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public <T> Set<ConstraintViolation<T>> validateValue(Class<T> beanType,
                                                         final String propertyName, Object value, Class<?>... groups) {
        return new HashSet<>();
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public BeanDescriptor getConstraintsForClass(Class<?> clazz) {
        return new BeanDescriptor() {

            /**
             * {@inheritDoc}
             **/
            @Override
            public boolean hasConstraints() {
                return false;
            }

            /**
             * {@inheritDoc}
             **/
            @Override
            public Class<?> getElementClass() {
                return null;
            }

            /**
             * {@inheritDoc}
             **/
            @Override
            public Set<ConstraintDescriptor<?>> getConstraintDescriptors() {
                return null;
            }

            /**
             * {@inheritDoc}
             **/
            @Override
            public ConstraintFinder findConstraints() {
                return null;
            }

            /**
             * {@inheritDoc}
             **/
            @Override
            public boolean isBeanConstrained() {
                return false;
            }

            /**
             * {@inheritDoc}
             **/
            @Override
            public PropertyDescriptor getConstraintsForProperty(
                    final String propertyName) {
                return null;
            }

            /**
             * {@inheritDoc}
             **/
            @Override
            public Set<PropertyDescriptor> getConstrainedProperties() {
                return null;
            }

            @Override
            public Set<ConstructorDescriptor> getConstrainedConstructors() {
                // TODO Stub de la méthode généré automatiquement
                return null;
            }

            @Override
            public Set<MethodDescriptor> getConstrainedMethods(MethodType arg0, MethodType... arg1) {
                // TODO Stub de la méthode généré automatiquement
                return null;
            }

            @Override
            public ConstructorDescriptor getConstraintsForConstructor(Class<?>... arg0) {
                // TODO Stub de la méthode généré automatiquement
                return null;
            }

            @Override
            public MethodDescriptor getConstraintsForMethod(String arg0, Class<?>... arg1) {
                // TODO Stub de la méthode généré automatiquement
                return null;
            }
        };
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public <T> T unwrap(Class<T> type) {
        return null;
    }

    @Override
    public ExecutableValidator forExecutables() {
        // TODO Stub de la méthode généré automatiquement
        return null;
    }
}