/**
 *
 */
package fr.ca.cat.ihm.validator;

import fr.ca.cat.ihm.utils.Generated;
import jakarta.validation.Configuration;

/**
 * Validator qui ne fait rien côtès java (permet de limiter le volumes des jar à embarqué car Spring quand il detecte les annonations de validation et essaye d'instancier un Validator).
 *
 * @author ETP1484
 */
@Generated
public interface NopValidatorConfiguration extends Configuration<NopValidatorConfiguration> {
}
