/**
 *
 */
package fr.ca.cat.ihm.validator;

import fr.ca.cat.ihm.utils.Generated;
import jakarta.validation.*;

/**
 * Validator qui ne fait rien côtès java (permet de limiter le volumes des jar à embarqué car Spring quand il detecte les annonations de validation et essaye d'instancier un Validator).
 *
 * @author ETP1484
 */
@Generated
public class NopValidatorFactory implements ValidatorFactory {

    /**
     * {@inheritDoc}
     **/
    @Override
    public Validator getValidator() {
        return new NopValidator();
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public ValidatorContext usingContext() {
        return null;
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public MessageInterpolator getMessageInterpolator() {
        return null;
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public TraversableResolver getTraversableResolver() {
        return null;
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public ConstraintValidatorFactory getConstraintValidatorFactory() {
        return new NopConstraintValidatorFactory();
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public <T> T unwrap(Class<T> type) {
        return null;
    }

    @Override
    public void close() {
        // TODO Stub de la méthode généré automatiquement

    }

    @Override
    public ClockProvider getClockProvider() {
        // TODO Stub de la méthode généré automatiquement
        return null;
    }

    @Override
    public ParameterNameProvider getParameterNameProvider() {
        // TODO Stub de la méthode généré automatiquement
        return null;
    }
}
