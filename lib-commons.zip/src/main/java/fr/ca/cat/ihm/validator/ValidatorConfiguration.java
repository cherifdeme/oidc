package fr.ca.cat.ihm.validator;

import fr.ca.cat.ihm.utils.Generated;
import jakarta.validation.*;
import jakarta.validation.valueextraction.ValueExtractor;

import java.io.InputStream;

/**
 * Validator qui ne fait rien côtès java (permet de limiter le volumes des jar à embarqué car Spring quand il detecte les annonations de validation et essaye d'instancier un Validator).
 *
 * @author ETP1484
 */
@Generated
public class ValidatorConfiguration implements NopValidatorConfiguration {

    /**
     * {@inheritDoc}
     **/
    @Override
    public NopValidatorConfiguration ignoreXmlConfiguration() {
        return this;
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public NopValidatorConfiguration messageInterpolator(final MessageInterpolator interpolator) {
        return this;
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public NopValidatorConfiguration traversableResolver(final TraversableResolver resolver) {
        return this;
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public NopValidatorConfiguration constraintValidatorFactory(final ConstraintValidatorFactory constraintValidatorFactory) {
        return this;
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public NopValidatorConfiguration addMapping(final InputStream stream) {
        return this;
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public NopValidatorConfiguration addProperty(final String name, final String value) {
        return this;
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public MessageInterpolator getDefaultMessageInterpolator() {
        return new NopMessageInterpolator();
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public TraversableResolver getDefaultTraversableResolver() {
        return null;
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public ConstraintValidatorFactory getDefaultConstraintValidatorFactory() {
        return new NopConstraintValidatorFactory();
    }

    /**
     * {@inheritDoc}
     **/
    @Override
    public ValidatorFactory buildValidatorFactory() {
        return new NopValidatorFactory();
    }

    @Override
    public NopValidatorConfiguration addValueExtractor(ValueExtractor<?> arg0) {
        return null;
    }

    @Override
    public NopValidatorConfiguration clockProvider(ClockProvider arg0) {
        return null;
    }

    @Override
    public BootstrapConfiguration getBootstrapConfiguration() {
        return null;
    }

    @Override
    public ClockProvider getDefaultClockProvider() {
        return null;
    }

    @Override
    public ParameterNameProvider getDefaultParameterNameProvider() {
        return null;
    }

    @Override
    public NopValidatorConfiguration parameterNameProvider(ParameterNameProvider arg0) {
        return null;
    }
}
