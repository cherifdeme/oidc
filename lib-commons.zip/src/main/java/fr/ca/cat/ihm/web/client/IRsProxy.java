package fr.ca.cat.ihm.web.client;

import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.web.client.dto.http.*;

import java.util.Map;

/**
 * The set of common methods for HTTP/1.1 is defined below.
 * Although this set can be expanded, additional methods cannot be assumed to share the same semantics for separately extended clients and servers.
 *
 * @author ET02455
 */
public interface IRsProxy {

    /**
     * Retrieve information. GET requests must be safe and idempotent, meaning regardless of how many times it repeats with the same parameters, the results are the same.
     * They can have side effects, but the user doesn't expect them, so they cannot be critical to the operation of the system. Requests can also be partial or conditional.
     *
     * @param path
     * @param pathParams
     * @param queryParams
     * @return
     * @throws TechnicalException
     */
    public GetMethod get(String path, Map<String, String> pathParams, Map<String, String> queryParams) throws TechnicalException;

    /**
     * Request that the resource at the URI do something with the provided entity. Often POST is used to create a new entity, but it can also be used to update an entity.
     *
     * @param path
     * @param pathParams
     * @param content
     * @param contentType
     * @return
     * @throws TechnicalException
     */
    public PostMethod post(String path, Map<String, String> pathParams, Object content, String contentType) throws TechnicalException;

    /**
     * Store an entity at a URI. PUT can create a new entity or update an existing one. A PUT request is idempotent. Idempotency is the main difference between the expectations of PUT versus a POST request.
     *
     * @param path
     * @param pathParams
     * @param queryParams
     * @param content
     * @param contentType
     * @return
     * @throws TechnicalException
     */
    public PutMethod put(String path, Map<String, String> pathParams, Map<String, String> queryParams, Object content, String contentType) throws TechnicalException;


    /**
     * The PATCH method affects the resource identified by the Request-URI, and it also MAY have side effects on other resources
     * PATCH is neither safe nor idempotent
     *
     * @param path
     * @param pathParams
     * @param queryParams
     * @param content
     * @param contentType
     * @return
     * @throws TechnicalException
     * @see <a href="https://www.rfc-editor.org/rfc/rfc5789">...</a>
     */
    public PatchMethod patch(String path, Map<String, String> pathParams, Map<String, String> queryParams, Object content, String contentType) throws TechnicalException;


    /**
     * Request that a resource be removed; however, the resource does not have to be removed immediately. It could be an asynchronous or long-running request.
     *
     * @param path
     * @param pathParams
     * @param queryParams
     * @return
     * @throws TechnicalException
     */
    public DeleteMethod delete(String path, Map<String, String> pathParams, Map<String, String> queryParams) throws TechnicalException;

    /**
     * The HEAD method is identical to GET except that the server MUST NOT return a message-body in the response.
     * The metainformation contained in the HTTP headers in response to a HEAD request SHOULD be identical to the information sent in response to a GET request.
     * This method can be used for obtaining metainformation about the entity implied by the request without transferring the entity-body itself.
     * This method is often used for testing hypertext links for validity, accessibility, and recent modification.
     *
     * @param path
     * @param pathParams
     * @param queryParams
     * @return
     * @throws TechnicalException
     */
    public HeadMethod head(String path, Map<String, String> pathParams, Map<String, String> queryParams) throws TechnicalException;

    /**
     * The OPTIONS method represents a request for information about the communication options available on the request/response chain identified by the Request-URI.
     * This method allows the client to determine the options and/or requirements associated with a resource, or the capabilities of a server, without implying a resource action or initiating a resource retrieval.
     *
     * @param path
     * @param queryParams
     * @return
     * @throws TechnicalException
     */
    public OptionsMethod options(String path, Map<String, String> pathParams, Map<String, String> queryParams) throws TechnicalException;


    /**
     * Request that the resource at the URI do something with the provided entity. Often POST is used to create a new entity, but it can also be used to update an entity.
     *
     * @param path
     * @param pathParams
     * @param queryParams
     * @param content
     * @param contentType
     * @return
     * @throws TechnicalException
     */
    public PostMethod post(String path, Map<String, String> pathParams, Map<String, String> queryParams,
                           Object content, String contentType) throws TechnicalException;

}
