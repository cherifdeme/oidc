package fr.ca.cat.ihm.web.client;

import java.util.List;

import fr.ca.cat.ihm.utils.Generated;

@Generated
public class RsConf {

    private String url;

    private String authorization;

    private String clientId;

    private String redirectUrl;

    private String scope;

    /**
     * Liste des exceptions de type business
     */
    private List<String> businessExceptions = null;

    /**
     * Indique si proxy résilient
     */
    private boolean resilientProxy;


    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getAuthorization() {
        return authorization;
    }

    public void setAuthorization(String authorization) {
        this.authorization = authorization;
    }

    /**
     * Retourne la liste des exceptions de type business.
     */
    public List<String> getBusinessExceptions() {
        return businessExceptions;
    }

    public void setBusinessExceptions(List<String> businessExceptions) {
        this.businessExceptions = businessExceptions;
    }

    /**
     * Booléen précisant le choix du proxy : true = proxy résilient.
     */
    public boolean isResilientProxy() {
        return resilientProxy;
    }

    public void setResilientProxy(boolean resilientProxy) {
        this.resilientProxy = resilientProxy;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    public String getRedirectUrl() {
        return redirectUrl;
    }

    public void setRedirectUrl(String redirectUrl) {
        this.redirectUrl = redirectUrl;
    }

    public String getScope() {
        return scope;
    }

    public void setScope(String scope) {
        this.scope = scope;
    }

}
