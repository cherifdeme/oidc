package fr.ca.cat.ihm.web.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.LogUtils;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.logger.TypeLogger;
import fr.ca.cat.ihm.redis.RedisCacheService;
import fr.ca.cat.ihm.redis.RedisCacheUAService;
import fr.ca.cat.ihm.security.auc9.WebClientAuc9Service;
import fr.ca.cat.ihm.security.auc9.WebClientAuc9ServiceImpl;
import fr.ca.cat.ihm.security.dto.SecurityAPIBean;
import fr.ca.cat.ihm.security.dto.SecurityDTO;
import fr.ca.cat.ihm.utils.Generated;
import fr.ca.cat.ihm.utils.Version;
import fr.ca.cat.ihm.web.client.impl.WebClientImpl;
import fr.ca.cat.most.util.log.MostCode;
import redis.clients.jedis.exceptions.JedisException;

@Component
public final class WebClientFactory {

    private static final Logger LOGGER = LogFactory.getLog(WebClientFactory.class, TypeLogger.LOGGER_SOCLE);
    private static final MostCode MC_IHME_API_AUC9_REFRESH_KO = new MostCode("IHME-API_AUC9_REFRESH_KO");
    private static final MostCode MC_IHME_API_FACTORY_REFRESH = new MostCode("IHME-API_FACTORY_REFRESH");
    private static final MostCode MC_IHME_API_FACTORY_PASSWORD = new MostCode("IHME-API_FACTORY_PASSWORD");
    private static final MostCode MC_IHME_API_FACTORY_REDIS_KO = new MostCode("MC_IHME_API_FACTORY_REDIS_KO");
    private static final MostCode MC_IHME_API_FACTORY_AT_SOCLE_NOT_FOUND = new MostCode("MC_IHME_API_FACTORY_AT_SOCLE_NOT_FOUND");
    private final RedisCacheService redisCacheService;
    private final RedisCacheUAService redisCacheUAService;
    private final RsConf confAuc9Api2m;
    private final WebClientAuc9Service auc9Service;

    /**
     * Constructeur prive pour bloquer l'instanciation
     */
    @Autowired
    public WebClientFactory(final RedisCacheService redisCacheService, final RedisCacheUAService redisCacheUAService,
                            @Qualifier("authentificationCollaborateurV2") final RsConf confAuc9Api2m,
                            final WebClientAuc9Service auc9Service) {
        this.redisCacheService = redisCacheService;
        this.redisCacheUAService = redisCacheUAService;
        this.confAuc9Api2m = confAuc9Api2m;
        this.auc9Service = auc9Service;
    }

    /**
     * Recuperation du context sécurité d'appel à l'api2m pour une UA
     */
    public SecurityAPIBean getUaSecurityApiBean(final RsConf rsConf, final Context context, final String consumerId,
                                                final Version consumerVersion) throws TechnicalException {
        SecurityAPIBean uaSecurityBeanApi;

        final var ctxUa = new Context(context.getBrowser(), context.getPerformanceDTO(), context.getSecurityDTO(),
                consumerId, consumerVersion, context.getContextExecution());
        // Construction RsConf auC9 pour l'ua
        final var uaAuc9Conf = new RsConf();
        uaAuc9Conf.setAuthorization(rsConf.getAuthorization());
        uaAuc9Conf.setClientId(rsConf.getClientId());
        uaAuc9Conf.setUrl(confAuc9Api2m.getUrl());
        uaAuc9Conf.setRedirectUrl(rsConf.getRedirectUrl());

        auc9Service.setContext(ctxUa);
        auc9Service.setRsConf(uaAuc9Conf);

        uaSecurityBeanApi = getUaTokenFromRedis(context, auc9Service);

        if (uaSecurityBeanApi == null) {
            LOGGER.debug(MC_IHME_API_FACTORY_PASSWORD, "Aucun token trouvé pour l'UA. Création des tokens via le token socle", context);
            Context ctxAuln = new Context(context.getBrowser(), context.getPerformanceDTO(), context.getSecurityDTO(),
                    "AULN", new Version("1.0"), context.getContextExecution());
            // Construction contexte security socle IHME !!
            manageSocleAccessToken(ctxAuln);

            uaSecurityBeanApi = getUaAccessToken(context, auc9Service);
        }

        return uaSecurityBeanApi;
    }

    @Generated
    private void manageSocleAccessToken(final Context context) throws TechnicalException {
        SecurityDTO secu = context.getSecurityDTO();

        // on synchronise si les UA parallelisent des appels
        SecurityAPIBean socleApiBean;
        SecurityAPIBean socleRefreshTokenBean;
        synchronized (secu) {
            // Recuperation du token IHME en cache
            try {
                LOGGER.debug(MC_IHME_API_FACTORY_PASSWORD, "Recuperation access token socle pour la session: "
                        + LogUtils.obfuscateUUIDString(context.getSecurityDTO().getAulnSessionId()), context);
                socleApiBean = redisCacheService.getTokens(context);
            } catch (JedisException e) {
                LOGGER.error(MC_IHME_API_FACTORY_REDIS_KO, "Erreur lors de la recuperation du token socle", context);
                throw new TechnicalException(context, "FWK802");
            }

            try {
                LOGGER.debug(MC_IHME_API_FACTORY_PASSWORD, "Recuperation refresh token socle pour la session: "
                        + LogUtils.obfuscateUUIDString(context.getSecurityDTO().getAulnSessionId()), context);
                socleRefreshTokenBean = redisCacheService.getRefreshToken(context);
            } catch (JedisException e) {
                LOGGER.error(MC_IHME_API_FACTORY_REDIS_KO, "Erreur lors de la recuperation du refresh token socle", context);
                throw new TechnicalException(context, "FWK802");
            }

            if (null == socleApiBean) {
                LOGGER.debug(MC_IHME_API_FACTORY_PASSWORD, "Aucun access token socle trouvé pour la session: "
                        + LogUtils.obfuscateUUIDString(context.getSecurityDTO().getAulnSessionId()), context);
                // Pas de token IHME en cache. on test s'il y a un refresh token
                // IHME

                LOGGER.info(MC_IHME_API_FACTORY_REFRESH, "Refresh token nécessaire", context);

                if (socleRefreshTokenBean != null) {
                    LOGGER.debug(MC_IHME_API_FACTORY_REFRESH, "Refresh token existant. On initie le refresh pour la session: "
                            + LogUtils.obfuscateUUIDString(context.getSecurityDTO().getAulnSessionId()), context);
                    // On a trouve un refresh token IHME
                    // On est en mode refresh
                    try {
                        auc9Service.setContext(context);
                        auc9Service.setRsConf(confAuc9Api2m);

                        // Set refresh token security api bean
                        secu.setApiSecurity(socleRefreshTokenBean);

                        // Demande de token via un refresh token
                        socleApiBean = auc9Service.getToken();

                        // Sauvegarde du token en cache
                        redisCacheService.saveToken(context, socleApiBean);
                        LOGGER.debug(MC_IHME_API_FACTORY_PASSWORD, "Sauvegarde access token socle pour la session: "
                                + LogUtils.obfuscateUUIDString(context.getSecurityDTO().getAulnSessionId()), context);
                    } catch (Exception e) {
                        LOGGER.error(MC_IHME_API_AUC9_REFRESH_KO, "echec appel AUC9 en mode refresh", e, context);
                        secu.setApiSecurity(null);
                    }
                }
            }

            if (null == socleApiBean) {
                LOGGER.error(MC_IHME_API_FACTORY_AT_SOCLE_NOT_FOUND, "Aucun jeton socle trouvé", context);
                throw new TechnicalException(context, "FWK801");

            }

            // Report du refresh token
            if (socleRefreshTokenBean != null && socleApiBean.getRefresh_token() == null) {
                socleApiBean.setRefresh_token(socleRefreshTokenBean.getRefresh_token());
            }

            secu.setApiSecurity(socleApiBean);
        }

    }

    @Generated
    private SecurityAPIBean getUaTokenFromRedis(final Context context, final WebClientAuc9Service auc9) {
        // Recuperation du cache manager
        LOGGER.debug(MC_IHME_API_FACTORY_PASSWORD, "Recuperation information de session pour l'ua.", context);
        var uaSessionTokensBean = (SecurityAPIBean) redisCacheUAService.getTokens(context);
        // SecurityAPIBean uaSessionTokensBean = tokens != null ? tokens : redisCacheService.getTokens(context); ;

        if (uaSessionTokensBean != null) {
            LOGGER.debug(MC_IHME_API_FACTORY_PASSWORD, "Information de session pour l'ua trouvee en cache", context);
        } else {
            LOGGER.debug(MC_IHME_API_FACTORY_PASSWORD, "Aucune Information de session pour l'ua trouvee en cache", context);
            LOGGER.debug(MC_IHME_API_FACTORY_PASSWORD, "Recherche d'un refresh token pour l'ua en cache", context);

            String refreshToken = redisCacheUAService.getRefreshToken(context);

            if (refreshToken != null) {
                LOGGER.debug(MC_IHME_API_FACTORY_PASSWORD, "Refresh token trouve pour l'ua", context);

                // Si on a un refreshToken on demande un refresh sinon on aura
                // une nouvelle session
                try {
                    LOGGER.debug(MC_IHME_API_FACTORY_PASSWORD, "Demande de nouveau token pour l'ua", context);
                    uaSessionTokensBean = auc9.refreshToken(refreshToken);
                    // On sauvegarde la session dans redis si le refresh c'est
                    // bien passe
                    redisCacheUAService.saveToken(context, uaSessionTokensBean);
                } catch (TechnicalException e) {
                    LOGGER.error(MC_IHME_API_FACTORY_PASSWORD, "Erreur lors du refresh du token", e, context);
                    // On reset la session si une erreur intervient pendant le
                    // refresh du token
                }
            } else {
                LOGGER.debug(MC_IHME_API_FACTORY_PASSWORD, "Aucun refresh token trouve pour l'ua en cache", context);
            }
        }

        return uaSessionTokensBean;
    }

    @Generated
    private SecurityAPIBean getUaAccessToken(final Context context, final WebClientAuc9Service auc9) throws TechnicalException {
        // Recuperation du cache manager
        LOGGER.debug(MC_IHME_API_FACTORY_PASSWORD, "Recuperation information de session pour l'ua.", context);
        SecurityAPIBean uaSessionTokensBean;

        // Aucune session en cours. On demande un token pour l'UA

        LOGGER.debug(MC_IHME_API_FACTORY_PASSWORD, "Aucune information de session pour l'ua. Cinematique AZ code en cours", context);

        LOGGER.debug(MC_IHME_API_FACTORY_PASSWORD, "Recuperation de Access Token code pour l'ua", context);
        uaSessionTokensBean = auc9.getUATokensFromJWT();
        LOGGER.debug(MC_IHME_API_FACTORY_PASSWORD, "Access Token code recupere pour l'ua", context);
        redisCacheUAService.saveToken(context, uaSessionTokensBean);
        redisCacheUAService.saveRefreshToken(context, uaSessionTokensBean.getRefresh_token());

        return uaSessionTokensBean;
    }

    public IRsProxy getRsProxy(final RsConf rsConf, final Context context, final String consumerId,
                               final Version consumerVersion) throws TechnicalException {

        final var ctxAulne = new Context(context.getBrowser(), context.getPerformanceDTO(), context.getSecurityDTO(),
                "AULN", new Version("1.0"), context.getContextExecution());
        final var ctxUa = new Context(context.getBrowser(), context.getPerformanceDTO(), context.getSecurityDTO(),
                consumerId, consumerVersion, context.getContextExecution());

        final var sec = context.getSecurityDTO();
        SecurityAPIBean apiBean = null;

        LOGGER.debug(MC_IHME_API_FACTORY_PASSWORD, "Construction des tokens pour l'UA", context);
        // Construction contexte security socle de l'UA !!
        apiBean = getUaSecurityApiBean(rsConf, context, consumerId, consumerVersion);

        // Si le contexte de sécurité IHME n'a pas été mis lors de la récup du jeton UA on le fait
        if (sec.getApiSecurity() == null || sec.getApiSecurity().getAccess_token() == null) {
            manageSocleAccessToken(ctxAulne);
        }

        if (apiBean == null) {
            apiBean = sec.getApiSecurity();
        }

        return new WebClientImpl(rsConf, ctxUa, apiBean);
    }
}