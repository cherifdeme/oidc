package fr.ca.cat.ihm.web.client.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import fr.ca.cat.ihm.utils.Generated;
import org.apache.commons.lang3.StringUtils;

@Generated
public class Canal {

    @JsonProperty("canalId")
    private String canalId;
    @JsonProperty("canalDistribution")
    private String canalDistribution;
    @JsonProperty("transport")
    private String transport;


    @JsonCreator
    public Canal(@JsonProperty("canalId") String canalId, @JsonProperty("canalDistributeur") String canalDistributeur, @JsonProperty("transport") String transport) {
        this.canalId = canalId;
        this.canalDistribution = canalDistributeur;
        this.transport = transport;
    }

    public String getCanalId() {
        return canalId;
    }

    public void setCanalId(String canalId) {
        this.canalId = canalId;
    }

    public String getCanalDistribution() {
        return canalDistribution;
    }

    public void setCanalDistribution(String canalDistribution) {
        this.canalDistribution = canalDistribution;
    }

    @JsonIgnore
    public boolean isValid() {
        if (StringUtils.isBlank(canalId) || StringUtils.isBlank(canalDistribution)) {
            return false;
        }
        return true;
    }

    public String getTransport() {
        return transport;
    }

    public void setTransport(String transport) {
        this.transport = transport;
    }
}
