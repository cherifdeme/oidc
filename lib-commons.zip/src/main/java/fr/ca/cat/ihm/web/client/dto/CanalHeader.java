package fr.ca.cat.ihm.web.client.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.ca.cat.ihm.utils.Generated;

@Generated
public class CanalHeader {
    @JsonProperty("canal")
    private Canal canal;

    @JsonCreator
    public CanalHeader(@JsonProperty("canal") Canal canal) {
        this.canal = canal;
    }

    public Canal getCanal() {
        return canal;
    }

    public void setCanal(Canal canal) {
        this.canal = canal;
    }

    @JsonIgnore
    public boolean isValid() {
        if (canal == null) {
            return false;
        }
        return canal.isValid();
    }

    @Override
    public String toString() {
        try {
            return (new ObjectMapper()).writeValueAsString(this);
        } catch (JsonProcessingException e) {
            return "";
        }
    }
}
