package fr.ca.cat.ihm.web.client.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import fr.ca.cat.ihm.utils.Generated;
import org.apache.commons.lang3.StringUtils;

@Generated
public class Consommateur {

    private String nom;
    private String version;

    @JsonCreator
    public Consommateur(
            @JsonProperty("nom") String nom,
            @JsonProperty("version") String version
    ) {
        this.nom = nom;
        this.version = version;
    }

    @JsonProperty("nom")
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    @JsonProperty("version")
    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }

    @JsonIgnore
    public boolean isValid() {
        if (StringUtils.isBlank(nom) || StringUtils.isBlank(version)) {
            return false;
        }
        if (!version.matches("^[0-9]+(\\.[0-9]+){0,2}$")) {
            return false;
        }
        return true;
    }
}
