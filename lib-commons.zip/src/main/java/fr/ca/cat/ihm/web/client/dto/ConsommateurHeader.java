package fr.ca.cat.ihm.web.client.dto;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.ca.cat.ihm.utils.Generated;

@Generated
public class ConsommateurHeader {

    @JsonProperty("consommateur")
    private Consommateur consommateur;

    @JsonCreator
    public ConsommateurHeader(@JsonProperty("consommateur") Consommateur consommateur) {
        this.consommateur = consommateur;
    }

    public Consommateur getConsommateur() {
        return consommateur;
    }

    public void setConsommateur(Consommateur consommateur) {
        this.consommateur = consommateur;
    }

    @JsonIgnore
    public boolean isValid() {
        if (consommateur == null) {
            return false;
        }
        return consommateur.isValid();
    }

    @Override
    public String toString() {
        try {
            return (new ObjectMapper()).writeValueAsString(this);
        } catch (JsonProcessingException e) {
            return "";
        }
    }
}
