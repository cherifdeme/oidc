package fr.ca.cat.ihm.web.client.dto;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import fr.ca.cat.ihm.utils.Generated;

@Generated
@JsonIgnoreProperties(ignoreUnknown = true)
public class IdToken {
    private long exp;
    private String sub;

    public IdToken(long exp, String sub) {
        this.exp = exp;
        this.sub = sub;
    }

    public IdToken() {

    }

    public long getExp() {
        return exp;
    }

    public void setExp(long exp) {
        this.exp = exp;
    }

    public String getSub() {
        return sub;
    }

    public void setSub(String sub) {
        this.sub = sub;
    }
}
