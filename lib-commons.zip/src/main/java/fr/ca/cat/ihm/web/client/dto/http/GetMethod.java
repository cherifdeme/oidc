package fr.ca.cat.ihm.web.client.dto.http;

import fr.ca.cat.ihm.utils.Generated;

@Generated
public class GetMethod extends HttpMethod {
    public GetMethod() {
        super();
    }
}
