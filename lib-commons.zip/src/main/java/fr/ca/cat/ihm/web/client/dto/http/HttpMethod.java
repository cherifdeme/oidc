package fr.ca.cat.ihm.web.client.dto.http;

import fr.ca.cat.ihm.utils.Generated;

@Generated
public class HttpMethod {
    private Object responseBody = null;

    public Object getResponseBody() {
        return responseBody;
    }

    public void setResponseBody(Object responseBody) {
        this.responseBody = responseBody;
    }


    public String getResponseBodyAsString() {
        return responseBody.toString();
    }

    private boolean responseAvailable() {
        return (responseBody != null);
    }

}
