package fr.ca.cat.ihm.web.client.dto.http;

import fr.ca.cat.ihm.utils.Generated;

@Generated
public class PatchMethod extends HttpMethod {
    public PatchMethod() {
        super();
    }
}
