package fr.ca.cat.ihm.web.client.dto.http;

import fr.ca.cat.ihm.utils.Generated;

@Generated
public class PostMethod extends HttpMethod {
    public PostMethod() {
        super();
    }
}
