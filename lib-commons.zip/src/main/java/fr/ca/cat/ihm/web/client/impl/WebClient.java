package fr.ca.cat.ihm.web.client.impl;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.logger.TypeLogger;
import fr.ca.cat.ihm.security.IhmeEncryptor;
import fr.ca.cat.ihm.utils.Constants;
import fr.ca.cat.ihm.utils.Generated;
import fr.ca.cat.ihm.web.client.RsConf;
import fr.ca.cat.ihm.web.client.dto.Canal;
import fr.ca.cat.ihm.web.client.dto.CanalHeader;
import fr.ca.cat.ihm.web.client.dto.Consommateur;
import fr.ca.cat.ihm.web.client.dto.ConsommateurHeader;
import fr.ca.cat.most.util.log.MDCConstants;
import fr.ca.cat.most.util.log.MostCode;
import fr.ca.cat.securite.saml.UserCatFactory;
import org.json.JSONObject;
import org.slf4j.MDC;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.util.MultiValueMap;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;
import reactor.core.publisher.Mono;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import static fr.ca.cat.ihm.utils.Constants.FWK533;

/**
 * Classe qui regroupe les méthodes communes au webclient,
 * elle est utilisée lors des appels aux APIs.
 *
 * @author cherif DEME
 */

public class WebClient {
    public static final String AUTHORIZATION = "Authorization";
    private static final Logger LOGGER = LogFactory.getLog(WebClient.class, TypeLogger.LOGGER_SOCLE);
    private static final MostCode MC_API_CALL = new MostCode("IHME-API_CALL");
    private static final MostCode MC_API_CALL_STATUS = new MostCode("IHME-API_CALL_STATUS");
    protected RsConf rsConf;
    protected Context context;

    public WebClient(RsConf rsConf, Context context) {
        this.rsConf = rsConf;
        this.context = context;
    }

    @Generated
    protected void setAuthorization(final MultiValueMap<String, String> headers) throws TechnicalException {
        try {
            final var encryptor = new IhmeEncryptor();
            headers.add(Constants.HDR_AUTHORIZATION, encryptor.decrypt(rsConf.getAuthorization()));
        } catch (Exception e) {
            final var tex = new TechnicalException(context, e, FWK533);
            LOGGER.error(Constants.MC_IHME_API_CIPHERED_KO, tex.getMessageException(), e, context);
            throw tex;
        }
    }

    public UriComponents getUriComponents(final String url, final String path) {

        final var uriComponents = UriComponentsBuilder.fromHttpUrl(url).path(path);
        return uriComponents.build();
    }

    @Generated
    UriComponents getUriComponents(String url, String path, Map<String, String> pathParams, Map<String, String> queryParams) {

        final var uriComponents = UriComponentsBuilder.fromHttpUrl(url).path(path);
        if (queryParams != null && !queryParams.isEmpty()) {
            for (Map.Entry<String, String> queryParam : queryParams.entrySet()) {
                try {
                    //fix rtc524871
                    String value = queryParam.getValue() == null ? null : URLEncoder.encode(queryParam.getValue(),
                            StandardCharsets.UTF_8.displayName());
                    uriComponents.queryParam(queryParam.getKey(), value);
                } catch (UnsupportedEncodingException e) {
                    LOGGER.warn("Error encoding query params", e, context);
                }
            }
        }
        if (pathParams != null && !pathParams.isEmpty()) {
            return uriComponents.buildAndExpand(pathParams);
        }
        return uriComponents.build();
    }


    protected void buildBody(final MultiValueMap<String, String> bodyParameters) {
        final var scope = rsConf.getScope() != null ? rsConf.getScope() : Constants.SCOPE_VALUE;
        final var sec = context.getSecurityDTO();
        final var beanAPI = sec.getApiSecurity();

        bodyParameters.add(Constants.SCOPE, Constants.SCOPE_VALUE);
        bodyParameters.add(Constants.AUTHENTICATION_LEVEL, "2");
        bodyParameters.add(Constants.SCOPE, scope);

        if (null != beanAPI && null != beanAPI.getRefresh_token()) {
            LOGGER.debug(Constants.MC_IHME_API_AUC9_REFRESH_TOKEN, beanAPI.getRefresh_token(), null);
            bodyParameters.add(Constants.REFRESH_TOKEN, beanAPI.getRefresh_token());
            bodyParameters.add(Constants.GRANT_TYPE, Constants.REFRESH_TOKEN);
        } else {

            final var user = UserCatFactory.getUser(sec.getSamlAssertion(), sec.getUserDTO().getSamlToken());

            // yen a forcément un
            final var idx = user.getCredentials().indexOf(':');

            bodyParameters.add(Constants.GRANT_TYPE, "password");
            bodyParameters.add("username", user.getCredentials().substring(0, idx));
            bodyParameters.add("password", user.getCredentials().substring(idx + 1));
            bodyParameters.add("functional_post", user.getFunctionalPostID());
        }

        LOGGER.info(Constants.MC_IHME_API_AUC9_GRANT_TYPE, bodyParameters.get(Constants.GRANT_TYPE).toString(), null);
        LOGGER.info(Constants.MC_IHME_API_AUC9_SCOPE, bodyParameters.get(Constants.SCOPE).toString(), null);

    }

    protected void provideClientHeader(final MultiValueMap<String, String> headers) {
        //Header DTO
        final var consommateurHeader = new ConsommateurHeader(new Consommateur(context.getUaId(), context.getUaVersion().getCurrent() + ".0"));
        final var consommateurOrigine = new ConsommateurHeader(new Consommateur(
                MDC.get(MDCConstants.idConsommateurOrigine),
                MDC.get(MDCConstants.versionConsommateurOrigine)
        ));


        final var canalHeader = new CanalHeader(new Canal(
                context.getContextExecution().getSessionMode().getCanal(),
                context.getContextExecution().getSessionMode().getDistribCanal(),
                context.getContextExecution().getTansportReel()));

        headers.add("cache-control", "no-cache");
        headers.add("idCR", context.getContextExecution().getProfile().getStructureId());
        headers.add("correlationid", context.getCorrelationId());
        headers.add("cats_consommateur", consommateurHeader.toString());
        headers.add("cats_consommateurOrigine", consommateurOrigine.toString());
        headers.add("cats_canal", canalHeader.toString());
    }

    @Generated
    public Mono<?> executePostRequest(final MultiValueMap<String, String> headers, final Object formData,
                                         final RsConf rsConf, final UriComponents uri, final Class type, final HttpMethod method,
                                         final String contentType) {


        final var webClient = org.springframework.web.reactive.function.client.WebClient.create(rsConf.getUrl());
        return webClient
                .method(method)
                .uri(uri.toUri())
                .contentType(MediaType.valueOf(contentType))
                .headers(httpHeaders -> {
                    httpHeaders.addAll(headers);
                })
                .bodyValue(formData)
                .exchangeToMono(response -> {
                    if (response.statusCode()
                            .equals(HttpStatus.OK)) {

                        doPerf(HttpStatus.OK.value(), method.name(), uri);
                        return response.bodyToMono(type);
                    } else {
                        return response.createException();
                    }
                });
    }

    @Generated
    public Mono<?> executeGetRequest(final MultiValueMap<String, String> headers, final RsConf rsConf, final UriComponents uri,
                              final Class type, final HttpMethod method) {
        final var webClient = org.springframework.web.reactive.function.client.WebClient.create(rsConf.getUrl());
        return webClient
                .method(method)
                .uri(uri.toUri())
                .headers(httpHeaders -> {
                    httpHeaders.addAll(headers);
                })
                .exchangeToMono(response -> {
                    if (response.statusCode()
                            .equals(HttpStatus.OK)) {
                        doPerf(HttpStatus.OK.value(), method.name(), uri);
                        return response.bodyToMono(type);
                    } else {
                        return response.createException();
                    }
                });
    }

    public void setContext(Context context) {
        this.context = context;
    }

    public void doPerf(final int status, final String methodName, final UriComponents uri) {
        Map<String, String> perfMsg = new HashMap<>(2);
        perfMsg.put("method", methodName);
        perfMsg.put("host", uri.getHost());
        perfMsg.put("path", uri.getPath());
        final var deb = System.currentTimeMillis();
        LOGGER.debug(MC_API_CALL_STATUS, "Response : {status=" + status + "}", context);
        LOGGER.perf(MC_API_CALL, (int) (System.currentTimeMillis() - deb), new JSONObject(perfMsg), context);
    }
}
