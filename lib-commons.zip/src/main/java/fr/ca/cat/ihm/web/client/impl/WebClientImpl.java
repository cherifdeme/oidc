package fr.ca.cat.ihm.web.client.impl;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.logger.TypeLogger;
import fr.ca.cat.ihm.security.dto.SecurityAPIBean;
import fr.ca.cat.ihm.utils.Generated;
import fr.ca.cat.ihm.web.client.IRsProxy;
import fr.ca.cat.ihm.web.client.RsConf;
import fr.ca.cat.ihm.web.client.dto.http.*;
import fr.ca.cat.most.util.log.MostCode;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Map;
import java.util.Objects;

/**
 * implementation du webclient, appel les APIs,
 * utilise la librairie spring webflux pour faire des appels http.
 *
 * @author cherif DEME
 */

@Generated
public class WebClientImpl extends WebClient implements IRsProxy {
    public static final String FWK530 = "FWK530";
    private static final MostCode MC_API_KO_31 = new MostCode("IHME-API_1472475000031");
    private static final MostCode MC_API_KO_51 = new MostCode("IHME-API_1472475000051");
    private static final MostCode MC_API_KO_61 = new MostCode("IHME-API_1472475000061");
    private static final MostCode MC_API_KO_21 = new MostCode("IHME-API_1472475000021");
    private static final MostCode MC_API_KO_11 = new MostCode("IHME-API_1472475000011");
    private static final String QUERY_PARAMS = "}{queryParams=";
    private static final String PATH_PARAMS = "}{pathParams=";
    private static final String LE_PARAMETRE_PATH_EST_NULL = "Le paramétre PATH est NULL";
    private static final String CONTENT2 = "}{content=";
    private static final String CONTENT_TYPE = "}{contentType=";
    private static final String PATH2 = "}{path=";
    private static final String DETAIL2 = ", detail : ";
    private static final String URL2 = "URL : ";
    private static final Logger LOGGER = LogFactory.getLog(WebClientImpl.class, TypeLogger.LOGGER_SOCLE);

    private final SecurityAPIBean apiBean;

    public WebClientImpl(final RsConf rsConf, final Context context, final SecurityAPIBean apiBean) {
        super(rsConf, context);
        this.apiBean = apiBean;
    }

    @Override
    public PostMethod post(final String path, final Map<String, String> pathParams, final Object content,
                           final String contentType) throws TechnicalException {
        return post(path, pathParams, null, content, contentType);
    }

    @Override
    public PostMethod post(final String path, final Map<String, String> pathParams, final Map<String, String> queryParams,
                           final Object content, final String contentType) throws TechnicalException {
        final var postMethod = new PostMethod();
        LOGGER.info("On entre dans la methode POST avec les parametres {url=" + this.rsConf.getUrl() + PATH2 +
                path + CONTENT_TYPE + contentType + CONTENT2 + content + "}", context);

        if (path == null) {
            LOGGER.warn(LE_PARAMETRE_PATH_EST_NULL, this.context);
            return null;
        }

        final var uri = getUriComponents(this.rsConf.getUrl(), path, pathParams, queryParams);

        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        this.provideClientHeader(headers);
        this.provideSecurity(headers);

        final var mono = executePostRequest(headers, content, rsConf, uri, String.class, HttpMethod.POST, contentType);
        final var data = mono.block();
        if (data instanceof WebClientResponseException e) {
            LOGGER.error(MC_API_KO_11, URL2 + rsConf.getUrl() + DETAIL2 + e.getMessage(), e, context);
            throw processException(e);
        } else {
            postMethod.setResponseBody(data);
        }
        LOGGER.debug("On sort de la methode POST", context);

        return postMethod;
    }

    @Override
    public GetMethod get(final String path, final Map<String, String> pathParams, final Map<String, String> queryParams)
            throws TechnicalException {

        final var getMethod = new GetMethod();
        LOGGER.info("On entre dans la methode GET avec les parametres {url=" + rsConf.getUrl() + PATH2 + path +
                PATH_PARAMS + pathParams + QUERY_PARAMS + queryParams + "}", context);

        if (path == null) {
            LOGGER.warn(LE_PARAMETRE_PATH_EST_NULL, context);
            return null;
        }

        final var uri = getUriComponents(rsConf.getUrl(), path, pathParams, queryParams);

        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        this.provideClientHeader(headers);
        this.provideSecurity(headers);

        final var result = executeGetRequest(headers, rsConf, uri, String.class, HttpMethod.GET);

        final var block = result.block();
        if (block instanceof WebClientResponseException e) {
            LOGGER.error(MC_API_KO_21, URL2 + rsConf.getUrl() + DETAIL2 + e.getMessage(), e, context);
            throw processException(e);
        } else {
            getMethod.setResponseBody(block);
        }
        LOGGER.debug("On sort de la methode GET", context);
        return getMethod;
    }

    @Override
    public PutMethod put(final String path, final Map<String, String> pathParams, final Map<String, String> queryParams,
                         final Object content, final String contentType) throws TechnicalException {
        final var putMethod = new PutMethod();
        LOGGER.info("On entre dans la methode PUT avec les parametres {url=" + this.rsConf.getUrl() + PATH2 +
                path + CONTENT_TYPE + contentType + CONTENT2 + content + "}", context);

        if (path == null) {
            LOGGER.warn(LE_PARAMETRE_PATH_EST_NULL, this.context);
            return null;
        }

        final var uri = getUriComponents(this.rsConf.getUrl(), path, pathParams, queryParams);

        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        this.provideClientHeader(headers);
        this.provideSecurity(headers);

        final var mono = executePostRequest(headers, content, rsConf, uri, String.class, HttpMethod.PUT, contentType);
        final var data = mono.block();
        if (data instanceof WebClientResponseException e) {
            LOGGER.error(MC_API_KO_31, URL2 + rsConf.getUrl() + DETAIL2 + e.getMessage(), e, context);
            throw processException(e);
        } else {
            putMethod.setResponseBody(data);
        }
        LOGGER.debug("On sort de la methode PUT", context);

        return putMethod;
    }

    @Override
    public DeleteMethod delete(final String path, final Map<String, String> pathParams, final Map<String,
            String> queryParams) throws TechnicalException {
        final var deleteMethod = new DeleteMethod();
        LOGGER.info("On entre dans la methode DELETE avec les parametres {url=" + rsConf.getUrl() + PATH2 +
                path + PATH_PARAMS + pathParams + QUERY_PARAMS + queryParams + "}", context);

        if (path == null) {
            LOGGER.warn(LE_PARAMETRE_PATH_EST_NULL, context);
            return null;
        }

        final var uri = getUriComponents(rsConf.getUrl(), path, pathParams, queryParams);

        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        this.provideClientHeader(headers);
        this.provideSecurity(headers);

        final var result = executeGetRequest(headers, rsConf, uri, String.class, HttpMethod.DELETE);
        final var block = result.block();

        if (block instanceof WebClientResponseException e) {
            LOGGER.error(MC_API_KO_21, URL2 + rsConf.getUrl() + DETAIL2 + e.getMessage(), e, context);
            throw processException(e);
        } else {
            deleteMethod.setResponseBody(block);
        }
        LOGGER.debug("On sort de la methode DELETE", context);
        return deleteMethod;
    }

    @Override
    public PatchMethod patch(final String path, final Map<String, String> pathParams, final Map<String, String> queryParams,
                             final Object content, String contentType) throws TechnicalException {
        LOGGER.info("On entre dans la methode PATCH avec les parametres {url=" + this.rsConf.getUrl() + PATH2 +
                path + CONTENT_TYPE + contentType + CONTENT2 + content + "}", context);
        final var patchMethod = new PatchMethod();
        if (path == null) {
            LOGGER.warn(LE_PARAMETRE_PATH_EST_NULL, this.context);
            return null;
        }

        final var uri = getUriComponents(this.rsConf.getUrl(), path, pathParams, queryParams);

        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        this.provideClientHeader(headers);
        this.provideSecurity(headers);

        final var mono = executePostRequest(headers, content, rsConf, uri, String.class, HttpMethod.PATCH, contentType);
        final var data = mono.block();
        if (data instanceof WebClientResponseException e) {
            LOGGER.error(MC_API_KO_31, URL2 + rsConf.getUrl() + DETAIL2 + e.getMessage(), e, context);
            throw processException(e);
        } else {
            patchMethod.setResponseBody(data);
        }
        LOGGER.debug("On sort de la methode PATCH", context);

        return patchMethod;
    }

    @Override
    public HeadMethod head(final String path, final Map<String, String> pathParams, final Map<String, String> queryParams)
            throws TechnicalException {
        final var headMethod = new HeadMethod();
        LOGGER.info("On entre dans la methode HEAD avec les parametres {url=" + rsConf.getUrl() + PATH2 +
                path + PATH_PARAMS + pathParams + QUERY_PARAMS + queryParams + "}", context);

        if (path == null) {
            LOGGER.warn(LE_PARAMETRE_PATH_EST_NULL, context);
            return null;
        }

        final var uri = getUriComponents(rsConf.getUrl(), path, pathParams, queryParams);

        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        this.provideClientHeader(headers);
        this.provideSecurity(headers);

        final var result = executeGetRequest(headers, rsConf, uri, String.class, HttpMethod.HEAD);
        final var block = result.block();

        if (block instanceof WebClientResponseException e) {
            LOGGER.error(MC_API_KO_51, URL2 + rsConf.getUrl() + DETAIL2 + e.getMessage(), e, context);
            throw processException(e);
        } else {
            headMethod.setResponseBody(block);
        }
        LOGGER.debug("On sort de la methode HEAD", context);
        return headMethod;
    }

    @Override
    public OptionsMethod options(final String path, final Map<String, String> pathParams, final Map<String, String> queryParams)
            throws TechnicalException {
        final var optionsMethod = new OptionsMethod();
        LOGGER.info("On entre dans la methode OPTION avec les parametres {url=" + rsConf.getUrl() + PATH2 +
                path + PATH_PARAMS + pathParams + QUERY_PARAMS + queryParams + "}", context);

        if (path == null) {
            LOGGER.warn(LE_PARAMETRE_PATH_EST_NULL, context);
            return null;
        }

        final var uri = getUriComponents(rsConf.getUrl(), path, pathParams, queryParams);

        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        this.provideClientHeader(headers);
        this.provideSecurity(headers);

        final var result = executeGetRequest(headers, rsConf, uri, String.class, HttpMethod.OPTIONS);
        final var block = result.block();

        if (block instanceof WebClientResponseException e) {
            LOGGER.error(MC_API_KO_61, URL2 + rsConf.getUrl() + DETAIL2 + e.getMessage(), e, context);
            throw processException(e);
        } else {
            optionsMethod.setResponseBody(block);
        }
        LOGGER.debug("On sort de la methode OPTION", context);
        return optionsMethod;
    }

    protected void provideSecurity(final MultiValueMap<String, String> headers) {
        //un seul header de securité "bearer"
        headers.add(AUTHORIZATION, "Bearer " + apiBean.getAccess_token());
    }

    private TechnicalException processException(WebClientResponseException entity) {
        final var resolve = HttpStatus.resolve(entity.getStatusCode().value());
        final var technicalException = new TechnicalException(context, FWK530,
                new String[]{entity.getStatusText(), context.getCorrelationId()});
        assert resolve != null;
        technicalException.setStatusCode(resolve.value());
        final UriComponents uri = UriComponentsBuilder.fromUri(Objects.requireNonNull(entity.getRequest()).getURI()).build();
        doPerf(entity.getStatusCode().value(), Objects.requireNonNull(entity.getRequest()).getMethod().name(), uri);
        return technicalException;
    }
}
