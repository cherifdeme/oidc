package fr.ca.cat.ihm.ws;

import fr.ca.cat.ihm.utils.Generated;
import fr.ca.cat.ihm.ws.impl.HeaderServiceHandler;
import jakarta.xml.ws.handler.HandlerResolver;

/**
 * Interface permettant de gérer l'injection du jeton SAML dans les header des
 * WebServices.
 *
 * @author ETP0981
 */
@Generated
public interface IServiceHandlerResolver extends HandlerResolver {

    /**
     * Setter utilisé pour injecter par Spring le headerServiceHandler
     *
     * @param headerServiceHandler Objet headerServiceHandler à injecter
     */
    void setHeaderServiceHandler(HeaderServiceHandler headerServiceHandler);

}
