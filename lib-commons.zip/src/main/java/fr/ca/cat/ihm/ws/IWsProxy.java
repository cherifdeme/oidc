/**
 *
 */
package fr.ca.cat.ihm.ws;

import fr.ca.cat.ihm.utils.Generated;

/**
 * Proxy fournissant l'objet de WebService configuré et contenant les header de
 * sécurité.
 *
 * @author ETP0981
 */
@Generated
public interface IWsProxy {

    /**
     * Fournit l'objet du WebService.
     *
     * @return la classe du WebService.
     */
    Object getObject();

}
