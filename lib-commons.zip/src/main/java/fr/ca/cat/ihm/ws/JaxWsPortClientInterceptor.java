package fr.ca.cat.ihm.ws;

import fr.ca.cat.ihm.utils.Generated;
import jakarta.jws.WebService;
import jakarta.xml.ws.*;
import jakarta.xml.ws.soap.SOAPFaultException;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.factory.BeanClassLoaderAware;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.lang.Nullable;
import org.springframework.util.Assert;
import org.springframework.util.ClassUtils;
import org.springframework.util.StringUtils;

import javax.xml.namespace.QName;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

@Generated
public class JaxWsPortClientInterceptor extends LocalJaxWsServiceFactory implements MethodInterceptor, BeanClassLoaderAware, InitializingBean {
    private final Object preparationMonitor = new Object();
    @Nullable
    private Service jaxWsService;
    @Nullable
    private String portName;
    @Nullable
    private String username;
    @Nullable
    private String password;
    @Nullable
    private String endpointAddress;
    private boolean maintainSession;
    private boolean useSoapAction;
    @Nullable
    private String soapActionUri;
    @Nullable
    private Map<String, Object> customProperties;
    @Nullable
    private WebServiceFeature[] portFeatures;
    @Nullable
    private Class<?> serviceInterface;
    private boolean lookupServiceOnStartup = true;
    @Nullable
    private ClassLoader beanClassLoader = ClassUtils.getDefaultClassLoader();
    @Nullable
    private QName portQName;
    @Nullable
    private Object portStub;

    @Nullable
    public Service getJaxWsService() {
        return this.jaxWsService;
    }

    public void setJaxWsService(@Nullable Service jaxWsService) {
        this.jaxWsService = jaxWsService;
    }

    @Nullable
    public String getPortName() {
        return this.portName;
    }

    public void setPortName(@Nullable String portName) {
        this.portName = portName;
    }

    @Nullable
    public String getUsername() {
        return this.username;
    }

    public void setUsername(@Nullable String username) {
        this.username = username;
    }

    @Nullable
    public String getPassword() {
        return this.password;
    }

    public void setPassword(@Nullable String password) {
        this.password = password;
    }

    @Nullable
    public String getEndpointAddress() {
        return this.endpointAddress;
    }

    public void setEndpointAddress(@Nullable String endpointAddress) {
        this.endpointAddress = endpointAddress;
    }

    public boolean isMaintainSession() {
        return this.maintainSession;
    }

    public void setMaintainSession(boolean maintainSession) {
        this.maintainSession = maintainSession;
    }

    public boolean isUseSoapAction() {
        return this.useSoapAction;
    }

    public void setUseSoapAction(boolean useSoapAction) {
        this.useSoapAction = useSoapAction;
    }

    @Nullable
    public String getSoapActionUri() {
        return this.soapActionUri;
    }

    public void setSoapActionUri(@Nullable String soapActionUri) {
        this.soapActionUri = soapActionUri;
    }

    public Map<String, Object> getCustomProperties() {
        if (this.customProperties == null)
            this.customProperties = new HashMap<>();
        return this.customProperties;
    }

    public void setCustomProperties(Map<String, Object> customProperties) {
        this.customProperties = customProperties;
    }

    public void addCustomProperty(String name, Object value) {
        getCustomProperties().put(name, value);
    }

    public void setPortFeatures(WebServiceFeature... features) {
        this.portFeatures = features;
    }

    @Nullable
    public Class<?> getServiceInterface() {
        return this.serviceInterface;
    }

    public void setServiceInterface(@Nullable Class<?> serviceInterface) {
        if (serviceInterface != null)
            Assert.isTrue(serviceInterface.isInterface(), "'serviceInterface' must be an interface");
        this.serviceInterface = serviceInterface;
    }

    public void setLookupServiceOnStartup(boolean lookupServiceOnStartup) {
        this.lookupServiceOnStartup = lookupServiceOnStartup;
    }

    @Nullable
    protected ClassLoader getBeanClassLoader() {
        return this.beanClassLoader;
    }

    public void setBeanClassLoader(@Nullable ClassLoader classLoader) {
        this.beanClassLoader = classLoader;
    }

    public void afterPropertiesSet() {
        if (this.lookupServiceOnStartup)
            prepare();
    }

    public void prepare() {
        Class<?> ifc = getServiceInterface();
        Assert.notNull(ifc, "Property 'serviceInterface' is required");
        WebService ann = ifc.<WebService>getAnnotation(WebService.class);
        if (ann != null)
            applyDefaultsFromAnnotation(ann);
        Service serviceToUse = getJaxWsService();
        if (serviceToUse == null)
            serviceToUse = createJaxWsService();
        this.portQName = getQName((getPortName() != null) ? getPortName() : ifc.getName());
        Object stub = getPortStub(serviceToUse, (getPortName() != null) ? this.portQName : null);
        preparePortStub(stub);
        this.portStub = stub;
    }

    protected void applyDefaultsFromAnnotation(WebService ann) {
        if (getWsdlDocumentUrl() == null) {
            String wsdl = ann.wsdlLocation();
            if (StringUtils.hasText(wsdl))
                try {
                    setWsdlDocumentUrl(new URL(wsdl));
                } catch (MalformedURLException ex) {
                    throw new IllegalStateException("Encountered invalid @Service wsdlLocation value [" + wsdl + "]", ex);
                }
        }
        if (getNamespaceUri() == null) {
            String ns = ann.targetNamespace();
            if (StringUtils.hasText(ns))
                setNamespaceUri(ns);
        }
        if (getServiceName() == null) {
            String sn = ann.serviceName();
            if (StringUtils.hasText(sn))
                setServiceName(sn);
        }
        if (getPortName() == null) {
            String pn = ann.portName();
            if (StringUtils.hasText(pn))
                setPortName(pn);
        }
    }

    protected boolean isPrepared() {
        synchronized (this.preparationMonitor) {
            return (this.portStub != null);
        }
    }

    @Nullable
    protected final QName getPortQName() {
        return this.portQName;
    }

    protected Object getPortStub(Service service, @Nullable QName portQName) {
        if (this.portFeatures != null)
            return (portQName != null) ? service.getPort(portQName, getServiceInterface(), this.portFeatures) : service
                    .getPort(getServiceInterface(), this.portFeatures);
        return (portQName != null) ? service.getPort(portQName, getServiceInterface()) : service
                .getPort(getServiceInterface());
    }

    protected void preparePortStub(Object stub) {
        Map<String, Object> stubProperties = new HashMap<>();
        String username = getUsername();
        if (username != null) {
            stubProperties.put(BindingProvider.USERNAME_PROPERTY, username);
        }
        String password = getPassword();
        if (password != null) {
            stubProperties.put(BindingProvider.PASSWORD_PROPERTY, password);
        }
        String endpointAddress = getEndpointAddress();
        if (endpointAddress != null) {
            stubProperties.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, endpointAddress);
        }
        if (isMaintainSession()) {
            stubProperties.put(BindingProvider.SESSION_MAINTAIN_PROPERTY, Boolean.TRUE);
        }
        if (isUseSoapAction()) {
            stubProperties.put(BindingProvider.SOAPACTION_USE_PROPERTY, Boolean.TRUE);
        }
        String soapActionUri = getSoapActionUri();
        if (soapActionUri != null) {
            stubProperties.put(BindingProvider.SOAPACTION_URI_PROPERTY, soapActionUri);
        }
        stubProperties.putAll(getCustomProperties());
        if (!stubProperties.isEmpty()) {
            if (!(stub instanceof BindingProvider)) {
                throw new RuntimeException("Port stub of class [" + stub.getClass().getName() +
                        "] is not a customizable JAX-WS stub: it does not implement interface [javax.xml.ws.BindingProvider]");
            }
            ((BindingProvider) stub).getRequestContext().putAll(stubProperties);
        }
    }

    @Nullable
    protected Object getPortStub() {
        return this.portStub;
    }

    @Nullable
    public Object invoke(MethodInvocation invocation) throws Throwable {
        if (AopUtils.isToStringMethod(invocation.getMethod()))
            return "JAX-WS proxy for port [" + getPortName() + "] of service [" + getServiceName() + "]";
        synchronized (this.preparationMonitor) {
            if (!isPrepared())
                prepare();
        }
        return doInvoke(invocation);
    }

    @Nullable
    protected Object doInvoke(MethodInvocation invocation) throws Throwable {
        try {
            return doInvoke(invocation, getPortStub());
        } catch (SOAPFaultException ex) {
            throw ex;
        } catch (ProtocolException ex) {
            throw ex;
        } catch (WebServiceException ex) {
            throw ex;
        }
        //return invocation;
    }

    @Nullable
    protected Object doInvoke(MethodInvocation invocation, @Nullable Object portStub) throws Throwable {
        Method method = invocation.getMethod();
        try {
            return method.invoke(portStub, invocation.getArguments());
        } catch (InvocationTargetException ex) {
            throw ex.getTargetException();
        } catch (Throwable ex) {
            throw ex;
        }
        //return method;
    }
}
