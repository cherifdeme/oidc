package fr.ca.cat.ihm.ws;

import fr.ca.cat.ihm.utils.Generated;
import jakarta.xml.ws.BindingProvider;
import org.aopalliance.aop.Advice;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.lang.Nullable;
import org.springframework.util.Assert;

@Generated
public class JaxWsPortProxyFactoryBean extends JaxWsPortClientInterceptor implements FactoryBean<Object> {
    @Nullable
    private Object serviceProxy;

    public void afterPropertiesSet() {
        super.afterPropertiesSet();
        Class<?> ifc = getServiceInterface();
        Assert.notNull(ifc, "Property 'serviceInterface' is required");
        ProxyFactory pf = new ProxyFactory();
        pf.addInterface(ifc);
        pf.addInterface(BindingProvider.class);
        pf.addAdvice((Advice) this);
        this.serviceProxy = pf.getProxy(getBeanClassLoader());
    }

    @Nullable
    public Object getObject() {
        return this.serviceProxy;
    }

    public Class<?> getObjectType() {
        return getServiceInterface();
    }

    public boolean isSingleton() {
        return true;
    }
}
