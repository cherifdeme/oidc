package fr.ca.cat.ihm.ws;

import fr.ca.cat.ihm.utils.Generated;
import jakarta.xml.ws.Service;
import jakarta.xml.ws.WebServiceFeature;
import jakarta.xml.ws.handler.HandlerResolver;
import org.springframework.core.io.Resource;
import org.springframework.lang.Nullable;
import org.springframework.util.Assert;

import javax.xml.namespace.QName;
import java.io.IOException;
import java.net.URL;
import java.util.concurrent.Executor;

@Generated
public class LocalJaxWsServiceFactory {
    @Nullable
    private URL wsdlDocumentUrl;

    @Nullable
    private String namespaceUri;

    @Nullable
    private String serviceName;

    @Nullable
    private WebServiceFeature[] serviceFeatures;

    @Nullable
    private Executor executor;

    @Nullable
    private HandlerResolver handlerResolver;

    public void setWsdlDocumentResource(Resource wsdlDocumentResource) throws IOException {
        Assert.notNull(wsdlDocumentResource, "WSDL Resource must not be null");
        this.wsdlDocumentUrl = wsdlDocumentResource.getURL();
    }

    @Nullable
    public URL getWsdlDocumentUrl() {
        return this.wsdlDocumentUrl;
    }

    public void setWsdlDocumentUrl(@Nullable URL wsdlDocumentUrl) {
        this.wsdlDocumentUrl = wsdlDocumentUrl;
    }

    @Nullable
    public String getNamespaceUri() {
        return this.namespaceUri;
    }

    public void setNamespaceUri(@Nullable String namespaceUri) {
        this.namespaceUri = (namespaceUri != null) ? namespaceUri.trim() : null;
    }

    @Nullable
    public String getServiceName() {
        return this.serviceName;
    }

    public void setServiceName(@Nullable String serviceName) {
        this.serviceName = serviceName;
    }

    public void setServiceFeatures(WebServiceFeature... serviceFeatures) {
        this.serviceFeatures = serviceFeatures;
    }

    public void setExecutor(@Nullable Executor executor) {
        this.executor = executor;
    }

    public void setHandlerResolver(@Nullable HandlerResolver handlerResolver) {
        this.handlerResolver = handlerResolver;
    }

    public Service createJaxWsService() {
        Service service;
        Assert.notNull(this.serviceName, "No service name specified");
        if (this.serviceFeatures != null) {
            service = (this.wsdlDocumentUrl != null) ? Service.create(this.wsdlDocumentUrl, getQName(this.serviceName), this.serviceFeatures) : Service.create(getQName(this.serviceName), this.serviceFeatures);
        } else {
            service = (this.wsdlDocumentUrl != null) ? Service.create(this.wsdlDocumentUrl, getQName(this.serviceName)) : Service.create(getQName(this.serviceName));
        }
        if (this.executor != null)
            service.setExecutor(this.executor);
        if (this.handlerResolver != null)
            service.setHandlerResolver(this.handlerResolver);
        return service;
    }

    protected QName getQName(String name) {
        return (getNamespaceUri() != null) ? new QName(getNamespaceUri(), name) : new QName(name);
    }
}