/**
 *
 */
package fr.ca.cat.ihm.ws;

import fr.ca.cat.ihm.utils.Generated;
import fr.ca.cat.ihm.ws.impl.ServiceHandlerResolverImpl;

/**
 * Fournit l'implementation de la classe d'injection du jeton SAML dans les
 * header des WebServices
 *
 * @author ETP0981
 */
@Generated
public final class ServiceHandlerResolverFactory {

    /**
     * Constructeur privé pour bloquer l'instanciation
     */
    private ServiceHandlerResolverFactory() {
    }

    /**
     * Fournit la classe pour la gestion de la classe d'injection du jeton SAML
     * dans les header des WebServices.
     *
     * @return ISecurity
     */
    public static IServiceHandlerResolver getServiceHandlerResolver() {
        return new ServiceHandlerResolverImpl();
    }

}
