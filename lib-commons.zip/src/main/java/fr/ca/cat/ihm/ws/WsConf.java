package fr.ca.cat.ihm.ws;

import java.net.URL;

/**
 * Objet de configuration d'un WebService.
 *
 * @author ETP0981
 */

/**
 * @author ET01528
 */
public class WsConf {

    /**
     * Interface du service pour lequel le proxy est créé.
     */
    private Class<?> serviceInterface;
    /**
     * URL du document WSDL qui définit le service.
     */
    private URL wsdlDocumentUrl;
    /**
     * Namespace URI du service.<br>
     * Correspond au champ "targetNamespace" du WSDL.
     */
    private String namespaceUri;
    /**
     * Point d'accès au WebService.
     */
    private String endpointAddress;
    /**
     * Nom du service.
     */
    private String serviceName;
    /**
     * Nom du port du service.
     */
    private String portName;


    /**
     * Retourne l'interface du service pour lequel le proxy est créé.
     *
     * @return serviceInterface
     */
    public Class<?> getServiceInterface() {
        return serviceInterface;
    }

    /**
     * Définit l'interface du service pour lequel le proxy est créé.
     *
     * @param serviceInterface serviceInterface à définir
     */
    public void setServiceInterface(final Class<?> serviceInterface) {
        this.serviceInterface = serviceInterface;
    }

    /**
     * Retourne l'URL du document WSDL qui décrit le service.
     *
     * @return wsdlDocumentUrl
     */
    public URL getWsdlDocumentUrl() {
        return wsdlDocumentUrl;
    }

    /**
     * Définit l'URL du document WSDL qui définit le service.
     *
     * @param wsdlDocumentUrl
     */
    public void setWsdlDocumentUrl(final URL wsdlDocumentUrl) {
        this.wsdlDocumentUrl = wsdlDocumentUrl;
    }

    /**
     * Retourne le namespace URI du service.
     *
     * @return namespaceUri
     */
    public String getNamespaceUri() {
        return namespaceUri;
    }

    /**
     * Définit le namespace URI du service.<br>
     * Correspond au champ "targetNamespace" du WSDL.
     *
     * @param namespaceUri
     */
    public void setNamespaceUri(final String namespaceUri) {
        this.namespaceUri = namespaceUri;
    }

    /**
     * Retourne le point d'accès au WebService.
     *
     * @return endpointAddress
     */
    public String getEndpointAddress() {
        return endpointAddress;
    }

    /**
     * Définit le point d'accès du WebService.
     *
     * @param endpointAddress
     */
    public void setEndpointAddress(final String endpointAddress) {
        this.endpointAddress = endpointAddress;
    }

    /**
     * Retourne le nom du service.
     *
     * @return serviceName
     */
    public String getServiceName() {
        return serviceName;
    }

    /**
     * Définit le nom du service.
     *
     * @param serviceName
     */
    public void setServiceName(final String serviceName) {
        this.serviceName = serviceName;
    }

    /**
     * Définit le nom du port.<br>
     * Correspond au "wsdl:port".
     *
     * @return portName
     */
    public String getPortName() {
        return portName;
    }

    /**
     * Retourne le nom du port.
     *
     * @param portName
     */
    public void setPortName(final String portName) {
        this.portName = portName;
    }
}
