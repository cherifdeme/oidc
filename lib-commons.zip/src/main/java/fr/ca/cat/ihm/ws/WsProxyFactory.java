/**
 *
 */
package fr.ca.cat.ihm.ws;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.utils.Generated;
import fr.ca.cat.ihm.utils.Version;
import fr.ca.cat.ihm.ws.impl.HeaderServiceHandler;
import fr.ca.cat.ihm.ws.impl.WsProxyImpl;

/**
 * Fournit l'implementation du proxy permettant d'injecter les configurations du
 * WebService et les informations de sécurité header des WebServices
 *
 * @author ETP0981
 */
@Generated
public final class WsProxyFactory {

    /**
     * Constructeur privé pour bloquer l'instanciation
     */
    private WsProxyFactory() {
    }

    /**
     * Fournit la classe pour la gestion du proxy des WebServices.
     *
     * @return IWsProxy
     */
    public static IWsProxy getWsProxy(final WsConf wsConf,
                                      final HeaderServiceHandler headerServiceHandler) {
        return new WsProxyImpl(wsConf, headerServiceHandler);
    }

    /**
     * Retourne le proxy permettant d'injecter les headers de sécurité dans la
     * requête SOA.
     *
     * @param <T>
     * @param wsConf
     * @param context
     * @param consumerId      identifiant du consommateur SOA (notion de contrat sur la
     *                        couche médiation). Pour une UA standard, c'est l'id UA
     * @param consumerVersion identifiant de version du consommateur SOA (notion de contrat
     *                        sur la couche médiation). Pour une UA standard, c'est la
     *                        version V.nn de l'UA.
     * @return Le proxy.
     */
    @SuppressWarnings("unchecked")
    public static final <T> T getWsProxy(final WsConf wsConf,
                                         final Context context, final String consumerId,
                                         final Version consumerVersion) {

        // la fabrication du contexte dans les différents controleur socle ne
        // garantit pas qu'il contienne un uaID et une version cohérents
        // avec les contrats détenus par la couche SOA.
        final Context ctx4soap = new Context(context.getBrowser(),
                context.getPerformanceDTO(), context.getSecurityDTO(),
                consumerId, consumerVersion, context.getContextExecution());

        final HeaderServiceHandler headerServiceHandler = new HeaderServiceHandler(
                ctx4soap, wsConf);

        final IWsProxy wsProxy = WsProxyFactory.getWsProxy(wsConf,
                headerServiceHandler);
        return (T) wsProxy.getObject();
    }

}
