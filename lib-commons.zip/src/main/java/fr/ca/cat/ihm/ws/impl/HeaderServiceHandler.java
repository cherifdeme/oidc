package fr.ca.cat.ihm.ws.impl;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.controller.bean.ContextExecution;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.logger.TypeLogger;
import fr.ca.cat.ihm.security.dto.SecurityDTO;
import fr.ca.cat.ihm.security.tools.SecuritySoapConstants;
import fr.ca.cat.ihm.utils.ContextHelper;
import fr.ca.cat.ihm.utils.Generated;
import fr.ca.cat.ihm.utils.RequestUtils;
import fr.ca.cat.ihm.ws.WsConf;
import fr.ca.cat.most.util.log.MDCConstants;
import fr.ca.cat.securite.saml.UserCatFactory;
import jakarta.xml.soap.*;
import jakarta.xml.ws.handler.MessageContext;
import jakarta.xml.ws.handler.soap.SOAPHandler;
import jakarta.xml.ws.handler.soap.SOAPMessageContext;
import org.slf4j.MDC;
import org.w3c.dom.Element;

import javax.xml.namespace.QName;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

/**
 * SOAPHandler utilisé à chaque consommation d'un WebService. L'injection se
 * fait via le {@link ServiceHandlerResolverImpl}.<br>
 * Ce Handler est chargé d'injecter les headers MOST dans toutes les requêtes
 * SOAP (message sortant). Cela concerne le Header CA-Tech, CA-Group, et le
 * jeton SAML lié à l'utilisateur appelant. <br>
 * Ces Headers sont obligatoires pour que le DataPower valide la requête SOAP et
 * propage l'appel de consommation WebService
 */
@Generated
public class HeaderServiceHandler implements SOAPHandler<SOAPMessageContext> {

    // Numero de version du Header sur Most (1.0)
    private static final String VERSION = "1.0";

    private static final Logger LOGGER = LogFactory.getLog(TypeLogger.LOGGER_SOCLE);

    private SecurityDTO securityDTO;

    private Context context;


    /**
     * @param context Contexte d'exécution, récupéré au niveau du controleur ou de l'orchestrateur
     * @param pConf   utile pour les traces : permettre de connaitre le service pour lequel on travaille
     */
    public HeaderServiceHandler(final Context context, final WsConf pConf) {
        super();
        this.context = context;
        if (context != null) {
            this.securityDTO = context.getSecurityDTO();
        }
    }

    /**
     * @return context
     */
    public Context getContext() {
        return context;
    }

    /**
     * @see jakarta.xml.ws.handler.soap.SOAPHandler#getHeaders()
     */
    @Override
    public Set<QName> getHeaders() {
        return null;
    }

    /**
     * @see jakarta.xml.ws.handler.Handler#close(jakarta.xml.ws.handler.MessageContext)
     */
    @Override
    public void close(final MessageContext arg0) {
    }

    /**
     * @see jakarta.xml.ws.handler.Handler#handleFault(jakarta.xml.ws.handler.MessageContext)
     */
    @Override
    public boolean handleFault(final SOAPMessageContext arg0) {
        return false;
    }

    /**
     * Cette méthode est appelée à chaque émission ou réception d'un message SOAP.
     * Pas de perfMonitoring,traces de perfs manuelles pour connaitre le service effectivement sollicité
     *
     * @see jakarta.xml.ws.handler.Handler#handleMessage(jakarta.xml.ws.handler.MessageContext)
     */
    @Override
    public boolean handleMessage(final SOAPMessageContext arg0) {

        boolean success = true;

        if (((Boolean) arg0.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY)).booleanValue()) {

            try {
                buildHttpHeaders(arg0);
                // Récupération de l'envelope du message SOAP pour la manipuler
                final SOAPEnvelope envelope = arg0.getMessage().getSOAPPart().getEnvelope();

                envelope.addNamespaceDeclaration("xsd", "http://www.w3.org/2001/XMLSchema");
                envelope.addNamespaceDeclaration("xsi", "http://www.w3.org/2001/XMLSchema-instance");

                // Récupération du header de la requête SOAP s'il existe, sinon
                // création du header
                SOAPHeader header = envelope.getHeader();
                if (null == header) {
                    header = envelope.addHeader();
                }

                // Utilisation de la SOAPFactory pour créer les éléments du header
                final SOAPFactory soapFactory = SOAPFactory.newInstance();

                // Création du CA-TECH Header
                final Name name = envelope.createName(SecuritySoapConstants.HEADER_TECH, SecuritySoapConstants.PREFIX_HEADER_TECH, SecuritySoapConstants.NAMESPACE_HEADER_TECH);
                final SOAPHeaderElement caTechHeaderElement = header.addHeaderElement(name);

                // Numero de version du Header sur Most
                caTechHeaderElement.addAttribute(envelope.createName(SecuritySoapConstants.NUM_VERSION), VERSION);

                // Identifiant de l'application consommatrice
                final SOAPElement consumer = caTechHeaderElement.addChildElement(
                                envelope.createName(SecuritySoapConstants.CONSUMER, SecuritySoapConstants.PREFIX_HEADER_TECH, SecuritySoapConstants.NAMESPACE_HEADER_TECH))
                        .addTextNode(getContext().getUaId());
                // Version de l'application consommatrice
                consumer.addAttribute(envelope.createName(SecuritySoapConstants.VERSION), getContext().getUaVersion().getCurrent());

                final ContextExecution ctxExe = getContext().getContextExecution();

                // Caisse régionale de l'utilisateur
                final SOAPElement dataContext = caTechHeaderElement.addChildElement(
                        envelope.createName(SecuritySoapConstants.DATA_CONTEXT, SecuritySoapConstants.PREFIX_HEADER_TECH, SecuritySoapConstants.NAMESPACE_HEADER_TECH));
                dataContext.addAttribute(envelope.createName(SecuritySoapConstants.CR_ID), ctxExe.getProfile().getStructureId());


                // Création du header SOAP HeaderApplicationContext
                final SOAPHeaderElement headerAppliContext = header.addHeaderElement(envelope.createName(
                        SecuritySoapConstants.HEADER_APPLI_CONTEXT,
                        SecuritySoapConstants.PREFIX_HEADER_APPLI_CONTEXT,
                        SecuritySoapConstants.NAMESPACE_HEADER_APPLI_CONTEXT));


                // ajout des attributs du header
                // version du header
                headerAppliContext.addAttribute(envelope.createName(SecuritySoapConstants.VERSION), ContextHelper.VERSION_CONTEXT_EXE);
                // identifiant du poste opérationnel
                headerAppliContext.addAttribute(envelope.createName(SecuritySoapConstants.OPERATIONAL_POST), ctxExe.getSystemInfo().getOperationalPost().getId());
                // identifiant de l'EDS de connexion
                headerAppliContext.addAttribute(envelope.createName(SecuritySoapConstants.CONNECTION_EDS), ctxExe.getSystemInfo().getEds().getId());
                // identificant du poste fonctionnel de l'EDS
                headerAppliContext.addAttribute(envelope.createName(SecuritySoapConstants.FUNCTIONAL_POST_EDS), ctxExe.getProfile().getFunctionalPost().getEdsId());
                // identifiant du canal
                headerAppliContext.addAttribute(envelope.createName(SecuritySoapConstants.CHANNEL), ctxExe.getSessionMode().getCanal());
                // identifiant du canal de distribution
                headerAppliContext.addAttribute(envelope.createName(SecuritySoapConstants.DISTRIB_CHANNEL), ctxExe.getSessionMode().getDistribCanal());
                // identifiant de la session du portail
                headerAppliContext.addAttribute(envelope.createName(SecuritySoapConstants.SESSION_PORTAL), ctxExe.getSessionMode().getIdSessionPortail());
                // identifiant de corrélation
                headerAppliContext.addAttribute(envelope.createName(SecuritySoapConstants.ID_CORRELATION), getContext().getCorrelationId());
                // type CASA de l'utilisateur
                headerAppliContext.addAttribute(envelope.createName(SecuritySoapConstants.USER_TYPE_CASA), ctxExe.getProfile().getUser().getType());
                // réseau bancaire
                headerAppliContext.addAttribute(envelope.createName(SecuritySoapConstants.BANK_NETWORK), ctxExe.getProfile().getBankNetwork());

                //on essaie sans utiliser le contexte, on fait confiance à SLF4J
                headerAppliContext.addAttribute(envelope.createName(SecuritySoapConstants.ID_CONSOMMATEUR_ORIGINE), MDC.get(MDCConstants.idConsommateurOrigine));
                headerAppliContext.addAttribute(envelope.createName(SecuritySoapConstants.VERSION_CONSOMMATEUR_ORIGINE), MDC.get(MDCConstants.versionConsommateurOrigine));


                // Création du SAMLHeader à partir du jeton SAML lié à
                // l'utilisateur
                final Name samlHeader = envelope.createName("Security", "wsse", "http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd");
                final SOAPHeaderElement samlHeaderElement = header.addHeaderElement(samlHeader);

                // pousser le jeton SAML ds les headers
                // L'attribut 'MustUnderstand' est qualifié à 'false' pour
                // éviter les conflits ou problèmes liés aux doublons dans les namespaces
                samlHeaderElement.setMustUnderstand(false);

                //dans le doute on reparse localement le jeton SAML pour obtenir un dom element "local"
                Element samlEltConstruitLocalement = UserCatFactory.getSamlElement(this.securityDTO.getUserDTO().getSamlToken());
                samlHeaderElement.addChildElement(soapFactory.createElement(samlEltConstruitLocalement));


            } catch (Exception e) {
                LOGGER.warn(e.getMessage(), e, getContext());
                success = false;
            }
        }
        return success;
    }

    private SOAPMessageContext buildHttpHeaders(SOAPMessageContext arg0) {
        HashMap<String, List<String>> headers = new HashMap<>();
        ArrayList<String> dummy = new ArrayList<>(1);
        dummy.add(context.getCorrelationId());
        headers.put(SecuritySoapConstants.ID_CORRELATION, dummy);
        String k8s = context.getVpucK8s();
        if (!k8s.isEmpty()) {
            dummy = new ArrayList<>(1);
            dummy.add(k8s);
            headers.put(RequestUtils.COOKIE_VPUC_K8S, dummy);

            dummy = new ArrayList<>(1);
            dummy.add(k8s);
            headers.put(RequestUtils.HEADER_VPUC_K8S, dummy);
        }
        dummy = new ArrayList<>(1);
        dummy.add(context.getSecurityDTO().getUserDTO().getId());
        headers.put(RequestUtils.LOGIN, dummy);
        arg0.put(MessageContext.HTTP_REQUEST_HEADERS, headers);
        return arg0;
    }
}
