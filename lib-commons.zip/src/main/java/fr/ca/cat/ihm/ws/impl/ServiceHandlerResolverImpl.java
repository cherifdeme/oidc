package fr.ca.cat.ihm.ws.impl;

import fr.ca.cat.ihm.ws.IServiceHandlerResolver;
import jakarta.xml.ws.handler.Handler;
import jakarta.xml.ws.handler.PortInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * HandlerResolver qui permet de gérer les handlers qui vont être utilisés lors
 * de la consommation de WebServices.
 */
public class ServiceHandlerResolverImpl implements IServiceHandlerResolver {

    private HeaderServiceHandler headerServiceHandler;

    /**
     * @see jakarta.xml.ws.handler.HandlerResolver#getHandlerChain(jakarta.xml.ws.handler.PortInfo)
     */
    @Override
    public List<Handler> getHandlerChain(final PortInfo arg0) {
        final List<Handler> handlers = new ArrayList<>();
        // Ajout du SOAPHandler chargé d'injecter les en-têtes MOST dans la
        // requête SOAP
        handlers.add(headerServiceHandler);
        return handlers;
    }

    /**
     * {@inheritDoc}
     */
    public void setHeaderServiceHandler(final HeaderServiceHandler headerServiceHandler) {
        this.headerServiceHandler = headerServiceHandler;
    }
}
