/**
 *
 */
package fr.ca.cat.ihm.ws.impl;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.logger.PerfMessage;
import fr.ca.cat.ihm.logger.TypeLogger;
import fr.ca.cat.ihm.ws.*;
import fr.ca.cat.most.util.log.MostCode;
import org.aopalliance.intercept.MethodInvocation;

/**
 * Proxy fournissant l'objet de WebService configuré et contenant les header de
 * sécurité.
 *
 * @author ETP0981
 */
public class WsProxyImpl extends JaxWsPortProxyFactoryBean implements IWsProxy {

    // L'instance de logger pour cette classe.
    private static final Logger LOGGER = LogFactory.getLog(TypeLogger.LOGGER_SOCLE);
    private static final MostCode MC_PERF_SOA_INVOKE = new MostCode("IHME-SOA_CALL");

    public WsProxyImpl(final WsConf wsConf, final HeaderServiceHandler headerServiceHandler) {

        super();

        final Context ctx = headerServiceHandler.getContext();
        if (LOGGER.isDebugEnabled()) {
            String message = "Construction proxy pour appel webservice avec adresse = " + wsConf.getEndpointAddress() +
                    ", serviceName = " +
                    wsConf.getServiceName() +
                    ", portName = " +
                    wsConf.getPortName();
            LOGGER.debug(message, ctx);
        }

        this.setServiceInterface(wsConf.getServiceInterface());
        this.setWsdlDocumentUrl(wsConf.getWsdlDocumentUrl());
        this.setNamespaceUri(wsConf.getNamespaceUri());
        this.setEndpointAddress(wsConf.getEndpointAddress());
        this.setServiceName(wsConf.getServiceName());
        this.setPortName(wsConf.getPortName());
        final IServiceHandlerResolver serviceHandlerResolver = ServiceHandlerResolverFactory.getServiceHandlerResolver();
        serviceHandlerResolver.setHeaderServiceHandler(headerServiceHandler);
        this.setHandlerResolver(serviceHandlerResolver);
        this.afterPropertiesSet();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Object invoke(final MethodInvocation invocation) throws Throwable {
        final long start = System.currentTimeMillis();
        final Object invoked = super.invoke(invocation);
        final long end = System.currentTimeMillis();

        final PerfMessage msg = new PerfMessage((int) (end - start), "callSOA.invoke " + invocation.getMethod().getName());
        msg.setFunctionName("invoke");
        msg.setUri(getEndpointAddress());

        LOGGER.perf(MC_PERF_SOA_INVOKE, msg.getTimeInMs(), msg.toString(), null);

        return invoked;
    }
}
