package fr.ca.cat.ihm;


import fr.ca.cat.ihm.bundle.ResourceBundleFactory;
import fr.ca.cat.ihm.error.BundleErrorManagerImpl;
import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.redis.RedisCacheService;
import fr.ca.cat.ihm.resilience.ConfigurationResilience4jModules;
import fr.ca.cat.ihm.security.impl.MockFileSecurityImpl;
import fr.ca.cat.ihm.url.PropertiesUrlServiceImpl;
import fr.ca.cat.ihm.utils.Generated;
import fr.ca.cat.ihm.validation.ValidationProcessorImpl;
import fr.ca.cat.ihm.validation.impl.DynamicValidatorImpl;
import fr.ca.cat.ihm.web.client.RsConf;
import fr.ca.cat.ihm.ws.WsConf;
import fr.ca.cat.ihm.ws.generated.srvutestsoclesoa.SRVUTestSocleSOA;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.timelimiter.TimeLimiterRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.PropertiesFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.ResourceLoader;

import java.io.IOException;

/**
 * for test
 */
@Configuration
@Generated
public class BeanConfigurationTest {
    @Autowired
    private ResourceLoader resourceLoader;

    @Bean
    @Qualifier("bundleTest")
    public ResourceBundleMessageSource messageSource() {
        ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();
        String[] baseNames = new String[]{"bundle/ErrorTestMessage",
                "bundle/test_message",
                "bundle/fwk_errorbundle",
                "bundle/fwkmessage",
                "bundle/onlyDefault_errorbundle",
                "bundle/test_errorbundle",
                "bundle/test_junit_errorbundle"};
        messageSource.setBasenames(baseNames);
        messageSource.setDefaultEncoding("UTF-8");

        System.out.println("baseName set " + messageSource.getBasenameSet());
        return messageSource;
    }
    @Bean
    public BundleErrorManagerImpl error(@Qualifier("BundleServiceBean") ResourceBundleFactory resourceBundleFactory) {
        return new BundleErrorManagerImpl(resourceBundleFactory);
    }

    @Bean("BundleServiceBean")
    @Autowired
    public ResourceBundleFactory bundleService(@Qualifier("bundleTest") ResourceBundleMessageSource messageSource) {
        return new ResourceBundleFactory(messageSource);
    }

    public PropertiesFactoryBean configProperties() {
        PropertiesFactoryBean factoryBean = new PropertiesFactoryBean();
        factoryBean.setLocation(new ClassPathResource("socle.beans.properties"));
        return factoryBean;
    }

    @Bean
    public MockFileSecurityImpl security() {
        MockFileSecurityImpl mockFileSecurityImpl = new MockFileSecurityImpl();
        mockFileSecurityImpl.setAtknTtlMinus(180000);
        return mockFileSecurityImpl;
    }

    @Bean("test_resilience_places")
    public RsConf authentificationCollaborateurV1() {
        RsConf rsConf = new RsConf();
        rsConf.setAuthorization("6ef762f6f19b88fa0fca583ba5d3fe5");
        rsConf.setUrl("http://localhost:8090/places/v1.8");
        return rsConf;
    }

    @Bean("test_resilience_v360")
    public RsConf authentificationCollaborateurV2() {
        RsConf rsConf = new RsConf();
        rsConf.setAuthorization("Ciphered{cd6d320f312da8920cf1cd8393418e771ef2538189bea060416acf0142cba0e5f6b439ca749dfe3e38d3e35d87998476d3cafe72d8e2c40ab47cb2edac62cb1cba2498ea5e395eb7c5073b1d217e8a7798b90c952feed94e97b7606cdc8557828281ee3f38c55695889d5d488b817b46b11ee0e6e2ea81fef5c469bb33a1deedecd151ddee5930330480836621a1d393}");
        rsConf.setUrl("http://localhost:8090/vision360/v2");
        rsConf.setResilientProxy(true);
        return rsConf;
    }

    @Bean("test_resilience_sutestsoclesoa_business")
    public WsConf sutestsoclesoaBusiness() throws IOException {
        WsConf wsConf = new WsConf();
        wsConf.setServiceInterface(SRVUTestSocleSOA.class);
        wsConf.setWsdlDocumentUrl(resourceLoader.getResource("classpath:wsdl/SRVU_TestSocleSOA.wsdl").getURL());
        wsConf.setNamespaceUri("http://fr.ca.cat/srvutestsoclesoa/1/SRVU_TestSocleSOA/");
        wsConf.setEndpointAddress("http://localhost:8090/SRVU_TestSocleSOA_vs");
        wsConf.setServiceName("SRVU_TestSocleSOA_1_0");
        wsConf.setPortName("SRVU_TestSocleSOAPort");
        return wsConf;
    }

    @Bean("authentificationCollaborateurV2")
    public RsConf getConf() {
        RsConf conf = new RsConf();
        conf.setAuthorization("Ciphered{4df0ce0384f60c4b0adae6d6698e58da8cb942c372bbae14d07c7655aea89970402ca50ea7849cef95679013d66f76940843feee8a6a8d488753d2fa24827ea28f1f853e75a85335f03f8572578d44929378632e15185cd25678a07afa1a6b1396e37eae3277516d9394896bdb5cfcf19b5e1b8d2851531a2b7089e780f0f7e2e12ac07ae694f1e880b1b647edc87d657b6f}");
        conf.setUrl("https://dev1-private.api.credit-agricole.fr/authentification_collaborateur/v2");
        return conf;
    }

    @Bean
    public RedisCacheService redisCacheService() {
        return new RedisCacheService(false, "localhost", "6379");
    }

    @Bean
    @Autowired
    public ValidationProcessorImpl validation(@Qualifier("BundleServiceBean") ResourceBundleFactory beanService) {
        return new ValidationProcessorImpl(beanService);
    }

    @Bean
    public DynamicValidatorImpl dynamicValidator() {
        return new DynamicValidatorImpl();
    }

    @Bean
    public PropertiesUrlServiceImpl logicalHost() throws TechnicalException {
        return new PropertiesUrlServiceImpl("socle.logicalhost.properties");
    }


    @Bean
    public ConfigurationResilience4jModules configurationResilience4() {
        return new ConfigurationResilience4jModules();
    }


    @Bean
    public CircuitBreakerRegistry circuitBreakerRegistry() {
        return CircuitBreakerRegistry.ofDefaults();
    }

    @Bean
    public TimeLimiterRegistry timelimiterRegistry() {
        return TimeLimiterRegistry.ofDefaults();
    }

}
