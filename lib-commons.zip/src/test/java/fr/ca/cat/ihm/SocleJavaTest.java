package fr.ca.cat.ihm;

import fr.ca.cat.ihm.controller.bean.Browser;
import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.performance.dto.PerformanceDTO;
import fr.ca.cat.ihm.security.dto.SecurityAPIBean;
import fr.ca.cat.ihm.security.dto.SecurityDTO;
import fr.ca.cat.ihm.security.dto.UserDTO;
import fr.ca.cat.ihm.utils.Generated;
import fr.ca.cat.ihm.utils.Version;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Locale;

/**
 * Classe mère à privilégier pour les tests concernant le socle Java
 * Permet de stocker des méthodes utiles à plusieurs classes de test
 */
@Generated
public class SocleJavaTest {

    public final static String HEADERNAME_AUTHORIZATION = "authorization";
    private final String DEFAULT_VALUE = "Inconnu";

    private String initHeaderAuthorization() throws IOException {

        StringBuilder buffer = new StringBuilder();
        final BufferedReader in = new BufferedReader(new InputStreamReader(
                Thread.currentThread().getContextClassLoader().getResourceAsStream("tai/IDDR001.xml")));
        String currentLine = null;

        while (null != (currentLine = in.readLine())) {
            buffer.append(currentLine + "\n");
        }

        return buffer.toString();
    }

    /**
     * Retourne un contexte avec la langue française
     *
     * @return Context
     * @throws Exception
     */
    public Context getContext() throws Exception {
        return new Context(new Browser("test", new Locale("fr")), new PerformanceDTO("Context"), getSecurity(), "test", new Version("1.0"));
    }

    /**
     * Retourne un contexte avec la langue anglaise
     *
     * @return Context
     * @throws Exception
     */
    public Context getEnglishContext() throws Exception {
        return new Context(new Browser("test", new Locale("en")), new PerformanceDTO("EnglishContext"), getSecurity(), "test", new Version("1.0"));
    }

    /**
     * Retourne un contexte avec une langue bidon
     *
     * @return Context
     * @throws Exception
     */
    public Context getXxContext() throws Exception {
        return new Context(new Browser("test", new Locale("xx")), new PerformanceDTO("XxContext"), getSecurity(), "test", new Version("1.0"));
    }

    /**
     * Retourne un user avec un jeton SAML bouchon
     *
     * @return UserDTO
     * @throws Exception
     */
    public UserDTO getUser() throws Exception {
        return getSecurity().getUserDTO();
    }

    /**
     * Test qui consiste à ne pas tester les classes réelles de la securité
     * Tant qu'à faire autant le rendre performant et ne pas parser le jeton SAML.
     *
     * @return
     * @throws Exception
     */
    public SecurityDTO getSecurity() throws Exception {

        UserDTO user = new UserDTO();

        user.setSamlToken(initHeaderAuthorization());


        user.setBrowser(DEFAULT_VALUE);
        user.setIp(DEFAULT_VALUE);

        user.setConnectionStructureID("87800");
        user.setFuncScopeBOUID("87800");

        user.setFirstName("OW60001");
        user.setLastName("OW60001");
        user.setFunctionalPostID("878003LP3");
        user.setProfile("Agent");
        user.setVip(false);

        for (String habil : "SOPUTOUS".split(",")) {
            user.getResources().add(habil);
        }

        SecurityDTO security = new SecurityDTO();
        final SecurityAPIBean apiSecurity = new SecurityAPIBean();
        apiSecurity.setRefresh_token("test");
        security.setApiSecurity(apiSecurity);
        security.setUserDTO(user);

        return security;
    }

}
