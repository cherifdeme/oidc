package fr.ca.cat.ihm.bundle;

import fr.ca.cat.ihm.SocleJavaTest;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class BundleUtilsTest extends SocleJavaTest {

    private static final String TROISIEME = "troisième";
    private static final String BUNDLE_UTILS = "BundleUtils";

    @Test
    public void testMessagFormat() {
        String text = "text ' et '' var {0} et var {1} et re var {0}";
        String text1 = "text avec' et '' et var {2}";
        String text2 = "text avec' et double'' var {3}";

        Object[] parms = {"mavar", 12, true};

        String res = BundleUtils.formatMessage(text, (Object[]) parms);
        assertEquals("text ' et '' var mavar et var 12 et re var mavar", res);
        res = BundleUtils.formatMessage(text1, (Object[]) parms);
        assertEquals("text avec' et '' et var true", res);
        res = BundleUtils.formatMessage(text2, (Object[]) null);
        assertEquals("text avec' et double'' var {3}", res);
    }

    /**
     * Teste le formatage de message
     */
    @Test
    public void testFormatMessage1() {
        String messageResult = BundleUtils.formatMessage("Ceci est le {0} message de test de la classe {1}", "premier", BUNDLE_UTILS);
        assertEquals("Ceci est le premier message de test de la classe BundleUtils", messageResult);
    }

    /**
     * Teste le formatage de message
     */
    @Test
    public void testFormatMessage2() {
        String messageResult = BundleUtils.formatMessage("Ceci est le {0} message de test", "deuxième", BUNDLE_UTILS);
        assertEquals("Ceci est le deuxième message de test", messageResult);
    }

    /**
     * Teste le formatage de message
     */
    @Test
    public void testFormatMessage3() {
        String messageResult = BundleUtils.formatMessage("Ceci est le {0} message de test de la classe {1}", TROISIEME);
        assertEquals("Ceci est le troisième message de test de la classe {1}", messageResult);
    }

    /**
     * Teste le formatage de message
     */
    @Test
    public void testFormatMessage4() {
        String messageResult = BundleUtils.formatMessage("Ceci est le '{0}' message de test de la classe ''{1}''", TROISIEME, BUNDLE_UTILS);
        assertEquals("Ceci est le 'troisième' message de test de la classe ''BundleUtils''", messageResult);
    }

    /**
     * Teste le formatage de message
     */
    @Test
    public void testFormatMessage5() {
        String messageResult = BundleUtils.formatMessage("Ceci est le '{0}' message de test de la classe ''{1}''", TROISIEME, BUNDLE_UTILS, "Test");
        assertEquals("Ceci est le 'troisième' message de test de la classe ''BundleUtils''", messageResult);
    }

}
