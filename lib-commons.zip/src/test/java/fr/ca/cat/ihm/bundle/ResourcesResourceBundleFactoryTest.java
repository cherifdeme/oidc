package fr.ca.cat.ihm.bundle;

import fr.ca.cat.ihm.BeanConfigurationTest;
import fr.ca.cat.ihm.SocleJavaTest;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.core.io.ResourceLoader;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

/**
 * @author ETP1485
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {BeanConfigurationTest.class})
public class ResourcesResourceBundleFactoryTest extends SocleJavaTest {
    public static final String BUNDLE_FWKMESSAGE = "bundle/fwkmessage";
    String value = null;
    @Autowired
    ResourceBundleMessageSource messageSource;

    @Test
    public void testGetBundleFrancais() {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
        Date date1 = Calendar.getInstance().getTime();
        messageSource.getMessage("TECHNICAL_PORTAL_STATUS_LEAVING", null, Locale.FRANCE);
        Date date2 = Calendar.getInstance().getTime();

        messageSource.getMessage("TECHNICAL_CATALOG_INCORRECT_FORMAT", null, Locale.FRANCE);
        Date date3 = Calendar.getInstance().getTime();

        messageSource.getMessage("TECHNICAL_CATALOG_INCORRECT_FORMAT", null, Locale.FRANCE);
        Date date4 = Calendar.getInstance().getTime();

        messageSource.getMessage("TECHNICAL_BUSINESS_REFERENTIAL", null, Locale.FRANCE);
        Date date5 = Calendar.getInstance().getTime();

        System.out.println(sdf.format(date1));
        System.out.println(sdf.format(date2));
        System.out.println(sdf.format(date3));
        System.out.println(sdf.format(date4));
        System.out.println(sdf.format(date5));

        assertNotNull("Le bundle ne peut pas être null", messageSource);
    }

    @Test
    public void testGetBundleAnglais() {
        messageSource.setBasename(BUNDLE_FWKMESSAGE);
        messageSource.setDefaultLocale(Locale.ENGLISH);
        assertNotNull("Le bundle ne peut pas être null", messageSource);
    }

    @Test
    public void testGetBundleLangueInconnue() {
        messageSource.setBasename(BUNDLE_FWKMESSAGE);
        assertNotNull("Le bundle ne peut pas être null", messageSource);
    }

    @Test
    public void testGetStringAvecBundleFrancais() {
        value = messageSource.getMessage("test", null, Locale.FRANCE);
        assertEquals("Ceci est un test", value);
    }

    @Test
    public void testGetStringAvecBundleAnglais() {
        value = messageSource.getMessage("test", null, Locale.ENGLISH);
        assertEquals("This is a test", value);
    }

    @Test
    public void testGetStringAvecBundleLangueInconnue() {
        messageSource.setBasename(BUNDLE_FWKMESSAGE);
        value = messageSource.getMessage("test", null, new Locale("XX"));
        assertNotNull(value);
    }

    @Test
    public void testGetStringParameterizable() {
        String[] params = {"toto"};
        value = messageSource.getMessage("testParams", params, Locale.FRANCE);
        assertEquals("Ceci est un test toto", value);
    }

    @Test
    public void testGetStringAvecContextNull() {
        // avec un contexte null, on doit récupérer les messages français
        value = messageSource.getMessage("test", null, Locale.FRANCE);
        assertEquals("Ceci est un test", value);
    }

}
