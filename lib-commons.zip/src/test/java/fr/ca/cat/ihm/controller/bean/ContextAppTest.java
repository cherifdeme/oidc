package fr.ca.cat.ihm.controller.bean;


import fr.ca.cat.ihm.utils.ContextHelper;
import org.junit.Assert;
import org.junit.Test;

/**
 * @author etp2248
 * Classe qui vérifie que le mapping json/java s'effectue correctement pour le contexte d'éxecution
 */

public class ContextAppTest {

    private final String sCtxApp = "{\"appId\":\"ua_syntheseclient\",\"appUid\":\"ceeae44ec-3269-6d9c-a0c8-dbddd3cebb79\",\"versionApp\":\"1.0\",\"origineId\":\"ua_syntheseclient\",\"origineUid\":\"ceeae44ec-3269-6d9c-a0c8-dbddd3cebb79\",\"origineVersion\":\"1.0\"}";


    /**
     * Test du mapping
     */
    @Test
    public void testContextApp() {

        ContextApp ctxApp = ContextHelper.getContextApp(sCtxApp);

        Assert.assertNotNull(ctxApp);
        Assert.assertEquals("check appUid", "ceeae44ec-3269-6d9c-a0c8-dbddd3cebb79", ctxApp.getAppUid());
    }


}
