package fr.ca.cat.ihm.controller.bean;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.utils.ContextHelper;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.io.IOException;

/**
 * @author etp2248
 * Classe qui vérifie que le mapping json/java s'effectue correctement pour le contexte d'éxecution
 */

public class ContextExecutionTest {

    private static final Logger LOGGER = LogFactory.getLog(ContextExecutionTest.class);
    // valeurs des différentes données du contexte d'exécution
    private static final String TYPE_USER = "type_user";
    private static final String CANAL = "canal_sessionMode";
    private static final String LABEL_EDS = "label_EDS";
    private static final String OPERATIONAL_POST = "id_operationalPost";
    private static final String EDS = "id_EDS";
    private static final String FUNCTIONAL_POST = "edsId_functionalPost";
    private static final String DISTRIB_CANAL = "distribCanal_sessionMode";
    private static final String BANK_NETWORK = "bankNetwork_profile";
    private ContextExecution contextExecution;

    /**
     * @throws JsonProcessingException
     * @throws JsonParseException
     * @throws IOException
     */
    @Before
    public void setUp() throws JsonProcessingException {
        StringBuilder json = new StringBuilder("{ \"profile\" :{ \"functionalPost\" :{ \"id\" : \"id_functionalPost\", \"label\" : \"label_functionalPost\", \"functionId\" : \"functionId_functionalPost\", \"edsId\" : \"edsId_functionalPost\" } , ")
                .append("\"user\" : { \"id\" : \"id_user\", \"code\" : \"code_user\", \"type\" : \"type_user\", \"lastName\" : \"lastName_user\", \"firstName\" : \"firstName_user\" }, ")
                .append("\"customerRole\" :{ \"markets\" : [\"markets_1\",\"markets_2\"], \"segments\" : [\"segment_1\",\"segment_2\"] }, \"structureId\" : \"structureId_profile\" , \"bankNetwork\": \"bankNetwork_profile\" }, ")
                .append("\"systemInfo\" :{ \"operationalPost\" : { \"id\" : \"id_operationalPost\", \"label\" : \"label_operationalPost\", \"type\" : \"type_operationalPost\", \"mediaType\": \"mediaType_operationalPost\", \"deviceType\": \"deviceType_operationalPost\", ")
                .append("\"printerPeripherals\": [")
                .append("{ \"id\" : \"id_printerPeripherals1\", \"type\": \"type_printerPeripherals1\", \"label\": \"label_printerPeripherals1\", \"isDefault\": 0, \"printerType\": 0,	\"colorSupport\": 0, \"printerTrayNumber\": 1, \"versoSupport\": 1  },")
                .append("{ \"id\" : \"id_printerPeripherals2\", \"type\": \"type_printerPeripherals2\", \"label\": \"label_printerPeripherals2\", \"isDefault\": 1, \"printerType\": 2,	\"colorSupport\": 1, \"printerTrayNumber\": 2, \"versoSupport\": 0  }")
                .append("] }, \"eds\": { \"id\": \"id_EDS\", \"label\":\"label_EDS\" } }, ")
                .append("\"sessionMode\": { \"canal\" : \"canal_sessionMode\", \"distribCanal\": \"distribCanal_sessionMode\", \"transport\": \"\", \"CCMActive\" : true } }");
        contextExecution = new ObjectMapper().readValue(json.toString(), ContextExecution.class);
    }


    /**
     * Test du mapping
     */
    @Test
    public void testContextExecution() {

        Assert.assertNotNull(contextExecution);

        Assert.assertEquals(TYPE_USER, contextExecution.getProfile().getUser().getType());
        Assert.assertEquals(CANAL, contextExecution.getSessionMode().getCanal());
        Assert.assertTrue(contextExecution.getSessionMode().isCcmActive());
        Assert.assertEquals(LABEL_EDS, contextExecution.getSystemInfo().getEds().getLabel());

        // tests sur les données transmises aux services SOA dans les headers SOAP
        Assert.assertEquals(OPERATIONAL_POST, contextExecution.getSystemInfo().getOperationalPost().getId());
        Assert.assertEquals(EDS, contextExecution.getSystemInfo().getEds().getId());
        Assert.assertEquals(FUNCTIONAL_POST, contextExecution.getProfile().getFunctionalPost().getEdsId());
        Assert.assertEquals(DISTRIB_CANAL, contextExecution.getSessionMode().getDistribCanal());
        Assert.assertEquals(ContextHelper.DEFAULT_VALUE, contextExecution.getSessionMode().getTransport());
        Assert.assertEquals(BANK_NETWORK, contextExecution.getProfile().getBankNetwork());

        // Liste des périphériques (!= null)
        Assert.assertNotNull(contextExecution.getSystemInfo().getOperationalPost().getPrinterPeripherals());
        // Liste des périphériques de longueur 2
        Assert.assertEquals(2, contextExecution.getSystemInfo().getOperationalPost().getPrinterPeripherals().length);
        // Première imprimante de la liste
        PrinterPeripheral printerPeripheral0 = contextExecution.getSystemInfo().getOperationalPost().getPrinterPeripherals()[0];
        Assert.assertEquals("id_printerPeripherals1", printerPeripheral0.getId());
        Assert.assertEquals("type_printerPeripherals1", printerPeripheral0.getType());
        Assert.assertEquals("label_printerPeripherals1", printerPeripheral0.getLabel());
        Assert.assertEquals(0, (int) printerPeripheral0.getIsDefault());
        Assert.assertEquals(0, (int) printerPeripheral0.getPrinterType());
        Assert.assertEquals(0, (int) printerPeripheral0.getColorSupport());
        Assert.assertEquals(1, (int) printerPeripheral0.getPrinterTrayNumber());
        Assert.assertEquals(1, (int) printerPeripheral0.getVersoSupport());
        // Deuxième imprimante de la liste
        PrinterPeripheral printerPeripheral1 = contextExecution.getSystemInfo().getOperationalPost().getPrinterPeripherals()[1];
        Assert.assertEquals("id_printerPeripherals2", printerPeripheral1.getId());
        Assert.assertEquals("type_printerPeripherals2", printerPeripheral1.getType());
        Assert.assertEquals("label_printerPeripherals2", printerPeripheral1.getLabel());
        Assert.assertEquals(1, (int) printerPeripheral1.getIsDefault());
        Assert.assertEquals(2, (int) printerPeripheral1.getPrinterType());
        Assert.assertEquals(1, (int) printerPeripheral1.getColorSupport());
        Assert.assertEquals(2, (int) printerPeripheral1.getPrinterTrayNumber());
        Assert.assertEquals(0, (int) printerPeripheral1.getVersoSupport());
    }


    /**
     * on s'assure que des attributs inconnus (ici *NotFOund) ne plantent pas le parsing.
     */
    @Test
    public void testIgnoreProperties() {

        try {
            StringBuilder json = new StringBuilder("{ \"profile\" :{ \"functionalPost\" :{ \"id\" : \"id_functionalPost\", \"label\" : \"label_functionalPost\", \"functionId\" : \"functionId_functionalPost\", \"edsId\" : \"edsId_functionalPost\" } , ")
                    .append("\"user\" : { \"id\" : \"id_user\", \"code\" : \"code_user\", \"type\" : \"type_user\", \"lastName\" : \"lastName_user\", \"firstName\" : \"firstName_user\" }, ")
                    .append("\"customerRole\" :{ \"markets\" : [\"markets_1\",\"markets_2\"], \"segments\" : [\"segment_1\",\"segment_2\"] }, \"structureId\" : \"structureId_profile\" , \"bankNetwork\": \"bankNetwork_profile\" }, ")
                    .append("\"systemInfo\" :{ \"operationalPost\" : { \"id\" : \"id_operationalPost\", \"label\" : \"label_operationalPost\", \"type\" : \"type_operationalPost\", \"mediaType\": \"mediaType_operationalPost\", \"deviceType\": \"deviceType_operationalPost\", ")
                    .append("\"printerPeripherals\": [")
                    .append("{ \"id\" : \"id_printerPeripherals1\", \"type\": \"type_printerPeripherals1\", \"label\": \"label_printerPeripherals1\", \"isDefault\": 0, \"printerType\": 0,	\"colorSupport\": 0, \"printerTrayNumber\": 1, \"versoSupport\": 1  },")
                    .append("{ \"id\" : \"id_printerPeripherals2\", \"type\": \"type_printerPeripherals2\", \"label\": \"label_printerPeripherals2\", \"isDefault\": 1, \"printerType\": 2,	\"colorSupport\": 1, \"printerTrayNumber\": 2, \"versoSupport\": 0  }")
                    .append("] }, \"eds\": { \"id\": \"id_EDS\", \"label\":\"label_EDS\" } }, ")
                    .append("\"sessionMode\": { \"canalNotFound\" : \"canal_sessionMode\", \"distribCanalNotFound\": \"distribCanal_session\", \"transportNotFound\": \"\", \"CCMActiveNotFound\" : true } }");

            ContextExecution toto = new ObjectMapper().readValue(json.toString(), ContextExecution.class);

            Assert.assertTrue(toto.getSessionMode().getCanal().isEmpty());


        } catch (JsonProcessingException e) {
            LOGGER.error("ca merdoie !", e, null);
            Assert.fail(e.getMessage());
        }
    }

}
