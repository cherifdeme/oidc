package fr.ca.cat.ihm.controller.bean.dto;

import fr.ca.cat.ihm.controller.dto.StateDTO;
import org.junit.Assert;
import org.junit.Test;

public class StateDTOTest {
    StateDTO stateDTO;

    @Test
    public void testStateDTO() {
        stateDTO = new StateDTO();
        stateDTO.setLabel("WELCOME");
        Assert.assertEquals("WELCOME", stateDTO.getLabel());
        Assert.assertEquals(StateDTO.PageType.JSP, stateDTO.getPageType());
        stateDTO.setPageType(StateDTO.PageType.HTML);
        Assert.assertEquals(StateDTO.PageType.HTML, stateDTO.getPageType());
    }
}
