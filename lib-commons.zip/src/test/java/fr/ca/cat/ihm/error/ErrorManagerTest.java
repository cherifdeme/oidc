/**
 *
 */
package fr.ca.cat.ihm.error;

import fr.ca.cat.ihm.BeanConfigurationTest;
import fr.ca.cat.ihm.SocleJavaTest;
import fr.ca.cat.ihm.bundle.ResourceBundleFactory;
import fr.ca.cat.ihm.config.FwkSocle;
import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.error.dto.ErrorDTO;
import fr.ca.cat.ihm.exception.BusinessException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.Locale;

import static org.junit.Assert.assertEquals;

/**
 * Test gestion des erreurs
 *
 * @author ET01343
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {BeanConfigurationTest.class})
public class ErrorManagerTest extends SocleJavaTest {

    public IErrorManager errorManager;
    public ResourceBundleFactory resourceBundleFactory;
    private ResourceBundleMessageSource messageSource;
    private Context context;
    private Context englishContext;
    private Locale locale;

    @Before
    public void setUp() throws Exception {
        FwkSocle.init();
        setContext();
        setEnglishContext();
        locale = getContext().getBrowser().getLocale();

        messageSource = new ResourceBundleMessageSource();
        String[] baseNames = new String[]{"bundle/ErrorTestMessage",
                "bundle/test_message",
                "bundle/fwk_errorbundle",
                "bundle/fwkmessage",
                "bundle/onlyDefault_errorbundle",
                "bundle/test_errorbundle",
                "bundle/test_junit_errorbundle"};
        messageSource.setBasenames(baseNames);
        messageSource.setDefaultEncoding("UTF-8");

        resourceBundleFactory = new ResourceBundleFactory(messageSource);

        errorManager = new BundleErrorManagerImpl(resourceBundleFactory);
    }

    @After
    public void tearDown() {
        FwkSocle.unload();
    }

    @Test
    public void testGetError() {
        String code = "TST000";
        String[] args = {"800", "500"};

        ErrorDTO error = errorManager.getErrorUA("test_junit", code, args, context);
        testError(error);

        // test avec une exception
        try {
            testException(code, args);
        } catch (BusinessException e) {
            error = errorManager.getError("test_junit", e, context);
            testError(error);
        }

        // test sans arguments
        error = errorManager.getErrorUA("test_junit", code, null, context);
        testErrorNoArgs(error);

        // test avec un language différent de "fr"
        error = errorManager.getErrorUA("test_junit", code, args, englishContext);
        testError_en(error);

        testGetErrorFWK();
    }


    @Test
    public void testGetErrorOnlyDefaultLanguage() {
        String code = "TST000";
        String[] args = {"800", "500"};

        // quelle que soit la locale on est sur le default qu'on a valorisé en français => testError
        ErrorDTO error = errorManager.getErrorUA("onlyDefault", code, args, context);
        testError(error);

        // test avec une exception
        try {
            testException(code, args);
        } catch (BusinessException e) {
            error = errorManager.getError("onlyDefault", e, context);
            testError(error);
        }

        // test sans arguments
        error = errorManager.getErrorUA("onlyDefault", code, null, context);
        testErrorNoArgs(error);

        // test avec un language différent de "fr"
        error = errorManager.getErrorUA("onlyDefault", code, args, englishContext);
        testError_en(error);

        testGetErrorFWK();
    }

    private void testError(ErrorDTO error) {
        assertEquals("TST000", error.getCode());
        assertEquals(messageSource.getMessage("error.test.2", null, locale), error.getMessage());
        assertEquals(messageSource.getMessage("error.test.4", null, locale), error.getAction());
        assertEquals("1", error.getGravity().getDbValue());
    }

    private void testErrorNoArgs(ErrorDTO error) {
        assertEquals("TST000", error.getCode());
        assertEquals(messageSource.getMessage("error.test.16", null, locale), error.getMessage());
        assertEquals(messageSource.getMessage("error.test.8", null, locale), error.getAction());
        assertEquals("1", error.getGravity().getDbValue());
    }

    private void testException(String code, String[] args)
            throws BusinessException {
        BusinessException e = new BusinessException(context, code, args);
        e.afterConstructor(errorManager);
        throw e;
    }

    private void testError_en(ErrorDTO error) {
        assertEquals("TST000", error.getCode());
        assertEquals(messageSource.getMessage("error.test.9", null, locale), error.getMessage());
        assertEquals(messageSource.getMessage("error.test.10", null, locale), error.getAction());
        assertEquals("1", error.getGravity().getDbValue());
    }

    private void testGetErrorFWK() {
        String code = "FWK028";
        String[] args = {"toto", "26"};

        ErrorDTO error = errorManager.getErrorFWK(code, args, context);
        testErrorFWK(error);

        // test avec une exception
        try {
            testException(code, args);
        } catch (BusinessException e) {
            error = errorManager.getError("test_junit", e, context);
            testErrorFWK(error);
        }

        // test sans arguments
        error = errorManager.getErrorFWK(code, null, context);
        testErrorNoArgsFWK(error);

        // test avec un language différent de "fr"
        error = errorManager.getErrorFWK(code, args, englishContext);
        testErrorFWK_en(error);
    }

    private void testErrorFWK(ErrorDTO error) {
        assertEquals("FWK028", error.getCode());
        assertEquals(messageSource.getMessage("error.test.11", null, locale), error.getMessage());
        assertEquals(messageSource.getMessage("error.test.12", null, locale), error.getAction());
        assertEquals("2", error.getGravity().getDbValue());
    }

    private void testErrorNoArgsFWK(ErrorDTO error) {
        assertEquals("FWK028", error.getCode());
        assertEquals(messageSource.getMessage("error.test.13", null, locale), error.getMessage());
        assertEquals(messageSource.getMessage("error.test.12", null, locale), error.getAction());
        assertEquals("2", error.getGravity().getDbValue());
    }

    private void testErrorFWK_en(ErrorDTO error) {
        assertEquals("FWK028", error.getCode());
        assertEquals(messageSource.getMessage("error.test.14", null, locale), error.getMessage());
        assertEquals(messageSource.getMessage("error.test.15", null, locale), error.getAction());
        assertEquals("2", error.getGravity().getDbValue());
    }

    private void setContext() throws Exception {
        if (context == null) {
            context = getContext();
        }
    }

    private void setEnglishContext() throws Exception {
        if (englishContext == null) {
            englishContext = getEnglishContext();
        }
    }
}
