package fr.ca.cat.ihm.exception;

import fr.ca.cat.ihm.SocleJavaTest;
import org.junit.Assert;
import org.junit.Test;

public class SocleExceptionTest extends SocleJavaTest {
    @Test
    public void testSocleException() throws Exception {
        SocleException exp = new BusinessException(getContext(), new Throwable("test"), "code", null);
        Assert.assertEquals("fr.ca.cat.ihm.exception.BusinessException: SocleException", exp.toString());
    }
}
