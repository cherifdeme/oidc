package fr.ca.cat.ihm.exception;

import fr.ca.cat.ihm.BeanConfigurationTest;
import fr.ca.cat.ihm.SocleJavaTest;
import fr.ca.cat.ihm.bundle.ResourceBundleFactory;
import fr.ca.cat.ihm.controller.bean.Browser;
import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.error.IErrorManager;
import fr.ca.cat.ihm.performance.dto.PerformanceDTO;
import fr.ca.cat.ihm.utils.Version;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.util.Locale;

/**
 * Classe de test permettant de vérifier l'affichage de la TechnicalException typiquement
 *
 * @author ETP2473
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {BeanConfigurationTest.class})
public class TechnicalExceptionTest extends SocleJavaTest {

    private static final String ERREUR_TEST = "Erreur test";
    private static final String CONTEXT2 = "Context";
    /* constantes contenant les maessages attendus dans les tests */
    private static final String MSG_ARGS = "Message avec arguments, le premier est toto, et le 2e est tutu !";
    private static final String MSG = "Voici un message qui ne contient pas d'argument !";
    private static final String MSG_EX = "Voici un message qui ne contient pas d'argument mais avec une exception !";
    private static final String MSG_EX_ARGS = "Message avec exception et avec arguments, le premier est toto, et le 2e est tutu !";

    private static final String MSG_EN_ARGS = "Message with args, first is toto, and second is tutu !";
    private static final String MSG_EN = "This is a message without args !";
    private static final String MSG_EN_EX = "This is a message without args but with exception !";
    private static final String MSG_EN_EX_ARGS = "Message with exception and args, first is toto, and second is tutu !";

    @Autowired
    public IErrorManager errorManager;
    @Autowired
    private ResourceBundleMessageSource messageSource;
    private ResourceBundleFactory factory;

    @Before
    public void setUp() {
        messageSource.setBasename("bundle/test_errorbundle");
        factory = new ResourceBundleFactory(messageSource);
    }

    /**
     * teste l'affichage de l'erreur technique
     */
    @Test
    public void testToString() {
        Context context = null;
        try {
            context = getContext();
        } catch (Exception e) {
            context = new Context(new Browser("test", new Locale("fr")), new PerformanceDTO(CONTEXT2), null, "test", new Version("1.0"));
        }

        TechnicalException technicalException = new TechnicalException(context, new Exception(ERREUR_TEST), "FWK001", new String[]{"arg1", "arg2"});
        technicalException.afterConstructor(errorManager);
        String toStringResult = technicalException.toString();
        Assert.assertNotNull(toStringResult);
        Assert.assertTrue(toStringResult.contains("FWK001"));
        Assert.assertTrue(toStringResult.contains("arg1"));
        Assert.assertTrue(toStringResult.contains("arg2"));
    }

    /**
     * TechnicalException: teste la récupération du message d'erreur sans argument
     */
    @Test
    public void testGetMessage() {
        Context context;

        // test avec un message en français
        try {
            context = getContext();
        } catch (Exception e) {
            context = new Context(new Browser("test", new Locale("fr")), new PerformanceDTO(CONTEXT2), null, "test", new Version("1.0"));
        }
        TechnicalException te = new TechnicalException(context, "TST001");
        te.afterConstructor(errorManager);
        Assert.assertEquals(MSG, te.getMessageException());

        BusinessException be = new BusinessException(context, new Exception(ERREUR_TEST), "TST002");
        be.afterConstructor(errorManager);
        Assert.assertEquals(MSG_EX, be.getMessageException());


        // test avec un message en anglais
        try {
            context = getEnglishContext();
        } catch (Exception e) {
            context = new Context(new Browser("test", new Locale("en")), new PerformanceDTO("EnglishContext"), null, "test", new Version("1.0"));
        }
        be = new BusinessException(context, "TST001");
        be.afterConstructor(errorManager);
        Assert.assertEquals(MSG_EN, be.getMessageException());

        te = new TechnicalException(context, new Exception(ERREUR_TEST), "TST002");
        te.afterConstructor(errorManager);
        Assert.assertEquals(MSG_EN_EX, te.getMessageException());
    }

    /**
     * TechnicalException: teste la récupération du message d'erreur avec arguments
     */
    @Test
    public void testGetMessageWithArgs() {
        Context context = null;
        String[] args = new String[]{"toto", "tutu"};

        // test avec un message en français
        try {
            context = getContext();
        } catch (Exception e) {
            context = new Context(new Browser("test", new Locale("fr")), new PerformanceDTO(CONTEXT2), null, "test", new Version("1.0"));
        }
        TechnicalException te = new TechnicalException(context, "TST000", args);
        te.afterConstructor(errorManager);
        Assert.assertEquals(MSG_ARGS, te.getMessageException());

        BusinessException be = new BusinessException(context, new Exception(ERREUR_TEST), "TST003", args);
        be.afterConstructor(errorManager);
        Assert.assertEquals(MSG_EX_ARGS, be.getMessageException());

        // test en anglais
        try {
            context = getEnglishContext();
        } catch (Exception e) {
            context = new Context(new Browser("test", new Locale("en")), new PerformanceDTO("EnglishContext"), null, "test", new Version("1.0"));
        }
        be = new BusinessException(context, "TST000", args);
        be.afterConstructor(errorManager);
        Assert.assertEquals(MSG_EN_ARGS, be.getMessageException());

        te = new TechnicalException(context, new Exception(ERREUR_TEST), "TST003", args);
        te.afterConstructor(errorManager);
        Assert.assertEquals(MSG_EN_EX_ARGS, te.getMessageException());
    }

}
