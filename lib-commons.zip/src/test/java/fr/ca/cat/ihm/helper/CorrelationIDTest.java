package fr.ca.cat.ihm.helper;

import fr.ca.cat.correlationid.CorrelationID;
import fr.ca.cat.ihm.SocleJavaTest;
import org.junit.Assert;
import org.junit.Test;

/**
 * Classe de test de l'identifiant de correlation
 *
 * @author ETP2473
 */
public class CorrelationIDTest extends SocleJavaTest {

    /**
     * Identifiant de CR utilisé POUR LES LOGS lorsqu'aucun n'est reçu sur le SP
     */
    private static final String CR_DEFAULT = "00000";

    /**
     * Longueur attendue de l'identifiant de correlation
     */
    private static final int ID_CORRELATION_LENGHT = 77;

    /**
     * Teste la méthode generateCorrelationID
     */
    @Test
    public void testGenerateCorrelationID() {
        String idCorrelation = CorrelationID.generateCorrelationID(CR_DEFAULT);
        Assert.assertNotNull(idCorrelation);
        Assert.assertEquals(ID_CORRELATION_LENGHT, idCorrelation.length());
    }

    /**
     * Teste la méthode logFormatCorrelationID
     */
    @Test
    public void testLogFormatCorrelationID() {
        String id = "00000E931F33D-1675-46AC-AB5E-6236BB69E00011160015-1324-4321-1234-123456789AB8";
        String idCorrelationToFormat = CorrelationID.logFormatCorrelationID(id);
        Assert.assertNotNull(idCorrelationToFormat);
        Assert.assertEquals(idCorrelationToFormat, "11160015-1324-4321-1234-123456789 AB8");
    }

}
