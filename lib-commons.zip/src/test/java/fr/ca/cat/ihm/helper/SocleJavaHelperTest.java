package fr.ca.cat.ihm.helper;

import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.exception.UnauthorizedException;
import fr.ca.cat.ihm.security.dto.SecurityAPIBean;
import fr.ca.cat.ihm.security.dto.SecurityDTO;
import fr.ca.cat.ihm.security.dto.UserDTO;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;

import static fr.ca.cat.ihm.security.ISecurity.SECURITY_DTO_ATTRIBUTE_NAME;
import static fr.ca.cat.ihm.security.impl.SecurityImpl.AULN_SESSION_ID;
import static org.junit.Assert.assertThrows;

public class SocleJavaHelperTest {
    SocleJavaHelper helper;

    @Before
    public void setup() {
        helper = new SocleJavaHelper();
    }

    @Test
    public void testGetBrowser() {

        assertThrows(IllegalStateException.class,
                () -> {
                    helper.getBrowser();
                });
    }

    @Test
    public void testGetSecurity() throws TechnicalException, UnauthorizedException {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setAttribute(AULN_SESSION_ID, "eb1f77c7-28c5-4318-90bd-1aabd8601a5c");
        SecurityDTO dto = new SecurityDTO();
        UserDTO user = new UserDTO();
        dto.setUserDTO(user);
        dto.setAulnSessionId("eb1f77c7-28c5-4318-90bd-1aabd8601a5c");
        dto.setApiSecurity(new SecurityAPIBean());
        request.setAttribute(SECURITY_DTO_ATTRIBUTE_NAME, dto);
        SecurityDTO security = helper.getSecurity(request);
        Assert.assertNotNull(security);
        request.setAttribute(SECURITY_DTO_ATTRIBUTE_NAME, null);
        security = helper.getSecurity(request);
        Assert.assertNull(security);
    }

    @Test
    public void testGetSecurityBis() {

        assertThrows(IllegalStateException.class,
                () -> {
                    helper.getSecurity();
                });
    }

    @Test
    public void testGetUserLocale() {

        assertThrows(IllegalStateException.class,
                () -> {
                    helper.getUserLocale();
                });
    }

    @Test
    public void testGetUserPrincipal() {
        assertThrows(IllegalStateException.class,
                () -> {
                    helper.getUserPrincipal();
                });
    }

    @Test
    public void testGetWebApplicationContext() {
        assertThrows(IllegalStateException.class,
                () -> {
                    helper.geWebApplicationContext();
                });
    }

    @Test
    public void testGetContextExecution() {
        assertThrows(IllegalStateException.class,
                () -> {
                    helper.getContextExecution();
                });
    }
}
