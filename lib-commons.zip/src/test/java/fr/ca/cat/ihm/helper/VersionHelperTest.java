package fr.ca.cat.ihm.helper;

import fr.ca.cat.ihm.utils.Version;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class VersionHelperTest {
    VersionHelper helper;

    @Before
    public void setup() {
        helper = new VersionHelper();
    }

    @Test
    public void testGetVersion() {
        Version longVersion = VersionHelper.getLongVersion("1.0-SNAPSHOT");
        Assert.assertEquals(longVersion.getCurrent(), "1.0");
        longVersion = VersionHelper.getVersion("1.0-SNAPSHOT");
        Assert.assertEquals("1.0", longVersion.getCurrent());
    }
}
