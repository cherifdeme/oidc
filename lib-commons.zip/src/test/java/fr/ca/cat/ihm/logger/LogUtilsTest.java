package fr.ca.cat.ihm.logger;

import fr.ca.cat.ihm.utils.Consommateur;
import fr.ca.cat.ihm.utils.Version;
import org.junit.Before;
import org.junit.Test;
import org.mockito.MockedStatic;

import static org.mockito.Mockito.mockStatic;

public class LogUtilsTest {
    Consommateur consommateur = new Consommateur("test", new Version("1.0"));
    MockedStatic<LogUtils> spy;

    @Before
    public void init() {
        spy = mockStatic(LogUtils.class);
    }

    @Test
    public void testRemoveMDC() {
        LogUtils.removeMDC();
        spy.verify(LogUtils::removeMDC);
        spy.close();
    }


    @Test
    public void testSetEmetteur() {
        LogUtils.setEmetteur(consommateur);
        spy.verify(() -> LogUtils.setEmetteur(consommateur));
        spy.close();
    }

    @Test
    public void testSetConsommateur() {
        LogUtils.setConsommateur(consommateur);
        spy.verify(() -> LogUtils.setConsommateur(consommateur));
        spy.close();
    }

    @Test
    public void testSetConsommateurOrigine() {
        LogUtils.setConsommateurOrigine(consommateur);
        spy.verify(() -> LogUtils.setConsommateurOrigine(consommateur));
        spy.close();
    }
}
