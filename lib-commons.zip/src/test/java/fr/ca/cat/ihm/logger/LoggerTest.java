/**
 *
 */
package fr.ca.cat.ihm.logger;

import fr.ca.cat.ihm.SocleJavaTest;
import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.most.util.log.MostCode;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Classe de test du logger
 *
 * @author ETP1485
 */
public class LoggerTest extends SocleJavaTest {


    Logger logger = LogFactory.getLog(TypeLogger.LOGGER_SOCLE);

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
    }

    /**
     * @throws java.lang.Exception
     */
    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testLogSocle() throws Exception {
        String type = "SOCLE";
        Context ctx = getContext();

        logDebug(logger, type, ctx);

        logger.warn("This is a warn message " + type, ctx);
        logger.error(new MostCode("pouet"), "erro message with no context and no exception", null, null);

        logError(logger, type, ctx);
    }

    @Test
    public void testLogVide() throws Exception {
        Logger logger = LogFactory.getLog();
        String type = "UA";
        Context ctx = getContext();

        logDebug(logger, type, ctx);
        logInfo(logger, type, ctx);

        logger.warn("This is a warn message " + type, ctx);

        logError(logger, type, ctx);
    }

    @Test
    public void testLogPerf() throws Exception {
        Logger logger = LogFactory.getLog();
        Context ctx = getContext();
        logger.perf(11, "ceci est une mesure de perf", ctx);

    }


    private void logError(Logger log, String type, Context ctx) throws Exception {
        try {
            throw new Exception("My Exception " + type);
        } catch (Exception e) {
            log.error("This is an exception " + type, e, ctx);
            log.warn("une exception loguee avec warn " + type, e, ctx);
        } finally {
            log.fatal("This is a fatal exception " + type, ctx);
        }
    }

    private void logDebug(Logger log, String type, Context ctx) {
        if (log.isDebugEnabled()) {
            log.debug("This is a debug message " + type, ctx);
        } else {
            log.warn("Debug is disabled for " + type, ctx);
        }
    }

    private void logInfo(Logger log, String type, Context ctx) {
        if (log.isInfoEnabled()) {
            log.info("This is a info message " + type, ctx);
        } else {
            log.warn("Info is disabled for " + type, ctx);
        }
    }

    @Test
    public void testCounter() {
        String aCounter = LogUtils.counterForChildProcess(null);
        assertEquals("001", aCounter);
        aCounter = LogUtils.counterForNextProcess(aCounter);
        assertEquals("002", aCounter);

        aCounter = LogUtils.counterForChildProcess(aCounter);
        assertEquals("002-001", aCounter);
        aCounter = LogUtils.counterForNextProcess(aCounter);
        assertEquals("002-002", aCounter);
        aCounter = LogUtils.counterForNextProcess(aCounter);
        assertEquals("002-003", aCounter);
        aCounter = LogUtils.counterForNextProcess(aCounter);
        assertEquals("002-004", aCounter);

        aCounter = LogUtils.counterForChildProcess(aCounter);
        assertEquals("002-004-001", aCounter);


    }


    @Test
    public void testPerfMessage() throws Exception {

        String counter = LogUtils.counterForChildProcess(null);
        PerfMessage msg = new PerfMessage();
        msg.setFunctionName("test fonction");
        msg.setCounter(counter);


        logger.perf(2000, msg.toString(), getContext());
        logger.perf(9999, msg.toString(), null);
    }


}
