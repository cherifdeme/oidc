package fr.ca.cat.ihm.performance;

import fr.ca.cat.ihm.annotation.PerfMonitoring;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.logger.TypeLogger;
import org.junit.Assert;
import org.junit.Test;

public class MonitorAspectTest {

    private static final Logger LOGGER = LogFactory.getLog(MonitorAspectTest.class, TypeLogger.LOGGER_SOCLE);

    @Test
    public void testPerfMonitoring() {

        dummy();
        Assert.assertTrue(true);
    }


    @PerfMonitoring(description = "logWithPerfMonitoring", mostCode = "IHME-TEST-PERF")
    private void dummy() {
        LOGGER.info("pouete", null);
        LOGGER.perf(42, "pouete", null);
    }
}
