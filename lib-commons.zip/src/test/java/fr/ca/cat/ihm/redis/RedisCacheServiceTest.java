package fr.ca.cat.ihm.redis;


import com.github.fppt.jedismock.RedisServer;
import fr.ca.cat.ihm.controller.bean.Browser;
import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.crypto.CryptoSHA256;
import fr.ca.cat.ihm.performance.dto.PerformanceDTO;
import fr.ca.cat.ihm.security.dto.SecurityAPIBean;
import fr.ca.cat.ihm.security.dto.SecurityDTO;
import fr.ca.cat.ihm.security.dto.UserDTO;
import fr.ca.cat.ihm.utils.Version;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.test.util.ReflectionTestUtils;
import redis.clients.jedis.commands.JedisCommands;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;
import java.util.UUID;

@RunWith(MockitoJUnitRunner.Silent.class)
public class RedisCacheServiceTest {

    private RedisCacheService redisCacheServicemock = Mockito.mock(RedisCacheService.class);
    private RedisServer server;

    // Test save token a une Context avec SecurityApiBean
    @Test
    public void testSaveToken() throws IOException {
        //CONFIG
        server = RedisServer.newRedisServer().start();
        try {
            SecurityAPIBean securityAPIBean = new SecurityAPIBean();
            securityAPIBean.setRefresh_token("token");
            securityAPIBean.setExpires_in(1000000);
            securityAPIBean.setId_token("id_token");
            securityAPIBean.setRefresh_token("");
            securityAPIBean.setAccess_token("accesstoken");
            Browser browser = new Browser("", Locale.FRANCE);
            PerformanceDTO performanceDTO = new PerformanceDTO(UUID.randomUUID().toString());
            Version version = new Version("5.5");
            SecurityDTO securityDTO = new SecurityDTO();
            securityDTO.setApiSecurity(securityAPIBean);
            securityDTO.setUserDTO(new UserDTO());
            securityDTO.setAulnSessionId("");
            securityDTO.setSamlAssertion(null);
            Context ctx = new Context(browser, performanceDTO, securityDTO, "uald", version);
            Mockito.doNothing().when(redisCacheServicemock).saveToken(ctx, securityAPIBean);
            //ACTION
            RedisCacheService redis = new RedisCacheService(false, server.getHost(), String.valueOf(server.getBindPort()));
            redis.saveToken(ctx, securityAPIBean);
            Mockito.verify(redisCacheServicemock).saveRefreshToken(ctx, securityAPIBean);
            JedisCommands jedis = (JedisCommands) ReflectionTestUtils.getField(redis, "jedis");
            //TEST
            Assert.assertEquals("accesstoken", jedis.hget("api2m:session:" + CryptoSHA256.cryptoHash(ctx.getSecurityDTO().getAulnSessionId()) + ":uald", "access_token"));
            Assert.assertEquals("id_token", jedis.hget("api2m:session:" + CryptoSHA256.cryptoHash(ctx.getSecurityDTO().getAulnSessionId()) + ":uald", "id_token"));

        } catch (Exception e) {
        } finally {
            server.stop();
        }

    }

    @Test
    public void testGetToken() throws IOException {
        //CONFIG
        server = RedisServer.newRedisServer().start();
        try {
            SecurityAPIBean expectedSecurityAPIBean = new SecurityAPIBean();
            expectedSecurityAPIBean.setRefresh_token("getToken");
            expectedSecurityAPIBean.setExpires_in(1000000);
            expectedSecurityAPIBean.setId_token("id_tokengetToken");
            expectedSecurityAPIBean.setRefresh_token("");
            expectedSecurityAPIBean.setAccess_token("accesstokengetToken");
            Browser browser = new Browser("", Locale.FRANCE);
            PerformanceDTO performanceDTO = new PerformanceDTO(UUID.randomUUID().toString());
            Version version = new Version("5.5");

            SecurityDTO securityDTO = new SecurityDTO();
            securityDTO.setApiSecurity(expectedSecurityAPIBean);
            securityDTO.setUserDTO(new UserDTO());
            securityDTO.setAulnSessionId("");
            securityDTO.setSamlAssertion(null);
            Context ctx = new Context(browser, performanceDTO, securityDTO, "uald", version);
            //ACTION
            RedisCacheService redis = new RedisCacheService(false, server.getHost(), String.valueOf(server.getBindPort()));
            redis.saveToken(ctx, expectedSecurityAPIBean);
            SecurityAPIBean resultSecurityAPIBean = redis.getTokens(ctx);
            //TEST
            Assert.assertEquals(expectedSecurityAPIBean.getAccess_token(), resultSecurityAPIBean.getAccess_token());
            Assert.assertEquals(expectedSecurityAPIBean.getId_token(), resultSecurityAPIBean.getId_token());
        } catch (Exception e) {

        } finally {
            server.stop();
        }

    }


    @Test
    public void testSaveRefreshToken() throws InterruptedException, NoSuchAlgorithmException, IOException {
        //CONFIG
        server = RedisServer.newRedisServer().start();
        try {
            SecurityAPIBean expectedSecurityAPIBean = new SecurityAPIBean();
            expectedSecurityAPIBean.setExpires_in(1000000);
            expectedSecurityAPIBean.setId_token("id_RefreshToken");
            expectedSecurityAPIBean.setRefresh_token("RefreshToken");
            expectedSecurityAPIBean.setAccess_token("accesstokengetToken");
            Browser browser = new Browser("", Locale.FRANCE);
            PerformanceDTO performanceDTO = new PerformanceDTO(UUID.randomUUID().toString());
            Version version = new Version("5.5");

            SecurityDTO securityDTO = new SecurityDTO();
            securityDTO.setApiSecurity(expectedSecurityAPIBean);
            securityDTO.setUserDTO(new UserDTO());
            securityDTO.setAulnSessionId("");
            securityDTO.setSamlAssertion(null);
            Context ctx = new Context(browser, performanceDTO, securityDTO, "uald", version);
            //ACTION
            RedisCacheService redis = new RedisCacheService(false, server.getHost(), String.valueOf(server.getBindPort()));
            redis.saveRefreshToken(ctx, expectedSecurityAPIBean);
            JedisCommands jedis = (JedisCommands) ReflectionTestUtils.getField(redis, "jedis");
            //TEST
            Assert.assertEquals("RefreshToken", jedis.get("api2m:refresh:" + CryptoSHA256.cryptoHash(ctx.getSecurityDTO().getAulnSessionId()) + ":uald"));

        } catch (Exception e) {

        } finally {
            server.stop();
        }
    }


}
