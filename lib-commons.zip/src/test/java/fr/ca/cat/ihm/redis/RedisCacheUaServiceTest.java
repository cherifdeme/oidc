package fr.ca.cat.ihm.redis;

import fr.ca.cat.ihm.SocleJavaTest;
import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.utils.Constants;
import fr.ca.cat.ihm.utils.RedisCacheUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.*;

public class RedisCacheUaServiceTest extends SocleJavaTest {

    @InjectMocks
    private RedisCacheUAService redisCacheService;
    @Mock
    private CacheManager cacheManager;

    @Mock
    private Cache cache;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void saveToken() throws Exception {
        // --- CONFIG -- //
        Context context = getContext();
        context.getSecurityDTO().setAulnSessionId("test");
        final var sessionKey = RedisCacheUtils.getRedisKey(Constants.API2M_SESSION_PREFIX, context);
        when(cacheManager.getCache(Constants.TOKEN_CACHE)).thenReturn(cache);
        doNothing().when(cache).put(sessionKey, "test");

        // --- ACTION -- //
        redisCacheService.saveToken(context, "test");

        // --- TEST -- //
        // Mock
        verify(cacheManager, times(2)).getCache(Constants.TOKEN_CACHE);
        verify(cache).put(sessionKey, "test");
    }

    @Test
    public void testSaveToken() throws Exception {
        Context context = getContext();
        context.getSecurityDTO().setAulnSessionId("test");
        // --- CONFIG -- //
        final var sessionKey = RedisCacheUtils.getRedisKey(Constants.API2M_SESSION_PREFIX, context);
        when(cacheManager.getCache(Constants.TOKEN_CACHE)).thenReturn(cache);
        when(cache.get(sessionKey, Object.class)).thenReturn("test");

        // --- ACTION -- //
        final String cache1 = (String) redisCacheService.getTokens(context);

        // --- TEST -- //
        // Mock
        verify(cacheManager, times(2)).getCache(Constants.TOKEN_CACHE);
        verify(cache).get(sessionKey, Object.class);

        // Method return
        assertThat(cache1, is("test"));
    }

    @Test
    public void testSaveRefreshToken() throws Exception {
        // --- CONFIG -- //
        Context context = getContext();
        context.getSecurityDTO().setAulnSessionId("test");
        final var sessionKey = RedisCacheUtils.getRedisKey(Constants.API2M_SESSION_PREFIX, context);
        when(cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE)).thenReturn(cache);
        doNothing().when(cache).put(sessionKey, "test");

        // --- ACTION -- //
        redisCacheService.saveRefreshToken(context, "test");

        // --- TEST -- //
        // Mock
        verify(cacheManager, times(2)).getCache(Constants.REFRESH_TOKEN_CACHE);
    }

    @Test
    public void testGetRefreshToken() throws Exception {
        Context context = getContext();
        context.getSecurityDTO().setAulnSessionId("test");
        // --- CONFIG -- //
        final var sessionKey = RedisCacheUtils.getRedisKey(Constants.API2M_SESSION_PREFIX, context);
        when(cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE)).thenReturn(cache);
        when(cache.get(sessionKey, Object.class)).thenReturn("test");

        // --- ACTION -- //
        final String cache1 = redisCacheService.getRefreshToken(context);

        // --- TEST -- //
        // Mock
        verify(cacheManager, times(2)).getCache(Constants.REFRESH_TOKEN_CACHE);

        // Method return
        Assert.assertNull(cache1);
    }

}
