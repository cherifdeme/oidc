package fr.ca.cat.ihm.resilience;

import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class BufferStateCircuitBreakerTest {

    private static BufferStateCircuitBreaker cb;

    @Test
    public void testSetCircuit() {
        cb = new BufferStateCircuitBreaker();
        cb.setCircuit("test");
        cb.logged();
        cb.getShortCircuited();
        cb.getFailure();
        cb.getSuccess();
        cb.isTracable();
        final String date = cb.getDate();
        assertNotNull(date);
    }
}
