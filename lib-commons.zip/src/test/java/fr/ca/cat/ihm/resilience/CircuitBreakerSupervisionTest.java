package fr.ca.cat.ihm.resilience;

import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import static java.lang.Long.valueOf;
import static org.mockito.Mockito.times;

public class CircuitBreakerSupervisionTest {

    @Mock
    private static CircuitBreakerSupervision cb;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testSetPeriod() {
        cb.setPeriod(valueOf("10"));
        Mockito.verify(cb, times(1)).setPeriod(valueOf("10"));
        cb.initSupervision();
        Mockito.verify(cb, times(1)).initSupervision();

    }
}
