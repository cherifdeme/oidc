package fr.ca.cat.ihm.resilience;

import fr.ca.cat.ihm.BeanConfigurationTest;
import fr.ca.cat.ihm.exception.TechnicalException;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import org.apache.commons.io.FileUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

import static org.junit.Assert.assertTrue;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {BeanConfigurationTest.class})
public class LogMetricsResilience4jTest {

    private static final String CB_NAME_PLACES = "places";

    private static final String LOG_METRICS_R4J = "message={\"Group\":\"Appels-Services\",\"Key\":\"places\",\"SUCCESS\"";

    @Autowired
    private CircuitBreakerRegistry circuitBreakerRegistry;

    @Before
    public void setUp() throws Exception {
        circuitBreakerRegistry.circuitBreaker(CB_NAME_PLACES);
    }


    @Test
    public void testLogMetricsResilience4J() throws IOException {

        LogMetricsResilience4j logmetrics = new LogMetricsResilience4j();
        logmetrics.run();
        logmetrics.run();
        logmetrics.run();

        String logperf = FileUtils.readFileToString(new File("./target/logs/perf-test.log"), StandardCharsets.UTF_8);

        assertTrue(logperf.contains(LOG_METRICS_R4J));

    }

}