package fr.ca.cat.ihm.security;


import fr.ca.cat.ihm.SocleJavaTest;
import org.junit.Assert;
import org.junit.Test;

import java.util.regex.Matcher;


public class EncryptorTest extends SocleJavaTest {


    @Test
    public void testDecrypt() {

        try {
            IhmeEncryptor encryptor = new IhmeEncryptor();
            String resu = encryptor.decrypt("Ciphered{7ffec80f939b006035dafdee03a778fff7f04bf85397920df1c7670a0e8290ec69f83c34b4}");

            Assert.assertEquals("pouet", resu);
        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());

        }


    }

    @Test
    public void testEncrypt() {

        try {
            IhmeEncryptor encryptor = new IhmeEncryptor();
            String resu = encryptor.encrypt("pouet");
            System.out.println(resu);
            Matcher matcher = IhmeEncryptor.CIPHERED_PATTERN.matcher(resu);

            Assert.assertTrue("ya pas ciphererd", matcher.matches());

        } catch (Exception e) {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }

    }


}
