package fr.ca.cat.ihm.security.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.security.dto.SecurityAPIBean;
import fr.ca.cat.ihm.security.dto.SecurityDTO;
import fr.ca.cat.ihm.security.dto.UserDTO;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.util.ReflectionTestUtils;

import static fr.ca.cat.ihm.security.ISecurity.SECURITY_DTO_ATTRIBUTE_NAME;
import static fr.ca.cat.ihm.security.impl.SecurityImpl.AULN_SESSION_ID;

public class MockFileSecurityImplTest {
    MockFileSecurityImpl secu;

    @Before
    public void setup() {
        secu = new MockFileSecurityImpl();
    }

    @Test
    public void testExtractSecurityFromRequest() throws TechnicalException, JsonProcessingException {
        ReflectionTestUtils.setField(secu, "samlTokenStub", "tai/IDDR001.xml");
        ReflectionTestUtils.setField(secu, "sessionIdFile", "tai/IDDR001.xml");
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setAttribute(AULN_SESSION_ID, "eb1f77c7-28c5-4318-90bd-1aabd8601a5c");
        SecurityDTO dto = new SecurityDTO();
        UserDTO user = new UserDTO();
        dto.setUserDTO(user);
        dto.setAulnSessionId("eb1f77c7-28c5-4318-90bd-1aabd8601a5c");
        dto.setApiSecurity(new SecurityAPIBean());
        request.setAttribute(SECURITY_DTO_ATTRIBUTE_NAME, dto);
        SecurityDTO securityDTO = secu.extractSecurityFromRequest(request);
        Assert.assertNotNull(securityDTO);
        request.setAttribute(SECURITY_DTO_ATTRIBUTE_NAME, null);
        securityDTO = secu.extractSecurityFromRequest(request);
        Assert.assertNotNull(securityDTO);
    }
}
