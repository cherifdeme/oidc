package fr.ca.cat.ihm.security.impl;

import fr.ca.cat.ihm.exception.UnauthorizedException;
import fr.ca.cat.ihm.redis.RedisCacheService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.mock.web.MockHttpServletRequest;

import static fr.ca.cat.ihm.security.impl.SecurityImpl.AULN_SESSION_ID;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class SecurityFullRedisTest {
    @Mock
    RedisCacheService redisCacheService;
    SecurityFullRedis secu;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);
        secu = new SecurityFullRedis(redisCacheService);
    }

    @Test
    public void getSamlToken() throws UnauthorizedException {
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setParameter(AULN_SESSION_ID, "eb1f77c7-28c5-4318-90bd-1aabd8601a5c");
        when(redisCacheService.getSAMLRedis(any())).thenReturn("test");
        final String samlToken = secu.getSamlToken(request);
        Assert.assertEquals("test", samlToken);
    }
}
