/**
 *
 */
package fr.ca.cat.ihm.security.impl;

import fr.ca.cat.ihm.SocleJavaTest;
import fr.ca.cat.ihm.config.FwkSocle;
import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.exception.UnauthorizedException;
import fr.ca.cat.ihm.security.ISecurity;
import fr.ca.cat.ihm.security.dto.SecurityAPIBean;
import fr.ca.cat.ihm.security.dto.SecurityDTO;
import fr.ca.cat.ihm.security.dto.UserDTO;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.util.ReflectionTestUtils;

import static fr.ca.cat.ihm.security.ISecurity.SECURITY_DTO_ATTRIBUTE_NAME;
import static fr.ca.cat.ihm.security.impl.SecurityImpl.AULN_SESSION_ID;
import static org.junit.Assert.*;

/**
 * Classe de test
 *
 * @author Louis TOURNAYRE
 */
public class SecurityTest extends SocleJavaTest {

    /**
     * @throws java.lang.Exception
     */
    @Before
    public void setUp() throws Exception {
        FwkSocle.init();
    }

    /**
     * @throws java.lang.Exception
     */
    @After
    public void tearDown() throws Exception {
        FwkSocle.unload();
    }

    /**
     * Test method .
     *
     * @throws Exception
     */
    @Test
    public void testSecurity() throws Exception {
        SecurityDTO security = this.getSecurity();
        assertNotNull("La sécurité ne peut pas être null", security);
        assertNotNull("Le user ne peut pas être null", security.getUserDTO());
        assertNotNull("Les ressources d'habilitation ne peut pas être null", security.getUserDTO().getResources());
        assertTrue("La ressources d'habilitation SOPUTOUS doit exister", security.getUserDTO().hasResource("SOPUTOUS"));
    }

    @Test
    public void testGetContext() throws TechnicalException, UnauthorizedException {
        MockFileSecurityImpl mock = new MockFileSecurityImpl();
        ReflectionTestUtils.setField(mock, "samlTokenStub", "tai/IDDR001.xml");
        SecurityImpl secu = new SecurityImpl();
        MockHttpServletRequest request = new MockHttpServletRequest();
        request.setAttribute(AULN_SESSION_ID, "eb1f77c7-28c5-4318-90bd-1aabd8601a5c");
        SecurityDTO dto = new SecurityDTO();
        UserDTO user = new UserDTO();
        dto.setUserDTO(user);
        dto.setAulnSessionId("eb1f77c7-28c5-4318-90bd-1aabd8601a5c");
        dto.setApiSecurity(new SecurityAPIBean());
        request.setAttribute(SECURITY_DTO_ATTRIBUTE_NAME, dto);
        SecurityDTO securityDTO = secu.extractSecurityFromRequest(request);
        assertNotNull(securityDTO);
        request.setAttribute(SECURITY_DTO_ATTRIBUTE_NAME, null);
        request.addHeader(ISecurity.SAML_HEADER_NAME, mock.getSamlToken(request));
        assertThrows(TechnicalException.class,
                () -> {
                    secu.extractSecurityFromRequest(request);
                });
    }
}
