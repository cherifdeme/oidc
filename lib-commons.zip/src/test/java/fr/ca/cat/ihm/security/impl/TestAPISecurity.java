package fr.ca.cat.ihm.security.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import fr.ca.cat.ihm.SocleJavaTest;
import fr.ca.cat.ihm.security.dto.SecurityAPIBean;
import fr.ca.cat.ihm.web.client.dto.IdToken;
import org.apache.commons.codec.binary.Base64;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;


public class TestAPISecurity extends SocleJavaTest {

    private static final String id_token = "eyJhbGciOiJSUzI1NiJ9.eyJpc3MiOiJodHRwczovL2RldjEtYmRpZy1yZXN0LmNyZWRpdC1hZ3JpY29sZS5mci9nYXRld2F5L2F1dGhlbnRpZmljYXRpb25fY29sbGFib3JhdGV1ci92MiIsInN1YiI6Ik9YNjAwMDEiLCJhdWQiOlsiYXBwIl0sImV4cCI6MTUwNzY0NjY0NywiaWF0IjoxNTA3NjQ2MTA3LCJhdXRoX3RpbWUiOjE1MDc2NDYxMDcsImp0aSI6ImU4ZThkMWRiLTgxZWYtNGU4Yi1hYWY2LThjNzI5MjY2ODg1OSJ9.Tv81uy2ixn38UWgSkz7YKkQETmGl-07Zvrf0QeG2bL4bb_8Mzg51QpcxIMt6iwsCZZnNeRBnLKdI5QfBdO3GqJKXFEIqbm9kI0Mh93C4GlK927uVO5Xfd-fgxNrFWSgxiikEq_6ncCymm4lxyWFwh9BRqAitsYgHu805KRAFWfQNuwnsu5B92ouo6AF5sr_L8x_lTaDR1R3c5xx_mb81wN9fNTAdv5CIV9hYJ4tpE5fJ96GFpT6ffdsMwTLIkCJLtp7hNVP0_datnZlLstTtubb-HGhIpM7clV5eT22bDKS20NWVWLopssAT4TBOmP4hfmyDdihyNUFDYXKPdjYZbA";
    private static final String access_token = "eyJhbGciOiJSU0EtT0FFUCIsInR5cCI6IkpXVCIsImVuYyI6IkExMjhDQkMtSFMyNTYifQ.zsgZU7TQtc55n-ia2hdlcd7BH9lQiNNXdojpgk8YenQQfGlMbYvciR63qMGbhEeholpGRX6w_elGL01sIM3qRyh82e4Re8YG6ndo3FcA7KxeoB56F7RHcDEJ2XP45lhPGbqVbGGV79P4jjAC1ij6bZK9lO4ppnrjyfWluzhPeM1oHn69todarpQU33Vz4eA_dzizOtmV0xPVurIP73_8oMeReo4ObwzhzTqRpeZptQeNkkS75UQfFGMrMF2CS1dRpVXEtkGJsVUlfsWPoCKmEguu1a7iJva2ymhD-f2J_x8lKkVzvRwEuj6LdN8RM-vrYJQnXdAgKAfHb0yk8-pETQ.8GgVJJhoih_UsDsdcyw6UA.evoKn_Z1ptzgR5vptQJuEgwvG-l0IvBbeStov5cmVRnsXOpQp4ArDWS0wHubp4awao7MYSydGN5NH6bkup38Ze9BwSmfAy6bwriCUfHYX1I3YWmu3NsicVnQCdKs5L8F4DfQ6g2OCfNKr9F4_3Uzdf7wBE93VnxwzEjAuV7cSlVEiudKL93RJq1oIjWmQ9SgZBI_I2i0A2o6EEjI4i9A2MXDthrCIbo7zSL42qXorwQ9fJnwLc6iYzJQw6D6cfKm-OUa6y_haM5JgWFCWBprwIuCw8sB_nD2nitOJPUtjdivEwLR8HnSHtEHeXQQap3osfKTHV0mOhM_McCwlfgqjiFgAwx8NffNRISIsKAi79opWtsrPCficiUOgWpCPTPkcliRYc6CDCynGqejgr0Rr-l2SFPuY0qOtV3c8TKw6WVknHsPuuJG3mT89UOxV5aEl4IQCP5qxMvy-g2wpJIavwIY6T-mdqxfEiLY0BAJ8OCsI5LK2xtainycTO69pcVhasngc2aP98Jt4X80Vyo3DMArkg4a5TuBKWM3MtoNQ_pfI5iU4q2oJhH7khCsJNDuUiVo-7VWqTwhV5BdB59zv3wvnjlTM6vzBlf6xTtXpPJnPgXPIAJJi5oFYLDSxqLk910fW4S5kZ56ZJNBv49bhEquSUwCFzx5mQXThEmKG1PjMfBeH_lEY2Bhq3LYPBIN4QqibKDFt7JAixwxYAvBXzv7AeXnU1s6-o0Jp6QfNjRS15tgfHl1p10IWjdFyeHDG7P0HZaIlomHv6PTq1C6BlzTL32yKVuWugAiNB6pCpTfcAK3rP9tRTSp2qYMM9y2AEhhsUluzwN0hiqBTB0oTG2KvuQE1ifLbUAb-QRVUNJ1IVU44hSxjAzX38DrCDdMXPAIYxLdhhsiZrMA6ETFvw26dXodLzXvxKIi9ulY2xpXh58h8gKNOD-dbKZPMzQWufpCYlm2mQiYE6dGJlaSy0FPBv0-eFQwinXFxbS7MaclciThCfVPZ4B7Ex55iIbb3dNlE3rJpQPbz6kbYNQDIP1kuJSlBmhJReXUPrhCogf5k9OPMeUDk5nqKt_PwpZcO1JSg2P0GkeusEY_wltiq1ZgEVvWhs2ch2GDLmwxEhF_vhwBdz_R4DwjrLAbYQNZDGCPZX5j_E53Wz3S4eqBlA.iDJO7uLsGLvcC6LsCh8ZWA";
    private static final String refresh_token = "36e59f63-6f5c-48a0-92a6-82ce4c7a5c34";
    private static final String token_type = "bearer";

    private SecurityAPIBean secuBean;


    /**
     *
     */
    @Before
    public void setUp() {
        secuBean = new SecurityAPIBean();
        secuBean.setAccess_token(access_token);
        secuBean.setToken_type(token_type);
        secuBean.setRefresh_token(refresh_token);
        secuBean.setId_token(id_token);
        secuBean.setExpires_in(540);
    }


    @Test
    public void testIdToken() {
        ObjectMapper om = new ObjectMapper();

        try {
            IdToken toktok = om.readValue(Base64.decodeBase64(secuBean.getId_token().split("\\.")[1]), IdToken.class);

            Assert.assertEquals("expiration time", 1507646647, toktok.getExp());
            Assert.assertEquals("subject_identifier", "OX60001", toktok.getSub());

        } catch (Exception e) {
            Assert.fail(e.getMessage());
        }

    }
}
