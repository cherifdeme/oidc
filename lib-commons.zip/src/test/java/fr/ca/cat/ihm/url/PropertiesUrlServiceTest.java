package fr.ca.cat.ihm.url;

import fr.ca.cat.ihm.BeanConfigurationTest;
import fr.ca.cat.ihm.SocleJavaTest;
import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.controller.bean.SessionMode;
import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.url.IUrlService.ZoneEnum;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.*;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {BeanConfigurationTest.class})
public class PropertiesUrlServiceTest extends SocleJavaTest {
    @Autowired
    private PropertiesUrlServiceImpl urlService;
    private Context context;

    @Before
    public void setUp() throws Exception {
        initContext();
    }

    private void initContext() throws Exception {
        context = super.getContext();

        // initialisation des données de contexte
        context.getContextExecution().getSessionMode().setUsage(SessionMode.USAGE_COL);

        context.getSecurityDTO().getUserDTO().addResource("ABCDEFG01234");
    }


    @Test
    public void testFindLogicalHost() {

        String logicalHost = urlService.findLogicalHost("notDefined", getContext());
        assertNull(logicalHost);

        logicalHost = urlService.findLogicalHost("http://portail.sat.cam", getContext());
        assertEquals("SOPU", logicalHost);
    }


    @Test
    public void testImplMethod() {

        PropertiesUrlServiceImpl impl = (PropertiesUrlServiceImpl) urlService;
        assertNotNull(impl.getMapHoteLogique());
    }


    @Test
    public void testException4CodeCoverage() {
        String url;
        String hoteLogique = "";


        try {
            new PropertiesUrlServiceImpl("notDefined");
        } catch (TechnicalException tex) {
            assertEquals(PropertiesUrlServiceImpl.FWK052, tex.getCode());
        }


        try {
            url = urlService.getURL4LogicalHost(null, getContext(), ZoneEnum.END_USER);
            assertEquals("not reachable", url);
        } catch (TechnicalException tex) {
            assertEquals(PropertiesUrlServiceImpl.FWK051, tex.getCode());
        }


        try {
            url = urlService.getURL4LogicalHost(hoteLogique, null, ZoneEnum.END_USER);
            assertEquals("not reachable", url);
        } catch (TechnicalException tex) {
            assertEquals(PropertiesUrlServiceImpl.FWK051, tex.getCode());
        }


        try {
            url = urlService.getURL4LogicalHost(hoteLogique, getContext(), null);
            assertEquals("not reachable", url);
        } catch (TechnicalException tex) {
            assertEquals(PropertiesUrlServiceImpl.FWK051, tex.getCode());
        }

        try {
            hoteLogique = "MISDEFINED";
            url = urlService.getURL4LogicalHost(hoteLogique, getContext(), ZoneEnum.END_USER);
            assertEquals("not reachable", url);
        } catch (TechnicalException tex) {
            assertEquals(PropertiesUrlServiceImpl.FWK051, tex.getCode());
        }


    }

    @Test
    public void testGetURL4LogicalHost() {
        String url;
        String hoteLogique = "";

        try {
            hoteLogique = "SOPU";
            url = urlService.getURL4LogicalHost(hoteLogique, getContext(), ZoneEnum.END_USER);
            assertEquals("http://portail.sat.cam", url);
        } catch (TechnicalException e) {
            fail(e.getMessage());
        }

        //set CR + EDS
        getContext().getContextExecution().getProfile().setStructureId("86900");
        getContext().getContextExecution().getSystemInfo().getEds().setId("00510");


        try {
            hoteLogique = "IHME";
            url = urlService.getURL4LogicalHost(hoteLogique, getContext(), ZoneEnum.END_USER);
            assertEquals("http://sopu.ca-gascogne.credit-agricole.fr", url);
        } catch (TechnicalException e) {
            fail(e.getMessage());
        }

        //set Type à non collab
        getContext().getContextExecution().getSessionMode().setUsage(SessionMode.USAGE_CLI);

        try {
            hoteLogique = "IHME";
            url = urlService.getURL4LogicalHost(hoteLogique, getContext(), ZoneEnum.FRONT_END);
            assertEquals("http://sopu.ca-technologies.fr", url);
        } catch (TechnicalException e) {
            fail(e.getMessage());
        }

        try {
            hoteLogique = "IHME";
            url = urlService.getURL4LogicalHost(hoteLogique, getContext(), ZoneEnum.BACK_END);
            assertEquals("http://np.sat.cam.ca-technologies.fr", url);
        } catch (TechnicalException e) {
            fail(e.getMessage());
        }

        try {
            hoteLogique = "DONTEXIST";
            url = urlService.getURL4LogicalHost(hoteLogique, getContext(), ZoneEnum.FRONT_END);
            fail("Ce nom d'hote logique n'existe pas et devrait retourner une erreur");
        } catch (TechnicalException e) {
            //erreur attendue
        }
    }

    @Override
    public Context getContext() {
        return context;
    }
}
