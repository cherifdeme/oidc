package fr.ca.cat.ihm.utils.zos;

import com.google.gson.Gson;
import fr.ca.cat.ihm.utils.zos.dto.Zos;
import org.junit.Assert;
import org.junit.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.HashMap;
import java.util.Map;

public class ZosConnectUtilsTest {
    private Map<String, Object> zosMap = new HashMap<>();

    @Test
    public void testAfterInit() {
        zosMap.put("ZUUA0", new Gson().fromJson("{\"libelle\":\"integration vmoa branche A\",\"mapping\":{\"87800\":{\"CaisseRegionale\":\"TTJ2\",\"Domaine\":\"UAG\"},\"88200\":{\"CaisseRegionale\":\"TTJ2\",\"Domaine\":\"UAH\"}}}", Map.class));
        ZosConnectUtils zosConnectUtils = new ZosConnectUtils();
        ReflectionTestUtils.setField(zosConnectUtils, "zosMap", zosMap);
        ReflectionTestUtils.setField(zosConnectUtils, "property", "ZUUA0");
        zosConnectUtils.afterInit();
        final Zos codeCaisse = zosConnectUtils.getCodeCaisse("87800");
        Assert.assertEquals(codeCaisse.getCaisseRegionale(), "TTJ2");
        Assert.assertEquals(codeCaisse.getDomaine(), "UAG");
    }
}
