package fr.ca.cat.ihm.validator;

import fr.ca.cat.ihm.validation.impl.DynamicValidatorImpl;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;

import java.util.HashMap;

public class DynamicValidatorImplTest {
    @Test
    public void testGlobal() {
        DynamicValidatorImpl validator = new DynamicValidatorImpl();
        Assert.assertTrue(validator.getDynamicValidators().isEmpty());
        ;
        final DynamicValidatorImpl spy = Mockito.spy(validator);
        spy.updateMaxValidator("test", new HashMap<>(), true);
        Mockito.verify(spy).updateMaxValidator("test", new HashMap<>(), true);
        spy.updateMaxValidator("test", new HashMap<>(), false);
        Mockito.verify(spy).updateMaxValidator("test", new HashMap<>(), false);
        spy.updateMinValidator("test", new HashMap<>(), false);
        Mockito.verify(spy).updateMinValidator("test", new HashMap<>(), false);
        spy.updateMinValidator("test", new HashMap<>(), true);
        Mockito.verify(spy).updateMinValidator("test", new HashMap<>(), true);
        spy.updatePatternValidator("test", new HashMap<>(), false);
        Mockito.verify(spy).updateMaxValidator("test", new HashMap<>(), false);
    }
}
