package fr.ca.cat.ihm.validator;

import jakarta.validation.ConstraintValidator;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;

public class NopConstraintValidatorFactoryTest {
    @Test
    public void testGetInstance() {
        NopConstraintValidatorFactory constraintValidatorFactory = new NopConstraintValidatorFactory();

        final ConstraintValidator<?, ?> instance = constraintValidatorFactory.getInstance(null);
        Assert.assertEquals(instance.isValid(null, null), true);
        final ConstraintValidator<?, ?> spy = Mockito.spy(instance);
        spy.initialize(null);
        Mockito.verify(spy).initialize(null);
    }
}
