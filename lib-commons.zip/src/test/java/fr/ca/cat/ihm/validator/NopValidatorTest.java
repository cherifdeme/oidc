package fr.ca.cat.ihm.validator;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.executable.ExecutableValidator;
import jakarta.validation.metadata.BeanDescriptor;
import org.junit.Assert;
import org.junit.Test;

import java.util.Set;

public class NopValidatorTest {
    NopValidator nopValidator = new NopValidator();

    @Test
    public void testValidate() {
        final Set<ConstraintViolation<Object>> validate = nopValidator.validate(null);
        Assert.assertNotNull(validate);
        final Object unwrap = nopValidator.unwrap(null);
        Assert.assertNull(unwrap);
        final ExecutableValidator validator = nopValidator.forExecutables();
        Assert.assertNull(validator);

    }

    @Test
    public void testValidateProperty() {
        final Set<ConstraintViolation<Object>> constraintViolations = nopValidator.validateProperty(null, null);
        Assert.assertNotNull(constraintViolations);
    }

    @Test
    public void testValidateValue() {
        final Set<ConstraintViolation<Object>> constraintViolations = nopValidator.validateValue(null, null, null, null);
        Assert.assertNotNull(constraintViolations);
    }

    @Test
    public void testGetConstraintsForClass() {
        final BeanDescriptor constraintsForClass = nopValidator.getConstraintsForClass(null);
        Assert.assertNull(constraintsForClass.getConstraintsForConstructor(null));
        Assert.assertNull(constraintsForClass.getConstraintsForProperty(null));
        Assert.assertNull(constraintsForClass.getConstraintDescriptors());
        Assert.assertNull(constraintsForClass.getConstraintsForMethod(null, null, null));
        Assert.assertNull(constraintsForClass.getConstrainedConstructors());
        Assert.assertNull(constraintsForClass.getConstrainedMethods(null));
        Assert.assertNull(constraintsForClass.getConstrainedProperties());
        Assert.assertNull(constraintsForClass.getElementClass());
        Assert.assertFalse(constraintsForClass.isBeanConstrained());
        Assert.assertFalse(constraintsForClass.hasConstraints());
        Assert.assertNull(constraintsForClass.findConstraints());
    }

}
