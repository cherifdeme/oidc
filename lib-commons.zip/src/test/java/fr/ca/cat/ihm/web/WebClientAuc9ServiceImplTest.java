package fr.ca.cat.ihm.web;

import com.github.tomakehurst.wiremock.junit.WireMockRule;
import fr.ca.cat.ihm.SocleJavaTest;
import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.security.auc9.WebClientAuc9ServiceImpl;
import fr.ca.cat.ihm.security.dto.SecurityAPIBean;
import fr.ca.cat.ihm.web.client.RsConf;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.mockito.Mockito;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static com.github.tomakehurst.wiremock.common.ContentTypes.ACCEPT;
import static com.github.tomakehurst.wiremock.common.ContentTypes.CONTENT_TYPE;
import static org.mockito.Mockito.times;


public class WebClientAuc9ServiceImplTest extends SocleJavaTest {
    @Rule
    public WireMockRule wireMockRule = new WireMockRule(60269);

    WebClientAuc9ServiceImpl webClient;

    @Before
    public void setup() throws Exception {
        RsConf rsConf = getAuthentificationCollaborateurV2();
        webClient = new WebClientAuc9ServiceImpl(rsConf, getContext());
    }

    @Test
    public void testGetUATokensFromJWT() throws TechnicalException {
        this.stub("/authentification_collaborateur/v2/token", response);
        final SecurityAPIBean uaTokensFromJWT = webClient.getUATokensFromJWT();
        Assert.assertNotNull(uaTokensFromJWT);

    }

    @Test
    public void testGetOpenidToken() throws TechnicalException {
        this.stub("/authentification_collaborateur/v2/openid/token", response);
        final SecurityAPIBean uaTokensFromJWT = webClient.getOpenidToken();
        Assert.assertNotNull(uaTokensFromJWT);

    }

    @Test
    public void testGetToken() throws TechnicalException {
        this.stub("/authentification_collaborateur/v2/token", response);
        final SecurityAPIBean uaTokensFromJWT = webClient.getToken();
        Assert.assertNotNull(uaTokensFromJWT);

    }

    @Test
    public void testRefreshToken() throws TechnicalException {
        this.stub("/authentification_collaborateur/v2/token", response);
        final SecurityAPIBean uaTokensFromJWT = webClient.refreshToken("test");
        Assert.assertNotNull(uaTokensFromJWT);

    }

    @Test
    public void testRevokeToken() {
        this.stub("/authentification_collaborateur/v2/revoke", response);
        final WebClientAuc9ServiceImpl spy = Mockito.spy(webClient);
        spy.revokeToken(new SecurityAPIBean());
        Mockito.verify(spy, times(1)).revokeToken(Mockito.any());
        Mockito.verify(spy, times(1)).executePostRequest(Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any());
    }

    private void stub(String uri, String response) {
        stubFor(post(uri)
                .withHeader(CONTENT_TYPE, equalTo("application/x-www-form-urlencoded;charset=UTF-8"))
                .withHeader(ACCEPT, containing("*/*"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader(CONTENT_TYPE, "application/json")
                        .withBody(response)
                )
        );
    }

    private RsConf getAuthentificationCollaborateurV2() {
        RsConf conf = new RsConf();
        conf.setAuthorization("Ciphered{4df0ce0384f60c4b0adae6d6698e58da8cb942c372bbae14d07c7655aea89970402ca50ea7849cef95679013d66f76940843feee8a6a8d488753d2fa24827ea28f1f853e75a85335f03f8572578d44929378632e15185cd25678a07afa1a6b1396e37eae3277516d9394896bdb5cfcf19b5e1b8d2851531a2b7089e780f0f7e2e12ac07ae694f1e880b1b647edc87d657b6f}");
        conf.setUrl(wireMockRule.url("/authentification_collaborateur/v2"));
        return conf;
    }

    private String response = "{\"token_type\":\"bearer\",\"expires_in\":2700,\"access_token\":\"eyJ0eXAiOiJKV1QiLCJlbmMiOiJBMTI4Q0JDLUhTMjU2IiwiYWxnIjoiUlNBLU9BRVAifQ.i6YRg5sN795WmgvdjH_2m6sciJQLLdFxte-w68SQ2AyV4ODshhxImbo6CHegDlhtNY08fS56cHpqEiOMPT_udzLe2jTdmMlh5vhKHjAIpq4eXJryFrWQq_il8WmdG_0sYoNDXJR7z0MrkCbZAG__t25Rqsm2E4ci5P6W7HNHyUeLdZP5pMKQoxj0-h_X9dGX0u49CtvFPLFOCFgWWiB8G9SM_L5AuyIlSfs_IMzibYU1QtjqQwQPsbjnAK4YigDDE9gA1rZj5ETeFbaC5jzIOOmjacJ05hfAtWBos2jdiu4fV1dIzbWKWQRYYMogXwJrlevPQ__PU9ABYrSMTOLvyg.AtQ2WvRzL6F4sc7mraNRyA.0HbiKJOTdu20QRXmLOye3KN_kHdGbLJoFtmWZjhIpXTmrLGNWsVkz9agoQo2FJgcJDLqaZ3tKje9HWA-qinrkAbu3o-tyhesh0VGLTX7jR_kA0CpKfuHm8YLLcLeiLIxwb9DoSjfodVaX2fMLW9Dmw6lgbkYWLRFYxba3MDgxHi7IevynHhOGh892ztQu4LrxI6IPIOeQ5nfJ6kIft1KS96Jr1ToveHaCBBI6SYlfbOUs3oyAx_M1rBpSUD-AMhoGfkUqVQ3LntKfB7TmzS4J8zvUO9oZEmvrKo1Qt4pzr50FKnhz1IAocUaznbItrzyuro0Gx2g4ijGl4niT2a_FWuXVuBIx-l1rs-lor914YmsksC7msRyA1Zp0b4i1ZbxM-uN-jdVOUAuQzjsxUkSNMbs9WbQZWgJVGf74MHe1JZfJn33ddPI1X_BJXIldUR_ImpHoVUHBWPScFlxK5F76HvOFATQ2ytquTWCezwHrKBYwu7toP27EP7gtoIPM6zp5Lvaa-KLBSoFOM8ykWr_XITuvUwc2EAlG-xLwTuWF3JarCd5qqWEOQdHZNBgLN4OiF0aaF1IJ8Eg6o2Njw1b9zlzwMSspbYNI6y9frH_QolBXzZGpt0Ggv3ZRPHgrzpvtqn3pa6Gt91fPtUuh77TkqLO8kMAAC2g3k_uGLAll6vkkT--RlAkPV1eDqiw0UYRHxkI_JfEumt7FdW0Qxi4clYrrAyupa09FQa-98B26QY9fnPocJA38ABFhD54hwnsKmqkR-XsoF9q9rdqrEcxAAFIO9N2dNrCGd7GoO4AAwhHnbBXBHwusSsGD6wgbo1l9OLGiG0k-jK2-bAXhzOeThm5EO5I0XlCL_64qI9LcDzZ8MtQ-XEWmsKV4MqpzFMitO-cfs79yza9AWTJfZxAOsVwePtNtDJWqwo1hAyyIwIvPfVJUm2rGDTsbeMlWMPaTMx22cxlPTrawRRFAyE_rh8SdKrVnjVQ9avPWPcy9MN-XuAZRcyvUeCFgK1NOJIvBcM0TVF75q14DYN7Um-OcWBl1IbbO3cb5kEmvSIGNRTEru5u3L2F_pGtz81bh9drsPzSn60QwSi-4z3wbLqTEu4NN-3AejfOSKwmr25WyqqMqoYwbeYS7fmpmgzAXC-2rv2bHJOojhTLTWhL6OwdfOu9JrKQvKUoHbFf1Fiviq8YfxflY-mYYBquPSXZFSviJbgFHshh6EdfCY8pLIKFYEYCkCjXOMQaWo4izNsDVRgBCmBfS4J1sfqHfPVKNkPuwECNpN4IATpZA_OrA7NSxbKUmDaG9JhzWOWVtDPkU1oRR_bm0IlyGQYv5aR3amTIGRtcUGI4KTL-NZDIbi88SR-hMMt1fdQ31CRMV2RX4gEBYI301CKaoInMmmSm8au9xuoSNn4pDvqPnVJewj2govqe5P5VPDwomfSebvXfKjWKnAzXh5DNICcx0Qr7h0f8qADBbd31lh1tNUSxBcEXBMzis5GLhfFK3hiqW_yXR8vlmxN2V05F5T88LXo4GCtpoTXQR_GI4_qTuiNYNSawmrWH7zoSx8JPC6aQTlbbmEf_tcQyb7zTOEUIUAfB4DXH.QpgaduIek71Sld4oM_srCA\",\"id_token\":\"eyJraWQiOiJwSVRqa0JPNm9STnJDUU43VGhWTTRHejJkTHBRVjJRM1hITk5Fb2o5X2k0IiwiYWxnIjoiUlMyNTYifQ.eyJpc3MiOiJodHRwczovL3JjdDEtcHJpdmF0ZS5hcGkuY3JlZGl0LWFncmljb2xlLmZyL2F1dGhlbnRpZmljYXRpb25fY29sbGFib3JhdGV1ci92MiIsInN1YiI6Ik9XNjAwMDEiLCJhdWQiOlsiZWM0YTdhN2U1MDRlNTRjMGIzMmU1MmQxYWM1YmIxOWJkMTliYThhZjk5MDQ4ZmRkMzZjYzk3MmFkNWFkMWMzNSIsImh0dHBzOi8vcmN0MS1wcml2YXRlLmFwaS5jcmVkaXQtYWdyaWNvbGUuZnIvYXV0aGVudGlmaWNhdGlvbl9jb2xsYWJvcmF0ZXVyL3YyIl0sImV4cCI6MTcxNzc2MzM1MCwiaWF0IjoxNzE3NzYyODEwLCJhdXRoX3RpbWUiOjE3MTc3NjI4MTAsImp0aSI6IjU1N2Y3ZTc5LWYxODYtNDNiYy05N2YzLTE0MWEzNTdmODJjZCIsInNpZCI6ImI5OGFjOTEzLWRlM2MtNGQyNi05Y2E3LWM1ODhjNTEyOTAxMCIsImFjciI6IjIwIiwiYXpwIjoiZWM0YTdhN2U1MDRlNTRjMGIzMmU1MmQxYWM1YmIxOWJkMTliYThhZjk5MDQ4ZmRkMzZjYzk3MmFkNWFkMWMzNSIsImFtciI6WyJwd2QiXX0.j_E36qMyzk5XL9YMeafjLlboZ-geVGETlIJyB_XZql0KlqvGxxkufI6-sG0VDl_n1xgzokv9lby1wmgfLAI-cQAtQvfl71lpdhlZN-02-Y1xuDXlffONRR_X8H5iGckUFLek5x6j9PCK8Ii75b510Ju8p8SmQcYVehkAorDeK5lmQGxecOj0MbrUUy1mJRafAI7B2GtDJnQQ6wp3Z4ZT9P3kiZBfW6B6zygHdY3OMDX2VjYpIh26rEbD4bzm4zhHSlNX9lQ1pSe1OTaHRu1KrxTaeSqKsfVM1oGzjghLvTR1FxLHDr_0b-6U25iBcty5rh6EqyxhzBz0t1ZRa8YJcg\",\"refresh_token\":\"adb5c458-3a8c-47c3-83e6-d94fdfe03f7b\",\"scope\":\"openid\"}";
}
