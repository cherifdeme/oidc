package fr.ca.cat.ihm.web;

import fr.ca.cat.ihm.BeanConfigurationTest;
import fr.ca.cat.ihm.SocleJavaTest;
import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.redis.RedisCacheService;
import fr.ca.cat.ihm.redis.RedisCacheUAService;
import fr.ca.cat.ihm.security.auc9.WebClientAuc9ServiceImpl;
import fr.ca.cat.ihm.security.dto.SecurityAPIBean;
import fr.ca.cat.ihm.utils.Constants;
import fr.ca.cat.ihm.utils.RedisCacheUtils;
import fr.ca.cat.ihm.web.client.RsConf;
import fr.ca.cat.ihm.web.client.WebClientFactory;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import static org.junit.Assert.assertThrows;
import static org.mockito.Mockito.*;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {BeanConfigurationTest.class})
public class WebClientFactoryTest extends SocleJavaTest {

    Context context;
    WebClientFactory factory;
    @Autowired
    private RedisCacheService redisCacheService;
    @Mock
    private RedisCacheUAService redisCacheUAService;
    @Autowired
    @Qualifier("test_resilience_places")
    private RsConf confAuc9Api2m;
    @Mock
    private CacheManager cacheManager;
    @Mock
    private Cache cache;

    @Before
    public void setup() throws Exception {
        MockitoAnnotations.initMocks(this);
        context = getContext();
    }

    @Test
    public void testGetUaSecurityApiBean() {
        SecurityAPIBean refresh = new SecurityAPIBean();
        refresh.setRefresh_token("test");
        context.getSecurityDTO().setAulnSessionId("test");
        final RedisCacheService spy = spy(redisCacheService);
        final var sessionKey = RedisCacheUtils.getRedisKey(Constants.API2M_SESSION_PREFIX, context);
        when(cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE)).thenReturn(cache);
        doReturn(refresh).when(spy).getRefreshToken(context);
        doReturn(refresh).when(spy).getTokens(context);
        doNothing().when(cache).put(sessionKey, refresh);
        doNothing().when(spy).saveToken(context, refresh);
        factory = new WebClientFactory(spy, redisCacheUAService, confAuc9Api2m, new WebClientAuc9ServiceImpl(confAuc9Api2m, context));

        assertThrows(NullPointerException.class,
                () -> {
                    factory.getUaSecurityApiBean(confAuc9Api2m, context, "test", context.getUaVersion());
                });

    }

    @Test
    public void testGetRsProxy() throws TechnicalException {
        SecurityAPIBean refresh = new SecurityAPIBean();
        refresh.setRefresh_token("test");
        context.getSecurityDTO().setAulnSessionId("test");
        final RedisCacheService spy = spy(redisCacheService);
        final var sessionKey = RedisCacheUtils.getRedisKey(Constants.API2M_SESSION_PREFIX, context);
        when(cacheManager.getCache(Constants.REFRESH_TOKEN_CACHE)).thenReturn(cache);
        doReturn(refresh).when(spy).getRefreshToken(context);
        doReturn(refresh).when(spy).getTokens(context);
        doNothing().when(cache).put(sessionKey, refresh);
        doNothing().when(spy).saveToken(context, refresh);
        factory = new WebClientFactory(spy, redisCacheUAService, confAuc9Api2m, new WebClientAuc9ServiceImpl(confAuc9Api2m, context));
        assertThrows(NullPointerException.class,
                () -> {
                    factory.getRsProxy(confAuc9Api2m, context, context.getUaId(), context.getUaVersion());
                });

        assertThrows(NullPointerException.class,
                () -> {
                    factory.getRsProxy(confAuc9Api2m, context, context.getUaId(), context.getUaVersion());
                });
    }

}
