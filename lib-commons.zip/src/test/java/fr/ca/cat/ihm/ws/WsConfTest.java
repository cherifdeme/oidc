package fr.ca.cat.ihm.ws;

import fr.ca.cat.ihm.BeanConfigurationTest;
import fr.ca.cat.ihm.ws.generated.srvutestsoclesoa.SRVUTestSocleSOA;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.IOException;
import java.net.URL;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {BeanConfigurationTest.class})
public class WsConfTest {
    @Autowired
    ResourceLoader resourceLoader;

    @Test
    public void testGlobal() throws IOException {
        WsConf wsConf = new WsConf();
        wsConf.setServiceInterface(SRVUTestSocleSOA.class);
        wsConf.setServiceName("SRVU_TestSocleSOA_1_0");
        final URL url = resourceLoader.getResource("wsdl/SRVU_TestSocleSOA.wsdl").getURL();
        wsConf.setWsdlDocumentUrl(url);
        wsConf.setNamespaceUri("test");
        wsConf.setEndpointAddress("test");
        wsConf.setPortName("test");
        Assert.assertEquals("test", wsConf.getPortName());
        Assert.assertEquals("test", wsConf.getEndpointAddress());
        Assert.assertEquals("SRVU_TestSocleSOA_1_0", wsConf.getServiceName());
        Assert.assertEquals("test", wsConf.getNamespaceUri());
        Assert.assertEquals(SRVUTestSocleSOA.class, wsConf.getServiceInterface());
        Assert.assertEquals(wsConf.getWsdlDocumentUrl().toString(), url.toString());
    }
}
