package fr.ca.cat.ihm.ws;

import fr.ca.cat.ihm.BeanConfigurationTest;
import fr.ca.cat.ihm.SocleJavaTest;
import fr.ca.cat.ihm.ws.impl.HeaderServiceHandler;
import fr.ca.cat.ihm.ws.impl.WsProxyImpl;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {BeanConfigurationTest.class})
public class WsProxyImplTest extends SocleJavaTest {
    private static final String CB_NAME_TESTSOCLESOA_BUSINESS = "test_resilience_sutestsoclesoa_business";
    WsConf wsconf;
    HeaderServiceHandler headerServiceHandler;

    @Autowired
    private ApplicationContext context;

    @Test
    public void testWsProxyImpl() throws Exception {
        wsconf = (WsConf) context.getBean(CB_NAME_TESTSOCLESOA_BUSINESS);
        headerServiceHandler = new HeaderServiceHandler(getContext(), wsconf);
        WsProxyImpl impl = new WsProxyImpl(wsconf, headerServiceHandler);
        Assert.assertNotNull(impl);
    }
}