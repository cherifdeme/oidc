package pro.akvel.spring.converter.generator.param;

/**
 * ConstructIndexParam
 *
 * @author akvel
 * @since 14.08.2020
 */
public interface ConstructIndexParam extends ConstructorParam {

    Integer getIndex();
}
