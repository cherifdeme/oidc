package pro.akvel.spring.converter.generator.param;

/**
 * Marker
 *
 * @author akvel
 * @since 12.09.2021
 */
public interface PropertyParam extends Param{

    String getName();
}
