#!/bin/sh

readonly T_NOM_TRIBU="cats/tribu-socles-architecture"
readonly P_CODE_PRODUIT="p0042"
readonly S_CODE_SOLUTION="s1235"
readonly G_TAG="v1.0.0"
if [ -n "${T_NOM_TRIBU}" ]; then
  git init
  git switch -c develop
  git remote add origin "https://scm.saas.cagip.group.gca/${T_NOM_TRIBU}/${P_CODE_PRODUIT}/${S_CODE_SOLUTION}/s1235-uafromscratch/testing.git"
 git add .
  git commit -m "🎉 Initial commit"
  git push -u origin develop
  git switch -c master
  git push -u origin master
  git switch develop
  git tag -a ${G_TAG} -m "Creation Template ${G_TAG}"
  git push origin ${G_TAG}
fi
