package fr.ca.cats.p0042.s1235.config;

import fr.ca.cat.ihm.web.client.RsConf;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ApiConfig {
    @Value("${api.place.url}")
    private String placesURL;
    @Value("${api.authorization}")
    private String authorizationApi2m;
    @Value("${api.client-id}")
    private String clientID;

    @Bean("Places")
    public RsConf getPlacesBean() {
        RsConf rsConf = new RsConf();
        rsConf.setUrl(placesURL);
        rsConf.setAuthorization(authorizationApi2m);
        rsConf.setClientId(clientID);
        rsConf.setUseClientCredentials(true);
        return rsConf;
    }


}
