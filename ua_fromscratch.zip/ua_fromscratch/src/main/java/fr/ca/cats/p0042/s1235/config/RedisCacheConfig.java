package fr.ca.cats.p0042.s1235.config;

import fr.ca.cat.ihm.security.dto.SecurityAPIBean;
import fr.ca.cats.p0042.s1235.tools.Constants;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.redis.cache.RedisCacheConfiguration;
import org.springframework.data.redis.cache.RedisCacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializationContext;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;


/**
 * Classe de configuration de l'utilisation du cache REDIS pour le stockage des token de l'UA
 *
 * @author Cdeme
 */
@Configuration
@EnableCaching
public class RedisCacheConfig {

    /**
     * Injection de prefix du cache Redis
     */
    @Value("${redis.cache.prefix}")
    private String redisCachePrefix;

    /**
     * Injection de TTL pour la cache des refresh token
     * Default Value Lax
     */
    @Value("${redis.cache.refresh.token.ttl}")
    private Duration refreshTokenCacheTtl;

    @Value("${redis.cache.token.ttl}")
    private Duration tokenCacheTtl;

    /**
     * Création du bean permettant la création du cache manager Redis.
     * <br>Doit être initialisé en premier (avant utilisation par le socle.java)
     *
     * @param redisConnectionFactory Une factory de connexion au REDIS
     * @return Un cache manager
     * @see {@link CacheManager}
     */
    @Bean
    @Primary
    @Qualifier("redis_cache_ua")
    public CacheManager cacheManager(RedisConnectionFactory redisConnectionFactory) {
        // Creation liste des caches
        Map<String, RedisCacheConfiguration> cacheConfigurations = new HashMap<>();

        // Création configuration par défaut des caches
        var refreshTokenCacheConfiguration = RedisCacheConfiguration.defaultCacheConfig()
                .entryTtl(refreshTokenCacheTtl)
                .prefixCacheNameWith(redisCachePrefix)
                .serializeValuesWith(RedisSerializationContext.SerializationPair.fromSerializer(new Jackson2JsonRedisSerializer<>(String.class)));

        var tokenCacheConfiguration = RedisCacheConfiguration.defaultCacheConfig()
                .entryTtl(tokenCacheTtl)
                .prefixCacheNameWith(redisCachePrefix)
                .serializeValuesWith(RedisSerializationContext.SerializationPair.fromSerializer(new Jackson2JsonRedisSerializer<>(SecurityAPIBean.class)));

        // Ajout du cache pour la gestion des Refresh Token
        cacheConfigurations.put(Constants.REFRESH_TOKEN_CACHE, refreshTokenCacheConfiguration);
        cacheConfigurations.put(Constants.TOKEN_CACHE, tokenCacheConfiguration);

        return RedisCacheManager.builder(redisConnectionFactory).cacheDefaults(RedisCacheConfiguration.defaultCacheConfig()).withInitialCacheConfigurations(cacheConfigurations).build();
    }

}
