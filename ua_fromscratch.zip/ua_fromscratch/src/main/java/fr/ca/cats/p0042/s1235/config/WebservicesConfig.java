package fr.ca.cats.p0042.s1235.config;

import fr.ca.cats.p0042.s0115.lib.connector.soa.SoaConnector;
import fr.ca.cats.p0042.s0115.lib.connector.soa.SoaConnectorImpl;
import fr.ca.cats.p0042.s0115.lib.connector.soa.impl.SoaConnectorMessageCallback;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.security.task.DelegatingSecurityContextAsyncTaskExecutor;

import java.util.concurrent.Executor;

@Configuration
public class WebservicesConfig {
    @Value("${soa.srvutestsoclesoa.gen.package}")
    private String srvutestsoclesoaPackage;

    @Bean
    @Qualifier("srvutestsoclesoaMarshaller")
    public Jaxb2Marshaller srvutestsoclesoaMarshaller() {
        Jaxb2Marshaller jaxb2Marshaller = new Jaxb2Marshaller();
        jaxb2Marshaller.setContextPaths(srvutestsoclesoaPackage);
        return jaxb2Marshaller;
    }

    @Bean
    @Qualifier("soacallback")
    public SoaConnectorMessageCallback commonCallback() {
        return new SoaConnectorMessageCallback();
    }

    @Bean
    @Autowired
    public SoaConnector getSoaConnector(@Qualifier("soacallback") SoaConnectorMessageCallback callback) {
        return new SoaConnectorImpl(callback);
    }

    // ==> nécessaire uniquement si utilisation du pattern TimeLimiter (Resilience4J) sur l'appel SOA
    @Bean
    public Executor executor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(6);
        executor.setMaxPoolSize(10);
        executor.setQueueCapacity(100);
        executor.setThreadNamePrefix("ua_fromscratch-");
        executor.initialize();
        return new DelegatingSecurityContextAsyncTaskExecutor(executor);
    }
}
