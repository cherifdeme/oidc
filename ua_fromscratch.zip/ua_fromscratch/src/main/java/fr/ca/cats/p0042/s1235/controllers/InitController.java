package fr.ca.cats.p0042.s1235.controllers;

import fr.ca.cat.ihm.controller.AbstractBreakableController;
import fr.ca.cat.ihm.controller.dto.ResponseDTO;
import fr.ca.cat.ihm.controller.dto.StateDTO;
import fr.ca.cat.ihm.controller.dto.StateDTO.PageType;
import fr.ca.cat.ihm.exception.SocleException;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.utils.Version;
import fr.ca.cats.p0042.s1235.dto.RequestInitDTO;
import fr.ca.cats.p0042.s1235.dto.WelcomeDTO;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@PreAuthorize("hasAuthority('SOPUTOUS')")
@RestController
@RequestMapping("/rest/ua_fromscratch")
public class InitController extends AbstractBreakableController {

    private static final Logger LOGGER = LogFactory.getLog();
    @Value("${ua.version.framework.springboot:non renseignée}")
    private String versionSpringBoot;

    @Value("${version:non renseignée}")
    private String version;

    @Value("${ua.ID:non renseignée}")
    private String id;

    public InitController() {
        super();
    }


    @PostMapping(value = "/init")
    public @ResponseBody ResponseDTO
    init(@RequestBody RequestInitDTO requestDTO) throws SocleException {

        StateDTO stateDTO = new StateDTO();
        stateDTO.setLabel("WELCOME");
        stateDTO.setPageType(PageType.HTML);

        WelcomeDTO welcomeDTO = new WelcomeDTO();
        welcomeDTO.setWelcomeMessage("UA générée ua_fromscratch - Springboot version : " + versionSpringBoot);

        LOGGER.debug("InitController ua_fromscratch", getContext());

        return createSuccessfulResponse(welcomeDTO, stateDTO);
    }

    @Override
    protected String getUaID() {
        return id;
    }

    @Override
    protected Version getUaVersion() {
        return new Version(version);
    }
}
 
