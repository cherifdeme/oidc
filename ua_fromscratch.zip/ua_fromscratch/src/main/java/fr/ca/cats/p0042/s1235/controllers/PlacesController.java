package fr.ca.cats.p0042.s1235.controllers;

import fr.ca.cat.ihm.controller.AbstractBreakableController;
import fr.ca.cat.ihm.controller.dto.ResponseDTO;
import fr.ca.cat.ihm.controller.dto.StateDTO;
import fr.ca.cat.ihm.controller.dto.StateDTO.PageType;
import fr.ca.cat.ihm.exception.BusinessException;
import fr.ca.cat.ihm.exception.SocleException;
import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.utils.Version;
import fr.ca.cat.ihm.utils.zos.ZosConnectUtils;
import fr.ca.cat.ihm.web.client.IRsProxy;
import fr.ca.cat.ihm.web.client.RsConf;
import fr.ca.cat.ihm.web.client.dto.http.GetMethod;
import fr.ca.cats.p0042.s1235.dto.ResponseServiceDTO;
import fr.ca.cats.p0042.s1235.dto.places.CR;
import fr.ca.cats.p0042.s1235.exceptions.ApiException;
import fr.ca.cats.p0042.s1235.services.api.IPlacesService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.StringJoiner;

@PreAuthorize("hasAuthority('SOPUTOUS')")
@RestController
@RequestMapping("/rest/places")
public class PlacesController extends AbstractBreakableController {

    private static final Logger LOGGER = LogFactory.getLog();
    private static final String TST001 = "TST001";
    private IPlacesService placesService;

    @Autowired
    public PlacesController(IPlacesService placesService) {
        this.placesService = placesService;
    }

    /**
     * Ressource pour r�cup�rer la liste des CR
     *
     * @return Liste de {@link CR}
     * @throws SocleException Erreur lors de l'appel à l'API
     */
    @PostMapping("/regional_banks")
    public @ResponseBody ResponseDTO getCRList() throws SocleException {
        StateDTO stateDTO = new StateDTO();
        stateDTO.setLabel("WELCOME");
        stateDTO.setPageType(PageType.HTML);
        final var responseServiceDTO = new ResponseServiceDTO();
        responseServiceDTO.setServiceReturn("");

        // Obtention Bean de configuration Places
        final var apiConf = (RsConf) getBean("Places");

        // Appel API Places
        CR[] crs = null;

        try {
            crs = this.placesService.getCRList(String.format("Bearer %s", getAccessToken(apiConf)));

            final var joiner = new StringJoiner(" - ");
            for (CR cr : crs) {
                joiner.add(cr.getRegionalBankName());
            }

            final var concat = joiner.toString();

            responseServiceDTO.setServiceReturn(concat);

        } catch (ApiException e) {
            LOGGER.error("Erreur sur l'appel à l'API Places, message : " + e.getMessage(), e, null);
            throw new BusinessException(getContext(), e, TST001);
        } catch (Exception e) {
            throw new TechnicalException(getContext(), e, TST001);
        }

        return createSuccessfulResponse(responseServiceDTO, stateDTO);

    }

    protected String getUaID() {
        return "ua_fromscratch";
    }

    protected Version getUaVersion() {
        return new Version("1.0");
    }
}
