package fr.ca.cats.p0042.s1235.controllers;

import fr.ca.cat.ihm.controller.AbstractBreakableController;
import fr.ca.cat.ihm.controller.dto.ResponseDTO;
import fr.ca.cat.ihm.controller.dto.StateDTO;
import fr.ca.cat.ihm.controller.dto.StateDTO.PageType;
import fr.ca.cat.ihm.exception.BusinessException;
import fr.ca.cat.ihm.exception.SocleException;
import fr.ca.cat.ihm.exception.TechnicalException;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.utils.Version;
import fr.ca.cats.p0042.s1235.dto.RequestServiceDTO;
import fr.ca.cats.p0042.s1235.dto.ResponseServiceDTO;
import fr.ca.cats.p0042.s1235.services.soa.ITestSocleSoaService;
import fr.ca.cats.p0042.s1235.srvutestsoclesoa.generated.SRVUTestSocleSOAtesterBFFault;
import fr.ca.cats.p0042.s1235.srvutestsoclesoa.generated.TesterBFReponse;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import jakarta.xml.bind.JAXBElement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;
import java.util.concurrent.CompletableFuture;

@PreAuthorize("hasAuthority('SOPUTOUS')")
@RestController
@RequestMapping("/rest/soa")
public class SoaController extends AbstractBreakableController {
    public static final Logger LOGGER = LogFactory.getLog();
    private static final String TST000 = "TST000";
    @Value("${roseSoaHost}")
    private String rosesoahosts;
    @Value("${soa.srvutestsoclesoa.path}")
    private String srvutestsoclesoaPath;
    private ITestSocleSoaService soaService;

    @Autowired
    public SoaController(ITestSocleSoaService soaService) {
        this.soaService = soaService;
    }

    /**
     * Appel opération TesterBF du SRVU_TestSocleSoa - méthode avec lib-soa-connector
     * <p>
     * CircuitBreaker déporté dans TestSocleSoaServiceImpl
     *
     * @return {@link ResponseDTO}
     * @throws SocleException
     */
    @PostMapping("/srvutestsoclesoa/testerbf")
    public @ResponseBody ResponseDTO testerBF(@RequestBody RequestServiceDTO paramServiceDTO) throws Exception {

        StateDTO stateDTO = new StateDTO();
        stateDTO.setLabel("WELCOME");
        stateDTO.setPageType(PageType.HTML);

        LOGGER.debug("SoaController - testbfappelbf, paramètre en entrée :" + paramServiceDTO.getParamService(), getContext());

        ResponseServiceDTO responseServiceDTO = new ResponseServiceDTO();

        CompletableFuture<JAXBElement<Object>> tbf = soaService.appelTestSocleSoa(getContext(), rosesoahosts, srvutestsoclesoaPath, paramServiceDTO.getParamService(), "testerbf");
        final JAXBElement<Object> objectJAXBElement = tbf.get();
        final TesterBFReponse o = (TesterBFReponse) Optional.ofNullable(objectJAXBElement).map(JAXBElement::getValue).orElse(null);
        responseServiceDTO.setServiceReturn(o.getSortie().getReponse());

        return createSuccessfulResponse(responseServiceDTO, stateDTO);
    }

    /**
     * Appel opération TesterBF du SRVU_TestSocleSoa avec custom callback
     *
     * @return {@link ResponseDTO}
     * @throws SocleException
     */
    @PostMapping(value = "/srvutestsoclesoa/testerbf/with_custom_callback")
    public @ResponseBody ResponseDTO testerBFWithCustomCallback(@RequestBody RequestServiceDTO paramServiceDTO) throws SocleException {

        StateDTO stateDTO = new StateDTO();
        stateDTO.setLabel("WELCOME");
        stateDTO.setPageType(PageType.HTML);
        ResponseServiceDTO responseServiceDTO = new ResponseServiceDTO();
        responseServiceDTO.setServiceReturn("");

        try {
            TesterBFReponse tbf = soaService.appelTestSocleSoaWithCustomCallback(getContext(), rosesoahosts,
                    srvutestsoclesoaPath, paramServiceDTO.getParamService(), "with_custom_callback");
            responseServiceDTO.setServiceReturn(tbf.getSortie().getReponse());
        } catch (SRVUTestSocleSOAtesterBFFault e) {
            throw new BusinessException(getContext(), e, TST000);
        } catch (Exception e) {
            throw new TechnicalException(getContext(), e, TST000);
        }

        return createSuccessfulResponse(responseServiceDTO, stateDTO);
    }


    public ResponseDTO soaRequestFallback(Exception e) {
        if (e instanceof SRVUTestSocleSOAtesterBFFault) {
            LOGGER.debug("Fallback method: Erreur de type Business lors de l'appel à srvutestsoclesoa", null);
        } else {
            LOGGER.debug("Fallback method: Erreur de type Technical lors de l'appel à srvutestsoclesoa", null);
        }
        return new ResponseDTO();
    }

    public ResponseDTO soaRequestFallback(CallNotPermittedException e) {
        LOGGER.debug("Fallback method: Erreur de type circuit ouvert", null);
        return new ResponseDTO();
    }

    protected String getUaID() {
        return "ua_fromscratch";
    }

    protected Version getUaVersion() {
        return new Version("1.0");
    }
}
