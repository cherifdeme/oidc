package fr.ca.cats.p0042.s1235.dto;

import fr.ca.cat.ihm.controller.dto.DataDTO;

public class ContextDTO extends DataDTO {
    private String client_id;
    private String regional_bank_id;
    private String zip_code;

    public String getRegional_bank_id() {
        return regional_bank_id;
    }

    public void setRegional_bank_id(String regional_bank_id) {
        this.regional_bank_id = regional_bank_id;
    }

    public String getZip_code() {
        return zip_code;
    }

    public void setZip_code(String zip_code) {
        this.zip_code = zip_code;
    }

    public String getClient_id() {
        return client_id;
    }

    public void setClient_id(String client_id) {
        this.client_id = client_id;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String toString() {

        StringBuilder builder = new StringBuilder();
        builder.append("user_context={\"client_id\":\"").append(client_id)
                .append("\",\"regional_bank_id\":\"").append(regional_bank_id).append("\",\"zip_code\":\"")
                .append(zip_code).append("\"}&client_id=").append(client_id);
        return builder.toString();
    }
}
