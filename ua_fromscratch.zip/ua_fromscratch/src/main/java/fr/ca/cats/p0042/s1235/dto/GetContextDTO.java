package fr.ca.cats.p0042.s1235.dto;

import fr.ca.cat.ihm.controller.dto.DataDTO;

public class GetContextDTO extends DataDTO {
    private String context_id;

    public String getContext_id() {
        return context_id;
    }

    public void setContext_id(String context_id) {
        this.context_id = context_id;
    }
}

