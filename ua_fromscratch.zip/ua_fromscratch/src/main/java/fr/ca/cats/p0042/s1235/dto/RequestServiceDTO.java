package fr.ca.cats.p0042.s1235.dto;

import fr.ca.cat.ihm.controller.dto.DataDTO;

public class RequestServiceDTO extends DataDTO {
    private String paramService;

    public String getParamService() {
        return paramService;
    }

    public void setParamService(String param) {
        this.paramService = param;
    }
}
