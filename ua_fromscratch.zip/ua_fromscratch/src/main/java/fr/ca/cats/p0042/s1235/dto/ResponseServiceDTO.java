package fr.ca.cats.p0042.s1235.dto;

import fr.ca.cat.ihm.controller.dto.DataDTO;

public class ResponseServiceDTO extends DataDTO {

    private String serviceReturn;

    public String getServiceReturn() {
        return serviceReturn;
    }

    public void setServiceReturn(String serviceReturn) {
        this.serviceReturn = serviceReturn;
    }

}
