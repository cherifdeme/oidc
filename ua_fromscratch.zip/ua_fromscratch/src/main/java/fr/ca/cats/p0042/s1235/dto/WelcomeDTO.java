package fr.ca.cats.p0042.s1235.dto;

import fr.ca.cat.ihm.controller.dto.DataDTO;

public class WelcomeDTO extends DataDTO {

    private String welcomeMessage;

    public String getWelcomeMessage() {
        return welcomeMessage;
    }

    public void setWelcomeMessage(String welcomeMessage) {
        this.welcomeMessage = welcomeMessage;
    }


}
