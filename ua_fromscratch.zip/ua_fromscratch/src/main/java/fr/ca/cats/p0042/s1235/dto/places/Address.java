package fr.ca.cats.p0042.s1235.dto.places;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Objet d�finissant une adresse d'une agence
 *
 * @author ET02720
 */
public class Address extends Entity {

    /**
     * Adresse de l'agence
     *
     * @see Address#getAddress()
     * @see Address#setAddress(String)
     */
    private String address;


    /**
     * Code postal profressionel de l'agence
     *
     * @see Address#getBusinessZipCode()
     * @see Address#setBusinessZipCode(String)
     */
    private String businessZipCode;

    /**
     * District de l'agence
     *
     * @see Address#getDistrict()
     * @see Address#setDistrict(String)
     */
    private String district;

    /**
     * Retourne l'adresse
     *
     * @return Une adresse
     */
    @JsonProperty(value = "address")
    public String getAddress() {
        return address;
    }

    /**
     * Met � jour l'adress
     *
     * @param address Nouvelle adresse
     */
    @JsonProperty(value = "address")
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * Retourne le code postal professionel
     *
     * @return Le code postal professionel
     */
    @JsonProperty(value = "business_zip_code")
    public String getBusinessZipCode() {
        return businessZipCode;
    }

    /**
     * Met � jour le code postal professionnel
     *
     * @param businessZipCode Le nouveau code postal profressionnel
     */
    @JsonProperty(value = "business_zip_code")
    public void setBusinessZipCode(String businessZipCode) {
        this.businessZipCode = businessZipCode;
    }

    /**
     * Retourne le district
     *
     * @return Le district
     */
    @JsonProperty(value = "district")
    public String getDistrict() {
        return this.district;
    }

    /**
     * Met � jour le district
     *
     * @param district Le nouveau district
     */
    @JsonProperty(value = "district")
    public void setDistrict(String district) {
        this.district = district;
    }
}
