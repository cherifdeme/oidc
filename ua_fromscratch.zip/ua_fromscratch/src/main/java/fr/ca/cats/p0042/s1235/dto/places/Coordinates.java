package fr.ca.cats.p0042.s1235.dto.places;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Object d�finissant des coordon�es
 *
 * @author ET02720
 */
public class Coordinates {

    /**
     * Latitude
     *
     * @see Coordinates#getLatitude()
     * @see Coordinates#setLatitude(String)
     */
    private String latitude;

    /**
     * Longitude
     *
     * @see Coordinates#getLongitude()
     * @see Coordinates#setLongitude(String)
     */
    private String longitude;


    /**
     * Retourne la latitude de la coordon�e
     *
     * @return La latitude
     */
    @JsonProperty(value = "latitude")
    public String getLatitude() {
        return latitude;
    }

    /**
     * Met � jour la latitude de la coordon�e
     *
     * @param latitude La nouvelle latitude
     */
    @JsonProperty(value = "latitude")
    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    /**
     * Retourne la longitude de la coordon�e
     *
     * @return La longitude
     */
    @JsonProperty(value = "longitude")
    public String getLongitude() {
        return longitude;
    }

    /**
     * Met � jour la longitude de la coordon�e
     *
     * @param longitude La nouvelle longitude
     */
    @JsonProperty(value = "longitude")
    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }
}
