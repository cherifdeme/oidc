package fr.ca.cats.p0042.s1235.dto.places;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Objet d�finissant un planning des heures d'ouverture de l'agence pour un jour
 *
 * @author ET02720
 */
public class WeekSchedule {

    /**
     * Jour de la semaine
     *
     * @see WeekSchedule#getDayOfWeek()
     * @see WeekSchedule#setDayOfWeek(String)
     */
    private String dayOfWeek;

    /**
     * Heure d'ouverture de la journ�e
     *
     * @see WeekSchedule#getOpeningHours()
     * @see WeekSchedule#setOpeningHours(OpeningHours[])
     * @see {@link OpeningHours}
     */
    private OpeningHours[] openingHours;

    /**
     * Retourne le jour de la semaine
     *
     * @return Le jour de la semaine
     */
    @JsonProperty(value = "day_of_week")
    public String getDayOfWeek() {
        return dayOfWeek;
    }

    /**
     * Met � jour le jour de la semaine
     *
     * @param dayOfWeek Le nouveau jour de la semaine
     */
    @JsonProperty(value = "day_of_week")
    public void setDayOfWeek(String dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }

    /**
     * Retourn les heures d'ouverture de la journ�e
     *
     * @return Les nouvelles heures d'ouverture de la journ�e
     * @see {@link OpeningHours}
     */
    @JsonProperty(value = "opening_hours")
    public OpeningHours[] getOpeningHours() {
        return openingHours;
    }

    /**
     * Met � jour les heures d'ouverture de la journ�e
     *
     * @param openingHours Les nouvelles heures d'ouverture de la journ�e
     * @see {@link OpeningHours}
     */
    @JsonProperty(value = "opening_hours")
    public void setOpeningHours(OpeningHours[] openingHours) {
        this.openingHours = openingHours;
    }
}
