package fr.ca.cats.p0042.s1235.exceptions;

public class ApiException extends Exception {

    /**
     * Exception pour les erreurs de types appel d'API
     */
    private static final long serialVersionUID = 4618795739247215845L;

    private final int statusCode;

    /**
     * Déclaration d'une ApiException
     *
     * @param code    Code HTTP de l'erreur
     * @param message Message de l'exception
     */
    public ApiException(int code, String message) {
        super(message);
        this.statusCode = code;
    }

    /**
     * Récupération du code HTTP de l'erreur
     *
     * @return Code HTTP
     */
    public int getStatusCode() {
        return statusCode;
    }

}
