package fr.ca.cats.p0042.s1235.feign.client;


import feign.Headers;
import feign.Param;
import feign.RequestLine;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cats.p0042.s1235.dto.places.CR;
import fr.ca.cats.p0042.s1235.exceptions.ApiException;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.cloud.openfeign.FeignClient;

/**
 * Service Feign Client pour appeler les ressources de l'API Places
 */
@FeignClient(value = "places", url = "${api.place.url}")

@Headers({"Authorization: {accessToken}", "correlationId: {correlationId}"})
public interface PlacesServiceFeign {

    /**
     * Déclaration du logger de la classe
     */
    public static final Logger LOGGER = LogFactory.getLog();

    /**
     * Ressource pour la récupération de la liste des CR
     *
     * @return {@link CR}
     */
    @RequestLine("GET /regional_banks")
    @CircuitBreaker(name = "placesGetCRList", fallbackMethod = "getCRListRequestFallback")
    CR[] getCRListRequest(@Param("accessToken") String accessToken, @Param("correlationId") String correlationId) throws ApiException;

    /**
     * CallBack pour la gestion du CircuitBreaker placesGetCRList
     *
     * @param e Exception levée par l'API
     * @return Liste de CR par défaut
     */
    default CR[] getCRListRequestFallback(Exception e) {

        if (e instanceof ApiException) {
            LOGGER.info("Fallback method: Erreur lors de l'appel à l'api Places: getCRListRequest", null);
        } else if (e instanceof CallNotPermittedException) {
            LOGGER.info("Fallback method: Erreur lors de l'appel à l'api Places: getCRListRequest - Circuitbreaker OUVERT", null);
        }

        return new CR[]{};
    }
}
