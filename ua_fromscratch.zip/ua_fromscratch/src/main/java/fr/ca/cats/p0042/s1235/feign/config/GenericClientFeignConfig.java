package fr.ca.cats.p0042.s1235.feign.config;

import feign.Contract;
import fr.ca.cats.p0042.s1235.feign.status.ClientFeignStatusDecoder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration générale des clients Feign
 */
@Configuration
public class GenericClientFeignConfig {

    /**
     * Déclation de la gestion des erreurs
     *
     * @return {@link ClientFeignStatusDecoder}
     */
    @Bean
    public ClientFeignStatusDecoder clientFeignErrorDecoder() {
        return new ClientFeignStatusDecoder();
    }

    /**
     * Declaration du contrat d'interface utilisé par Feign
     *
     * @return {@link Contract}
     */
    @Bean
    public Contract feignContract() {
        return new Contract.Default();
    }

}
