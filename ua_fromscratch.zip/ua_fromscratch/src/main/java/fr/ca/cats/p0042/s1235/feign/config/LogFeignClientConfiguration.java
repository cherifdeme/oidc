package fr.ca.cats.p0042.s1235.feign.config;

import feign.Logger;
import fr.ca.cat.ihm.logger.LogFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration de la log des clients Feign
 */
@Configuration
public class LogFeignClientConfiguration {

    public static final fr.ca.cat.ihm.logger.Logger LOGGER = LogFactory.getLog();

    /**
     * Variable du niveau de log Feign
     */
    @Value("${api.feign.log}")
    protected Logger.Level level;

    /**
     * Déclaration du niveau de log Feign
     *
     * @return {@link Logger.Level}
     */
    @Bean
    Logger.Level feignLoggerLevel() {
        // TODO
        // test à enlever avant diffusion
        LOGGER.debug("feign logger Level : " + level, null);

        return level;
    }

}
