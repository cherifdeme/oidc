package fr.ca.cats.p0042.s1235.feign.status;

import feign.FeignException;
import feign.Response;
import feign.codec.Decoder;
import feign.codec.ErrorDecoder;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cats.p0042.s1235.exceptions.ApiException;
import fr.ca.cats.p0042.s1235.tools.AppUtils;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.ObjectFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.http.HttpMessageConverters;
import org.springframework.cloud.openfeign.support.HttpMessageConverterCustomizer;
import org.springframework.cloud.openfeign.support.SpringDecoder;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.io.Reader;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;

/**
 * Classe pour la gestion globale des erreurs des clients Feign
 */
public class ClientFeignStatusDecoder implements ErrorDecoder, Decoder {

    public static final Logger LOGGER = LogFactory.getLog();
    @Autowired
    ObjectFactory<HttpMessageConverters> objectFactory;
    @Autowired
    ObjectProvider<HttpMessageConverterCustomizer> customizers;

    /**
     * Gestion des erreurs pour les client Feign
     */
    @Override
    public Exception decode(String invoqueur, Response response) {
        // Lecture du message d'erreur du body de la réponse
        String errorMessage = getResponseErrorMessage(response);
        final UriComponents uri = UriComponentsBuilder.fromUriString(response.request().url()).build();
        AppUtils.doPerf(response.status(), "FEIGN " + response.request().httpMethod().name(), uri, null);
        return new ApiException(response.status(), errorMessage);
    }

    /**
     * Lecture du body de la reponse
     *
     * @param response La réponse à lire
     * @return le contenu du body de la réponse
     */
    private String getResponseErrorMessage(Response response) {
        String erroMessage = null;
        Reader reader = null;
        try {
            reader = response.body().asReader(StandardCharsets.UTF_8);
            erroMessage = IOUtils.toString(reader);
        } catch (IOException e) {
            LOGGER.error("Erreur lors de lecture du body de la réponse, uri : " + response.request().url(), null);
            erroMessage = "Server error";
        } finally {
            try {
                if (reader != null) {
                    reader.close();
                }
            } catch (IOException e) {
                LOGGER.error("Erreur lors de lecture du body de la réponse, uri : " + response.request().url(), null);
                erroMessage = "Server error";
            }
        }

        return erroMessage;
    }

    /**
     * on surcharge la methode decode de feign pour afficher les logs perf.
     * on arrive là quand le status est à 200
     */
    @Override
    public Object decode(Response response, Type type) throws FeignException, IOException {
        final UriComponents uri = UriComponentsBuilder.fromHttpUrl(response.request().url()).build();
        AppUtils.doPerf(response.status(), "FEIGN " + response.request().httpMethod().name(), uri, null);
        return new SpringDecoder(objectFactory, customizers).decode(response, type);
    }
}
