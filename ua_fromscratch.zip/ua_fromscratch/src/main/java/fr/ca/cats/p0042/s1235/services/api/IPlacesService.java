package fr.ca.cats.p0042.s1235.services.api;

import fr.ca.cats.p0042.s1235.dto.places.CR;
import fr.ca.cats.p0042.s1235.exceptions.ApiException;


public sealed interface IPlacesService permits PlacesServiceImpl {

    /**
     * Retourne la liste des CR
     *
     * @return La liste des CR
     * @throws Exception
     * @throws ApiException Erreur lors de l'appel HTTP
     * @see {@link CR}
     */

    public CR[] getCRList(String accessToken) throws ApiException;


}
