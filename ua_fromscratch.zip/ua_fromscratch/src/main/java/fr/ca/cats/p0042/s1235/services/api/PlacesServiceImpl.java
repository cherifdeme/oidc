package fr.ca.cats.p0042.s1235.services.api;

import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cats.p0042.s1235.dto.places.CR;
import fr.ca.cats.p0042.s1235.exceptions.ApiException;
import fr.ca.cats.p0042.s1235.feign.client.PlacesServiceFeign;
import fr.ca.cats.p0042.s1235.tools.AppUtils;
import org.springframework.stereotype.Service;

@Service
public non-sealed class PlacesServiceImpl implements IPlacesService {

    private static final Logger LOGGER = LogFactory.getLog(PlacesServiceImpl.class);
    /**
     * Service Feign pour les appels de l'api
     */
    private PlacesServiceFeign placesServiceFeign;

    /**
     * Constructeur
     *
     * @param placesServiceFeign
     */
    public PlacesServiceImpl(PlacesServiceFeign placesServiceFeign) {
        this.placesServiceFeign = placesServiceFeign;
    }


    @Override
    public CR[] getCRList(String accessToken) throws ApiException {
        LOGGER.debug("Récupération de la list des CR", null);

        String correlationId = AppUtils.getCorrelationId();

        CR[] crs = this.placesServiceFeign.getCRListRequest(accessToken, correlationId);

        LOGGER.debug("Récupération de la list des CR --> OK", null);

        return crs;
    }
}
