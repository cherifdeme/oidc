package fr.ca.cats.p0042.s1235.services.soa;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.utils.Version;
import fr.ca.cat.ihm.ws.WsConf;
import fr.ca.cats.p0042.s1235.srvutestsoclesoa.generated.TesterBFAppelDAOReponse;
import fr.ca.cats.p0042.s1235.srvutestsoclesoa.generated.TesterBFReponse;
import jakarta.xml.bind.JAXBElement;

import java.util.concurrent.CompletableFuture;

public interface ITestSocleSoaService {

    /**
     * appel au service soa avec lib-soa-connector
     *
     * @param context
     * @param roseURI      Rose SOA host
     * @param path         d'appel au service
     * @param paramService paramètres d'appel
     * @return le résultat de l'appel à appelTestSocleSoa
     * @throws Exception
     * @see {@link TesterBFReponse}
     */
    CompletableFuture<JAXBElement<Object>> appelTestSocleSoa(Context context, String roseURI, String path, String paramservice, String serviceName) throws Exception;

    /**
     * appel au service soa avec lib-soa-connector et Callback
     *
     * @param context
     * @param roseURI      Rose SOA host
     * @param path         d'appel au service
     * @param paramservice paramètres d'appel
     * @return le résultat de l'appel à appelTestSocleSoa "custom"
     * @throws Exception
     * @see {@link TesterBFReponse}
     */
    TesterBFReponse appelTestSocleSoaWithCustomCallback(Context context, String roseURI, String path, String paramservice, String serviceName) throws Exception;
}
