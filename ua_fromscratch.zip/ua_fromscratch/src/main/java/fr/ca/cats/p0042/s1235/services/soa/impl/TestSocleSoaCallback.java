package fr.ca.cats.p0042.s1235.services.soa.impl;


import fr.ca.cats.p0042.s0115.lib.connector.soa.dto.HeaderApplicationContext;
import fr.ca.cats.p0042.s0115.lib.connector.soa.impl.SoaConnectorMessageCallback;
import fr.ca.cats.p0042.s0115.lib.connector.soa.utils.CatsHolder;
import fr.ca.cats.p0042.s1235.srvutestsoclesoa.generated.HeaderTechType;
import fr.ca.cats.p0042.s1235.srvutestsoclesoa.generated.ObjectFactory;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import org.springframework.stereotype.Component;
import org.springframework.ws.WebServiceMessage;
import org.springframework.ws.soap.SoapMessage;

@Component
public class TestSocleSoaCallback extends SoaConnectorMessageCallback {

    private static final String HEADER_TECH_VERSION = "1.0";
    private static final String CONSUMER = "ua_springboot";
    private static final String CONSUMER_VERSION = "1.0";

    private static final String TODO = "TODO";

    private static final ObjectFactory TEST_SOCLE_SOA_OBJECT_FACTORY = new ObjectFactory();

    @Override
    public void addHeaderTech(final WebServiceMessage message) {
        final var soapHeader = ((SoapMessage) message).getSoapHeader();

        // Builds JAXBElement HeaderTechType header
        final var headerTechTypes = TEST_SOCLE_SOA_OBJECT_FACTORY.createHeaderTech(buildHeaderTechType(CONSUMER, CatsHolder.getIdCr()));
        JAXBContext context;
        try {
            context = JAXBContext.newInstance(HeaderTechType.class);
            final var marshaller = context.createMarshaller();
            marshaller.marshal(headerTechTypes, soapHeader.getResult());
        } catch (JAXBException ex) {

        }
    }

    private HeaderTechType buildHeaderTechType(final String codeApplication, final String idCr) {
        final var headerTechType = TEST_SOCLE_SOA_OBJECT_FACTORY.createHeaderTechType();
        headerTechType.setNumeroVersion(HEADER_TECH_VERSION);

        final var consumer = TEST_SOCLE_SOA_OBJECT_FACTORY.createConsumer();
        consumer.setVersion(CONSUMER_VERSION);
        consumer.setValue(codeApplication);
        headerTechType.setConsumer(consumer);

        final var dataContext = TEST_SOCLE_SOA_OBJECT_FACTORY.createDataContext();
        dataContext.setDataVersion(CONSUMER_VERSION);
        dataContext.setIdCR(idCr);
        headerTechType.setDataContext(dataContext);

        final var transactionContext = TEST_SOCLE_SOA_OBJECT_FACTORY.createTransactionContext();
        transactionContext.setIsTransactional(false);
        headerTechType.setTransactionContext(transactionContext);

        return headerTechType;
    }

    @Override
    protected HeaderApplicationContext buildHeaderApplicationContext() {
        final var headerApplicationContext = new HeaderApplicationContext(TODO, TODO, TODO,
                TODO, TODO, TODO, TODO, TODO, TODO, TODO, TODO);

        return headerApplicationContext;
    }

    @Override
    protected void doCustomActionWithMessage(final WebServiceMessage message) {
        // A surcharger pour traiter un besoin custom
    }
}
