package fr.ca.cats.p0042.s1235.services.soa.impl;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cats.p0042.s0115.lib.connector.soa.SoaConnector;
import fr.ca.cats.p0042.s1235.services.soa.ITestSocleSoaService;
import fr.ca.cats.p0042.s1235.srvutestsoclesoa.generated.*;
import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.timelimiter.annotation.TimeLimiter;
import jakarta.xml.bind.JAXBElement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.oxm.jaxb.Jaxb2Marshaller;
import org.springframework.stereotype.Service;

import javax.xml.namespace.QName;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.concurrent.TimeoutException;

@Service
public class TestSocleSoaServiceImpl implements ITestSocleSoaService {

    public static final Logger LOGGER = LogFactory.getLog();
    private static final ObjectFactory TEST_SOCLE_SOA_OBJECT_FACTORY = new ObjectFactory();
    private SoaConnector testSocleSoaConnector;
    private TestSocleSoaCallback customCallback;
    private Jaxb2Marshaller srvutestsoclesoaMarshaller;
    private TesterBFReponse tbfr = new TesterBFReponse();
    private Sortie sortie = new Sortie();
    private Executor executor;

    @Autowired
    public TestSocleSoaServiceImpl(final SoaConnector testSocleSoaConnector, final TestSocleSoaCallback customCallback,
                                   @Qualifier("srvutestsoclesoaMarshaller") final Jaxb2Marshaller srvutestsoclesoaMarshaller, final Executor executor) {
        this.testSocleSoaConnector = testSocleSoaConnector;
        this.customCallback = customCallback;
        this.srvutestsoclesoaMarshaller = srvutestsoclesoaMarshaller;
        this.executor = executor;
    }

    /**
     * Circuitbreaker sur implémentation de l'appel
     * => permet d'opérer sur opération de service
     */
    @Override
    @CircuitBreaker(name = "appelTestSocleSoa", fallbackMethod = "soaRequestFallback")
    @TimeLimiter(name = "timeLimiterSocleSoa", fallbackMethod = "soaRequestTimeoutFallback")
    public CompletableFuture<JAXBElement<Object>> appelTestSocleSoa(final Context context, String roseURI, String path, String param, String serviceName) {
        final var request = TEST_SOCLE_SOA_OBJECT_FACTORY.createSRVUTestSocleSOAtesterBFRequest1(buildTesterBFRequete(param));
        return CompletableFuture.supplyAsync(() -> testSocleSoaConnector.invoke(request, context, roseURI, path, srvutestsoclesoaMarshaller, serviceName), executor);
    }

    private CompletableFuture<JAXBElement<Object>> soaRequestTimeoutFallback(TimeoutException e) {
        if (e instanceof TimeoutException) {
            LOGGER.error("TimeLimiter 'Erreur de type Timeout lors de l'appel à appelTestSocleSoa ", null);
            sortie.setReponse("TimeLimiter 'Erreur de type Timeout lors de l'appel à appelTestSocleSoa");
            tbfr.setSortie(sortie);
        }
        final QName response = new QName("http://fr.ca.cat/srvutestsoclesoa/1/SRVU_TestSocleSOA/", "SRVU_TestSocleSOAtesterBFResponse1");
        final JAXBElement<Object> objectJAXBElement = new JAXBElement<>(response, Object.class, null, tbfr);

        return CompletableFuture.completedFuture(objectJAXBElement);
    }

    @Override
    public TesterBFReponse appelTestSocleSoaWithCustomCallback(final Context context, String roseURI, String path, String param, String serviceName) {
        final var request = TEST_SOCLE_SOA_OBJECT_FACTORY.createSRVUTestSocleSOAtesterBFRequest1(buildTesterBFRequete(param));
        JAXBElement<TesterBFReponse> jaxbRecupererDonneesTableReponse;
        jaxbRecupererDonneesTableReponse = testSocleSoaConnector.invoke(request, customCallback, context, roseURI, path, srvutestsoclesoaMarshaller, serviceName);
        return Optional.ofNullable(jaxbRecupererDonneesTableReponse).map(JAXBElement::getValue).orElse(null);
    }

    /**
     * Construction requete
     *
     * @return requete
     */
    private TesterBFRequete buildTesterBFRequete(String param) {
        final var request = TEST_SOCLE_SOA_OBJECT_FACTORY.createTesterBFRequete();
        final var entree = TEST_SOCLE_SOA_OBJECT_FACTORY.createEntree();
        entree.setParametre(param);
        request.setEntree(entree);
        return request;
    }


    public TesterBFReponse soaRequestFallback(Exception e) {

        if (e instanceof SRVUTestSocleSOAtesterBFFault) {
            LOGGER.debug("Fallback method: Erreur de type Business lors de l'appel à srvutestsoclesoa", null);
            sortie.setReponse("Erreur de type Business lors de l'appel à srvutestsoclesoa");
            tbfr.setSortie(sortie);
        } else {
            LOGGER.debug("Fallback method: Erreur de type Technical lors de l'appel à srvutestsoclesoa", null);
            sortie.setReponse("Erreur de type Technical lors de l'appel à srvutestsoclesoa");
            tbfr.setSortie(sortie);
        }
        return tbfr;
    }

    public TesterBFReponse soaRequestFallback(CallNotPermittedException e) {
        LOGGER.debug("Fallback method: Erreur de type circuit ouvert", null);
        sortie.setReponse("Erreur de type circuit ouvert");
        tbfr.setSortie(sortie);
        return tbfr;
    }

}
