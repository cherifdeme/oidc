package fr.ca.cats.p0042.s1235.tools;

import fr.ca.cat.ihm.controller.bean.Context;
import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.ihm.logger.TypeLogger;
import fr.ca.cat.most.util.log.MostCode;
import jakarta.servlet.http.HttpServletRequest;
import org.json.JSONObject;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.util.UriComponents;

import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.*;

/**
 * Classe contenant des methodes static utilitaire
 *
 * @author ET02720
 */
public class AppUtils {
    public static final String ID_CORRELATION_HEADER = "idCorrelation";
    private static final Logger LOGGER = LogFactory.getLog(AppUtils.class, TypeLogger.LOGGER_SOCLE);
    private static final MostCode MC_API_CALL = new MostCode("IHME-API_CALL");

    private static final MostCode MC_API_CALL_STATUS = new MostCode("IHME-API_CALL_STATUS");

    /**
     * Constructeur privé
     */
    private AppUtils() {
    }

    /**
     * Récupération de la requête en cours
     *
     * @return {@link Optional<HttpServletRequest>}
     */
    public static Optional<HttpServletRequest> getCurrentHttpRequest() {
        return Optional.ofNullable(RequestContextHolder.getRequestAttributes())
                .filter(requestAttributes -> ServletRequestAttributes.class.isAssignableFrom(requestAttributes.getClass()))
                .map(ServletRequestAttributes.class::cast)
                .map(ServletRequestAttributes::getRequest);
    }

    /**
     * Récupération d'un correlationId soit depuis la requête soit on le créé
     *
     * @return
     */
    public static String getCorrelationId() {
        String correlationId = UUID.randomUUID().toString();

        // Récupération header correlationId si on vient d'une requêtre front
        Optional<HttpServletRequest> frontRequest = AppUtils.getCurrentHttpRequest();
        if (Objects.nonNull(frontRequest) && frontRequest.isPresent() && Objects.nonNull(frontRequest.get().getHeader(ID_CORRELATION_HEADER)) && !frontRequest.get().getHeader(ID_CORRELATION_HEADER).isEmpty()) {
            correlationId = frontRequest.get().getHeader(ID_CORRELATION_HEADER);
        }

        return correlationId;
    }


    /**
     * Permet de retourner le timestamp en millisecondes depuis maintenant plus
     * un temps de délai
     *
     * @param delay Le délai à rajouter à maintenant
     * @return Le timestamp en millisecondes
     */
    public static long delayFromNowToMilliseconds(int delay) {
        return LocalDateTime.now().plusSeconds(delay).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
    }

    /**
     * Permet de retourner une LocalDateTime à partir d'un timestamp en
     * millisecondes
     *
     * @param dateMilliseconds Le timestam en millisecondes
     * @return Un objet LocalDateTime
     * @see {@link LocalDateTime}
     */
    public static LocalDateTime dateFromMilliseconds(long dateMilliseconds) {
        return LocalDateTime.ofInstant(Instant.ofEpochMilli(dateMilliseconds), ZoneId.systemDefault());
    }


    public static String obfuscateUUIDString(String uuidString) {
        return uuidString.replaceAll(".{20}$", "XXXXX");
    }

    public static void doPerf(final int status, final String methodName, final UriComponents uri, Context context) {
        Map<String, String> perfMsg = new HashMap<>(2);
        perfMsg.put("method", methodName);
        perfMsg.put("host", uri.getHost());
        perfMsg.put("path", uri.getPath());
        final var deb = System.currentTimeMillis();
        LOGGER.debug(MC_API_CALL_STATUS, "Response : {status=" + status + "}", context);
        LOGGER.perf(MC_API_CALL, (int) (System.currentTimeMillis() - deb), new JSONObject(perfMsg), context);
    }
}
