package fr.ca.cats.p0042.s1235.tools;

/**
 * Classe permettant de centraliser les constantes du projet
 *
 * @author ET02720
 */
public class Constants {

    // Redis Cache
    public static final String REFRESH_TOKEN_CACHE = "REFRESH_TOKEN_CACHE";
    public static final String TOKEN_CACHE = "TOKEN_CACHE";

    private Constants() {
        throw new IllegalStateException("Utility class");
    }
}
