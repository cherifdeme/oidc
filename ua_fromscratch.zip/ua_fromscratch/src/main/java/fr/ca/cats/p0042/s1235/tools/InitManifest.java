package fr.ca.cats.p0042.s1235.tools;

import fr.ca.cat.ihm.logger.LogFactory;
import fr.ca.cat.ihm.logger.Logger;
import fr.ca.cat.most.util.log.MostCode;
import jakarta.annotation.PostConstruct;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
public class InitManifest {
    private static final MostCode IHME_SOCLE_INIT = new MostCode("IHME-SOCLE_INIT");
    private static final Logger LOGGER = LogFactory.getLog();
    @Value("#{${lib.dependencies}}")
    private Map<String, String> dependencies;

    @PostConstruct
    public void init() {
        Map<String, String> result = new HashMap<>();
        for (var entry : dependencies.entrySet()) {
            if (!entry.getValue().contains("@")) {
                result.put(entry.getKey(), entry.getValue());
            }
        }
        final var deb = System.currentTimeMillis();

        final JSONObject jsonObject = new JSONObject();
        jsonObject.put("librairies-versions", new JSONObject(result));
        LOGGER.perf(IHME_SOCLE_INIT, (int) (System.currentTimeMillis() - deb), jsonObject, null);
    }
}
