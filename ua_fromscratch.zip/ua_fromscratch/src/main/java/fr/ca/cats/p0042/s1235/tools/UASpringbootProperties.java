package fr.ca.cats.p0042.s1235.tools;

import fr.ca.cat.ihm.helper.VersionHelper;
import fr.ca.cat.ihm.utils.Version;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

/**
 * Classe utilitaire fournissant les informations de base de l'UA ua_springboot.
 */
@Component
public class UASpringbootProperties {
    private static String ua_springboot_version_st;
    private static String ua_springboot_groupe_support_st;
    private static String ua_springboot_more_infos_st;

    public UASpringbootProperties(
    @Value("${ua_fromscratch.version}")
    final String uaVersion,
    @Value("${ua_fromscratch.groupe_support}")
    final String uaGroupeSupport,
    @Value("${ua_fromscratch.more_infos}")
    final String uaMoreInfos)

    {
        ua_springboot_version_st = uaVersion;
        ua_springboot_groupe_support_st = uaGroupeSupport;
        ua_springboot_more_infos_st = uaMoreInfos;
    }

    /**
     * Renvoi la version complete (avec SNAPSHOT...) de l'UA.
     */
    public static String getFullVersion() {
        return UASpringbootProperties.ua_springboot_version_st;
    }

    /**
     * Renvoi la version courte de l'UA (x.y) .
     */
    public static Version getVersion() {
        return VersionHelper.getVersion(getFullVersion());
    }

    public static String getGroupeSupport() {
        return UASpringbootProperties.ua_springboot_groupe_support_st;
    }

    public static String getMoreInfos() {
        return UASpringbootProperties.ua_springboot_more_infos_st;
    }

    /**
     * Renvoi la version de l'UA sans SNAPSHOT.
     */
    public Version getLongVersion() {
        return VersionHelper.getLongVersion(getFullVersion());
    }
}