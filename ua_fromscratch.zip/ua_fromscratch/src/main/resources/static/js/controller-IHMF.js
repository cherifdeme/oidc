Package.create("IHMF");

IHMF.init = function () {
};

/**
 * Déclenchement du formulaire qui envoie à la fonction producteur les paramètres de lancement.
 * On finit de mettre en place les interactions ihmf/UA
 * Possibilité de définir la taille de la frame par des paramètres d'intégration. Sinon utiliser le feuilles de style.
 */
IHMF.pageReady = function () {

    var dims = {
        'height': appUnit.getIntegrationParams()['productorFrame.height'],
        'width': appUnit.getIntegrationParams()['productorFrame.width']
    };

    for (x in dims) {
        if (dims[x]) {
            $('#productorFrame').attr(x, dims[x]);
        }
    }

    $('#requestVersion').val(ihmf.requestVersion);
    $('#ihmLaunchParams').val(ihmf.ihmLaunchParams);
    $('#launchIHMFform')[0].action = ihmf.ihmfLaunchUrl;

    //la fonction est considérée comme lancée, juste avant le submit ne pas être en retard !!
    ihmf.launchSubmitted();
    $('#launchIHMFform').submit();

};