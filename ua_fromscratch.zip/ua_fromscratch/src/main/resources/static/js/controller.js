Package.create("MAIN");

MAIN.getRequestDTO = function (d) {
    var stateLabel = appUnit.getNavigation().getCurrentState();
    if (stateLabel == null) {
        stateLabel = "INIT";
    }
    var stateDTO =
        {
            label: stateLabel
        };
    var requestDTO =
        {
            state: stateDTO,
            data: d
        };
    return requestDTO;
};

MAIN.init = function () {
    var requestDTO = MAIN.getRequestDTO();

	var obj = {state:{enable: false}};
	appUnit.getModel().setData("ctxState", obj);
	
    appUnit.callService("rest/ua_fromscratch/init", requestDTO,
        function (data) {
            appUnit.getModel().setData("welcome", data);
        },
        function (message) { //erreurs techniques au niveau du controleur d'UA ou du call service

            var okHandler = function (popup) {
                popup.close();
                appUnit.closeMe();
            };

            if ((typeof (message) == 'object') && message.code) {
                //message "TECHNICAL" constitué par le controleur UA (encapsulation par le socle IHM des TechnicalException )
                caAlert.alert(message.code, message.label, okHandler);
            } else {
                // jqXHR.responseText (Cf restServiceCaller)
                caAlert.alert("Erreur technique", message, okHandler);
            }
        }
        //ici gérer l'erreur business si nécessaire

    ); //callService
};
MAIN.places_getCRList = function () {

    var uri = "rest/places/regional_banks";
    MAIN.clean();
    
    appUnit.callService(uri, "", function (data) {
            appUnit.getModel().setData("service", data);
        },
        function (data) { //Réponse TechnicalException

            MAIN.technicalError(data);
        }
        ,
        function (data) { //Réponse BusinessException

            MAIN.displayErreurAlert(data);
        }
    );
};
MAIN.srvutestsoclesoa_TesterBF = function () {

    var params = {paramService: "Paramètres fournis en entrée du Service"};
    MAIN.clean();

    appUnit.callService("rest/soa/srvutestsoclesoa/testerbf", params, function (data) {
            appUnit.getModel().setData("service", data);
        },
        function (data) { //Réponse TechnicalException

            MAIN.technicalError(data);
        },
        function (data) { //Réponse BusinessException

            MAIN.displayErreurAlert(data);
        });
};
MAIN.displayErreurAlert = function (exception) {

    var title = "Erreur Business";
    var msg = "<p>Message d'erreur métier</p><p> Veuillez contacter le service client</p>";
    var okHandler = function (popup) {
        console.log("Vous avez cliqué sur OK !");
        popup.close();
    };

    caAlert.alert(title, msg, okHandler);

};

MAIN.technicalError = function (exception) {
    var techErrorInfos = {
        code_erreur: exception.code,
        msg_erreur_tech: "message d'erreur technique à afficher",
        id_correlation: exception.correlationId,
        gr_support: 'Votre groupe support',
        id_ua: "ua_springboot",
        nom_composant: "Démonstrateur UA Springboot"
    };

    var callback = function () {
        console.log("La popup d'erreur technique s'est affiché !");
    };

    caAlert.technicalError(techErrorInfos, callback);
};

MAIN.clean = function () {
	appUnit.getModel().setData("service", "");
	appUnit.getModel().setData("ctx9", "");
};

MAIN.beforeClosing = function (responder) {

    //TODO si l'application est fermable => responder.result, sinon => responder.fault
    responder.result(true);

    //TODO Remove des listeners
    //TODO Supprimer les références aux extensions métier
    //TODO Fermer les UA filles s'il y en a

};

