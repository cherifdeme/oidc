package fr.ca.cats.p0042.s1235.cache;

import fr.ca.cats.p0042.s1235.config.RedisCacheConfig;
import fr.ca.cats.p0042.s1235.utils.TestsConstants;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.test.util.ReflectionTestUtils;

import java.time.Duration;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

@DisplayName("RedisCacheConfig")
@Tag("Service")
@Tag("Unit")
@ExtendWith(MockitoExtension.class)
class RedisCacheConfigTest {

    @InjectMocks
    private RedisCacheConfig redisCacheConfig;


    @Mock
    private RedisConnectionFactory redisConnectionFactory;

    @BeforeEach
    void setUp() throws Exception {
        ReflectionTestUtils.setField(redisCacheConfig, "redisCachePrefix", "ihml:test");
        ReflectionTestUtils.setField(redisCacheConfig, "refreshTokenCacheTtl", Duration.ofMinutes(120));
        ReflectionTestUtils.setField(redisCacheConfig, "tokenCacheTtl", Duration.ofSeconds(540));
    }


    @Test
    @DisplayName("Cas nominal")
    void testCacheManagerInit() {
        // ACTION
        CacheManager cacheManager = redisCacheConfig.cacheManager(redisConnectionFactory);

        // TEST
        assertThat(cacheManager.getCache(TestsConstants.REFRESH_TOKEN_CACHE), notNullValue(Cache.class));
        assertThat(cacheManager.getCache(TestsConstants.REFRESH_TOKEN_CACHE).getName(), is(TestsConstants.REFRESH_TOKEN_CACHE));
    }
}
