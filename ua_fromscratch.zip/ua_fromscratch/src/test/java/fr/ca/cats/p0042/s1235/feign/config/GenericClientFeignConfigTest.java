package fr.ca.cats.p0042.s1235.feign.config;

import feign.Contract;
import fr.ca.cats.p0042.s1235.feign.status.ClientFeignStatusDecoder;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;


@DisplayName("GenericClientFeignConfig")
@Tag("Feign")
@Tag("Unit")
@ExtendWith(MockitoExtension.class)
class GenericClientFeignConfigTest {

    @InjectMocks
    private GenericClientFeignConfig genericClientFeignConfig;

    @BeforeEach
    void setUp() throws Exception {
    }

    @Test
    @DisplayName("ClientFeignErrorDecoder")
    void testClientFeignErrorDecoder() {
        // ACTION
        ClientFeignStatusDecoder errorDecoder = genericClientFeignConfig.clientFeignErrorDecoder();

        // TEST
        assertThat(errorDecoder, notNullValue());
    }

    @Test
    @DisplayName("FeignContract")
    void testFeignContract() {
        // ACTION
        Contract contract = genericClientFeignConfig.feignContract();

        // TEST
        assertThat(contract instanceof Contract.Default, is(true));
    }

}
