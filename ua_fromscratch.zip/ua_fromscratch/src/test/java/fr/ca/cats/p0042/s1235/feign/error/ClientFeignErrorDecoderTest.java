package fr.ca.cats.p0042.s1235.feign.error;

import feign.Request;
import feign.Request.HttpMethod;
import feign.RequestTemplate;
import feign.Response;
import fr.ca.cats.p0042.s1235.exceptions.ApiException;
import fr.ca.cats.p0042.s1235.feign.status.ClientFeignStatusDecoder;
import org.apache.commons.io.IOUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.MockedStatic;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.Charset;
import java.util.Collection;
import java.util.HashMap;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.is;
import static org.mockito.ArgumentMatchers.any;

@DisplayName("ClientFeignErrorDecoder")
@Tag("Feign")
@Tag("Unit")
@ExtendWith(MockitoExtension.class)
class ClientFeignErrorDecoderTest {

    ClientFeignStatusDecoder clientFeignErrorDecoder;

    @BeforeEach
    void setUp() throws Exception {
        clientFeignErrorDecoder = new ClientFeignStatusDecoder();
    }

    @Test
    @DisplayName("ApiException")
    void testApiException() throws IOException {
        // CONFIG
        Request request = Request.create(HttpMethod.GET, "/api/dummy", new HashMap<String, Collection<String>>(), null, null, new RequestTemplate());
        Response response = Response.builder()
                .request(request)
                .status(500)
                .body("Server erreur", Charset.defaultCharset())
                .reason("Server erreur")
                .build();

        // ACTION
        ApiException ex = (ApiException) clientFeignErrorDecoder.decode("Invoker", response);

        // TEST
        assertThat(ex.getStatusCode(), is(500));
        assertThat(ex.getMessage(), is("Server erreur"));
    }

    @Test
    @DisplayName("BodyReadingException")
    void testBodyReadingException() throws IOException {
        // CONFIG
        Request request = Request.create(HttpMethod.GET, "/api/dummy", new HashMap<String, Collection<String>>(), null, null, new RequestTemplate());
        Response response = Response.builder()
                .request(request)
                .status(500)
                .body("Server erreur", Charset.defaultCharset())
                .reason("Server erreur")
                .build();

        // ACTION
        try (MockedStatic<IOUtils> ioUtilsMock = Mockito.mockStatic(IOUtils.class)) {
            ioUtilsMock.when(() -> IOUtils.toString(any(Reader.class))).thenThrow(new IOException("Error reading response body"));

            ApiException ex = (ApiException) clientFeignErrorDecoder.decode("Invoker", response);

            // TEST
            assertThat(ex.getStatusCode(), is(500));
            assertThat(ex.getMessage(), is("Server error"));
        }

    }
}
