package fr.ca.cats.p0042.s1235.utils;

public class TestsConstants {
    public static final String REFRESH_TOKEN_CACHE = "REFRESH_TOKEN_CACHE";
}
